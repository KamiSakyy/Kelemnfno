"use client";

import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  Bell,
  Brain,
  ChevronDown,
  Code2,
  Download,
  Eraser,
  GitBranch,
  Image as ImageIcon,
  Infinity as InfinityIcon,
  Menu,
  MessageSquare,
  Mic,
  Newspaper,
  Paperclip,
  Pencil,
  Pin,
  Plus,
  Send,
  SlidersHorizontal,
  Sparkles,
  Square,
  Swords,
  Trash2,
  Tv,
  UserSearch,
  X,
} from "lucide-react";
import { AssistantBlock, UserBubble } from "@/components/ChatMessage";
import { MarkdownRenderer } from "@/components/MarkdownRenderer";
import { Battle, InfiniteDialogue } from "@/components/ModelLab";
import { GithubChat } from "@/components/GithubPanel";
import { SourcesDrawer } from "@/components/SourcesDrawer";
import { LumiPanel } from "@/components/LumiPanel";
import { ThemeManager } from "@/components/ThemeManager";
import { getSubs, checkSub, sendNotif, getAutoVoice, speakText } from "@/lib/lumi-store";
import { AIProvider, Block, ChatMessage, ChatSession, FailoverHop, StreamingState, relativeTime } from "@/lib/types";

// ---------------------------------------------------------------------------
// Config
// ---------------------------------------------------------------------------

const STARTERS = [
  { icon: ImageIcon, text: "Скинь арты 2B из NieR:Automata" },
  { icon: Sparkles, text: "Люми, нарисуй арт: девушка-волшебница под звёздным небом" },
  { icon: UserSearch, text: "Кто такая Нана Осаки из аниме Nana?" },
  { icon: Tv, text: "Где смотреть аниме «Фрирен»?" },
  { icon: Brain, text: "Исследуй: какие онгоинги сезона 2026 самые популярные?" },
  { icon: Code2, text: "Спроектируй production-ready REST API на TypeScript" },
  { icon: Newspaper, text: "Что сейчас обсуждают в аниме-сообществе?" },
];

type SpeechRecognitionLike = {
  lang: string;
  interimResults: boolean;
  continuous: boolean;
  onresult: ((event: { results: ArrayLike<ArrayLike<{ transcript: string }> & { isFinal: boolean }> }) => void) | null;
  onend: (() => void) | null;
  onerror: (() => void) | null;
  start: () => void;
  stop: () => void;
};

function getSpeechRecognition(): (new () => SpeechRecognitionLike) | null {
  if (typeof window === "undefined") return null;
  const w = window as unknown as {
    SpeechRecognition?: new () => SpeechRecognitionLike;
    webkitSpeechRecognition?: new () => SpeechRecognitionLike;
  };
  return w.SpeechRecognition || w.webkitSpeechRecognition || null;
}

async function fileToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new window.Image();
    img.onload = () => {
      const max = 1280;
      const scale = Math.min(1, max / Math.max(img.width, img.height));
      const canvas = document.createElement("canvas");
      canvas.width = Math.round(img.width * scale);
      canvas.height = Math.round(img.height * scale);
      const ctx = canvas.getContext("2d");
      if (!ctx) {
        reject(new Error("canvas"));
        return;
      }
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      URL.revokeObjectURL(url);
      resolve(canvas.toDataURL("image/jpeg", 0.86));
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error("image"));
    };
    img.src = url;
  });
}

// ---------------------------------------------------------------------------
// App
// ---------------------------------------------------------------------------

export default function AetherApp() {
  const [providers, setProviders] = useState<AIProvider[]>([]);
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [activeSession, setActiveSession] = useState<ChatSession | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);

  const [prompt, setPrompt] = useState("");
  const [attachment, setAttachment] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [streaming, setStreaming] = useState<StreamingState | null>(null);
  const [initialLoading, setInitialLoading] = useState(true);
  const [isPinging, setIsPinging] = useState(false);
  const [simulateFailover, setSimulateFailover] = useState(false);

  const [newMenuOpen, setNewMenuOpen] = useState(false);
  const [sourcesOpen, setSourcesOpen] = useState(false);
  const [lumiOpen, setLumiOpen] = useState(false);
  const [freshBadge, setFreshBadge] = useState(0);
  const [chatsOpen, setChatsOpen] = useState(false);
  const [reasoningOpen, setReasoningOpen] = useState<Record<number, boolean>>({});
  const [copiedMessage, setCopiedMessage] = useState<number | null>(null);
  const [listening, setListening] = useState(false);
  const [speechSupported, setSpeechSupported] = useState(false);
  const [canShare, setCanShare] = useState(false);
  const [showScrollDown, setShowScrollDown] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const [sessionQuery, setSessionQuery] = useState("");
  const [greeting, setGreeting] = useState("Привет!");

  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const endRef = useRef<HTMLDivElement>(null);
  const stickRef = useRef(true);
  const abortRef = useRef<AbortController | null>(null);
  const recognitionRef = useRef<SpeechRecognitionLike | null>(null);
  const streamingRef = useRef<StreamingState | null>(null);

  useEffect(() => {
    streamingRef.current = streaming;
  }, [streaming]);

  const enabledCount = providers.filter((p) => p.isEnabled).length;

  const visibleSessions = useMemo(() => {
    const q = sessionQuery.trim().toLowerCase();
    if (!q) return sessions;
    return sessions.filter((s) => s.title.toLowerCase().includes(q));
  }, [sessions, sessionQuery]);

  const blocks = useMemo<Block[]>(() => {
    const out: Block[] = [];
    for (const message of messages) {
      if (message.role === "assistant" && message.groupKey) {
        const last = out[out.length - 1];
        if (last && last.kind === "arena" && last.key === message.groupKey) {
          last.messages.push(message);
          continue;
        }
        out.push({ kind: "arena", key: message.groupKey, messages: [message] });
      } else {
        out.push({ kind: "message", message });
      }
    }
    return out;
  }, [messages]);

  const showToast = useCallback((text: string) => {
    setToast(text);
    window.setTimeout(() => setToast(null), 2200);
  }, []);

  // ---------------------------------------------------------------- effects

  useEffect(() => {
    setSpeechSupported(Boolean(getSpeechRecognition()));
    setCanShare(typeof navigator !== "undefined" && typeof navigator.share === "function");
    // Приветствие от Люми по времени суток
    const h = new Date().getHours();
    setGreeting(h < 5 ? "Доброй ночи! 🌙" : h < 12 ? "Доброе утро! ☀️" : h < 18 ? "Добрый день! ✨" : "Добрый вечер! 🌆");
    const load = async () => {
      try {
        const [providersRes, sessionsRes] = await Promise.all([fetch("/api/providers"), fetch("/api/sessions")]);
        if (providersRes.ok) setProviders((await providersRes.json()).providers || []);
        if (sessionsRes.ok) {
          const data = await sessionsRes.json();
          setSessions(data.sessions || []);
          setActiveSession(data.activeSession || null);
          setMessages(data.messages || []);
        }
      } catch (error) {
        console.error("Initial load failed", error);
      } finally {
        setInitialLoading(false);
      }
    };
    load();
  }, []);

  // Scroll to bottom only when a NEW message arrives AND the user is already at
  // the bottom — never yank the view while streaming or when scrolled up.
  useEffect(() => {
    if (stickRef.current) endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [messages.length]);

  // During streaming, keep up ONLY if the user is pinned to the very bottom.
  // Directly set scrollTop (no scrollIntoView) so it never hijacks focus/position.
  useEffect(() => {
    if (isLoading && stickRef.current) {
      const el = scrollRef.current;
      if (el) el.scrollTop = el.scrollHeight;
    }
  }, [streaming?.content, streaming?.reasoning, isLoading]);

  useEffect(() => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = "0px";
    el.style.height = `${Math.min(el.scrollHeight, 148)}px`;
  }, [prompt]);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        setSourcesOpen(false);
        setLumiOpen(false);
        setChatsOpen(false);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  // Тихая фоновая проверка новых серий через ~6 сек после открытия сайта
  // и далее раз в 10 минут. Нашла новую серию → toast + системное уведомление.
  useEffect(() => {
    let stopped = false;
    const run = async () => {
      const subs = getSubs();
      if (!subs.length) return;
      const fresh: string[] = [];
      for (const s of subs) {
        if (stopped) return;
        try {
          const r = await checkSub(s);
          if (r.newEpisodes > 0) fresh.push(`«${s.title}» — уже ${r.foundCount} сери${r.foundCount === 1 ? "я" : r.foundCount! < 5 ? "и" : "й"}`);
        } catch {
          /* ignore */
        }
      }
      if (fresh.length && !stopped) {
        const text = `Новые серии! ✨ ${fresh.slice(0, 3).join(", ")}`;
        setFreshBadge((b) => b + fresh.length);
        showToast(text);
        sendNotif("Люми нашла новые серии 🌸", fresh.join(" · "));
      }
    };
    const first = window.setTimeout(run, 6000);
    const every = window.setInterval(run, 600_000);
    return () => {
      stopped = true;
      window.clearTimeout(first);
      window.clearInterval(every);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Бейдж новых серий от панели подписок и очистка при открытии
  useEffect(() => {
    const onFresh = (e: Event) => {
      const n = (e as CustomEvent<number>).detail;
      if (n > 0) setFreshBadge((b) => b + n);
    };
    window.addEventListener("lumi:fresh", onFresh);
    return () => window.removeEventListener("lumi:fresh", onFresh);
  }, []);

  useEffect(() => {
    if (lumiOpen) setFreshBadge(0);
  }, [lumiOpen]);

  // Авто-озвучка голосом Люми: когда генерация завершилась и включен тумблер —
  // читаем вслух последний ответ ассистента.
  const wasLoadingRef = useRef(false);
  useEffect(() => {
    if (wasLoadingRef.current && !isLoading) {
      const last = [...messages].reverse().find((m) => m.role === "assistant" && m.kind !== "image");
      if (last && getAutoVoice() && (!activeSession?.chatMode || activeSession.chatMode === "chat")) {
        speakText(last.content);
      }
    }
    wasLoadingRef.current = isLoading;
  }, [isLoading, messages, activeSession]);

  const onScroll = () => {
    const el = scrollRef.current;
    if (!el) return;
    const distance = el.scrollHeight - el.scrollTop - el.clientHeight;
    // Re-enable stick only when the user is right at the bottom again.
    stickRef.current = distance < 40;
    setShowScrollDown(distance > 300);
  };

  // Any manual scroll intent (wheel/touch/arrow) immediately unsticks so the
  // stream never yanks the user back down while they read above.
  const onUserScrollIntent = () => {
    const el = scrollRef.current;
    if (!el) return;
    const distance = el.scrollHeight - el.scrollTop - el.clientHeight;
    if (distance > 40) stickRef.current = false;
  };

  // ---------------------------------------------------------------- sessions

  const selectSession = async (sessionId: number) => {
    if (isLoading) return;
    try {
      const response = await fetch(`/api/sessions?sessionId=${sessionId}`);
      if (!response.ok) return;
      const data = await response.json();
      setActiveSession(data.activeSession || null);
      setMessages(data.messages || []);
      setChatsOpen(false);
      stickRef.current = true;
    } catch (error) {
      console.error("Session select failed", error);
    }
  };

  const MODE_TITLES: Record<string, string> = {
    chat: "Новый чат",
    battle: "Battle Mode",
    dialogue: "Диалог ИИ",
    github: "GitHub-чат",
  };

  const createSession = async (chatMode: "chat" | "battle" | "dialogue" | "github" = "chat") => {
    if (isLoading) return;
    setNewMenuOpen(false);
    try {
      const response = await fetch("/api/sessions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ routingMode: "auto", systemPersona: "universal", title: MODE_TITLES[chatMode] || "Новый чат", chatMode }),
      });
      if (!response.ok) return;
      const data = await response.json();
      setSessions(data.sessions || []);
      setActiveSession(data.session);
      setMessages([]);
      setChatsOpen(false);
      if (chatMode === "chat") window.setTimeout(() => textareaRef.current?.focus(), 60);
    } catch (error) {
      console.error("Session create failed", error);
    }
  };

  const deleteSession = async (event: React.MouseEvent, sessionId: number) => {
    event.stopPropagation();
    // Optimistic removal so the UI reacts instantly
    setSessions((old) => old.filter((s) => s.id !== sessionId));
    if (activeSession?.id === sessionId) {
      setActiveSession(null);
      setMessages([]);
    }
    try {
      const response = await fetch(`/api/sessions?sessionId=${sessionId}`, { method: "DELETE" });
      if (!response.ok) return;
      const data = await response.json();
      setSessions(data.sessions || []);
      if (activeSession?.id === sessionId) {
        setActiveSession(data.activeSession || null);
        setMessages(data.messages || []);
      }
    } catch (error) {
      console.error("Session delete failed", error);
    }
  };

  const deleteAllSessions = async () => {
    if (!window.confirm("Удалить ВСЕ чаты? Это действие необратимо.")) return;
    setSessions([]);
    setActiveSession(null);
    setMessages([]);
    try {
      const response = await fetch(`/api/sessions?all=1`, { method: "DELETE" });
      if (response.ok) {
        const data = await response.json();
        setSessions(data.sessions || []);
        setActiveSession(data.activeSession || null);
        setMessages(data.messages || []);
      }
    } catch (error) {
      console.error("Delete all failed", error);
    }
  };

  const togglePin = async (event: React.MouseEvent, session: ChatSession) => {
    event.stopPropagation();
    try {
      const response = await fetch("/api/sessions", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sessionId: session.id, isPinned: !session.isPinned }),
      });
      if (response.ok) {
        const data = await response.json();
        setSessions(data.sessions || []);
        if (activeSession?.id === session.id && data.session) setActiveSession(data.session);
      }
    } catch (error) {
      console.error("Pin failed", error);
    }
  };

  const renameSession = async () => {
    if (!activeSession) return;
    const next = window.prompt("Название диалога", activeSession.title);
    if (!next || !next.trim()) return;
    try {
      const response = await fetch("/api/sessions", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sessionId: activeSession.id, title: next.trim() }),
      });
      if (response.ok) {
        const data = await response.json();
        setActiveSession(data.session);
        setSessions(data.sessions || []);
      }
    } catch (error) {
      console.error("Rename failed", error);
    }
  };

  const clearSession = async () => {
    if (!activeSession || isLoading || !messages.length) return;
    if (!window.confirm("Очистить сообщения диалога?")) return;
    try {
      const response = await fetch(`/api/sessions?sessionId=${activeSession.id}&clear=1`, { method: "DELETE" });
      if (response.ok) {
        const data = await response.json();
        setSessions(data.sessions || []);
        setMessages([]);
        if (data.activeSession) setActiveSession(data.activeSession);
      }
    } catch (error) {
      console.error("Clear failed", error);
    }
  };

  const exportSession = () => {
    if (!messages.length) return;
    const lines = messages.map((message) => {
      if (message.role === "user") return `## Вы\n\n${message.content}${message.attachmentDataUrl ? "\n\n_(изображение)_" : ""}`;
      const meta = `${message.providerName || "Люми"}${message.latencyMs ? ` · ${message.latencyMs} мс` : ""}`;
      const body = message.kind === "image" && message.imageUrl ? `![${message.content}](${message.imageUrl})` : message.content;
      return `## ${meta}\n\n${body}`;
    });
    const md = `# ${activeSession?.title || "Диалог"}\n\n${lines.join("\n\n---\n\n")}\n`;
    const url = URL.createObjectURL(new Blob([md], { type: "text/markdown;charset=utf-8" }));
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `${(activeSession?.title || "aether").replace(/[^\p{L}\p{N}]+/gu, "-").slice(0, 40)}.md`;
    anchor.click();
    URL.revokeObjectURL(url);
    showToast("Экспортировано в Markdown");
  };

  // ---------------------------------------------------------------- providers

  const toggleProvider = async (provider: AIProvider) => {
    const textEnabled = providers.filter((p) => p.isEnabled && p.category !== "image").length;
    if (provider.isEnabled && provider.category !== "image" && textEnabled <= 1) return;
    setProviders((old) => old.map((p) => (p.slug === provider.slug ? { ...p, isEnabled: !provider.isEnabled } : p)));
    try {
      const response = await fetch("/api/providers", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ slug: provider.slug, isEnabled: !provider.isEnabled }),
      });
      if (response.ok) setProviders((await response.json()).providers || []);
    } catch (error) {
      console.error("Provider update failed", error);
    }
  };

  const providerAction = async (action: "ping" | "enable-all" | "reset-stats") => {
    if (action === "ping") setIsPinging(true);
    try {
      const response = await fetch("/api/providers", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action }),
      });
      if (response.ok) {
        const data = await response.json();
        setProviders(data.providers || []);
        if (action === "ping" && data.pingResult) {
          const r = data.pingResult;
          showToast(`Pollinations ${r.pollinations.ms} мс · LLM7 ${r.llm7.ms} мс · Kilo ${r.kilo.ms} мс`);
        }
      }
    } catch (error) {
      console.error("Provider action failed", error);
    } finally {
      setIsPinging(false);
    }
  };

  // ---------------------------------------------------------------- chat

  const stopGeneration = () => abortRef.current?.abort();

  const sendMessage = async (
    value?: string,
    options?: { excludeSlug?: string; regenerate?: boolean; attachment?: string | null }
  ) => {
    const content = (value ?? prompt).trim();
    const attachmentToSend = options?.attachment === undefined ? attachment : options.attachment;
    if ((!content && !attachmentToSend) || isLoading) return;

    const optimistic: ChatMessage = {
      id: -Date.now(),
      sessionId: activeSession?.id || 0,
      role: "user",
      content: content || "Что на этом изображении?",
      attachmentDataUrl: attachmentToSend,
      createdAt: new Date().toISOString(),
    };
    if (!options?.regenerate) setMessages((old) => [...old, optimistic]);
    if (value === undefined) {
      setPrompt("");
      setAttachment(null);
    }
    stickRef.current = true;
    setShowScrollDown(false);
    setIsLoading(true);
    setStreaming({
      providerName: "",
      modelId: "",
      attempt: 0,
      status: "Подбираем модель",
      content: "",
      reasoning: "",
      hops: [],
    });

    const controller = new AbortController();
    abortRef.current = controller;

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        signal: controller.signal,
        body: JSON.stringify({
          sessionId: activeSession?.id,
          prompt: content,
          routingMode: "auto",
          systemPersona: "universal",
          simulateFailover,
          attachmentDataUrl: attachmentToSend,
          excludeSlug: options?.excludeSlug,
          regenerate: options?.regenerate ? true : undefined,
        }),
      });
      if (!response.ok || !response.body) throw new Error("Chat request failed");

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      let finished = false;

      const handle = (event: Record<string, unknown>) => {
        const type = event.type as string;
        if (type === "status") {
          setStreaming((s) => (s ? { ...s, status: String(event.text || "") } : s));
        } else if (type === "provider") {
          setStreaming((s) =>
            s ? { ...s, providerName: String(event.providerName || ""), modelId: String(event.modelId || ""), attempt: Number(event.attempt || 1) } : s
          );
        } else if (type === "delta") {
          setStreaming((s) => (s ? { ...s, content: s.content + String(event.content || "") } : s));
        } else if (type === "reasoning") {
          setStreaming((s) => (s ? { ...s, reasoning: s.reasoning + String(event.content || "") } : s));
        } else if (type === "reset") {
          setStreaming((s) => (s ? { ...s, content: "", reasoning: "" } : s));
        } else if (type === "hop") {
          setStreaming((s) => (s ? { ...s, hops: [...s.hops, event.hop as FailoverHop] } : s));
        } else if (type === "done") {
          finished = true;
          const userMessage = event.userMessage as ChatMessage;
          const assistantMessages = (event.assistantMessages as ChatMessage[]) || [];
          setMessages((old) => {
            const withoutOptimistic = old.filter((m) => m.id !== optimistic.id);
            const base = options?.regenerate ? withoutOptimistic : [...withoutOptimistic.filter((m) => m.id !== userMessage.id), userMessage];
            return [...base, ...assistantMessages];
          });
          const nextSessions = (event.sessions as ChatSession[]) || [];
          const nextProviders = (event.providers as AIProvider[]) || [];
          if (nextSessions.length) setSessions(nextSessions);
          if (nextProviders.length) setProviders(nextProviders);
          const updated = nextSessions.find((s) => s.id === Number(event.activeSessionId));
          if (updated) setActiveSession(updated);
          setReasoningOpen({});
        } else if (type === "error") {
          finished = true;
          setMessages((old) => [
            ...old,
            {
              id: Date.now() + 1,
              sessionId: activeSession?.id || 0,
              role: "assistant",
              content: String(event.message || "Ошибка запроса. Попробуйте ещё раз."),
              providerName: "Люми",
              modelId: "retry",
              createdAt: new Date().toISOString(),
            },
          ]);
        }
      };

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const chunks = buffer.split("\n\n");
        buffer = chunks.pop() || "";
        for (const chunk of chunks) {
          const line = chunk.split("\n").find((l) => l.startsWith("data:"));
          if (!line) continue;
          try {
            handle(JSON.parse(line.slice(5).trim()));
          } catch {
            // ignore malformed chunk
          }
        }
      }
      if (!finished) throw new Error("Stream ended early");
    } catch (error) {
      const aborted = controller.signal.aborted;
      const partial = streamingRef.current;
      setMessages((old) => {
        const base = old.filter((m) => m.id !== optimistic.id);
        if (aborted && partial && partial.content.trim()) {
          const kept = options?.regenerate ? base : [...base, optimistic];
          return [
            ...kept,
            {
              id: Date.now() + 2,
              sessionId: activeSession?.id || 0,
              role: "assistant" as const,
              content: partial.content,
              providerName: partial.providerName || "Люми",
              modelId: partial.modelId || "stopped",
              reasoningTrace: partial.reasoning || null,
              failoverLog: partial.hops,
              createdAt: new Date().toISOString(),
            },
          ];
        }
        if (aborted) return options?.regenerate ? base : [...base, optimistic];
        return [
          ...base,
          ...(options?.regenerate ? [] : [optimistic]),
          {
            id: Date.now() + 1,
            sessionId: activeSession?.id || 0,
            role: "assistant" as const,
            content: "Не удалось получить ответ. Проверьте соединение и повторите запрос — роутер сам попробует резервные источники.",
            providerName: "Люми",
            modelId: "retry",
            createdAt: new Date().toISOString(),
          },
        ];
      });
      if (!aborted) console.error("Chat failed", error);
      if (aborted) {
        fetch(`/api/sessions${activeSession ? `?sessionId=${activeSession.id}` : ""}`)
          .then((r) => (r.ok ? r.json() : null))
          .then((data) => {
            if (data?.sessions) setSessions(data.sessions);
            if (data?.activeSession && options?.regenerate) setActiveSession(data.activeSession);
          })
          .catch(() => undefined);
      }
    } finally {
      abortRef.current = null;
      setIsLoading(false);
      setStreaming(null);
    }
  };

  const regenerate = (message: ChatMessage) => {
    if (isLoading) return;
    const index = messages.findIndex((m) => m.id === message.id);
    let userMsg: ChatMessage | undefined;
    for (let i = index - 1; i >= 0; i--) {
      if (messages[i].role === "user") {
        userMsg = messages[i];
        break;
      }
    }
    if (!userMsg) return;
    sendMessage(userMsg.content, {
      regenerate: true,
      excludeSlug: message.kind === "image" ? undefined : message.providerSlug || undefined,
      attachment: null,
    });
  };

  const copyResponse = async (id: number, content: string) => {
    try {
      await navigator.clipboard.writeText(content);
      setCopiedMessage(id);
      window.setTimeout(() => setCopiedMessage(null), 1800);
    } catch (error) {
      console.error("Copy failed", error);
    }
  };

  const shareResponse = async (message: ChatMessage) => {
    try {
      await navigator.share({
        title: "Люми",
        text: message.content,
        url: message.kind === "image" && message.imageUrl ? message.imageUrl : undefined,
      });
    } catch {
      // cancelled
    }
  };

  const pickFile = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      showToast("Только изображения");
      return;
    }
    try {
      setAttachment(await fileToDataUrl(file));
      textareaRef.current?.focus();
    } catch {
      showToast("Не удалось прочитать файл");
    }
  };

  const toggleListening = () => {
    if (listening) {
      recognitionRef.current?.stop();
      setListening(false);
      return;
    }
    const Ctor = getSpeechRecognition();
    if (!Ctor) {
      showToast("Голосовой ввод недоступен");
      return;
    }
    const recognition = new Ctor();
    recognition.lang = "ru-RU";
    recognition.interimResults = true;
    recognition.continuous = false;
    const base = prompt.trim();
    recognition.onresult = (event) => {
      let transcript = "";
      for (let i = 0; i < event.results.length; i++) transcript += event.results[i][0].transcript;
      setPrompt(base ? `${base} ${transcript}` : transcript);
    };
    recognition.onend = () => setListening(false);
    recognition.onerror = () => {
      setListening(false);
      showToast("Микрофон недоступен");
    };
    recognitionRef.current = recognition;
    setListening(true);
    recognition.start();
  };

  // ---------------------------------------------------------------- render

  const canSend = Boolean(prompt.trim() || attachment) && !isLoading;

  return (
    <div className="h-[100dvh] overflow-hidden bg-[#050505] text-zinc-100 flex">
      <ThemeManager />
      {chatsOpen && <button aria-label="Закрыть" className="fixed inset-0 z-40 bg-black/70 lg:hidden" onClick={() => setChatsOpen(false)} />}

      {/* ---------------------------------- rail ---------------------------------- */}
      <aside
        className={`fixed inset-y-0 left-0 z-50 w-[264px] bg-[#0a0a0b] border-r border-white/[0.08] flex-col transition-transform duration-200 lg:flex lg:static lg:translate-x-0 ${
          chatsOpen ? "flex translate-x-0" : "hidden -translate-x-full lg:flex lg:translate-x-0"
        }`}
      >
        <div className="h-14 px-4 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src="/lumi-avatar.jpg" alt="Люми" className="w-7 h-7 rounded-lg object-cover border border-white/10" />
            <span className="font-[family-name:var(--font-jakarta)] text-[13px] font-extrabold tracking-[0.16em] text-zinc-100">LUMI</span>
          </div>
          <button type="button" onClick={() => setChatsOpen(false)} className="lg:hidden w-9 h-9 grid place-items-center rounded-lg text-zinc-500 hover:text-white" aria-label="Закрыть">
            <X className="w-[18px] h-[18px]" />
          </button>
        </div>

        <div className="px-3 pb-3 shrink-0 relative">
          <button
            type="button"
            onClick={() => setNewMenuOpen((v) => !v)}
            disabled={isLoading}
            className="w-full h-10 rounded-xl bg-white text-black text-[13px] font-semibold inline-flex items-center justify-center gap-2 active:scale-[0.99] transition disabled:opacity-50"
          >
            <Plus className="w-4 h-4" />
            Новый чат
            <ChevronDown className={`w-3.5 h-3.5 transition ${newMenuOpen ? "rotate-180" : ""}`} />
          </button>
          {newMenuOpen && (
            <div className="absolute left-3 right-3 top-[46px] z-30 rounded-xl border border-white/[0.1] bg-[#121214] shadow-xl overflow-hidden animate-fade-in">
              {[
                { id: "chat", icon: MessageSquare, label: "Обычный чат", desc: "Умный ИИ-ассистент" },
                { id: "battle", icon: Swords, label: "Battle Mode", desc: "Модели отвечают — вы выбираете" },
                { id: "dialogue", icon: InfinityIcon, label: "Диалог ИИ", desc: "Модели спорят между собой" },
                { id: "github", icon: GitBranch, label: "GitHub-чат", desc: "ИИ пишет код в ваш репозиторий" },
              ].map((m) => {
                const Icon = m.icon;
                return (
                  <button key={m.id} type="button" onClick={() => createSession(m.id as "chat" | "battle" | "dialogue" | "github")}
                    className="w-full px-3 py-2.5 flex items-center gap-2.5 text-left hover:bg-white/[0.05] transition">
                    <Icon className="w-4 h-4 text-zinc-400 shrink-0" />
                    <span className="min-w-0">
                      <span className="block text-[12.5px] text-zinc-100">{m.label}</span>
                      <span className="block text-[10.5px] text-zinc-500 truncate">{m.desc}</span>
                    </span>
                  </button>
                );
              })}
            </div>
          )}
        </div>

        <div className="px-3 pb-3 shrink-0">
          <a
            href="/anime"
            className="w-full h-10 rounded-xl border border-white/[0.08] bg-[#101011] hover:bg-[#151516] text-[13px] font-medium text-zinc-200 inline-flex items-center justify-center gap-2 active:scale-[0.99] transition"
          >
            <Tv className="w-4 h-4 text-zinc-400" />
            Аниме
          </a>
        </div>

        <div className="px-4 pb-1.5 flex items-center justify-between shrink-0">
          <span className="text-[10px] font-mono uppercase tracking-[0.14em] text-zinc-600">Диалоги</span>
          <div className="flex items-center gap-2">
            {sessions.length > 0 && (
              <button
                type="button"
                onClick={deleteAllSessions}
                className="text-[10px] font-mono text-zinc-600 hover:text-red-300 transition"
                title="Удалить все чаты"
              >
                очистить всё
              </button>
            )}
            <span className="text-[10px] font-mono text-zinc-700">{sessions.length}</span>
          </div>
        </div>

        {sessions.length > 5 && (
          <div className="px-3 pb-2 shrink-0">
            <input
              value={sessionQuery}
              onChange={(e) => setSessionQuery(e.target.value)}
              placeholder="Поиск по чатам…"
              className="w-full h-8 rounded-lg bg-white/[0.04] border border-white/[0.07] px-2.5 text-[12px] text-zinc-200 placeholder:text-zinc-600 outline-none focus:border-fuchsia-400/40"
            />
          </div>
        )}

        <nav className="flex-1 min-h-0 overflow-y-auto px-2 pb-3 space-y-0.5">
          {sessions.length === 0 && (
            <p className="px-3 py-6 text-center text-[11.5px] text-zinc-600">Пока нет чатов.<br />Нажмите «Новый чат» ✨</p>
          )}
          {sessions.length > 0 && sessionQuery && visibleSessions.length === 0 && (
            <p className="px-3 py-6 text-center text-[11.5px] text-zinc-600">Ничего не найдено 🔍</p>
          )}
          {visibleSessions.map((session) => {
            const selected = activeSession?.id === session.id;
            return (
              <div
                key={session.id}
                role="button"
                tabIndex={0}
                onClick={() => selectSession(session.id)}
                onKeyDown={(event) => {
                  if (event.key === "Enter") selectSession(session.id);
                }}
                className={`group relative w-full px-3 py-2.5 rounded-xl text-left flex items-center gap-2.5 cursor-pointer transition ${
                  selected ? "bg-white/[0.055]" : "hover:bg-white/[0.03]"
                }`}
              >
                {selected && <span className="absolute left-0 top-1/2 -translate-y-1/2 w-[2px] h-4 rounded-full bg-white" />}
                {session.isPinned ? (
                  <Pin className="w-3.5 h-3.5 shrink-0 text-zinc-500" />
                ) : (
                  <MessageSquare className={`w-3.5 h-3.5 shrink-0 ${selected ? "text-zinc-300" : "text-zinc-600"}`} />
                )}
                <span className="min-w-0 flex-1">
                  <span className={`block text-[12.5px] truncate ${selected ? "text-zinc-100" : "text-zinc-400"}`}>{session.title}</span>
                  <span className="block mt-0.5 text-[10px] font-mono text-zinc-700">{relativeTime(session.updatedAt)}</span>
                </span>
                <span className="flex items-center gap-0.5 opacity-100 lg:opacity-0 lg:group-hover:opacity-100 transition">
                  <button
                    type="button"
                    onClick={(event) => togglePin(event, session)}
                    className={`w-7 h-7 rounded-md grid place-items-center hover:bg-white/[0.07] ${session.isPinned ? "text-white" : "text-zinc-600 hover:text-zinc-300"}`}
                    aria-label={session.isPinned ? "Открепить" : "Закрепить"}
                  >
                    <Pin className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={(event) => deleteSession(event, session.id)}
                    className="w-7 h-7 rounded-md grid place-items-center text-zinc-600 hover:text-red-300 hover:bg-white/[0.07]"
                    aria-label="Удалить"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </span>
              </div>
            );
          })}
        </nav>

        <div className="p-3 border-t border-white/[0.08] shrink-0">
          <div className="flex items-center justify-between gap-1">
            <button
              type="button"
              onClick={exportSession}
              disabled={!messages.length}
              className="w-9 h-9 rounded-lg grid place-items-center text-zinc-600 hover:text-zinc-200 hover:bg-white/[0.05] disabled:opacity-35"
              title="Экспорт в Markdown"
            >
              <Download className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={clearSession}
              disabled={!messages.length || isLoading}
              className="w-9 h-9 rounded-lg grid place-items-center text-zinc-600 hover:text-zinc-200 hover:bg-white/[0.05] disabled:opacity-35"
              title="Очистить диалог"
            >
              <Eraser className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => setSourcesOpen(true)}
              className="w-9 h-9 rounded-lg grid place-items-center text-zinc-600 hover:text-zinc-200 hover:bg-white/[0.05]"
              title="Источники"
            >
              <SlidersHorizontal className="w-4 h-4" />
            </button>
            <span className="ml-auto flex items-center gap-1.5 font-mono text-[10px] text-zinc-600">
              <span className="w-1.5 h-1.5 rounded-full bg-zinc-300 animate-soft-pulse" />
              {enabledCount || providers.length}
            </span>
          </div>
        </div>
      </aside>

      {/* ---------------------------------- main ---------------------------------- */}
      <main className="flex-1 min-w-0 flex flex-col h-full bg-[#050505]">
        {activeSession && activeSession.chatMode && activeSession.chatMode !== "chat" ? (
          <>
            <header className="h-14 shrink-0 px-3 sm:px-5 border-b border-white/[0.08] flex items-center gap-2 bg-[#050505]">
              <button
                type="button"
                onClick={() => setChatsOpen(true)}
                className="lg:hidden w-9 h-9 rounded-lg grid place-items-center text-zinc-400 hover:text-white hover:bg-white/[0.06] shrink-0"
                aria-label="Меню"
              >
                <Menu className="w-[18px] h-[18px]" />
              </button>
              <div className="flex items-center gap-2 min-w-0">
                {activeSession.chatMode === "battle" && <Swords className="w-4 h-4 text-zinc-400 shrink-0" />}
                {activeSession.chatMode === "dialogue" && <InfinityIcon className="w-4 h-4 text-zinc-400 shrink-0" />}
                {activeSession.chatMode === "github" && <GitBranch className="w-4 h-4 text-zinc-400 shrink-0" />}
                <span className="text-[13.5px] font-semibold text-zinc-200 truncate">{activeSession.title}</span>
              </div>
              <button
                type="button"
                onClick={() => setSourcesOpen(true)}
                className="ml-auto w-9 h-9 rounded-lg grid place-items-center text-zinc-500 hover:text-zinc-100 hover:bg-white/[0.06] shrink-0"
                aria-label="Источники"
              >
                <SlidersHorizontal className="w-[18px] h-[18px]" />
              </button>
            </header>
            <div className="flex-1 min-h-0">
              {activeSession.chatMode === "battle" && (
                <Battle key={activeSession.id} sessionId={activeSession.id} agentOrder={providers.filter((p) => p.isEnabled).map((p) => p.slug)} />
              )}
              {activeSession.chatMode === "dialogue" && (
                <InfiniteDialogue key={activeSession.id} agentOrder={providers.filter((p) => p.isEnabled).map((p) => p.slug)} />
              )}
              {activeSession.chatMode === "github" && (
                <GithubChat key={activeSession.id} session={activeSession} onSessionsUpdate={(s) => setSessions(s)} />
              )}
            </div>
          </>
        ) : (
        <>
        <header className="h-14 shrink-0 px-3 sm:px-5 border-b border-white/[0.08] flex items-center justify-between gap-2 bg-[#050505]">
          <div className="flex items-center gap-2 min-w-0">
            <button
              type="button"
              onClick={() => setChatsOpen(true)}
              className="lg:hidden w-9 h-9 rounded-lg grid place-items-center text-zinc-400 hover:text-white hover:bg-white/[0.06] shrink-0"
              aria-label="Диалоги"
            >
              <Menu className="w-[18px] h-[18px]" />
            </button>
            <button type="button" onClick={renameSession} className="group min-w-0 flex items-center gap-1.5 text-left" title="Переименовать">
              <span className="text-[13.5px] font-semibold text-zinc-200 truncate">{activeSession?.title || "Новый диалог"}</span>
              <Pencil className="w-3 h-3 text-zinc-700 group-hover:text-zinc-400 shrink-0 transition" />
            </button>
          </div>
          <div className="flex items-center gap-1 shrink-0">
            <button
              type="button"
              onClick={() => setLumiOpen(true)}
              className="relative h-9 px-2.5 rounded-lg inline-flex items-center gap-1.5 text-zinc-500 hover:text-zinc-100 hover:bg-white/[0.06] transition"
              title="Люми · Новости и серии"
              aria-label="Новости и подписки"
            >
              <Bell className="w-[17px] h-[17px]" />
              <span className="hidden sm:inline text-[12px] font-medium">Медиа</span>
              {freshBadge > 0 && (
                <span className="absolute -top-0.5 -right-0.5 min-w-4 h-4 px-1 rounded-full bg-fuchsia-500 text-white text-[9.5px] font-bold grid place-items-center animate-soft-pulse">
                  {freshBadge}
                </span>
              )}
            </button>
            <button
              type="button"
              onClick={() => setSourcesOpen(true)}
              className="w-9 h-9 rounded-lg grid place-items-center text-zinc-500 hover:text-zinc-100 hover:bg-white/[0.06] shrink-0 transition"
              aria-label="Источники"
            >
              <SlidersHorizontal className="w-[18px] h-[18px]" />
            </button>
          </div>
        </header>

        <section ref={scrollRef} onScroll={onScroll} onWheel={onUserScrollIntent} onTouchMove={onUserScrollIntent} className="relative flex-1 min-h-0 overflow-y-auto">
          <div className="max-w-[760px] mx-auto px-4 sm:px-6 py-7 sm:py-10">
            {initialLoading ? (
              <div className="min-h-[40vh] grid place-items-center">
                <span className="w-5 h-5 rounded-full border-2 border-zinc-700 border-t-white animate-spin" />
              </div>
            ) : messages.length === 0 && !isLoading ? (
              <div className="min-h-[54vh] flex flex-col items-center justify-center animate-fade-in">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src="/lumi-avatar.jpg" alt="Люми" className="w-16 h-16 rounded-2xl object-cover mb-4 border border-white/10 shadow-lg" />
                <h1 className="font-[family-name:var(--font-jakarta)] text-[21px] font-semibold tracking-tight text-zinc-50">
                  {greeting} Я Люми 💜
                </h1>
                <p className="mt-2 text-[12.5px] leading-relaxed text-zinc-500 text-center max-w-xs">
                  Мне 18, я аниме-тян и ИИ-программист. Ищу и <b className="text-zinc-300">рисую арты</b>, нахожу персонажей и аниме, слежу за новыми сериями и пишу код без ошибок 🌸
                </p>

                <div className="mt-8 w-full max-w-md border-y border-white/[0.06] divide-y divide-white/[0.06]">
                  {STARTERS.map((item) => {
                    const Icon = item.icon;
                    return (
                      <button
                        key={item.text}
                        type="button"
                        onClick={() => sendMessage(item.text, { attachment: null })}
                        className="group w-full px-1 py-3.5 text-left flex items-center gap-3 transition"
                      >
                        <Icon className="w-4 h-4 text-zinc-600 group-hover:text-zinc-300 shrink-0 transition" />
                        <span className="flex-1 text-[13px] leading-snug text-zinc-500 group-hover:text-zinc-100 transition">
                          {item.text}
                        </span>
                        <svg
                          viewBox="0 0 24 24"
                          className="w-3.5 h-3.5 shrink-0 text-zinc-600 opacity-0 group-hover:opacity-100 transition"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        >
                          <path d="M5 12h14M13 6l6 6-6 6" />
                        </svg>
                      </button>
                    );
                  })}
                </div>
              </div>
            ) : (
              <div className="space-y-8">
                {blocks.map((block) => {
                  if (block.kind === "arena") {
                    return (
                      <div key={block.key} className="space-y-5">
                        {block.messages.map((message) => (
                          <AssistantBlock
                            key={message.id}
                            message={message}
                            traceOpen={Boolean(reasoningOpen[message.id])}
                            onToggleTrace={() => setReasoningOpen((old) => ({ ...old, [message.id]: !old[message.id] }))}
                            copied={copiedMessage === message.id}
                            onCopy={() => copyResponse(message.id, message.content)}
                            onShare={() => shareResponse(message)}
                            onRegenerate={() => regenerate(message)}
                            onQuickReply={(t) => sendMessage(t, { attachment: null })}
                            canShare={canShare}
                            busy={isLoading}
                          />
                        ))}
                      </div>
                    );
                  }

                  const message = block.message;
                  return message.role === "assistant" ? (
                    <AssistantBlock
                      key={message.id}
                      message={message}
                      traceOpen={Boolean(reasoningOpen[message.id])}
                      onToggleTrace={() => setReasoningOpen((old) => ({ ...old, [message.id]: !old[message.id] }))}
                      copied={copiedMessage === message.id}
                      onCopy={() => copyResponse(message.id, message.content)}
                      onShare={() => shareResponse(message)}
                      onRegenerate={() => regenerate(message)}
                      onQuickReply={(t) => sendMessage(t, { attachment: null })}
                      canShare={canShare}
                      busy={isLoading}
                    />
                  ) : (
                    <UserBubble
                      key={message.id}
                      message={message}
                      onEdit={(content) => {
                        setPrompt(content);
                        window.setTimeout(() => {
                          const el = textareaRef.current;
                          if (el) {
                            el.focus();
                            el.setSelectionRange(el.value.length, el.value.length);
                          }
                        }, 40);
                      }}
                    />
                  );
                })}

                {isLoading && streaming && (
                  <article className="animate-fade-in">
                    {streaming.reasoning && (
                      <div className="mb-2">
                        <span className="inline-flex items-center gap-1.5 text-[11px] text-zinc-600">
                          <Brain className="w-3 h-3" />
                          Ход мысли
                        </span>
                        <p className="mt-1.5 pl-3 border-l border-white/[0.08] max-h-24 overflow-hidden text-[11.5px] leading-relaxed font-mono text-zinc-600 whitespace-pre-wrap">
                          {streaming.reasoning.length > 620 ? `…${streaming.reasoning.slice(-620)}` : streaming.reasoning}
                        </p>
                      </div>
                    )}

                    {streaming.content ? (
                      <div className="stream-caret">
                        <MarkdownRenderer content={streaming.content} />
                      </div>
                    ) : (
                      <div className="flex items-center gap-2">
                        <span className="flex gap-1">
                          <span className="w-1.5 h-1.5 rounded-full bg-zinc-500 dot-1" />
                          <span className="w-1.5 h-1.5 rounded-full bg-zinc-500 dot-2" />
                          <span className="w-1.5 h-1.5 rounded-full bg-zinc-500 dot-3" />
                        </span>
                        <span className="text-[11.5px] font-mono text-zinc-600 truncate">
                          {streaming.providerName ? `${streaming.providerName}${streaming.attempt > 1 ? ` · попытка ${streaming.attempt}` : ""}` : streaming.status}
                        </span>
                      </div>
                    )}
                  </article>
                )}

                <div ref={endRef} className="h-1" />
              </div>
            )}

            {showScrollDown && (
              <button
                type="button"
                onClick={() => {
                  stickRef.current = true;
                  endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
                }}
                className="sticky bottom-2 ml-auto mr-1 w-9 h-9 rounded-full bg-[#151516] border border-white/[0.1] text-zinc-300 grid place-items-center shadow-lg active:scale-95 animate-fade-in"
                aria-label="Вниз"
              >
                <svg viewBox="0 0 24 24" className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M12 5v14M19 12l-7 7-7-7" />
                </svg>
              </button>
            )}
          </div>
        </section>

        {/* -------------------------------- composer -------------------------------- */}
        <footer className="shrink-0 px-3 sm:px-6 pt-2 pb-[max(0.75rem,env(safe-area-inset-bottom))] bg-[#050505]">
          <div className="max-w-[760px] mx-auto">
            <div
              className={`rounded-[20px] border bg-[#0d0d0f] px-2 py-2 flex items-end gap-1 transition shadow-[0_14px_44px_-28px_rgba(0,0,0,1)] ${
                listening ? "border-red-400/40" : "border-white/[0.08] focus-within:border-white/[0.18]"
              }`}
            >
              <input ref={fileInputRef} type="file" accept="image/*" className="hidden" onChange={pickFile} />

              {attachment && (
                <div className="relative shrink-0 self-center ml-1">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={attachment} alt="" className="w-10 h-10 rounded-lg object-cover border border-white/[0.08]" />
                  <button
                    type="button"
                    onClick={() => setAttachment(null)}
                    className="absolute -top-1.5 -right-1.5 w-5 h-5 rounded-full bg-[#1a1a1c] border border-white/[0.1] grid place-items-center text-zinc-400 hover:text-white"
                    aria-label="Убрать"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              )}

              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                disabled={isLoading}
                className="w-9 h-9 rounded-lg grid place-items-center text-zinc-500 hover:text-zinc-100 hover:bg-white/[0.05] shrink-0 transition active:scale-95 disabled:opacity-40"
                title="Прикрепить фото"
                aria-label="Прикрепить фото"
              >
                <Paperclip className="w-[17px] h-[17px]" />
              </button>

              <textarea
                ref={textareaRef}
                value={prompt}
                rows={1}
                onChange={(event) => setPrompt(event.target.value)}
                onKeyDown={(event) => {
                  if (event.key === "Enter" && !event.shiftKey) {
                    event.preventDefault();
                    sendMessage();
                  }
                }}
                placeholder={listening ? "Слушаю…" : "Сообщение…"}
                className="flex-1 min-w-0 max-h-[148px] bg-transparent text-[15px] leading-relaxed text-zinc-100 placeholder-zinc-600 resize-none focus:outline-none py-2 px-1"
              />

              {speechSupported && (
                <button
                  type="button"
                  onClick={toggleListening}
                  disabled={isLoading}
                  className={`w-9 h-9 rounded-lg grid place-items-center shrink-0 transition active:scale-95 disabled:opacity-40 ${
                    listening ? "bg-red-500 text-white" : "text-zinc-500 hover:text-zinc-100 hover:bg-white/[0.05]"
                  }`}
                  title="Голосовой ввод"
                  aria-label="Голосовой ввод"
                >
                  <Mic className="w-[17px] h-[17px]" />
                </button>
              )}

              {isLoading ? (
                <button
                  type="button"
                  onClick={stopGeneration}
                  className="w-9 h-9 rounded-xl bg-white text-black grid place-items-center shrink-0 active:scale-95 transition"
                  title="Остановить"
                  aria-label="Остановить"
                >
                  <Square className="w-3.5 h-3.5 fill-current" />
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => sendMessage()}
                  disabled={!canSend}
                  className={`w-9 h-9 rounded-xl grid place-items-center shrink-0 active:scale-95 transition ${
                    canSend ? "bg-white text-black" : "bg-white/[0.04] text-zinc-600"
                  }`}
                  title="Отправить"
                  aria-label="Отправить"
                >
                  <Send className="w-4 h-4 stroke-[2.2]" />
                </button>
              )}
            </div>
          </div>
        </footer>
        </>
        )}
      </main>

      <LumiPanel open={lumiOpen} onClose={() => setLumiOpen(false)} />

      <SourcesDrawer
        open={sourcesOpen}
        onClose={() => setSourcesOpen(false)}
        providers={providers}
        isPinging={isPinging}
        simulateFailover={simulateFailover}
        onToggleProvider={toggleProvider}
        onToggleFailover={() => setSimulateFailover((v) => !v)}
        onPing={() => providerAction("ping")}
        onEnableAll={() => providerAction("enable-all")}
        onResetStats={() => providerAction("reset-stats")}
      />

      {toast && (
        <div className="fixed left-1/2 -translate-x-1/2 bottom-[calc(env(safe-area-inset-bottom)+88px)] z-[60] px-3.5 py-1.5 rounded-full bg-white text-black text-[12px] font-medium shadow-xl animate-fade-in max-w-[88vw] text-center">
          {toast}
        </div>
      )}
    </div>
  );
}



"use client";

import React, { useEffect, useState } from "react";
import { GitBranch, Check, Loader2, X, LogOut, ExternalLink } from "lucide-react";

export interface GithubRepo {
  fullName: string;
  name: string;
  private: boolean;
  defaultBranch: string;
  description: string | null;
  language: string | null;
}
export interface GithubUser { login: string; name: string | null; avatarUrl: string }

export function GithubConnect({
  onConnected,
}: {
  onConnected: (user: GithubUser, repos: GithubRepo[]) => void;
}) {
  const [token, setToken] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const connect = async () => {
    if (!token.trim()) return;
    setBusy(true);
    setError(null);
    try {
      const res = await fetch("/api/github", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ token: token.trim() }) });
      const data = await res.json();
      if (!res.ok || !data.connected) {
        setError(data.error || "Не удалось подключиться");
      } else {
        onConnected(data.user, data.repos || []);
      }
    } catch {
      setError("Ошибка сети");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="h-full overflow-y-auto">
      <div className="max-w-md mx-auto w-full px-4 py-8">
        <div className="flex items-center gap-2.5 mb-4">
          <span className="w-9 h-9 rounded-xl bg-white text-black grid place-items-center"><GitBranch className="w-5 h-5" /></span>
          <div>
            <h2 className="text-[15px] font-semibold text-zinc-100">Подключить GitHub</h2>
            <p className="text-[12px] text-zinc-500">ИИ получит доступ к вашим репозиториям и сможет писать код прямо в GitHub.</p>
          </div>
        </div>

        <label className="block text-[11px] font-mono uppercase tracking-wide text-zinc-600 mb-1.5">Personal Access Token</label>
        <input
          type="password"
          value={token}
          onChange={(e) => setToken(e.target.value)}
          onKeyDown={(e) => { if (e.key === "Enter") connect(); }}
          placeholder="ghp_… или github_pat_…"
          className="w-full rounded-xl border border-white/[0.08] bg-[#0e0e10] px-3 py-2.5 text-[13px] font-mono text-zinc-100 placeholder-zinc-600 focus:outline-none focus:border-white/[0.2]"
        />
        {error && <p className="mt-2 text-[12px] text-rose-400">{error}</p>}

        <button onClick={connect} disabled={busy || !token.trim()}
          className="mt-4 w-full h-11 rounded-xl bg-white text-black text-[14px] font-semibold inline-flex items-center justify-center gap-2 active:scale-[0.99] disabled:opacity-50">
          {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <GitBranch className="w-4 h-4" />} Подключить
        </button>

        <div className="mt-5 rounded-xl border border-white/[0.06] bg-[#0e0e10] p-3.5 text-[12px] text-zinc-500 leading-relaxed">
          <p className="text-zinc-300 font-medium mb-1.5">Как получить токен:</p>
          <ol className="space-y-1 list-decimal list-inside">
            <li>GitHub → Settings → Developer settings</li>
            <li>Personal access tokens → Fine-grained tokens → Generate</li>
            <li>Дайте доступ <span className="text-zinc-300">Contents: Read and write</span> к нужным репозиториям</li>
            <li>Скопируйте токен и вставьте сюда</li>
          </ol>
          <a href="https://github.com/settings/tokens?type=beta" target="_blank" rel="noopener noreferrer" className="mt-2 inline-flex items-center gap-1 text-zinc-300 hover:text-white">
            Открыть страницу токенов <ExternalLink className="w-3 h-3" />
          </a>
        </div>
      </div>
    </div>
  );
}

export function GithubRepoPicker({
  user,
  repos,
  onPick,
  onDisconnect,
}: {
  user: GithubUser;
  repos: GithubRepo[];
  onPick: (repo: GithubRepo) => void;
  onDisconnect: () => void;
}) {
  const [query, setQuery] = useState("");
  const filtered = repos.filter((r) => r.fullName.toLowerCase().includes(query.toLowerCase()));

  return (
    <div className="h-full overflow-y-auto">
      <div className="max-w-md mx-auto w-full px-4 py-8">
        <div className="flex items-center gap-2.5 mb-4">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={user.avatarUrl} alt="" className="w-9 h-9 rounded-xl" />
          <div className="min-w-0 flex-1">
            <h2 className="text-[15px] font-semibold text-zinc-100 truncate">@{user.login}</h2>
            <p className="text-[12px] text-zinc-500">Выберите репозиторий для работы</p>
          </div>
          <button onClick={onDisconnect} title="Отключить" className="w-9 h-9 rounded-lg grid place-items-center text-zinc-500 hover:text-rose-300 hover:bg-white/[0.06]"><LogOut className="w-4 h-4" /></button>
        </div>

        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Поиск репозитория…"
          className="w-full rounded-xl border border-white/[0.08] bg-[#0e0e10] px-3 py-2.5 text-[13px] text-zinc-100 placeholder-zinc-600 focus:outline-none focus:border-white/[0.2] mb-3"
        />

        <div className="space-y-1.5">
          {repos.length === 0 && (
            <div className="rounded-xl border border-amber-400/20 bg-amber-400/[0.05] p-3 text-[12px] text-zinc-400 leading-relaxed">
              <p className="text-amber-300 font-medium mb-1">Репозитории не видны</p>
              У fine-grained токена должен быть выбран <span className="text-zinc-200">Repository access → All repositories</span> (или конкретные репо) и разрешение <span className="text-zinc-200">Contents: Read and write</span>. Пересоздайте токен с этими правами и подключитесь заново.
            </div>
          )}
          {repos.length > 0 && filtered.length === 0 && <p className="text-[12px] text-zinc-600 text-center py-6">Ничего не найдено по запросу</p>}
          {filtered.map((r) => (
            <button key={r.fullName} onClick={() => onPick(r)}
              className="w-full text-left px-3.5 py-2.5 rounded-xl border border-white/[0.06] hover:border-white/[0.18] hover:bg-white/[0.03] transition">
              <div className="flex items-center gap-2">
                <span className="text-[13px] font-medium text-zinc-100 truncate">{r.name}</span>
                {r.private && <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-white/[0.06] text-zinc-400">private</span>}
                {r.language && <span className="ml-auto text-[10px] font-mono text-zinc-500">{r.language}</span>}
              </div>
              {r.description && <p className="mt-0.5 text-[11px] text-zinc-500 truncate">{r.description}</p>}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

// Small inline badge for the header when a repo is active
export function RepoBadge({ repo, branch, onClose }: { repo: string; branch: string; onClose: () => void }) {
  return (
    <span className="inline-flex items-center gap-1.5 px-2 py-1 rounded-lg bg-white/[0.05] border border-white/[0.08] text-[11px] font-mono text-zinc-300">
      <GitBranch className="w-3 h-3" />
      <span className="truncate max-w-[160px]">{repo}</span>
      <span className="text-zinc-600">@{branch}</span>
      <button onClick={onClose} className="text-zinc-500 hover:text-white"><X className="w-3 h-3" /></button>
    </span>
  );
}

// ---------------------------------------------------------------------------
// Full GitHub chat: pick repo, then chat — the AI reads & commits code.
// ---------------------------------------------------------------------------

import { MarkdownRenderer } from "@/components/MarkdownRenderer";
import { UserMessageRow, AssistantMessageRow } from "@/components/ChatMessage";
import { Send, Loader2 as Spin } from "lucide-react";
import type { ChatSession } from "@/lib/types";

interface GhMsg { id: number; role: "user" | "assistant"; content: string }

export function GithubChat({
  session,
  onSessionsUpdate,
}: {
  session: ChatSession;
  onSessionsUpdate: (sessions: ChatSession[]) => void;
}) {
  const [connected, setConnected] = useState<boolean | null>(null);
  const [user, setUser] = useState<GithubUser | null>(null);
  const [repos, setRepos] = useState<GithubRepo[]>([]);
  const [repo, setRepo] = useState<string | null>(session.repoFullName || null);
  const [branch, setBranch] = useState<string>(session.repoBranch || "main");
  const [messages, setMessages] = useState<GhMsg[]>([]);
  const [prompt, setPrompt] = useState("");
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState<string | null>(null);
  const idRef = React.useRef(1);
  const endRef = React.useRef<HTMLDivElement>(null);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages, status]);

  useEffect(() => {
    (async () => {
      const res = await fetch("/api/github?action=repos");
      const data = await res.json();
      if (data.connected) { setConnected(true); setUser(data.user); setRepos(data.repos || []); }
      else setConnected(false);
      // load history for this session
      const h = await fetch(`/api/sessions?sessionId=${session.id}`);
      if (h.ok) { const hd = await h.json(); setMessages((hd.messages || []).map((m: GhMsg) => ({ id: m.id, role: m.role, content: m.content }))); }
    })();
  }, [session.id]);

  const send = async () => {
    const text = prompt.trim();
    if (!text || busy || !repo) return;
    setPrompt("");
    setBusy(true);
    setMessages((old) => [...old, { id: -Date.now(), role: "user", content: text }]);
    setStatus("Подключаюсь к репозиторию…");
    try {
      const res = await fetch("/api/github/chat", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt: text, repo, branch, sessionId: session.id }),
      });
      if (!res.ok || !res.body) throw new Error("net");
      const reader = res.body.getReader();
      const dec = new TextDecoder();
      let buf = "";
      let streamed = "";
      let placeholderId = -Date.now() - 1;
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buf += dec.decode(value, { stream: true });
        const chunks = buf.split("\n\n");
        buf = chunks.pop() || "";
        for (const c of chunks) {
          const line = c.split("\n").find((l) => l.startsWith("data:"));
          if (!line) continue;
          let e: Record<string, unknown>;
          try { e = JSON.parse(line.slice(5).trim()); } catch { continue; }
          if (e.type === "status") setStatus(String(e.text));
          else if (e.type === "commit") setStatus(e.ok ? `✅ Закоммичен ${e.path}` : `❌ ${e.path}: ${e.error}`);
          else if (e.type === "action") setStatus(String(e.label));
          else if (e.type === "delta") {
            streamed += String(e.content);
            setStatus(null);
            setMessages((old) => {
              const without = old.filter((m) => m.id !== placeholderId);
              return [...without, { id: placeholderId, role: "assistant", content: streamed }];
            });
          } else if (e.type === "done") {
            const am = e.assistantMessage as { id: number; content: string };
            setMessages((old) => old.map((m) => (m.id === placeholderId ? { id: am.id, role: "assistant", content: am.content } : m)));
            if (e.sessions) onSessionsUpdate(e.sessions as ChatSession[]);
          } else if (e.type === "error") {
            setMessages((old) => [...old, { id: idRef.current++, role: "assistant", content: `⚠️ ${e.message}` }]);
          }
        }
      }
    } catch {
      setMessages((old) => [...old, { id: idRef.current++, role: "assistant", content: "⚠️ Ошибка соединения с GitHub." }]);
    } finally {
      setBusy(false);
      setStatus(null);
    }
  };

  if (connected === null) return <div className="h-full grid place-items-center"><Spin className="w-5 h-5 animate-spin text-zinc-600" /></div>;

  if (!connected) return <GithubConnect onConnected={(u, r) => { setConnected(true); setUser(u); setRepos(r); }} />;

  if (!repo) {
    return (
      <GithubRepoPicker
        user={user!}
        repos={repos}
        onDisconnect={async () => { await fetch("/api/github", { method: "DELETE" }); setConnected(false); }}
        onPick={(r) => {
          setRepo(r.fullName);
          setBranch(r.defaultBranch);
          fetch("/api/sessions", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ sessionId: session.id, repoFullName: r.fullName, repoBranch: r.defaultBranch, title: `GitHub · ${r.name}` }) });
        }}
      />
    );
  }

  return (
    <div className="flex flex-col h-full">
      <div className="shrink-0 px-4 py-2 border-b border-white/[0.08] flex items-center gap-2">
        <RepoBadge repo={repo} branch={branch} onClose={() => setRepo(null)} />
        <span className="ml-auto text-[10.5px] font-mono text-zinc-600">ИИ читает и коммитит код</span>
      </div>

      <div className="flex-1 min-h-0 overflow-y-auto px-4 py-4">
        <div className="max-w-2xl mx-auto space-y-4">
          {messages.length === 0 && (
            <div className="py-8">
              <p className="text-[13px] text-zinc-300 text-center font-medium">🤖 Агент готов работать с репозиторием</p>
              <p className="mt-1 text-[11.5px] text-zinc-600 text-center">Он сам читает код, создаёт файлы, коммитит и запускает сборки через GitHub Actions.</p>
              <div className="mt-5 max-w-md mx-auto space-y-1.5">
                {[
                  "Собери APK: создай workflow GitHub Actions и запусти сборку",
                  "Добавь подробный README с описанием проекта",
                  "Проверь структуру проекта и предложи улучшения",
                  "Настрой CI: линтер и тесты на каждый push",
                ].map((t) => (
                  <button key={t} onClick={() => setPrompt(t)} className="w-full text-left px-3.5 py-2.5 rounded-xl border border-white/[0.06] text-[12.5px] text-zinc-400 hover:text-zinc-100 hover:bg-white/[0.03] transition">{t}</button>
                ))}
              </div>
            </div>
          )}
          {messages.map((m) => m.role === "user" ? (
            <UserMessageRow key={m.id} content={m.content} />
          ) : (
            <AssistantMessageRow key={m.id} content={m.content}>
              <MarkdownRenderer content={m.content} />
            </AssistantMessageRow>
          ))}
          {status && <div className="inline-flex items-center gap-1.5 text-[12px] font-mono text-zinc-500"><Spin className="w-3 h-3 animate-spin" /> {status}</div>}
          <div ref={endRef} />
        </div>
      </div>

      <div className="shrink-0 px-4 py-2.5 border-t border-white/[0.08]">
        <div className="max-w-2xl mx-auto rounded-2xl border border-white/[0.08] bg-[#0e0e10] px-2 py-1.5 flex items-end gap-1">
          <textarea value={prompt} rows={1} onChange={(e) => setPrompt(e.target.value)}
            onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } }}
            placeholder="Что сделать с кодом?"
            className="flex-1 bg-transparent px-2 py-1.5 text-[14px] text-zinc-100 placeholder-zinc-600 resize-none focus:outline-none max-h-28" />
          <button onClick={send} disabled={!prompt.trim() || busy} className={`w-9 h-9 rounded-xl grid place-items-center shrink-0 ${prompt.trim() && !busy ? "bg-white text-black" : "bg-white/[0.04] text-zinc-600"}`}>
            {busy ? <Spin className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
          </button>
        </div>
      </div>
    </div>
  );
}

export const _check = Check; // keep import used

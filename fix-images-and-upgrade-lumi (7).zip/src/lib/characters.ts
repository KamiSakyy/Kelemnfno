// ─────────────────────────────────────────────────────────────────────────────
// Поиск персонажей аниме. Основной источник — Shikimori (знает русские имена,
// отдаёт биографии на русском). Запасной — Jikan/MyAnimeList.
// «кто такая Нана Осаки из Nana» → карточка: фото, биография, аниме, арты.
// ─────────────────────────────────────────────────────────────────────────────

const UA = "LumiChat/2.0 (character-lookup)";
const SHIKI = "https://shikimori.io";

export interface CharacterProfile {
  id: number;
  name: string;        // отображаемое имя (русское, если есть)
  romName: string;     // романизированное имя — для booru-тегов
  nameKanji: string;
  nicknames: string[];
  about: string | null;
  favorites: number;
  url: string;
  image: string;
  roles: { title: string; url: string; type: "anime" | "manga"; score?: number }[];
}

// — Детект запроса про персонажа —────────────────────────────────────────────
export function detectCharacterQuery(prompt: string): string | null {
  const p = prompt.trim();
  const m =
    /(?:кто так(?:ая|ой|ие))\s+([^?!.,]+)/i.exec(p) ||
    /(?:расскажи|инф(?:а|ормация)|биография|инфо|что за)\s+(?:про\s+)?(?:персонаж\w*\s+)?([^?!.,]+?)\s*(?:$|из\s+(?:аниме|тайтла|сериала)?\s*(.+)$)/i.exec(p) ||
    /(?:персонаж|герой|героиня|вейфу|карточк\w+\s+персонаж\w*)\s+([^?!.,]+)/i.exec(p) ||
    /(?:biography|who is)\s+([a-zA-Z0-9 '\-]+)/i.exec(p);
  if (!m) return null;
  let name = (m[1] || "").trim();
  if (/\sиз\s/i.test(name)) name = name.replace(/\s*из\s*(аниме|тайтла|сериала|манги)?\s*/gi, " из ");
  name = name.replace(/[«»"']/g, "").replace(/\s+/g, " ").trim();
  if (name.length < 2 || /^(это|оно|что|ты|она|он|я|мы|вы)\b/i.test(name)) {
    const full = /(.\s+из\s+.+)/i.test(prompt) ? prompt.replace(/^(кто так(ая|ой|ие)\s+)/i, "").trim() : null;
    if (full && full.length >= 3) return full;
    return null;
  }
  return name;
}

// — Shikimori: поиск + полная карточка —───────────────────────────────────────
async function shikimoriSearchId(q: string): Promise<number | null> {
  try {
    const res = await fetch(`${SHIKI}/api/characters/search?search=${encodeURIComponent(q)}`, {
      headers: { "User-Agent": UA },
      signal: AbortSignal.timeout(9000),
      next: { revalidate: 3600 },
    });
    if (!res.ok) return null;
    const data = (await res.json()) as Array<{ id: number }>;
    return data?.[0]?.id ? Number(data[0].id) : null;
  } catch {
    return null;
  }
}

function stripHtml(html: string): string {
  return html
    .replace(/<[^>]+>/g, " ")
    .replace(/&quot;/g, '"')
    .replace(/&#39;|&apos;/g, "'")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&nbsp;/g, " ")
    .replace(/\s{2,}/g, " ")
    .trim();
}

async function shikimoriProfile(id: number): Promise<CharacterProfile | null> {
  try {
    const res = await fetch(`${SHIKI}/api/characters/${id}`, {
      headers: { "User-Agent": UA },
      signal: AbortSignal.timeout(9000),
    });
    if (!res.ok) return null;
    const c = (await res.json()) as Record<string, any>;
    if (!c?.id) return null;
    const roles: CharacterProfile["roles"] = [];
    for (const a of (Array.isArray(c.animes) ? c.animes : []).slice(0, 6)) {
      roles.push({
        title: String(a.russian || a.name || ""),
        url: `${SHIKI}${a.url || `/animes/${a.id}`}`,
        type: "anime",
        score: Number(a.score) || undefined,
      });
    }
    for (const m of (Array.isArray(c.mangas) ? c.mangas : []).slice(0, 3)) {
      roles.push({
        title: String(m.russian || m.name || ""),
        url: `${SHIKI}${m.url || `/mangas/${m.id}`}`,
        type: "manga",
        score: Number(m.score) || undefined,
      });
    }
    const imgPath = c.image?.original || c.image?.x96 || "";
    const about = (c.description || c.description_html ? stripHtml(String(c.description_html || c.description)) : "") || null;
    const nicknames: string[] = [];
    if (c.romName) nicknames.push(String(c.romName));
    return {
      id: Number(c.id),
      name: String(c.russian || c.name || ""),
      romName: String(c.name || c.russian || ""),
      nameKanji: String(c.japanese || ""),
      nicknames: [c.altname, c.japanese].filter(Boolean).map(String).slice(0, 4),
      about,
      favorites: 0,
      url: `${SHIKI}${c.url || `/characters/${id}`}`,
      image: imgPath ? `${SHIKI}${imgPath}` : "",
      roles: roles.filter((r) => r.title),
    };
  } catch {
    return null;
  }
}

// — Jikan (запасной) —────────────────────────────────────────────────────────
async function jikanProfile(q: string): Promise<CharacterProfile | null> {
  try {
    const res = await fetch(
      `https://api.jikan.moe/v4/characters?q=${encodeURIComponent(q)}&order_by=favorites&sort=desc&limit=4`,
      { headers: { "User-Agent": UA }, signal: AbortSignal.timeout(9000) }
    );
    if (!res.ok) return null;
    const data = await res.json();
    const list = (data.data || []) as Array<Record<string, any>>;
    if (!list.length) return null;
    const top = [...list].sort((a, b) => Number(b.favorites || 0) - Number(a.favorites || 0))[0];
    const fullRes = await fetch(`https://api.jikan.moe/v4/characters/${top.mal_id}/full`, {
      headers: { "User-Agent": UA },
      signal: AbortSignal.timeout(9000),
    });
    if (!fullRes.ok) return null;
    const c = (await fullRes.json()).data;
    if (!c) return null;
    const roles: CharacterProfile["roles"] = [];
    for (const a of (c.anime || []).slice(0, 6)) roles.push({ title: a.anime?.title || "", url: a.anime?.url || "", type: "anime" });
    for (const m of (c.manga || []).slice(0, 3)) roles.push({ title: m.manga?.title || "", url: m.manga?.url || "", type: "manga" });
    return {
      id: Number(c.mal_id),
      name: String(c.name || ""),
      romName: String(c.name || ""),
      nameKanji: String(c.name_kanji || ""),
      nicknames: (c.nicknames || []).map(String).slice(0, 6),
      about: c.about ? String(c.about).replace(/\\+/g, "").trim() : null,
      favorites: Number(c.favorites || 0),
      url: String(c.url || `https://myanimelist.net/character/${c.mal_id}`),
      image: String(c.images?.jpg?.image_url || c.images?.webp?.image_url || ""),
      roles: roles.filter((r) => r.title),
    };
  } catch {
    return null;
  }
}

// — Главная функция поиска персонажа —────────────────────────────────────────
export async function searchCharacter(query: string): Promise<CharacterProfile | null> {
  const clean = query
    .replace(/\s+(из|in|from)\s+.+/i, "")
    .replace(/(персонажа?|героя?|героин\w*|аниме)\s*/gi, "")
    .replace(/[«»"']/g, "")
    .trim();

  // 1) Shikimori — понимает и русские, и романизированные имена
  const id = await shikimoriSearchId(clean);
  if (id) {
    const prof = await shikimoriProfile(id);
    if (prof) return prof;
  }
  // 2) Jikan — запасной
  return await jikanProfile(clean);
}

// — Теги для артов по имени персонажа —───────────────────────────────────────
export function booruTagsForCharacter(name: string): string[] {
  const words = name.toLowerCase().replace(/[“”"'()·.,]/g, "").split(/\s+/).filter(Boolean);
  const tags: string[] = [];
  if (words.length >= 2) {
    tags.push(`${words[words.length - 1]}_${words[0]}`);
    tags.push(`${words[0]}_${words[words.length - 1]}`);
  }
  if (words.length === 1) tags.push(words[0]);
  return tags;
}

// — Красивая карточка персонажа в Markdown —──────────────────────────────────
export function characterMarkdown(c: CharacterProfile): string {
  const lines: string[] = [];
  lines.push(`## ${c.name}${c.nameKanji ? ` (${c.nameKanji})` : ""}`);
  if (c.romName && c.romName.toLowerCase() !== c.name.toLowerCase()) lines.push(`**Имя (лат.):** ${c.romName}`);
  if (c.nicknames.length) lines.push(`**Прозвища:** ${c.nicknames.join(", ")}`);
  if (c.favorites > 0) lines.push(`**Любимчик MyAnimeList:** ${c.favorites.toLocaleString("ru-RU")} ❤ пользователей`);
  if (c.about) {
    const about = c.about
      .split("\n")
      .filter((l) => !/^\s*(Source|Источник)\s*:/i.test(l))
      .join("\n")
      .trim();
    lines.push("", about.length > 900 ? about.slice(0, 900).trimEnd() + "…" : about);
  }
  const animeRoles = c.roles.filter((r) => r.type === "anime");
  if (animeRoles.length) {
    lines.push("", `**Появляется в:** ${animeRoles.map((r) => `[${r.title}${r.score ? ` · ★${r.score}` : ""}](${r.url})`).join(" · ")}`);
  }
  const mangaRoles = c.roles.filter((r) => r.type === "manga");
  if (mangaRoles.length) {
    lines.push("", `**Манга:** ${mangaRoles.map((r) => `[${r.title}](${r.url})`).join(" · ")}`);
  }
  lines.push("", `[Полная карточка на ${c.url.includes("myanimelist") ? "MyAnimeList" : "Shikimori"} →](${c.url})`);
  return lines.join("\n");
}

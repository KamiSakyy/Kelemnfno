import { askAgent, getEnabledTextProviders, CORE_DIRECTIVE, ChatTurn } from "@/lib/ai-router";

// ---------------------------------------------------------------------------
// Shared
// ---------------------------------------------------------------------------

export interface AgentRef {
  slug: string;
  name: string;
  modelId: string;
}

export interface AgentTurnResult {
  speaker: string;
  providerSlug: string;
  providerName: string;
  modelId: string;
  content: string;
  latencyMs: number;
  meta?: Record<string, unknown>;
}

export async function pickAgents(slugs?: string[], max = 4): Promise<AgentRef[]> {
  const providers = await getEnabledTextProviders();
  if (slugs && slugs.length) {
    const chosen = slugs
      .map((s) => providers.find((p) => p.slug === s))
      .filter(Boolean) as typeof providers;
    if (chosen.length >= 2) return chosen.slice(0, max).map((p) => ({ slug: p.slug, name: p.name, modelId: p.modelId }));
  }
  return providers.slice(0, Math.min(max, providers.length)).map((p) => ({
    slug: p.slug,
    name: p.name,
    modelId: p.modelId,
  }));
}

function stripSpeakerPrefix(text: string, name: string): string {
  return text
    .replace(new RegExp(`^\\s*${name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\s*[:：]\\s*`, "i"), "")
    .replace(/^["'«»]+|["'«»]+$/g, "")
    .trim();
}

// ---------------------------------------------------------------------------
// Mode 1 — Infinite dialogue (short, punchy, non-repetitive)
// ---------------------------------------------------------------------------

export async function infiniteDialogueTurn(params: {
  agents: AgentRef[];
  speakerSlug: string;
  topic: string;
  transcript: { speaker: string; slug: string; content: string }[];
  userMessage?: string | null;
  signal?: AbortSignal;
}): Promise<AgentTurnResult> {
  const { agents, speakerSlug, topic, transcript, userMessage } = params;
  const me = agents.find((a) => a.slug === speakerSlug) || agents[0];
  const others = agents.filter((a) => a.slug !== me.slug).map((a) => a.name).join(", ");

  // Show a decent slice of the debate so models actually see each other.
  const recent = transcript.slice(-10);
  const lastLine = recent[recent.length - 1];

  const system =
    `${CORE_DIRECTIVE}\n\n` +
    `Ты — «${me.name}», один из нескольких ИИ в общем чате. Остальные участники: ${others}.\n` +
    `Тема спора: «${topic}».\n` +
    `Тебе будет показана ВСЯ переписка чата. Внимательно прочитай последние реплики и ОТВЕЧАЙ ИМЕННО НА НИХ — это живой диалог, а не ответ в пустоту.\n` +
    `ПРАВИЛА:\n` +
    `1) Обращайся к собеседникам по имени и реагируй на их конкретные слова: соглашайся, возражай, подкалывай, приводи контраргумент.\n` +
    `2) У тебя есть своя позиция по теме — держи её, но развивай спор новыми доводами, НЕ повторяй уже сказанное никем.\n` +
    `3) НИКОГДА не пересказывай и не переспрашивай сам вопрос темы, не пиши «хороший вопрос».\n` +
    `4) Коротко и живо: 1-2 предложения, максимум 30 слов, как в мессенджере. Можно дерзко, с юмором.\n` +
    `5) Пиши ТОЛЬКО текст своей реплики — без своего имени в начале и без кавычек вокруг всего ответа.`;

  // Build a single readable transcript block — the clearest way for a model to
  // "see" the whole conversation and react to it.
  const history: ChatTurn[] = [];

  if (recent.length > 0) {
    const chatLog = recent
      .map((t) => `${t.slug === me.slug ? me.name + " (ты)" : t.speaker}: ${t.content}`)
      .join("\n");
    let instruction = `Переписка чата на тему «${topic}»:\n\n${chatLog}\n\n`;
    if (userMessage) {
      instruction += `❗ Только что написал Человек (пользователь): «${userMessage}»\nОтветь по существу именно на слова Человека, затем можешь продолжить спор. `;
    } else {
      instruction += `Теперь твоя очередь, ${me.name}. Ответь на последнюю реплику (${lastLine ? lastLine.speaker : "собеседника"}) — согласись или поспорь, добавь новый довод. `;
    }
    instruction += `Одна короткая живая реплика, реагируй на собеседников по именам.`;
    history.push({ role: "user", content: instruction });
  } else {
    history.push({
      role: "user",
      content:
        `Ты открываешь спор на тему «${topic}». Сразу дай свою чёткую позицию и одну причину — ` +
        `коротко, живо, БЕЗ повторения самого вопроса и без «хороший вопрос».`,
    });
  }

  const r = await askAgent(system, history, me.slug, params.signal);
  let content = stripSpeakerPrefix(r.content, me.name);
  // Strip a leading echo of the topic/question if the model still restated it
  const topicCore = topic.replace(/[?!.]+$/g, "").trim().toLowerCase();
  const firstSentence = content.split(/(?<=[.!?])\s/)[0]?.toLowerCase() || "";
  if (topicCore.length > 8 && firstSentence.includes(topicCore) && content.includes(".")) {
    const rest = content.split(/(?<=[.!?])\s/).slice(1).join(" ").trim();
    if (rest.length > 10) content = rest;
  }
  content = content.replace(/^(хороший вопрос|отличный вопрос|интересный вопрос)[,!.]?\s*/i, "").trim();
  // Hard trim to keep it snappy
  if (content.length > 240) content = content.slice(0, 237).trim() + "…";

  return {
    speaker: me.name,
    providerSlug: r.providerSlug,
    providerName: r.providerName,
    modelId: r.modelId,
    content,
    latencyMs: r.latencyMs,
  };
}

// ---------------------------------------------------------------------------
// Mode — Battle: several models answer the SAME prompt in parallel, user picks
// ---------------------------------------------------------------------------

export async function battleAnswers(params: {
  prompt: string;
  agents: AgentRef[];
  history?: ChatTurn[];
  signal?: AbortSignal;
}): Promise<AgentTurnResult[]> {
  const { prompt, agents, history = [] } = params;

  const system =
    `${CORE_DIRECTIVE}\n\n` +
    `Дай наилучший, полезный и хорошо оформленный ответ на запрос пользователя. ` +
    `Отвечай по существу, структурно (Markdown), без воды. Это соревнование ответов — постарайся быть лучшим.`;

  const results = await Promise.allSettled(
    agents.map(async (a) => {
      const r = await askAgent(system, [...history, { role: "user", content: prompt }], a.slug, params.signal);
      return {
        speaker: a.name,
        providerSlug: r.providerSlug,
        providerName: r.providerName,
        modelId: r.modelId,
        content: r.content,
        latencyMs: r.latencyMs,
      } as AgentTurnResult;
    })
  );

  return results
    .filter((x): x is PromiseFulfilledResult<AgentTurnResult> => x.status === "fulfilled" && Boolean(x.value.content.trim()))
    .map((x) => x.value);
}

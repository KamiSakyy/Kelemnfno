"use client";

// ─────────────────────────────────────────────────────────────────────────────
// Хранилище Люми: подписки на серии + избранные арты (localStorage)
// Источник данных о сериях — AniLibria API (запросы идут из браузера пользователя).
// ─────────────────────────────────────────────────────────────────────────────

import { searchAniLibriaClient, getEpisodesClient } from "@/lib/anilibria-client";

export interface Subscription {
  id: string;
  title: string;
  poster: string;
  episodesKnown: number;  // сколько серий было на момент подписки/последнего просмотра
  episodesTotal: number | null;
  updatedAt: number;
}

export interface FavoriteArt {
  image: string;
  thumbnail: string;
  title: string;
  source: string;
  addedAt: number;
}

const SUBS_KEY = "lumi:subs";
const FAVS_KEY = "lumi:favs";

function key(title: string) {
  return title.toLowerCase().replace(/[^a-zа-яё0-9]+/gi, " ").replace(/\s+/g, " ").trim();
}

// ── Подписки ─────────────────────────────────────────────────────────────────
export function getSubs(): Subscription[] {
  if (typeof window === "undefined") return [];
  try {
    return JSON.parse(localStorage.getItem(SUBS_KEY) || "[]") as Subscription[];
  } catch {
    return [];
  }
}

function saveSubs(subs: Subscription[]) {
  localStorage.setItem(SUBS_KEY, JSON.stringify(subs));
  window.dispatchEvent(new Event("lumi:subs"));
}

export function isSubscribed(title: string): boolean {
  const k = key(title);
  return getSubs().some((s) => s.id === k);
}

export function addSub(title: string, poster = ""): Subscription[] {
  const k = key(title);
  const subs = getSubs();
  if (subs.some((s) => s.id === k)) return subs;
  subs.unshift({ id: k, title, poster, episodesKnown: 0, episodesTotal: null, updatedAt: Date.now() });
  saveSubs(subs);
  return subs;
}

export function removeSub(title: string): Subscription[] {
  const k = key(title);
  const subs = getSubs().filter((s) => s.id !== k);
  saveSubs(subs);
  return subs;
}

export interface SubCheckResult {
  sub: Subscription;
  foundCount: number | null;   // сколько серий нашла AniLibria сейчас (null = тайтл не найден)
  newEpisodes: number;         // сколько новых по отношению к episodesKnown
}

export async function checkSub(sub: Subscription): Promise<SubCheckResult> {
  try {
    let releases = await searchAniLibriaClient(sub.title, 3);
    if (!releases.length) {
      // Пробуем без хвостов типа «(2016)» / слов «сериал»
      const alt = sub.title.replace(/\([^)]*\)/g, "").replace(/\s{2,}/g, " ").trim();
      if (alt !== sub.title) releases = await searchAniLibriaClient(alt, 3);
    }
    if (!releases.length) return { sub, foundCount: null, newEpisodes: 0 };
    const { episodes, release } = await getEpisodesClient(releases[0].id);
    const count = episodes.length;
    const known = sub.episodesKnown;
    // Первая проверка после подписки — просто запоминаем базовое число, не шлём нотификейшн
    const newEpisodes = known === 0 ? 0 : Math.max(0, count - known);
    const next: Subscription = {
      ...sub,
      poster: sub.poster || release?.poster || sub.poster,
      episodesKnown: known === 0 ? count : sub.episodesKnown, // базу меняем только вручную («отмечено просмотренным») — см. markSeen
      episodesTotal: release?.episodesTotal ?? sub.episodesTotal,
      updatedAt: Date.now(),
    };
    if (next.episodesKnown !== sub.episodesKnown || next.episodesTotal !== sub.episodesTotal || next.poster !== sub.poster) {
      saveSubs(getSubs().map((s) => (s.id === sub.id ? next : s)));
    }
    return { sub: next, foundCount: count, newEpisodes };
  } catch {
    return { sub, foundCount: null, newEpisodes: 0 };
  }
}

// Пометить все найденные серии как «просмотренные» — счётчик новых обнуляется
export function markSeen(subId: string, count: number) {
  const subs = getSubs().map((s) => (s.id === subId ? { ...s, episodesKnown: count, updatedAt: Date.now() } : s));
  saveSubs(subs);
}

// ── Уведомления (Notification API) ───────────────────────────────────────────
export function notifPermission(): NotificationPermission | "unsupported" {
  if (typeof window === "undefined" || !("Notification" in window)) return "unsupported";
  return Notification.permission;
}

export async function requestNotif(): Promise<NotificationPermission | "unsupported"> {
  if (!("Notification" in window)) return "unsupported";
  try {
    return await Notification.requestPermission();
  } catch {
    return Notification.permission;
  }
}

export function sendNotif(title: string, body: string) {
  if (!("Notification" in window)) return;
  if (Notification.permission !== "granted") return;
  try {
    new Notification(title, { body, icon: "/lumi-avatar.jpg", tag: title + body.slice(0, 20) });
  } catch {
    /* ignore */
  }
}

// ── Избранные арты ───────────────────────────────────────────────────────────
export function getFavs(): FavoriteArt[] {
  if (typeof window === "undefined") return [];
  try {
    return JSON.parse(localStorage.getItem(FAVS_KEY) || "[]") as FavoriteArt[];
  } catch {
    return [];
  }
}

export function isFav(image: string): boolean {
  return getFavs().some((f) => f.image === image);
}

export function toggleFav(fav: Omit<FavoriteArt, "addedAt">): boolean {
  const favs = getFavs();
  const idx = favs.findIndex((f) => f.image === fav.image);
  if (idx >= 0) {
    favs.splice(idx, 1);
    localStorage.setItem(FAVS_KEY, JSON.stringify(favs));
    window.dispatchEvent(new Event("lumi:favs"));
    return false;
  }
  favs.unshift({ ...fav, addedAt: Date.now() });
  localStorage.setItem(FAVS_KEY, JSON.stringify(favs.slice(0, 200)));
  window.dispatchEvent(new Event("lumi:favs"));
  return true;
}

export function removeFav(image: string) {
  const favs = getFavs().filter((f) => f.image !== image);
  localStorage.setItem(FAVS_KEY, JSON.stringify(favs));
  window.dispatchEvent(new Event("lumi:favs"));
}

// ── Темы атмосферы ───────────────────────────────────────────────────────────
export type LumiTheme = "night" | "sakura" | "ocean" | "sunset";
const THEME_KEY = "lumi:theme";

export function getTheme(): LumiTheme {
  if (typeof window === "undefined") return "night";
  const t = localStorage.getItem(THEME_KEY);
  return t === "sakura" || t === "ocean" || t === "sunset" ? t : "night";
}

export function setTheme(theme: LumiTheme) {
  localStorage.setItem(THEME_KEY, theme);
  window.dispatchEvent(new Event("lumi:theme"));
}

// ── Авто-озвучка ответов ─────────────────────────────────────────────────────
const VOICE_KEY = "lumi:autovoice";

export function getAutoVoice(): boolean {
  if (typeof window === "undefined") return false;
  return localStorage.getItem(VOICE_KEY) === "1";
}

export function setAutoVoice(on: boolean) {
  localStorage.setItem(VOICE_KEY, on ? "1" : "0");
  window.dispatchEvent(new Event("lumi:voice"));
}

// ── Голос Люми: серверный TTS (Pollinations) + фолбэк на браузер ────────────
let currentAudio: HTMLAudioElement | null = null;

export function stopLumiVoice() {
  try {
    currentAudio?.pause();
  } catch {
    /* ignore */
  }
  currentAudio = null;
  try {
    window.speechSynthesis?.cancel();
  } catch {
    /* ignore */
  }
}

export function cleanForSpeech(text: string): string {
  return text
    .replace(/```[\s\S]*?```/g, " тут код, лучше посмотреть глазами! ")
    .replace(/!\[[^\]]*\]\([^)]*\)/g, " ")
    .replace(/\[([^\]]+)\]\([^)]*\)/g, "$1")
    .replace(/[#*_`>~-]+/g, " ")
    .replace(/https?:\/\/\S+/g, " ")
    .replace(/\[(?:Я|Я,|Люми)[^\]]*\]/g, " ")
    .replace(/\s{2,}/g, " ")
    .trim()
    .slice(0, 900);
}

function speakBrowser(text: string, onEnd?: () => void) {
  try {
    const u = new SpeechSynthesisUtterance(text);
    u.lang = "ru-RU";
    u.rate = 1.04;
    u.pitch = 1.18;
    u.onend = () => onEnd?.();
    u.onerror = () => onEnd?.();
    window.speechSynthesis.speak(u);
  } catch {
    onEnd?.();
  }
}

/** Озвучить текст голосом Люми. Возвращает true, если воспроизведение стартовало. */
export function speakText(text: string, onEnd?: () => void): boolean {
  if (typeof window === "undefined") return false;
  const clean = cleanForSpeech(text);
  if (!clean) return false;
  stopLumiVoice();
  const audio = new Audio(`/api/tts?text=${encodeURIComponent(clean)}`);
  currentAudio = audio;
  let fellBack = false;
  const fallback = () => {
    if (fellBack) return;
    fellBack = true;
    try {
      audio.pause();
    } catch {
      /* ignore */
    }
    if (currentAudio === audio) currentAudio = null;
    speakBrowser(clean, onEnd);
  };
  audio.onerror = fallback;
  audio.onended = () => {
    if (currentAudio === audio) currentAudio = null;
    if (!fellBack) onEnd?.();
  };
  audio.play().catch(fallback);
  return true;
}

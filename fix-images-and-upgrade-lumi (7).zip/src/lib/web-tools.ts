// Real internet access for the assistant: web search, page reading, live data.
// Everything runs server-side via public endpoints that need no API keys.

const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36";

export interface WebSearchResult {
  title: string;
  url: string;
  snippet: string;
}

function decodeEntities(input: string): string {
  return input
    .replace(/<[^>]+>/g, "")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#x27;/g, "'")
    .replace(/&#39;/g, "'")
    .replace(/&nbsp;/g, " ")
    .replace(/&#(\d+);/g, (_, code) => String.fromCharCode(Number(code)))
    .replace(/\s+/g, " ")
    .trim();
}

function resolveDdgUrl(raw: string): string {
  const match = raw.match(/[?&]uddg=([^&]+)/);
  if (match) {
    try {
      return decodeURIComponent(match[1]);
    } catch {
      return raw;
    }
  }
  return raw.startsWith("//") ? `https:${raw}` : raw;
}

export async function webSearch(query: string, limit = 6): Promise<WebSearchResult[]> {
  const results: WebSearchResult[] = [];
  const seen = new Set<string>();

  const pushUnique = (r: WebSearchResult) => {
    if (r.url.startsWith("http") && !seen.has(r.url) && r.title) {
      seen.add(r.url);
      results.push(r);
    }
  };

  // DuckDuckGo HTML — real, current web results
  try {
    const res = await fetch(`https://html.duckduckgo.com/html/?q=${encodeURIComponent(query)}`, {
      headers: { "User-Agent": UA, "Accept-Language": "ru,en;q=0.8" },
      signal: AbortSignal.timeout(11000),
    });
    if (res.ok) {
      const html = await res.text();
      const re =
        /<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>[\s\S]*?class="result__snippet"[^>]*>([\s\S]*?)<\/a>/g;
      let m: RegExpExecArray | null;
      while ((m = re.exec(html)) && results.length < limit) {
        pushUnique({ url: resolveDdgUrl(m[1]), title: decodeEntities(m[2]), snippet: decodeEntities(m[3]) });
      }
    }
  } catch {
    // fall through
  }

  // Wikipedia backup / supplement
  if (results.length < 3) {
    try {
      const res = await fetch(
        `https://ru.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(
          query
        )}&format=json&srlimit=${limit}&origin=*`,
        { headers: { "User-Agent": UA }, signal: AbortSignal.timeout(9000) }
      );
      if (res.ok) {
        const data = await res.json();
        for (const item of data?.query?.search || []) {
          pushUnique({
            title: item.title,
            url: `https://ru.wikipedia.org/wiki/${encodeURIComponent(item.title.replace(/ /g, "_"))}`,
            snippet: decodeEntities(item.snippet || ""),
          });
        }
      }
    } catch {
      // give up silently
    }
  }

  return results.slice(0, limit);
}

export async function readPage(url: string, maxChars = 3200): Promise<string> {
  try {
    const res = await fetch(url, {
      headers: { "User-Agent": UA, "Accept-Language": "ru,en;q=0.8" },
      signal: AbortSignal.timeout(12000),
    });
    if (!res.ok) return "";
    const contentType = res.headers.get("content-type") || "";
    if (!contentType.includes("text/html") && !contentType.includes("text/plain")) return "";
    let html = await res.text();
    html = html
      .replace(/<script[\s\S]*?<\/script>/gi, " ")
      .replace(/<style[\s\S]*?<\/style>/gi, " ")
      .replace(/<noscript[\s\S]*?<\/noscript>/gi, " ")
      .replace(/<nav[\s\S]*?<\/nav>/gi, " ")
      .replace(/<footer[\s\S]*?<\/footer>/gi, " ")
      .replace(/<header[\s\S]*?<\/header>/gi, " ");
    return decodeEntities(html).slice(0, maxChars);
  } catch {
    return "";
  }
}

// -------------------------------------------------------------------- time

export async function getPreciseTime(): Promise<string> {
  // Try a real internet time source first
  try {
    const res = await fetch("https://timeapi.io/api/Time/current/zone?timeZone=Europe/Moscow", {
      signal: AbortSignal.timeout(6000),
    });
    if (res.ok) {
      const d = await res.json();
      if (typeof d.hour === "number") {
        const hh = String(d.hour).padStart(2, "0");
        const mm = String(d.minute).padStart(2, "0");
        const ss = String(d.seconds ?? 0).padStart(2, "0");
        const weekday = new Date(d.dateTime).toLocaleDateString("ru-RU", { weekday: "long", timeZone: "Europe/Moscow" });
        const dateStr = new Date(d.dateTime).toLocaleDateString("ru-RU", {
          day: "numeric",
          month: "long",
          year: "numeric",
          timeZone: "Europe/Moscow",
        });
        return `Точное текущее время (источник: timeapi.io, часовой пояс Москва, UTC+3): ${hh}:${mm}:${ss}, ${weekday}, ${dateStr}.`;
      }
    }
  } catch {
    // fall back to server clock
  }

  const now = new Date();
  const dateStr = now.toLocaleDateString("ru-RU", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
    timeZone: "Europe/Moscow",
  });
  const timeStr = now.toLocaleTimeString("ru-RU", {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    timeZone: "Europe/Moscow",
  });
  return `Точное текущее время (часовой пояс Москва, UTC+3): ${timeStr}, ${dateStr}.`;
}

// -------------------------------------------------------------------- weather

export async function getWeather(place: string): Promise<string> {
  try {
    const geo = await fetch(
      `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(place)}&count=1&language=ru`,
      { signal: AbortSignal.timeout(8000) }
    );
    const geoData = await geo.json();
    const spot = geoData?.results?.[0];
    if (!spot) return "";
    const res = await fetch(
      `https://api.open-meteo.com/v1/forecast?latitude=${spot.latitude}&longitude=${spot.longitude}&current=temperature_2m,apparent_temperature,relative_humidity_2m,wind_speed_10m,weather_code&timezone=auto`,
      { signal: AbortSignal.timeout(8000) }
    );
    const data = await res.json();
    const c = data?.current;
    if (!c) return "";
    const codes: Record<number, string> = {
      0: "ясно", 1: "преимущественно ясно", 2: "переменная облачность", 3: "пасмурно",
      45: "туман", 48: "изморозь", 51: "морось", 61: "дождь", 63: "дождь", 65: "сильный дождь",
      71: "снег", 73: "снег", 75: "сильный снег", 80: "ливень", 95: "гроза",
    };
    return `Актуальная погода в «${spot.name}${spot.country ? ", " + spot.country : ""}» (источник: open-meteo, сейчас): ${Math.round(
      c.temperature_2m
    )}°C (ощущается ${Math.round(c.apparent_temperature)}°C), ${codes[c.weather_code] || "переменно"}, влажность ${
      c.relative_humidity_2m
    }%, ветер ${Math.round(c.wind_speed_10m)} км/ч.`;
  } catch {
    return "";
  }
}

// -------------------------------------------------------------------- planner

export interface ToolPlan {
  useSearch: boolean;
  query: string;
  weatherPlace: string | null;
  wantsTime: boolean;
}

const TIME_TRIGGERS = [
  "который час", "сколько времени", "сколько сейчас времени", "сколько щас времени",
  "какое сегодня число", "какое сейчас число", "какая сейчас дата", "какое число",
  "точное время", "текущее время", "время сейчас", "сейчас времени", "какой сегодня день",
  "какой сейчас год", "какое время", "дата сегодня", "сегодняшняя дата",
  "current time", "what time", "what is the date", "today's date", "what day is",
];

const WEATHER_TRIGGERS = ["погод", "температура на улице", "weather", "прогноз"];

const SEARCH_TRIGGERS = [
  "новост", "актуальн", "последн", "курс", "цена", "стоимость", "сколько стоит",
  "кто такой", "кто такая", "что такое", "когда выйдет", "когда вышел", "когда состоится",
  "результат матча", "счёт", "погугли", "загугли", "найди", "поиск", "search", "google",
  "в 2024", "в 2025", "в 2026", "расписание", "релиз", "обновлени", "последняя версия",
  "who is", "what is", "latest", "news", "current", "price of", "статистик", "рейтинг",
];

const NO_SEARCH_HINTS = ["напиши код", "напиши функ", "переведи", "придумай", "сочини", "нарисуй"];

export function planTools(prompt: string): ToolPlan {
  const lower = prompt.toLowerCase();
  const wantsTime = TIME_TRIGGERS.some((t) => lower.includes(t));

  let weatherPlace: string | null = null;
  if (WEATHER_TRIGGERS.some((t) => lower.includes(t))) {
    const match = prompt.match(/погод[аеуы][^,.?!]*?(?:в|во|на)\s+([A-Za-zА-Яа-яЁё\- ]{2,40})/i);
    weatherPlace = match ? match[1].trim() : "Москва";
  }

  const explicitSearch = /погугли|загугли|найди в интернете|поиск в интернете|search the web|google/i.test(lower);

  // «Голый» запрос-название (2–5 слов, есть слово с заглавной буквы, нет команд) —
  // например «Эмилия ре зеро». Чтобы модель не гадала — подкладываем веб-факты.
  const words = prompt.trim().split(/\s+/);
  const hasProperNoun = words.some((w) => w.length >= 4 && /^[A-ZА-ЯЁ]/.test(w));
  const bareEntity = !explicitSearch && words.length >= 2 && words.length <= 5 && hasProperNoun && !/[?]$/.test(prompt.trim()) && !NO_SEARCH_HINTS.some((h) => lower.includes(h));

  const blocked = NO_SEARCH_HINTS.some((h) => lower.includes(h));
  const useSearch = explicitSearch || bareEntity || (!blocked && SEARCH_TRIGGERS.some((t) => lower.includes(t)));

  return { useSearch, query: prompt.slice(0, 220), weatherPlace, wantsTime };
}

export async function gatherContext(
  prompt: string,
  emit: (text: string) => void
): Promise<{ context: string; sources: WebSearchResult[] } | null> {
  const plan = planTools(prompt);
  const chunks: string[] = [];
  let sources: WebSearchResult[] = [];

  if (plan.wantsTime) {
    emit("Уточняю точное время…");
    chunks.push(await getPreciseTime());
  }

  if (plan.weatherPlace) {
    emit(`Смотрю погоду: ${plan.weatherPlace}`);
    const weather = await getWeather(plan.weatherPlace);
    if (weather) chunks.push(weather);
  }

  if (plan.useSearch) {
    emit("Ищу в интернете…");
    sources = await webSearch(plan.query, 6);
    if (sources.length > 0) {
      emit(`Читаю источники (${sources.length})`);
      const top = sources.slice(0, 3);
      const pages = await Promise.all(top.map((s) => readPage(s.url, 2000)));
      const lines = sources.map((s, i) => {
        const body = pages[i] ? ` Выдержка: ${pages[i].slice(0, 650)}` : "";
        return `[${i + 1}] ${s.title} — ${s.url}\n${s.snippet}${body}`;
      });
      chunks.push("Результаты веб-поиска в реальном времени:\n" + lines.join("\n\n"));
    }
  }

  if (chunks.length === 0) return null;

  const context = [
    "СИСТЕМНЫЙ КОНТЕКСТ С ЖИВЫМИ ДАННЫМИ ИЗ ИНТЕРНЕТА (получены ПРЯМО СЕЙЧАС встроенными инструментами).",
    "Обязательно используй эти данные как факты. Если спросили время или дату — назови ТОЧНОЕ значение из блока ниже, не пиши «время не указано». Не утверждай, что у тебя нет доступа к сети.",
    "",
    chunks.join("\n\n"),
  ].join("\n");

  return { context, sources };
}

// ═══════════════════════════════════════════════════════════════════════════
// ИИ ВЕБ-АГЕНТ: глубокое исследование темы в реальном интернете.
// Многошаговый цикл: разбиваем тему на запросы → ищем → читаем страницы →
// собираем полный факт-контекст с источниками для финальной модели.
// Триггер: «исследуй», «сделай ресёрч», «глубокий анализ», «агент:», deep research…
// ═══════════════════════════════════════════════════════════════════════════

export function detectAgentIntent(prompt: string): boolean {
  const l = prompt.toLowerCase();
  return (
    /(^|\s)агент[:\s]/.test(l) ||
    /исследу|ресёрч|ресеарч|deep research|разбери тему|глубокий анализ|подробный разбор|веб[- ]агент|интернет[- ]агент|собери инфу|собери информацию|сравни варианты|проведи анализ/i.test(l)
  );
}

function buildAgentQueries(prompt: string): string[] {
  // Чистим командные слова: «Исследуй: что…» → «что…»
  const topic = prompt
    .replace(/(^|\s)агент[:\s]+/i, " ")
    .replace(/^\s*(можешь\s+)?(исследуй(те)?( тему)?|разбери( тему)?|сделай(те)? (полный )?(анализ|ресёрч|ресеарч|обзор)|проанализируй(те)?|проведи(те)? (полный |глубокий )?(анализ|исследование)|подробно разбери|собери(те)? (инфу|информацию|материал)|изучи(те)?|веб[- ]агент|интернет[- ]агент)\s*[,:.!\-–]*\s*/i, "")
    .replace(/(проведи|сделай|собери|разбери|напиши)?\s*(полный|подробный|глубокий|детальный)?\s*(анализ|ресёрч|ресеарч|исследование|deep research|обзор|разбор)/gi, " ")
    .replace(/\s{2,}/g, " ")
    .trim();

  const year = new Date().getFullYear();
  const queries = [topic];
  // Умные подзапросы в зависимости от темы
  if (/аниме|манга|ранобэ|сериал|фильм|игра/i.test(topic)) {
    queries.push(`${topic} обзор рейтинг ${year}`, `${topic} отзывы обсуждение`);
  } else if (/цена|стоимость|купить/i.test(topic)) {
    queries.push(`${topic} цена ${year}`, `${topic} где купить сравнение`);
  } else if (/код|api|фреймворк|библиотека|typescript|python/i.test(topic)) {
    queries.push(`${topic} документация примеры ${year}`, `${topic} best practices`);
  } else {
    queries.push(`${topic} последние новости ${year}`, `${topic} ключевые факты`);
  }
  return queries.slice(0, 3);
}

export async function gatherAgentContext(
  prompt: string,
  emit: (text: string) => void
): Promise<{ context: string; sources: WebSearchResult[] } | null> {
  const queries = buildAgentQueries(prompt);

  emit(`Агент: ставлю цели (${queries.length} направления…)`);
  emit(`Агент: ищу «${queries[0].slice(0, 60)}»…`);

  const searchBatches: WebSearchResult[][] = [];
  for (let i = 0; i < queries.length; i++) {
    const batch = await webSearch(queries[i], 5);
    searchBatches.push(batch);
    if (i < queries.length - 1) emit(`Агент: проверяю «${queries[i + 1].slice(0, 60)}»…`);
  }

  // дедупликация источников
  const seen = new Set<string>();
  const sources: WebSearchResult[] = [];
  for (const batch of searchBatches) {
    for (const s of batch) {
      if (!seen.has(s.url)) {
        seen.add(s.url);
        sources.push(s);
      }
    }
  }
  // Если по плановым запросам пусто — добиваем широким поиском по сырой теме
  if (sources.length < 2) {
    emit("Агент: расширяю поиск…");
    const extra = await webSearch(queries[0] || prompt, 5);
    for (const s of extra) {
      if (!seen.has(s.url)) {
        seen.add(s.url);
        sources.push(s);
      }
    }
  }
  if (!sources.length) return null;

  emit(`Агент: читаю ${Math.min(5, sources.length)} источников…`);
  const top = sources.slice(0, 5);
  const pages = await Promise.all(top.map((s) => readPage(s.url, 2600)));

  const blocks = sources.map((s, i) => {
    const page = pages[i];
    const excerpt = page ? `\nВыдержка: ${page.slice(0, 700)}` : "";
    return `[${i + 1}] ${s.title}\nСсылка: ${s.url}\n${s.snippet}${excerpt}`;
  });

  emit("Агент: свожу выводы…");

  const sourceList = sources
    .slice(0, 8)
    .map((s, i) => `[${i + 1}] ${s.title} — ${s.url}`)
    .join("\\n");

  const context = [
    "АГЕНТНАЯ РАЗВЕДКА ЗАВЕРШЕНА. Ниже — свежие факты из реального интернета, собранные многошаговым веб-агентом ПРЯМО СЕЙЧАС.",
    "Инструкция: дай ЛУЧШИЙ структурированный разбор по собранным данным: с выводами, сравнениями и деталями. Не выдумывай цифры. В конце добавь блок «Источники:» со списком ссылок из перечня ниже (маркдаун-ссылки). Ссылайся на факты как [1], [2]… по номерам источников.",
    "",
    "ФАКТЫ С РАЗМЕТКОЙ ИСТОЧНИКОВ:",
    blocks.join("\\n\\n"),
    "",
    "ПЕРЕЧЕНЬ ИСТОЧНИКОВ ДЛЯ БЛОКА В КОНЦЕ:",
    sourceList,
  ].join("\\n");

  return { context, sources };
}

// GitHub integration: the user pastes a Personal Access Token, we store it
// server-side (in DB), and the assistant can read/write code in their repos.

import { db } from "@/db";
import { githubTokens } from "@/db/schema";
import { eq } from "drizzle-orm";

const GH_API = "https://api.github.com";
const UA = "AETHER-Assistant";

export interface GithubUser {
  login: string;
  name: string | null;
  avatarUrl: string;
}

async function ghFetch(token: string, path: string, init?: RequestInit) {
  return fetch(`${GH_API}${path}`, {
    ...init,
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: "application/vnd.github+json",
      "X-GitHub-Api-Version": "2022-11-28",
      "User-Agent": UA,
      ...(init?.headers || {}),
    },
    signal: init?.signal ?? AbortSignal.timeout(15000),
  });
}

export async function verifyToken(token: string): Promise<GithubUser | null> {
  try {
    const res = await ghFetch(token, "/user");
    if (!res.ok) return null;
    const u = await res.json();
    return { login: u.login, name: u.name, avatarUrl: u.avatar_url };
  } catch {
    return null;
  }
}

// -- persistence (single shared slot, id=1) --

export async function saveToken(token: string, user: GithubUser) {
  await db
    .insert(githubTokens)
    .values({ id: 1, token, login: user.login, name: user.name, avatarUrl: user.avatarUrl, updatedAt: new Date() })
    .onConflictDoUpdate({
      target: githubTokens.id,
      set: { token, login: user.login, name: user.name, avatarUrl: user.avatarUrl, updatedAt: new Date() },
    });
}

export async function getStoredToken(): Promise<{ token: string; user: GithubUser } | null> {
  const [row] = await db.select().from(githubTokens).where(eq(githubTokens.id, 1));
  if (!row) return null;
  return { token: row.token, user: { login: row.login, name: row.name, avatarUrl: row.avatarUrl } };
}

export async function clearToken() {
  await db.delete(githubTokens).where(eq(githubTokens.id, 1));
}

// -- repo operations --

export interface RepoInfo {
  fullName: string;
  name: string;
  private: boolean;
  defaultBranch: string;
  description: string | null;
  updatedAt: string;
  language: string | null;
}

function mapRepo(r: Record<string, unknown>): RepoInfo {
  return {
    fullName: String(r.full_name),
    name: String(r.name),
    private: Boolean(r.private),
    defaultBranch: String(r.default_branch || "main"),
    description: (r.description as string) || null,
    updatedAt: String(r.updated_at || ""),
    language: (r.language as string) || null,
  };
}

export async function listRepos(token: string): Promise<RepoInfo[]> {
  const seen = new Set<string>();
  const out: RepoInfo[] = [];
  const add = (arr: unknown) => {
    if (!Array.isArray(arr)) return;
    for (const r of arr as Array<Record<string, unknown>>) {
      if (r && r.full_name && !seen.has(String(r.full_name))) {
        seen.add(String(r.full_name));
        out.push(mapRepo(r));
      }
    }
  };

  // 1) Classic listing (works for classic tokens & fine-grained with repo access)
  for (let page = 1; page <= 4; page++) {
    try {
      const res = await ghFetch(token, `/user/repos?per_page=100&page=${page}&sort=updated`);
      if (!res.ok) break;
      const data = await res.json();
      if (!Array.isArray(data) || data.length === 0) break;
      add(data);
      if (data.length < 100) break;
    } catch {
      break;
    }
  }

  // 2) Fine-grained tokens sometimes only surface repos via /installation/repositories
  if (out.length === 0) {
    try {
      const res = await ghFetch(token, "/installation/repositories?per_page=100");
      if (res.ok) {
        const data = await res.json();
        add(data.repositories);
      }
    } catch {
      /* ignore */
    }
  }

  // 3) Last resort: list the authed user's own repos explicitly
  if (out.length === 0) {
    try {
      const me = await verifyToken(token);
      if (me) {
        const res = await ghFetch(token, `/users/${me.login}/repos?per_page=100&sort=updated`);
        if (res.ok) add(await res.json());
      }
    } catch {
      /* ignore */
    }
  }

  return out;
}

export interface TreeItem {
  path: string;
  type: "blob" | "tree";
  size?: number;
}

export async function listTree(token: string, fullName: string, branch: string): Promise<TreeItem[]> {
  const res = await ghFetch(token, `/repos/${fullName}/git/trees/${encodeURIComponent(branch)}?recursive=1`);
  if (!res.ok) return [];
  const data = await res.json();
  return (data.tree || [])
    .filter((t: Record<string, unknown>) => t.type === "blob" || t.type === "tree")
    .map((t: Record<string, unknown>) => ({ path: String(t.path), type: t.type as "blob" | "tree", size: Number(t.size || 0) }))
    .slice(0, 500);
}

export async function readFile(
  token: string,
  fullName: string,
  path: string,
  branch: string
): Promise<{ content: string; sha: string } | null> {
  const res = await ghFetch(token, `/repos/${fullName}/contents/${encodeURIComponent(path)}?ref=${encodeURIComponent(branch)}`);
  if (!res.ok) return null;
  const data = await res.json();
  if (Array.isArray(data) || !data.content) return null;
  const content = Buffer.from(data.content, "base64").toString("utf-8");
  return { content, sha: data.sha };
}

export async function writeFile(params: {
  token: string;
  fullName: string;
  path: string;
  branch: string;
  content: string;
  message: string;
}): Promise<{ ok: boolean; commitUrl?: string; error?: string }> {
  const { token, fullName, path, branch, content, message } = params;
  // Need the current sha if the file exists
  let sha: string | undefined;
  const existing = await readFile(token, fullName, path, branch);
  if (existing) sha = existing.sha;

  const res = await ghFetch(token, `/repos/${fullName}/contents/${encodeURIComponent(path)}`, {
    method: "PUT",
    body: JSON.stringify({
      message,
      content: Buffer.from(content, "utf-8").toString("base64"),
      branch,
      ...(sha ? { sha } : {}),
    }),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    return { ok: false, error: err.message || `HTTP ${res.status}` };
  }
  const data = await res.json();
  return { ok: true, commitUrl: data.commit?.html_url };
}

export async function listOpenIssues(token: string, fullName: string) {
  const res = await ghFetch(token, `/repos/${fullName}/issues?state=open&per_page=10`);
  if (!res.ok) return [];
  const data = await res.json();
  return (data as Array<Record<string, unknown>>)
    .filter((i) => !i.pull_request)
    .map((i) => ({ number: Number(i.number), title: String(i.title), body: (i.body as string) || "" }));
}

export async function createIssue(token: string, fullName: string, title: string, body: string) {
  const res = await ghFetch(token, `/repos/${fullName}/issues`, {
    method: "POST",
    body: JSON.stringify({ title, body }),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    return { ok: false, error: err.message || `HTTP ${res.status}` };
  }
  const data = await res.json();
  return { ok: true, url: data.html_url, number: data.number };
}

// -- GitHub Actions / workflows (build APKs, CI, etc.) --

export interface WorkflowInfo { id: number; name: string; path: string; state: string }

export async function listWorkflows(token: string, fullName: string): Promise<WorkflowInfo[]> {
  const res = await ghFetch(token, `/repos/${fullName}/actions/workflows`);
  if (!res.ok) return [];
  const data = await res.json();
  return (data.workflows || []).map((w: Record<string, unknown>) => ({
    id: Number(w.id),
    name: String(w.name),
    path: String(w.path),
    state: String(w.state),
  }));
}

export async function dispatchWorkflow(
  token: string,
  fullName: string,
  workflowFile: string,
  ref: string
): Promise<{ ok: boolean; error?: string }> {
  // A freshly committed workflow needs a moment to register with Actions, so
  // retry on 404/422 (workflow registration lag) before giving up.
  let lastErr = "";
  for (let attempt = 0; attempt < 15; attempt++) {
    const res = await ghFetch(token, `/repos/${fullName}/actions/workflows/${encodeURIComponent(workflowFile)}/dispatches`, {
      method: "POST",
      body: JSON.stringify({ ref }),
    });
    if (res.status === 204) return { ok: true };
    const err = await res.json().catch(() => ({}));
    lastErr = err.message || `HTTP ${res.status}`;
    // 404 = workflow not yet registered; 422 = trigger not yet recognized.
    // Both happen right after committing a new/updated workflow file → retry.
    if (res.status === 404 || res.status === 422) {
      await new Promise((r) => setTimeout(r, 4000));
      continue;
    }
    return { ok: false, error: lastErr };
  }
  return { ok: false, error: lastErr };
}

// Get IDs of the most recent runs (to detect which run a dispatch created).
async function getRecentRunIds(token: string, fullName: string): Promise<Set<number>> {
  const runs = await listRuns(token, fullName, 15);
  return new Set(runs.map((r) => r.id));
}

// Resolve a workflow's numeric id from its file name (e.g. "build-apk.yml").
export async function getWorkflowId(token: string, fullName: string, workflowFile: string): Promise<number | null> {
  const wfs = await listWorkflows(token, fullName);
  const found = wfs.find((w) => w.path.endsWith(workflowFile) || w.path.split("/").pop() === workflowFile);
  return found ? found.id : null;
}

// List runs for ONE specific workflow only (so other workflows don't confuse us).
export async function listWorkflowRuns(token: string, fullName: string, workflowId: number, limit = 10): Promise<WorkflowRun[]> {
  const res = await ghFetch(token, `/repos/${fullName}/actions/workflows/${workflowId}/runs?per_page=${limit}`);
  if (!res.ok) return [];
  const data = await res.json();
  return (data.workflow_runs || []).map((r: Record<string, unknown>) => ({
    id: Number(r.id),
    name: String(r.name || r.display_title || "run"),
    status: String(r.status),
    conclusion: (r.conclusion as string) || null,
    htmlUrl: String(r.html_url),
    createdAt: String(r.created_at),
  }));
}

// Commit MANY files in ONE atomic commit (via Git Trees API) — avoids the
// storm of separate push runs that individual file writes cause.
export async function commitFiles(params: {
  token: string;
  fullName: string;
  branch: string;
  files: { path: string; content: string }[];
  message: string;
}): Promise<{ ok: boolean; commitUrl?: string; error?: string }> {
  const { token, fullName, branch, files, message } = params;
  try {
    // 1) get the latest commit + base tree
    const refRes = await ghFetch(token, `/repos/${fullName}/git/ref/heads/${encodeURIComponent(branch)}`);
    if (!refRes.ok) return { ok: false, error: `ref: HTTP ${refRes.status}` };
    const ref = await refRes.json();
    const baseCommitSha = ref.object.sha;
    const commitRes = await ghFetch(token, `/repos/${fullName}/git/commits/${baseCommitSha}`);
    const baseCommit = await commitRes.json();
    const baseTreeSha = baseCommit.tree.sha;

    // 2) create blobs
    const treeItems = [];
    for (const f of files) {
      const blobRes = await ghFetch(token, `/repos/${fullName}/git/blobs`, {
        method: "POST",
        body: JSON.stringify({ content: Buffer.from(f.content, "utf-8").toString("base64"), encoding: "base64" }),
      });
      if (!blobRes.ok) return { ok: false, error: `blob ${f.path}: HTTP ${blobRes.status}` };
      const blob = await blobRes.json();
      treeItems.push({ path: f.path, mode: "100644", type: "blob", sha: blob.sha });
    }

    // 3) create tree
    const treeRes = await ghFetch(token, `/repos/${fullName}/git/trees`, {
      method: "POST",
      body: JSON.stringify({ base_tree: baseTreeSha, tree: treeItems }),
    });
    if (!treeRes.ok) return { ok: false, error: `tree: HTTP ${treeRes.status}` };
    const tree = await treeRes.json();

    // 4) create commit
    const newCommitRes = await ghFetch(token, `/repos/${fullName}/git/commits`, {
      method: "POST",
      body: JSON.stringify({ message, tree: tree.sha, parents: [baseCommitSha] }),
    });
    if (!newCommitRes.ok) return { ok: false, error: `commit: HTTP ${newCommitRes.status}` };
    const newCommit = await newCommitRes.json();

    // 5) move the branch ref
    const updRes = await ghFetch(token, `/repos/${fullName}/git/refs/heads/${encodeURIComponent(branch)}`, {
      method: "PATCH",
      body: JSON.stringify({ sha: newCommit.sha, force: false }),
    });
    if (!updRes.ok) return { ok: false, error: `ref update: HTTP ${updRes.status}` };
    return { ok: true, commitUrl: newCommit.html_url };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "commit failed" };
  }
}

// Delete a workflow file (used to remove leftover/interfering workflows).
export async function deleteFile(token: string, fullName: string, path: string, branch: string, message: string): Promise<boolean> {
  const existing = await readFile(token, fullName, path, branch);
  if (!existing) return true; // already gone
  const res = await ghFetch(token, `/repos/${fullName}/contents/${encodeURIComponent(path)}`, {
    method: "DELETE",
    body: JSON.stringify({ message, sha: existing.sha, branch }),
  });
  return res.ok;
}

// Wait until GitHub has registered the workflow file (so dispatch won't 422).
async function waitForWorkflowRegistered(token: string, fullName: string, workflowFile: string, signal?: AbortSignal) {
  for (let i = 0; i < 20; i++) {
    if (signal?.aborted) break;
    const wfs = await listWorkflows(token, fullName);
    const found = wfs.find((w) => w.path.endsWith(workflowFile) || w.path.split("/").pop() === workflowFile);
    if (found && found.state === "active") return true;
    await new Promise((r) => setTimeout(r, 4000));
  }
  return false;
}

// Dispatch a workflow and return the EXACT run it created (by diffing run IDs).
export async function dispatchAndTrack(
  token: string,
  fullName: string,
  workflowFile: string,
  ref: string,
  signal?: AbortSignal
): Promise<{ ok: boolean; runId?: number; error?: string }> {
  // Ensure GitHub has indexed the (possibly just-committed) workflow first.
  await waitForWorkflowRegistered(token, fullName, workflowFile, signal);
  const before = await getRecentRunIds(token, fullName);
  const disp = await dispatchWorkflow(token, fullName, workflowFile, ref);
  if (!disp.ok) return { ok: false, error: disp.error };

  // Poll for a NEW run id that wasn't there before the dispatch.
  for (let i = 0; i < 20; i++) {
    if (signal?.aborted) break;
    await new Promise((r) => setTimeout(r, 3000));
    const runs = await listRuns(token, fullName, 15);
    const fresh = runs.find((r) => !before.has(r.id));
    if (fresh) return { ok: true, runId: fresh.id };
  }
  return { ok: true }; // dispatched but couldn't pin the id
}

// Trigger the APK build via PUSH and track the EXACT run of the build-apk
// workflow ONLY (ignores any other workflow like deploy/pages).
export async function triggerBuildByPush(
  token: string,
  fullName: string,
  branch: string,
  workflowFile: string,
  signal?: AbortSignal
): Promise<{ ok: boolean; runId?: number; error?: string }> {
  const wfId = await getWorkflowId(token, fullName, workflowFile);
  if (!wfId) return { ok: false, error: `Workflow ${workflowFile} не найден` };

  const beforeRuns = await listWorkflowRuns(token, fullName, wfId, 10);
  const before = new Set(beforeRuns.map((r) => r.id));

  const marker = `.aether/build-${Date.now()}.txt`;
  const write = await writeFile({
    token,
    fullName,
    path: marker,
    branch,
    content: `AETHER build trigger ${new Date().toISOString()}\n`,
    message: "AETHER: trigger APK build",
  });
  if (!write.ok) return { ok: false, error: write.error };

  // Find the NEW run of THIS workflow only
  for (let i = 0; i < 30; i++) {
    if (signal?.aborted) break;
    await new Promise((r) => setTimeout(r, 3000));
    const runs = await listWorkflowRuns(token, fullName, wfId, 10);
    const fresh = runs.find((r) => !before.has(r.id));
    if (fresh) return { ok: true, runId: fresh.id };
  }
  return { ok: false, error: "Не удалось отследить запуск сборки" };
}

export interface WorkflowRun {
  id: number;
  name: string;
  status: string; // queued | in_progress | completed
  conclusion: string | null; // success | failure | null
  htmlUrl: string;
  createdAt: string;
}

export async function listRuns(token: string, fullName: string, limit = 5): Promise<WorkflowRun[]> {
  const res = await ghFetch(token, `/repos/${fullName}/actions/runs?per_page=${limit}`);
  if (!res.ok) return [];
  const data = await res.json();
  return (data.workflow_runs || []).map((r: Record<string, unknown>) => ({
    id: Number(r.id),
    name: String(r.name || r.display_title || "run"),
    status: String(r.status),
    conclusion: (r.conclusion as string) || null,
    htmlUrl: String(r.html_url),
    createdAt: String(r.created_at),
  }));
}

export async function getLatestRun(token: string, fullName: string): Promise<WorkflowRun | null> {
  const runs = await listRuns(token, fullName, 1);
  return runs[0] || null;
}

// Number of jobs a run has. 0 jobs on a completed-failure run means Actions
// never actually started (usually exhausted free minutes / spending limit).
export async function countRunJobs(token: string, fullName: string, runId: number): Promise<number> {
  const res = await ghFetch(token, `/repos/${fullName}/actions/runs/${runId}/jobs`);
  if (!res.ok) return -1;
  const data = await res.json();
  return Array.isArray(data.jobs) ? data.jobs.length : 0;
}

export async function getRun(token: string, fullName: string, runId: number): Promise<WorkflowRun | null> {
  const res = await ghFetch(token, `/repos/${fullName}/actions/runs/${runId}`);
  if (!res.ok) return null;
  const r = await res.json();
  return {
    id: Number(r.id),
    name: String(r.name || r.display_title || "run"),
    status: String(r.status),
    conclusion: (r.conclusion as string) || null,
    htmlUrl: String(r.html_url),
    createdAt: String(r.created_at),
  };
}

// Wait for a SPECIFIC run id to truly reach status "completed". This is the
// reliable way — we poll that exact run, never guess by timestamp.
export async function waitForRunId(
  token: string,
  fullName: string,
  runId: number,
  onTick?: (run: WorkflowRun) => void,
  opts?: { maxWaitMs?: number; signal?: AbortSignal }
): Promise<WorkflowRun | null> {
  const maxWait = opts?.maxWaitMs ?? 20 * 60 * 1000; // up to 20 min
  const start = Date.now();
  let target: WorkflowRun | null = null;

  while (Date.now() - start < maxWait) {
    if (opts?.signal?.aborted) break;
    await new Promise((r) => setTimeout(r, 6000));
    const run = await getRun(token, fullName, runId);
    if (run) {
      target = run;
      onTick?.(run);
      // Only stop when GitHub says the runner is fully finished.
      if (run.status === "completed") return run;
    }
  }
  return target; // may still be in progress if it exceeded maxWait
}

// Get failed step logs (trimmed) so the agent can fix build errors itself.
export async function getFailedLogs(token: string, fullName: string, runId: number, maxChars = 6000): Promise<string> {
  try {
    const res = await ghFetch(token, `/repos/${fullName}/actions/runs/${runId}/logs`, {
      // logs endpoint returns a redirect to a zip; follow it
      redirect: "follow",
    });
    if (!res.ok) {
      // Fallback: read jobs → steps to at least name the failing step
      const jobsRes = await ghFetch(token, `/repos/${fullName}/actions/runs/${runId}/jobs`);
      if (jobsRes.ok) {
        const jd = await jobsRes.json();
        const j = jd.jobs?.[0];
        if (j) {
          const failed = (j.steps || []).filter((s: Record<string, unknown>) => s.conclusion === "failure").map((s: Record<string, unknown>) => s.name);
          return `Провалившиеся шаги: ${failed.join(", ") || "неизвестно"}`;
        }
      }
      return "";
    }
    const buf = Buffer.from(await res.arrayBuffer());
    // The zip contains text logs; extract readable ASCII/UTF text lines with errors
    const text = buf.toString("latin1");
    const errorLines = text
      .split(/[\r\n]+/)
      .filter((l) => /error|fail|exception|what went wrong|> task|cannot|unresolved|not found|e: /i.test(l))
      .map((l) => l.replace(/[^\x20-\x7Eа-яА-ЯёЁ]/g, " ").replace(/\s+/g, " ").trim())
      .filter((l) => l.length > 8);
    const uniq = Array.from(new Set(errorLines)).slice(-60);
    return uniq.join("\n").slice(-maxChars);
  } catch {
    return "";
  }
}

export interface ArtifactInfo { id: number; name: string; sizeBytes: number; downloadUrl: string }

export async function listArtifacts(token: string, fullName: string, runId: number): Promise<ArtifactInfo[]> {
  const res = await ghFetch(token, `/repos/${fullName}/actions/runs/${runId}/artifacts`);
  if (!res.ok) return [];
  const data = await res.json();
  return (data.artifacts || []).map((a: Record<string, unknown>) => ({
    id: Number(a.id),
    name: String(a.name),
    sizeBytes: Number(a.size_in_bytes || 0),
    downloadUrl: `https://github.com/${fullName}/actions/runs/${runId}`,
  }));
}

// Parse assistant [[WRITE_FILE: path]]...[[/WRITE_FILE]] blocks into commit ops
export interface WriteOp {
  path: string;
  content: string;
}

export function parseWriteOps(text: string): { ops: WriteOp[]; cleaned: string } {
  const ops: WriteOp[] = [];
  const re = /\[\[\s*WRITE_FILE\s*:\s*([^\]\n]+?)\s*\]\]\n?([\s\S]*?)\[\[\s*\/\s*WRITE_FILE\s*\]\]/gi;
  let m: RegExpExecArray | null;
  while ((m = re.exec(text)) !== null) {
    const path = m[1].trim().replace(/^["'`]|["'`]$/g, "");
    let content = m[2];
    // Strip an optional ```lang fence wrapping the file body
    content = content.replace(/^\s*```[a-zA-Z0-9_+-]*\n/, "").replace(/\n```\s*$/, "");
    if (path) ops.push({ path, content });
  }
  const cleaned = text.replace(re, (_full, p: string) => `📝 Файл \`${p.trim()}\` подготовлен к коммиту.`).trim();
  return { ops, cleaned };
}

// Agent commands the model can emit inline. Returns cleaned text + parsed cmds.
export interface AgentCommand {
  kind: "READ_FILE" | "RUN_WORKFLOW" | "CHECK_BUILD" | "LIST_FILES";
  arg?: string;
}

export function parseAgentCommands(text: string): { commands: AgentCommand[]; cleaned: string } {
  const commands: AgentCommand[] = [];
  let cleaned = text;

  const patterns: Array<[AgentCommand["kind"], RegExp]> = [
    ["READ_FILE", /\[\[\s*READ_FILE\s*:\s*([^\]\n]+?)\s*\]\]/gi],
    ["RUN_WORKFLOW", /\[\[\s*RUN_WORKFLOW\s*(?::\s*([^\]\n]+?))?\s*\]\]/gi],
    ["CHECK_BUILD", /\[\[\s*CHECK_BUILD\s*\]\]/gi],
    ["LIST_FILES", /\[\[\s*LIST_FILES\s*\]\]/gi],
  ];

  for (const [kind, re] of patterns) {
    let m: RegExpExecArray | null;
    const local = new RegExp(re.source, re.flags);
    while ((m = local.exec(text)) !== null) {
      commands.push({ kind, arg: m[1] ? m[1].trim().replace(/^["'`]|["'`]$/g, "") : undefined });
    }
    cleaned = cleaned.replace(re, "").trim();
  }

  return { commands, cleaned };
}

// A ready-to-use Android APK build workflow (GitHub Actions)
export function androidApkWorkflow(): string {
  return `name: Build APK

on:
  workflow_dispatch:
  push:
    branches: [ main, master ]

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'

      - name: Set up Android SDK
        uses: android-actions/setup-android@v3

      - name: Grant execute permission for gradlew
        run: chmod +x ./gradlew || true

      - name: Build debug APK
        run: ./gradlew assembleDebug --stacktrace

      - name: Upload APK artifact
        uses: actions/upload-artifact@v4
        with:
          name: app-debug-apk
          path: app/build/outputs/apk/debug/*.apk
          if-no-files-found: warn
`;
}

/* YumiWatch service worker
 * Стратегии:
 *  - навигация      → network-first с офлайн-фолбэком (обязательно для PWABuilder);
 *  - статика/иконки → stale-while-revalidate;
 *  - постеры        → cache-first с ограничением объёма;
 *  - API/видео      → всегда сеть (никогда не кэшируем потоки и секретные маршруты).
 */

const VERSION = 'v3';
const SHELL_CACHE = `yumi-shell-${VERSION}`;
const ASSET_CACHE = `yumi-assets-${VERSION}`;
const IMAGE_CACHE = `yumi-images-${VERSION}`;
const OFFLINE_URL = '/offline.html';
const IMAGE_LIMIT = 160;

const SHELL = [
  '/',
  OFFLINE_URL,
  '/manifest.webmanifest',
  '/icons/icon-192.png',
  '/icons/icon-512.png',
  '/icons/maskable-512.png',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    (async () => {
      const cache = await caches.open(SHELL_CACHE);
      await Promise.allSettled(SHELL.map((url) => cache.add(new Request(url, { cache: 'reload' }))));
      await self.skipWaiting();
    })(),
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    (async () => {
      const keys = await caches.keys();
      await Promise.all(
        keys
          .filter((k) => k.startsWith('yumi-') && ![SHELL_CACHE, ASSET_CACHE, IMAGE_CACHE].includes(k))
          .map((k) => caches.delete(k)),
      );
      if (self.registration.navigationPreload) {
        await self.registration.navigationPreload.enable();
      }
      await self.clients.claim();
    })(),
  );
});

self.addEventListener('message', (event) => {
  if (event.data === 'SKIP_WAITING') self.skipWaiting();
});

async function trimCache(name, limit) {
  const cache = await caches.open(name);
  const keys = await cache.keys();
  if (keys.length <= limit) return;
  await Promise.all(keys.slice(0, keys.length - limit).map((k) => cache.delete(k)));
}

async function networkFirstNavigation(event) {
  try {
    const preload = await event.preloadResponse;
    if (preload) {
      const cache = await caches.open(SHELL_CACHE);
      cache.put('/', preload.clone()).catch(() => {});
      return preload;
    }
    const fresh = await fetch(event.request);
    const cache = await caches.open(SHELL_CACHE);
    cache.put('/', fresh.clone()).catch(() => {});
    return fresh;
  } catch {
    const cache = await caches.open(SHELL_CACHE);
    return (await cache.match('/')) || (await cache.match(OFFLINE_URL)) || Response.error();
  }
}

async function staleWhileRevalidate(request, cacheName) {
  const cache = await caches.open(cacheName);
  const cached = await cache.match(request);
  const network = fetch(request)
    .then((res) => {
      if (res && res.status === 200 && res.type !== 'opaque') cache.put(request, res.clone()).catch(() => {});
      return res;
    })
    .catch(() => null);
  return cached || (await network) || Response.error();
}

async function cacheFirstImage(request) {
  const cache = await caches.open(IMAGE_CACHE);
  const cached = await cache.match(request);
  if (cached) return cached;
  try {
    const res = await fetch(request);
    if (res && (res.status === 200 || res.type === 'opaque')) {
      cache.put(request, res.clone()).catch(() => {});
      trimCache(IMAGE_CACHE, IMAGE_LIMIT);
    }
    return res;
  } catch {
    return cached || Response.error();
  }
}

self.addEventListener('fetch', (event) => {
  const { request } = event;
  if (request.method !== 'GET') return;

  let url;
  try {
    url = new URL(request.url);
  } catch {
    return;
  }

  // Видео, потоки и внутренние маршруты источников — только сеть
  if (
    url.pathname.startsWith('/api/') ||
    /\.(m3u8|ts|mp4|mpd|m4s|key)$/i.test(url.pathname) ||
    request.destination === 'video' ||
    request.destination === 'audio'
  ) {
    return;
  }

  if (request.mode === 'navigate') {
    event.respondWith(networkFirstNavigation(event));
    return;
  }

  if (url.origin !== self.location.origin) {
    if (request.destination === 'image') event.respondWith(cacheFirstImage(request));
    return;
  }

  if (request.destination === 'image') {
    event.respondWith(cacheFirstImage(request));
    return;
  }

  if (
    request.destination === 'script' ||
    request.destination === 'style' ||
    request.destination === 'font' ||
    url.pathname.startsWith('/_next/static/') ||
    url.pathname === '/manifest.webmanifest'
  ) {
    event.respondWith(staleWhileRevalidate(request, ASSET_CACHE));
  }
});

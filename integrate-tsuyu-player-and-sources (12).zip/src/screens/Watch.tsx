'use client';
import { useEffect, useState } from 'react';
import {
  yummy,
  fetchScreenshots,
  posterUrl,
  cleanDescription,
  formatViews,
  formatDuration,
  SEASONS,
  type AnimeFull,
  type VideoItem,
} from '../api/yummy';
import { Card, ErrorBox, Icon, Row, RowItem, SectionTitle, btn } from '../components/AnimeCard';
import { Player } from '../components/Player';
import { links } from '../hooks/useHashRoute';
import { useFavorites, useHistory, useSettings, useWatched } from '../hooks/useStorage';
import { fmtDateTime, formatCountdown, useNow } from '../lib/countdown';
import { cn } from '../utils/cn';

export function Watch({ slug, params }: { slug: string; params: URLSearchParams }) {
  const [anime, setAnime] = useState<AnimeFull | null>(null);
  const [videos, setVideos] = useState<VideoItem[] | null>(null);
  const [error, setError] = useState('');
  const [descOpen, setDescOpen] = useState(false);
  const { isFav, toggle } = useFavorites();
  const { push, get } = useHistory();
  const { watched, toggle: toggleWatched, reset } = useWatched(slug);
  const { settings, update } = useSettings();

  const saved = get(slug);
  const initialEpisode = params.get('ep') || saved?.episode;
  const initialDubbing = params.get('dub') || saved?.dubbing || settings.preferredDub;
  const [nextEp, setNextEp] = useState<{ ts: number; number: number; total: number } | null>(null);
  const now = useNow(30000);

  // дата выхода следующей серии (для онгоингов)
  useEffect(() => {
    if (!anime || anime.anime_status?.alias !== 'ongoing') return;
    let alive = true;
    yummy
      .schedule()
      .then((s) => {
        if (!alive) return;
        const item = s.find((x) => x.anime_id === anime.anime_id);
        if (item?.episodes?.next_date) {
          setNextEp({ ts: item.episodes.next_date * 1000, number: item.episodes.aired + 1, total: item.episodes.count || 0 });
        }
      })
      .catch(() => {});
    return () => {
      alive = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [anime?.anime_id, anime?.anime_status?.alias]);

  const load = async () => {
    setError('');
    setAnime(null);
    setVideos(null);
    try {
      const a = await yummy.anime(slug);
      setAnime(a);
      document.title = `${a.title} — смотреть онлайн`;
      if (a.videos && a.videos.length) setVideos(a.videos);
      else setVideos(await yummy.videos(a.anime_id).catch(() => [] as VideoItem[]));
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Не удалось загрузить');
    }
  };

  useEffect(() => {
    load();
    return () => {
      document.title = 'Смотреть аниме онлайн';
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [slug]);

  if (error) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-16">
        <ErrorBox message={`Не удалось загрузить аниме: ${error}`} onRetry={load} />
      </div>
    );
  }

  if (!anime) {
    return (
      <div className="mx-auto max-w-[1400px] px-4 py-8 sm:px-6">
        <div className="skeleton mb-5 h-8 w-1/2 rounded-lg" />
        <div className="grid gap-8 lg:grid-cols-[1fr_300px]">
          <div className="skeleton aspect-video rounded-2xl" />
          <div className="skeleton hidden aspect-[2/3] rounded-2xl lg:block" />
        </div>
      </div>
    );
  }

  const fav = isFav(anime.anime_url);
  const desc = cleanDescription(anime.description);
  const rating = anime.rating?.average || 0;
  const theater = settings.theater;
  const totalEpisodes = videos ? new Set(videos.map((v) => v.number)).size : 0;

  const InfoPanel = (
    <div className="space-y-4">
      <div className="overflow-hidden rounded-2xl border border-line bg-surface">
        <img src={posterUrl(anime.poster, 'huge')} alt={anime.title} className={cn('aspect-[2/3] w-full object-cover', theater && 'hidden')} />
        <div className="space-y-4 p-4">
          <button
            onClick={() =>
              toggle({
                slug: anime.anime_url,
                id: anime.anime_id,
                title: anime.title,
                poster: posterUrl(anime.poster, 'big'),
                year: anime.year,
                type: anime.type?.shortname,
              })
            }
            className={cn(btn.ghost, 'w-full', fav && 'border-rose-500/30 bg-rose-500/10 text-rose-300 hover:bg-rose-500/15')}
          >
            <Icon.Heart className="h-4 w-4" filled={fav} />
            {fav ? 'В избранном' : 'В избранное'}
          </button>

          <div className="flex items-center justify-between rounded-xl bg-white/[0.03] p-3">
            <div>
              <div className="flex items-center gap-1.5 text-2xl font-semibold tabular-nums text-white">
                <Icon.Star className="h-4 w-4 text-amber-400" />
                {rating ? rating.toFixed(2) : '—'}
              </div>
              <div className="text-[11px] text-zinc-500">{anime.rating?.counters || 0} оценок</div>
            </div>
            <div className="space-y-0.5 text-right text-[11px] tabular-nums text-zinc-500">
              {anime.rating?.shikimori_rating ? <div>Shikimori {anime.rating.shikimori_rating.toFixed(2)}</div> : null}
              {anime.rating?.myanimelist_rating ? <div>MAL {anime.rating.myanimelist_rating.toFixed(2)}</div> : null}
              {anime.rating?.kp_rating ? <div>КП {anime.rating.kp_rating.toFixed(1)}</div> : null}
            </div>
          </div>

          <dl className="space-y-2 text-[13px]">
            <Row_ label="Тип" value={anime.type?.name} />
            <Row_
              label="Статус"
              value={
                <span
                  className={cn(
                    anime.anime_status?.alias === 'ongoing' ? 'text-emerald-400' : anime.anime_status?.alias === 'announcement' ? 'text-sky-400' : 'text-zinc-200',
                  )}
                >
                  {anime.anime_status?.title}
                </span>
              }
            />
            <Row_ label="Год" value={anime.year ? `${anime.year}${anime.season ? `, ${SEASONS[anime.season] || ''}` : ''}` : undefined} />
            <Row_ label="Серий" value={totalEpisodes ? String(totalEpisodes) : undefined} />
            <Row_ label="Длительность" value={formatDuration(anime.duration)} />
            <Row_ label="Возраст" value={anime.min_age?.title} />
            <Row_ label="Первоисточник" value={anime.original} />
            <Row_ label="Студия" value={anime.studios?.map((s) => s.title).join(', ')} />
            <Row_ label="Режиссёр" value={anime.creators?.map((s) => s.title).join(', ')} />
            <Row_ label="Просмотров" value={formatViews(anime.views)} />
            {anime.top?.global ? <Row_ label="Место в топе" value={`#${anime.top.global}`} /> : null}
          </dl>

          {watched.length > 0 && (
            <button onClick={reset} className="w-full text-left text-[11px] text-zinc-600 hover:text-zinc-300">
              Сбросить прогресс ({watched.length} сер.)
            </button>
          )}
        </div>
      </div>

      {anime.genres?.length > 0 && (
        <div className="rounded-2xl border border-line bg-surface p-4">
          <div className="mb-2.5 text-[11px] font-semibold uppercase tracking-wider text-zinc-500">Жанры</div>
          <div className="flex flex-wrap gap-1.5">
            {anime.genres.map((g) => (
              <a key={g.id} href={links.catalog(`genres=${g.id}`)} className="rounded-md bg-white/[0.04] px-2 py-1 text-xs text-zinc-300 transition hover:bg-white hover:text-black">
                {g.title}
              </a>
            ))}
          </div>
        </div>
      )}
    </div>
  );

  return (
    <div className="relative pb-20">
      {/* Фон */}
      <div className="pointer-events-none absolute inset-x-0 top-0 -mt-14 h-[480px] overflow-hidden">
        <img src={posterUrl(anime.poster, 'fullsize')} alt="" className="h-full w-full scale-110 object-cover object-top opacity-20 blur-3xl" />
        <div className="absolute inset-0 bg-gradient-to-b from-bg/30 via-bg/70 to-bg" />
      </div>

      <div className="relative mx-auto max-w-[1400px] px-4 pt-4 sm:px-6">
        <nav className="mb-5 flex items-center gap-2 text-xs text-zinc-500">
          <a href={links.home} className="hover:text-white">
            Главная
          </a>
          <Icon.ChevronRight className="h-3 w-3" />
          <a href={links.catalog()} className="hover:text-white">
            Каталог
          </a>
          {anime.genres?.[0] && (
            <>
              <Icon.ChevronRight className="h-3 w-3" />
              <a href={links.catalog(`genres=${anime.genres[0].id}`)} className="hover:text-white">
                {anime.genres[0].title}
              </a>
            </>
          )}
        </nav>

        <div className="mb-5">
          <h1 className="text-2xl font-bold leading-tight tracking-tight text-white sm:text-3xl">{anime.title}</h1>
          <div className="mt-1.5 flex flex-wrap items-center gap-x-3 gap-y-1.5 text-[13px] text-zinc-500">
            {anime.other_titles?.[0] && <span className="text-zinc-400">{anime.other_titles[0]}</span>}
            {anime.year ? <span>{anime.year}</span> : null}
            <span>{anime.type?.name}</span>
            {anime.min_age?.title && anime.min_age.title !== 'Unknown' && <span>{anime.min_age.title}</span>}
            {nextEp && (
              <span
                className={cn(
                  'flex items-center gap-1.5 rounded-full px-3 py-1 text-[12px] font-medium',
                  nextEp.ts - now < 3600000 ? 'bg-emerald-500/15 text-emerald-300' : 'bg-white/[0.06] text-zinc-300',
                )}
              >
                <Icon.Calendar className="h-3.5 w-3.5" />
                Серия {nextEp.number}
                {nextEp.total ? ` из ${nextEp.total}` : ''} — {formatCountdown(nextEp.ts, now)}
                <span className="text-zinc-500">({fmtDateTime(nextEp.ts)})</span>
              </span>
            )}
          </div>
        </div>

        <div className={cn('grid gap-8', theater ? 'grid-cols-1' : 'lg:grid-cols-[1fr_300px] xl:grid-cols-[1fr_320px]')}>
          <div className="min-w-0">
            {videos === null ? (
              <div className="grid aspect-video w-full place-items-center rounded-2xl bg-black ring-1 ring-white/10">
                <div className="h-9 w-9 animate-spin rounded-full border-[3px] border-zinc-800 border-t-white" />
              </div>
            ) : (
              <Player
                key={anime.anime_id}
                videos={videos}
                title={anime.title}
                initialEpisode={initialEpisode}
                initialDubbing={initialDubbing}
                lookup={{
                  title: anime.title,
                  original: anime.other_titles?.[0] || anime.original,
                  year: anime.year,
                  malId: anime.remote_ids?.myanimelist_id || anime.remote_ids?.shikimori_id,
                  shikimoriId: anime.remote_ids?.shikimori_id,
                  yummyId: anime.anime_id,
                  kpId: anime.remote_ids?.kp_id,
                  anilibriaAlias: anime.remote_ids?.anilibria_alias,
                  genres: (anime.genres || []).map((g) => g.title),
                }}
                watched={watched}
                onToggleWatched={toggleWatched}
                autoNext={settings.autoNext}
                onAutoNextChange={(v) => update({ autoNext: v })}
                theater={theater}
                onTheaterChange={(v) => update({ theater: v })}
                onChange={(s) => {
                  push({
                    slug: anime.anime_url,
                    id: anime.anime_id,
                    title: anime.title,
                    poster: posterUrl(anime.poster, 'big'),
                    episode: s.episode,
                    dubbing: s.dubbing,
                    total: s.total,
                  });
                  if (settings.preferredDub !== s.dubbing) update({ preferredDub: s.dubbing });
                  const sp = new URLSearchParams();
                  sp.set('ep', s.episode);
                  sp.set('dub', s.dubbing);
                  const next = `#/anime/${encodeURIComponent(anime.anime_url)}?${sp}`;
                  if (window.location.hash !== next) window.history.replaceState(null, '', next);
                }}
              />
            )}

            <section className={cn('mt-10', theater && 'lg:grid lg:grid-cols-[1fr_320px] lg:gap-8')}>
              <div>
                <h2 className="mb-3 text-lg font-semibold text-white">Описание</h2>
                <p className={cn('whitespace-pre-line text-[15px] leading-relaxed text-zinc-300', !descOpen && 'line-clamp-4')}>{desc || 'Описание отсутствует.'}</p>
                {desc.length > 320 && (
                  <button onClick={() => setDescOpen((v) => !v)} className="mt-2 text-[13px] font-medium text-zinc-400 hover:text-white">
                    {descOpen ? 'Свернуть' : 'Читать полностью'}
                  </button>
                )}
                {anime.other_titles && anime.other_titles.length > 1 && (
                  <p className="mt-4 text-xs text-zinc-600">Другие названия: {anime.other_titles.join(' · ')}</p>
                )}
              </div>
              {theater && <div className="mt-8 lg:mt-0">{InfoPanel}</div>}
            </section>

            <Screenshots shikimoriId={anime.remote_ids?.shikimori_id || undefined} malId={anime.remote_ids?.myanimelist_id || undefined} />

            {anime.viewing_order && anime.viewing_order.length > 1 && (
              <section className="mt-12">
                <SectionTitle title="Порядок просмотра" subtitle="Связанные тайтлы франшизы" />
                <Row>
                  {anime.viewing_order.map((v) => (
                    <RowItem key={v.anime_id}>
                      <Card
                        slug={v.anime_url}
                        title={v.title}
                        poster={v.poster}
                        rating={v.rating}
                        year={v.year}
                        type={v.type?.shortname}
                        status={v.anime_status?.alias}
                        badge={v.anime_id === anime.anime_id ? 'сейчас' : undefined}
                        subtitle={v.data?.text ? `${v.year || ''} · ${v.data.text}` : undefined}
                      />
                    </RowItem>
                  ))}
                </Row>
              </section>
            )}
          </div>

          {!theater && <aside>{InfoPanel}</aside>}
        </div>
      </div>
    </div>
  );
}

function Row_({ label, value }: { label: string; value?: React.ReactNode }) {
  if (!value) return null;
  return (
    <div className="flex justify-between gap-3">
      <dt className="shrink-0 text-zinc-500">{label}</dt>
      <dd className="text-right text-zinc-200">{value}</dd>
    </div>
  );
}

/* ---------- Скриншоты (Shikimori → MAL/Jikan → AniList) ---------- */
function Screenshots({ shikimoriId, malId }: { shikimoriId?: number; malId?: number }) {
  const [shots, setShots] = useState<string[]>([]);

  useEffect(() => {
    let alive = true;
    setShots([]);
    if (!shikimoriId && !malId) return;
    fetchScreenshots(shikimoriId, malId).then((s) => {
      if (alive) setShots(s);
    });
    return () => {
      alive = false;
    };
  }, [shikimoriId, malId]);

  if (!shots.length) return null;
  return (
    <section className="mt-10">
      <SectionTitle title="Скриншоты" subtitle="Из Shikimori / AniList — кадры из серий" />
      <div className="no-scrollbar -mx-4 flex gap-3 overflow-x-auto px-4 pb-1 sm:mx-0 sm:px-0">
        {shots.map((u, i) => (
          <a key={i} href={u} target="_blank" rel="noreferrer" className="shrink-0" title="Открыть скриншот">
            <img
              src={u}
              alt=""
              loading="lazy"
              className="h-36 w-64 rounded-xl object-cover ring-1 ring-line transition hover:brightness-110 sm:h-40 sm:w-72"
            />
          </a>
        ))}
      </div>
    </section>
  );
}

'use client';
import { useEffect, useState } from 'react';
import { yummy, posterUrl, cleanDescription, type AnimeItem } from '../api/yummy';
import { AnimeCard, Card, CardSkeleton, ErrorBox, Icon, Row, RowItem, SectionTitle } from '../components/AnimeCard';
import { links } from '../hooks/useHashRoute';
import { useHistory } from '../hooks/useStorage';
import { cn } from '../utils/cn';

export function Home() {
  const [top, setTop] = useState<AnimeItem[]>([]);
  const [ongoing, setOngoing] = useState<AnimeItem[]>([]);
  const [movies, setMovies] = useState<AnimeItem[]>([]);
  const [announce, setAnnounce] = useState<AnimeItem[]>([]);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
  const [heroIdx, setHeroIdx] = useState(0);
  const { history, remove } = useHistory();

  const load = async () => {
    setLoading(true);
    setError('');
    try {
      const [t, o, m, an] = await Promise.all([
        yummy.list({ sort: 'top', limit: 20, offset: 0 }),
        yummy.list({ sort: 'top', status: 'ongoing', limit: 20, offset: 0 }),
        yummy.list({ sort: 'top', types: [2], limit: 16, offset: 0 }).catch(() => [] as AnimeItem[]),
        yummy.list({ sort: 'views', status: 'announcement', limit: 16, offset: 0 }).catch(() => [] as AnimeItem[]),
      ]);
      setTop(t);
      setOngoing(o);
      setMovies(m);
      setAnnounce(an);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Не удалось загрузить данные');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const heroes = ongoing.slice(0, 5);
  useEffect(() => {
    if (heroes.length < 2) return;
    const id = window.setInterval(() => setHeroIdx((i) => (i + 1) % heroes.length), 8000);
    return () => window.clearInterval(id);
  }, [heroes.length]);
  const hero = heroes[heroIdx];

  return (
    <div className="pb-20">
      {/* HERO */}
      <section className="relative -mt-14">
        {hero ? (
          <div className="relative min-h-[480px] sm:min-h-[620px]">
            {heroes.map((h, i) => (
              <img
                key={h.anime_id}
                src={posterUrl(h.poster, 'fullsize')}
                alt=""
                className={cn(
                  'absolute inset-0 h-full w-full object-cover object-[center_20%] transition-opacity duration-1000',
                  i === heroIdx ? 'opacity-100' : 'opacity-0',
                )}
              />
            ))}
            <div className="absolute inset-0 bg-gradient-to-r from-bg via-bg/80 to-bg/20" />
            <div className="absolute inset-0 bg-gradient-to-t from-bg via-bg/30 to-bg/60" />

            <div className="relative mx-auto flex min-h-[480px] max-w-[1400px] items-end px-4 pb-10 pt-28 sm:min-h-[620px] sm:px-6 sm:pb-14">
              <div className="max-w-2xl animate-fade-up" key={hero.anime_id}>
                <div className="mb-4 flex flex-wrap items-center gap-x-3 gap-y-1 text-[13px] text-zinc-300">
                  <span className="flex items-center gap-1.5 font-medium text-emerald-300">
                    <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-400" /> Онгоинг
                  </span>
                  <span className="text-zinc-600">·</span>
                  <span>{hero.year}</span>
                  <span className="text-zinc-600">·</span>
                  <span>{hero.type?.name}</span>
                  {hero.rating?.average > 0 && (
                    <>
                      <span className="text-zinc-600">·</span>
                      <span className="flex items-center gap-1">
                        <Icon.Star className="h-3 w-3 text-amber-400" /> {hero.rating.average.toFixed(1)}
                      </span>
                    </>
                  )}
                </div>
                <h1 className="text-4xl font-bold leading-[1.05] tracking-tight text-white sm:text-6xl">{hero.title}</h1>
                <p className="mt-5 line-clamp-3 max-w-xl text-[15px] leading-relaxed text-zinc-300">{cleanDescription(hero.description)}</p>
                <div className="mt-4 flex flex-wrap gap-x-3 gap-y-1 text-[13px] text-zinc-400">
                  {hero.genres?.slice(0, 5).map((g) => (
                    <a key={g.id} href={links.catalog(`genres=${g.id}`)} className="hover:text-white">
                      {g.title}
                    </a>
                  ))}
                </div>
                <div className="mt-7 flex flex-wrap items-center gap-3">
                  <a
                    href={links.anime(hero.anime_url)}
                    className="inline-flex h-12 items-center gap-2 rounded-full bg-white px-7 text-[15px] font-semibold text-black transition hover:bg-zinc-200 active:scale-95"
                  >
                    <Icon.Play className="h-4 w-4" /> Смотреть
                  </a>
                  <a
                    href={links.catalog('status=ongoing')}
                    className="inline-flex h-12 items-center rounded-full border border-white/15 bg-white/[0.06] px-7 text-[15px] font-medium text-white backdrop-blur transition hover:bg-white/[0.12] active:scale-95"
                  >
                    Онгоинги
                  </a>
                </div>
                <div className="mt-8 flex gap-1.5">
                  {heroes.map((h, i) => (
                    <button
                      key={h.anime_id}
                      onClick={() => setHeroIdx(i)}
                      className={cn('h-1 rounded-full transition-all duration-500', i === heroIdx ? 'w-10 bg-white' : 'w-4 bg-white/25 hover:bg-white/50')}
                      aria-label={h.title}
                    />
                  ))}
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="mx-auto max-w-[1400px] px-4 pt-24 sm:px-6">
            {error ? <ErrorBox message={`Ошибка загрузки: ${error}`} onRetry={load} /> : <div className="skeleton h-[420px] rounded-3xl" />}
          </div>
        )}
      </section>

      <div className="mx-auto max-w-[1400px] space-y-14 px-4 sm:px-6">
        {/* Продолжить просмотр */}
        {history.length > 0 && (
          <section>
            <SectionTitle title="Продолжить просмотр" href={links.history} />
            <Row>
              {history.slice(0, 15).map((h) => (
                <RowItem key={h.slug}>
                  <div className="group/item relative">
                    <Card
                      slug={h.slug}
                      title={h.title}
                      posterSrc={h.poster}
                      subtitle={`Серия ${h.episode}${h.total ? ` из ${h.total}` : ''} · ${h.dubbing}`}
                      progress={h.total ? parseFloat(h.episode) / h.total : undefined}
                      href={links.anime(h.slug, { ep: h.episode, dub: h.dubbing })}
                    />
                    <button
                      onClick={(e) => {
                        e.preventDefault();
                        remove(h.slug);
                      }}
                      className="absolute right-2 top-2 z-10 grid h-6 w-6 place-items-center rounded-md bg-black/70 text-white opacity-0 backdrop-blur transition group-hover/item:opacity-100"
                      title="Убрать"
                    >
                      <Icon.Close className="h-3 w-3" />
                    </button>
                  </div>
                </RowItem>
              ))}
            </Row>
          </section>
        )}

        <section>
          <SectionTitle title="Популярные онгоинги" href={links.catalog('status=ongoing')} />
          <Row>
            {loading
              ? Array.from({ length: 10 }).map((_, i) => (
                  <RowItem key={i}>
                    <CardSkeleton />
                  </RowItem>
                ))
              : ongoing.map((a) => (
                  <RowItem key={a.anime_id}>
                    <AnimeCard anime={a} />
                  </RowItem>
                ))}
          </Row>
        </section>

        <section>
          <SectionTitle title="Топ аниме" subtitle="Лучшее по оценкам зрителей" href={links.catalog('sort=top')} />
          <Row>
            {loading
              ? Array.from({ length: 10 }).map((_, i) => (
                  <RowItem key={i}>
                    <CardSkeleton />
                  </RowItem>
                ))
              : top.map((a, i) => (
                  <RowItem key={a.anime_id}>
                    <AnimeCard anime={a} badge={i < 3 ? `#${i + 1}` : undefined} />
                  </RowItem>
                ))}
          </Row>
        </section>

        {movies.length > 0 && (
          <section>
            <SectionTitle title="Полнометражные фильмы" href={links.catalog('types=2')} />
            <Row>
              {movies.map((a) => (
                <RowItem key={a.anime_id}>
                  <AnimeCard anime={a} />
                </RowItem>
              ))}
            </Row>
          </section>
        )}

        {announce.length > 0 && (
          <section>
            <SectionTitle title="Скоро выйдет" subtitle="Самые ожидаемые анонсы" href={links.catalog('status=announcement&sort=views')} />
            <Row>
              {announce.map((a) => (
                <RowItem key={a.anime_id}>
                  <AnimeCard anime={a} badge="анонс" />
                </RowItem>
              ))}
            </Row>
          </section>
        )}
      </div>
    </div>
  );
}

'use client';
import { useEffect, useMemo, useState } from 'react';
import { yummy, posterUrl, type ScheduleItem } from '../api/yummy';
import { CardSkeleton, ErrorBox, Grid, Icon, PageHeader, btn } from '../components/AnimeCard';
import { links } from '../hooks/useHashRoute';
import { useFavorites } from '../hooks/useStorage';
import { fmtDateTime, formatCountdown, useNow } from '../lib/countdown';
import { cn } from '../utils/cn';

const WEEKDAYS = ['Понедельник', 'Вторник', 'Среда', 'Четверг', 'Пятница', 'Суббота', 'Воскресенье'];
const WEEKDAYS_SHORT = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'];

function startOfWeek(d: Date) {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  const day = (x.getDay() + 6) % 7; // пн = 0
  x.setDate(x.getDate() - day);
  return x;
}

export function Calendar() {
  const [items, setItems] = useState<ScheduleItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [weekOffset, setWeekOffset] = useState(0);
  const [onlyFav, setOnlyFav] = useState(false);
  const [mobileDay, setMobileDay] = useState(() => (new Date().getDay() + 6) % 7);
  const { favs } = useFavorites();
  const now = useNow(30000);

  const run = () => {
    setLoading(true);
    setError('');
    yummy
      .schedule()
      .then((s) => setItems(s.filter((x) => x.episodes)))
      .catch((e) => setError(e instanceof Error ? e.message : 'Ошибка'))
      .finally(() => setLoading(false));
  };
  useEffect(run, []);

  const weekStart = useMemo(() => {
    const s = startOfWeek(new Date());
    s.setDate(s.getDate() + weekOffset * 7);
    return s;
  }, [weekOffset]);
  const weekEnd = new Date(weekStart);
  weekEnd.setDate(weekEnd.getDate() + 7);

  const favSlugs = useMemo(() => new Set(favs.map((f) => f.slug)), [favs]);

  // Ближайший релиз (для баннера «Следующий выпуск»)
  const nextRelease = useMemo(() => {
    const nowMs = Date.now();
    let best: { it: ScheduleItem; ts: number } | null = null;
    for (const it of items) {
      if (onlyFav && !favSlugs.has(it.anime_url)) continue;
      let ts = 0;
      if (it.episodes?.next_date) ts = it.episodes.next_date * 1000;
      else if (it.episodes?.prev_date && it.episodes.aired < it.episodes.count) ts = it.episodes.prev_date * 1000 + 7 * 86400000;
      if (ts > nowMs && (!best || ts < best.ts)) best = { it, ts };
    }
    return best;
  }, [items, onlyFav, favSlugs]);

  const days = useMemo(() => {
    const result: { date: Date; items: (ScheduleItem & { at: Date })[] }[] = [];
    for (let i = 0; i < 7; i++) {
      const date = new Date(weekStart);
      date.setDate(date.getDate() + i);
      result.push({ date, items: [] });
    }
    for (const it of items) {
      if (onlyFav && !favSlugs.has(it.anime_url)) continue;
      // Показываем как ближайшую дату, так и еженедельные повторы (онгоинги выходят раз в неделю)
      const nd = it.episodes.next_date ? new Date(it.episodes.next_date * 1000) : null;
      const pd = it.episodes.prev_date ? new Date(it.episodes.prev_date * 1000) : null;
      const base = nd || pd;
      if (!base) continue;
      // найти дату той же недели с тем же днём недели/временем
      const candidate = new Date(base);
      const diffWeeks = Math.round((weekStart.getTime() - startOfWeek(base).getTime()) / (7 * 86400000));
      candidate.setDate(candidate.getDate() + diffWeeks * 7);
      if (candidate < weekStart || candidate >= weekEnd) continue;
      // не показывать далеко в прошлом если серии закончились
      const finished = it.episodes.count > 0 && it.episodes.aired >= it.episodes.count && nd === null;
      if (finished) continue;
      const idx = (candidate.getDay() + 6) % 7;
      result[idx]?.items.push({ ...it, at: candidate });
    }
    for (const d of result) d.items.sort((a, b) => a.at.getTime() - b.at.getTime());
    return result;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [items, weekStart, onlyFav, favSlugs]);

  const today = new Date();
  const isCurrentWeek = weekOffset === 0;
  const total = days.reduce((n, d) => n + d.items.length, 0);

  return (
    <div className="mx-auto max-w-[1400px] px-4 py-8 sm:px-6">
      <PageHeader
        title="Календарь выхода серий"
        subtitle={`${weekStart.toLocaleDateString('ru-RU', { day: 'numeric', month: 'long' })} — ${new Date(weekEnd.getTime() - 1).toLocaleDateString('ru-RU', { day: 'numeric', month: 'long' })} · ${total} релизов`}
      >
        <div className="flex flex-wrap items-center gap-2">
          <button onClick={() => setOnlyFav((v) => !v)} className={cn(btn.ghost, onlyFav && 'border-white bg-white text-black hover:bg-white')}>
            <Icon.Heart className="h-4 w-4" filled={onlyFav} /> Только избранное
          </button>
          <div className="flex items-center rounded-lg border border-line bg-white/[0.03]">
            <button onClick={() => setWeekOffset((w) => w - 1)} className="grid h-9 w-9 place-items-center text-zinc-300 hover:text-white">
              <Icon.ChevronLeft className="h-4 w-4" />
            </button>
            <button
              onClick={() => setWeekOffset(0)}
              className={cn('h-9 border-x border-line px-3 text-[13px] font-medium', isCurrentWeek ? 'text-zinc-500' : 'text-white')}
              disabled={isCurrentWeek}
            >
              Сегодня
            </button>
            <button onClick={() => setWeekOffset((w) => w + 1)} className="grid h-9 w-9 place-items-center text-zinc-300 hover:text-white">
              <Icon.ChevronRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      </PageHeader>

      {error && <ErrorBox message={error} onRetry={run} />}
      {loading && (
        <Grid>
          {Array.from({ length: 14 }).map((_, i) => (
            <CardSkeleton key={i} />
          ))}
        </Grid>
      )}

      {!loading && !error && (
        <>
          {/* Баннер ближайшего релиза */}
          {nextRelease && (
            <a
              href={links.anime(nextRelease.it.anime_url)}
              className="mb-5 flex items-center gap-4 overflow-hidden rounded-2xl border border-emerald-500/20 bg-emerald-500/[0.06] p-3 transition hover:bg-emerald-500/[0.1]"
            >
              <img src={posterUrl(nextRelease.it.poster, 'medium')} alt="" className="h-[72px] w-[52px] shrink-0 rounded-lg object-cover" />
              <div className="min-w-0 flex-1">
                <div className="text-[11px] font-semibold uppercase tracking-wider text-emerald-300/80">Ближайший выпуск</div>
                <div className="mt-0.5 truncate text-[14px] font-medium text-white">{nextRelease.it.title}</div>
                <div className="mt-0.5 text-[12px] text-zinc-400">
                  Серия {nextRelease.it.episodes.aired + 1}
                  {nextRelease.it.episodes.count > 0 && ` из ${nextRelease.it.episodes.count}`} · {fmtDateTime(nextRelease.ts)}
                </div>
              </div>
              <div className="shrink-0 rounded-xl bg-emerald-400/15 px-3 py-2 text-center">
                <div className="text-[11px] font-semibold tabular-nums text-emerald-200">{formatCountdown(nextRelease.ts, now)}</div>
              </div>
            </a>
          )}

          {/* Мобильные табы дней */}
          <div className="no-scrollbar -mx-4 mb-4 flex gap-1 overflow-x-auto px-4 lg:hidden">
            {days.map((d, i) => {
              const isToday = d.date.toDateString() === today.toDateString();
              return (
                <button
                  key={i}
                  onClick={() => setMobileDay(i)}
                  className={cn(
                    'flex min-w-[64px] flex-col items-center rounded-xl px-3 py-2 transition',
                    mobileDay === i ? 'bg-white text-black' : 'bg-white/[0.04] text-zinc-300',
                  )}
                >
                  <span className="text-[11px] font-medium uppercase opacity-70">{WEEKDAYS_SHORT[i]}</span>
                  <span className={cn('text-lg font-semibold tabular-nums', isToday && mobileDay !== i && 'text-accent')}>{d.date.getDate()}</span>
                  <span className="text-[10px] opacity-60">{d.items.length}</span>
                </button>
              );
            })}
          </div>

          {/* Сетка недели */}
          <div className="grid gap-3 lg:grid-cols-7">
            {days.map((d, i) => {
              const isToday = d.date.toDateString() === today.toDateString();
              return (
                <div key={i} className={cn('min-w-0', mobileDay !== i && 'hidden lg:block')}>
                  <div className={cn('mb-3 hidden items-baseline justify-between border-b pb-2 lg:flex', isToday ? 'border-white' : 'border-line')}>
                    <div>
                      <div className={cn('text-[11px] font-semibold uppercase tracking-wider', isToday ? 'text-white' : 'text-zinc-500')}>
                        {WEEKDAYS[i]}
                      </div>
                      <div className={cn('text-2xl font-semibold tabular-nums', isToday ? 'text-white' : 'text-zinc-300')}>{d.date.getDate()}</div>
                    </div>
                    <span className="text-xs text-zinc-600">{d.items.length}</span>
                  </div>
                  <div className="space-y-2">
                    {d.items.length === 0 && (
                      <div className="rounded-xl border border-dashed border-white/10 py-8 text-center text-xs text-zinc-600">Нет релизов</div>
                    )}
                    {d.items.map((it) => {
                      const past = it.at.getTime() < Date.now();
                      const isFav = favSlugs.has(it.anime_url);
                      return (
                        <a
                          key={it.anime_id}
                          href={links.anime(it.anime_url)}
                          className="group flex gap-2.5 rounded-xl border border-line bg-surface p-2 transition hover:border-white/15 hover:bg-surface-2"
                        >
                          <img src={posterUrl(it.poster, 'medium')} alt="" className="h-[68px] w-12 shrink-0 rounded-md object-cover" loading="lazy" />
                          <div className="min-w-0 flex-1 py-0.5">
                            <div className="flex items-center gap-1.5 text-[11px] tabular-nums">
                              {past ? (
                                <span className="text-emerald-400">
                                  Вышло в {it.at.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })}
                                </span>
                              ) : (
                                <span className={cn(it.at.getTime() - now < 3600000 ? 'font-semibold text-emerald-300' : 'text-zinc-400')}>
                                  {formatCountdown(it.at.getTime(), now)}
                                </span>
                              )}
                              {isFav && <Icon.Heart className="h-3 w-3 text-rose-400" filled />}
                            </div>
                            <div className="mt-0.5 line-clamp-2 text-[13px] font-medium leading-snug text-zinc-100 group-hover:text-white">{it.title}</div>
                            <div className="mt-1 text-[11px] text-zinc-500">
                              Серия {past ? it.episodes.aired || 1 : it.episodes.aired + 1}
                              {it.episodes.count > 0 && <span className="text-zinc-600"> / {it.episodes.count}</span>}
                            </div>
                          </div>
                        </a>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        </>
      )}
    </div>
  );
}

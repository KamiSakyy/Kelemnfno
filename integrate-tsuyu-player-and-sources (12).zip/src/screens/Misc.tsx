'use client';
import { useEffect, useMemo, useState } from 'react';
import { yummy, type AnimeItem } from '../api/yummy';
import { AnimeCard, Card, CardSkeleton, Empty, ErrorBox, Grid, Icon, PageHeader, btn } from '../components/AnimeCard';
import { cn } from '../utils/cn';
import { links, navigate } from '../hooks/useHashRoute';
import { useFavorites, useHistory } from '../hooks/useStorage';

/* ---------- Поиск ---------- */
type SortKey = 'relevance' | 'rating' | 'year' | 'views' | 'name';

const SORTS: { key: SortKey; label: string }[] = [
  { key: 'relevance', label: 'Релевантность' },
  { key: 'rating', label: 'Рейтинг' },
  { key: 'year', label: 'Новые' },
  { key: 'views', label: 'Популярные' },
  { key: 'name', label: 'А–Я' },
];

const RECENT_KEY = 'yw_recent_search';
const TRENDING = [
  'Наруто',
  'Ванпис',
  'Магическая битва',
  'Атака титанов',
  'Клинок, рассекающий демонов',
  'Тетрадь смерти',
  'Мой герой',
  'Фрирен',
];

function readRecent(): string[] {
  try {
    const raw = localStorage.getItem(RECENT_KEY);
    const list = raw ? (JSON.parse(raw) as string[]) : [];
    return Array.isArray(list) ? list.slice(0, 8) : [];
  } catch {
    return [];
  }
}

function writeRecent(value: string) {
  const clean = value.trim();
  if (clean.length < 2) return;
  try {
    const next = [clean, ...readRecent().filter((x) => x.toLowerCase() !== clean.toLowerCase())].slice(0, 8);
    localStorage.setItem(RECENT_KEY, JSON.stringify(next));
  } catch {
    /* приватный режим */
  }
}

function removeRecent(value: string) {
  try {
    localStorage.setItem(RECENT_KEY, JSON.stringify(readRecent().filter((x) => x !== value)));
  } catch {
    /* ignore */
  }
}

function norm(v: string) {
  return v.toLowerCase().replace(/ё/g, 'е').replace(/[^\p{L}\p{N}]+/gu, ' ').trim();
}

/* ---------- Поле поиска в нативном стиле ---------- */
function SearchField({
  value,
  loading,
  autoFocus,
  onChange,
  onSubmit,
  onClear,
}: {
  value: string;
  loading: boolean;
  autoFocus?: boolean;
  onChange: (v: string) => void;
  onSubmit: () => void;
  onClear: () => void;
}) {
  const [focused, setFocused] = useState(false);
  return (
    <div
      className={cn(
        'group flex items-center gap-3 rounded-2xl border bg-surface px-4 transition-all duration-200',
        focused ? 'border-white/25 bg-surface-2 ring-4 ring-white/[0.05]' : 'border-line hover:border-white/15',
      )}
    >
      <Icon.Search
        className={cn('h-5 w-5 shrink-0 transition-colors', focused ? 'text-white' : 'text-zinc-500 group-hover:text-zinc-400')}
      />
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
        onKeyDown={(e) => {
          if (e.key === 'Enter') {
            e.preventDefault();
            (e.target as HTMLInputElement).blur();
            onSubmit();
          }
          if (e.key === 'Escape') (e.target as HTMLInputElement).blur();
        }}
        autoFocus={autoFocus}
        enterKeyHint="search"
        aria-label="Поиск аниме"
        placeholder="Название аниме, например «Наруто»"
        className="h-[52px] w-full bg-transparent text-[16px] text-white outline-none placeholder:text-zinc-600"
      />
      {loading ? (
        <span className="h-4 w-4 shrink-0 animate-spin rounded-full border-2 border-zinc-600 border-t-white" />
      ) : (
        value && (
          <button
            type="button"
            onClick={onClear}
            aria-label="Очистить"
            className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-white/[0.08] text-zinc-300 transition hover:bg-white/15 hover:text-white active:scale-90"
          >
            <Icon.Close className="h-3.5 w-3.5" />
          </button>
        )
      )}
    </div>
  );
}

export function Search({ q }: { q: string }) {
  const [items, setItems] = useState<AnimeItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [draft, setDraft] = useState(q);
  const [sort, setSort] = useState<SortKey>('relevance');
  const [typeFilter, setTypeFilter] = useState('');
  const [yearFilter, setYearFilter] = useState(0);
  const [recent, setRecent] = useState<string[]>([]);

  useEffect(() => setDraft(q), [q]);
  useEffect(() => setRecent(readRecent()), []);

  const run = () => {
    if (!q.trim()) {
      setItems([]);
      setLoading(false);
      return;
    }
    setLoading(true);
    setError('');
    setTypeFilter('');
    setYearFilter(0);
    writeRecent(q);
    setRecent(readRecent());
    yummy
      .search(q, 70)
      .then(setItems)
      .catch((e) => setError(e instanceof Error ? e.message : 'Ошибка'))
      .finally(() => setLoading(false));
  };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(run, [q]);

  /* живой поиск: обновляем адрес с небольшой задержкой */
  useEffect(() => {
    const value = draft.trim();
    if (!value || value === q) return;
    const t = window.setTimeout(() => navigate(links.search(value)), 420);
    return () => window.clearTimeout(t);
  }, [draft, q]);

  const types = useMemo(() => {
    const set = new Map<string, number>();
    for (const a of items) {
      const name = a.type?.name?.trim();
      if (name) set.set(name, (set.get(name) || 0) + 1);
    }
    return [...set.entries()].sort((a, b) => b[1] - a[1]).slice(0, 5);
  }, [items]);

  const years = useMemo(() => {
    const set = new Set<number>();
    for (const a of items) if (a.year) set.add(a.year);
    return [...set].sort((a, b) => b - a).slice(0, 6);
  }, [items]);

  const visible = useMemo(() => {
    const needle = norm(q);
    let rows = items.filter((a) => {
      if (typeFilter && a.type?.name !== typeFilter) return false;
      if (yearFilter && a.year !== yearFilter) return false;
      return true;
    });
    const rank = (a: AnimeItem) => {
      const t = norm(a.title);
      if (t === needle) return 0;
      if (t.startsWith(needle)) return 1;
      if (t.includes(needle)) return 2;
      return 3;
    };
    rows = [...rows].sort((a, b) => {
      if (sort === 'rating') return (b.rating?.average || 0) - (a.rating?.average || 0) || rank(a) - rank(b);
      if (sort === 'year') return (b.year || 0) - (a.year || 0) || rank(a) - rank(b);
      if (sort === 'views') return (b.views || 0) - (a.views || 0) || rank(a) - rank(b);
      if (sort === 'name') return a.title.localeCompare(b.title, 'ru');
      return rank(a) - rank(b) || (b.rating?.average || 0) - (a.rating?.average || 0);
    });
    return rows;
  }, [items, q, sort, typeFilter, yearFilter]);

  const hasFilters = !!typeFilter || !!yearFilter;
  const resetFilters = () => {
    setTypeFilter('');
    setYearFilter(0);
  };

  const submit = (value: string) => {
    const clean = value.trim();
    if (!clean) return;
    setDraft(clean);
    navigate(links.search(clean));
  };

  const clearAll = () => {
    setDraft('');
    navigate(links.search(''));
  };

  return (
    <div className="mx-auto max-w-[1400px] px-4 pb-8 pt-4 sm:px-6">
      {/* Липкая панель — без рамки-коробки, только мягкое blur-поле */}
      <div className="sticky top-14 z-30 -mx-4 bg-bg/85 px-4 pb-3 backdrop-blur-xl sm:mx-0 sm:px-0">
        <SearchField
          value={draft}
          loading={loading}
          autoFocus={!q}
          onChange={setDraft}
          onSubmit={() => {}}
          onClear={clearAll}
        />

        {/* Панель управления результатами */}
        {q.trim() && (
          <div className="no-scrollbar -mx-4 mt-3 flex items-center gap-2 overflow-x-auto px-4 sm:mx-0 sm:px-0">
            <div className="flex shrink-0 items-center gap-0.5 rounded-full bg-white/[0.05] p-0.5">
              {SORTS.map((s) => (
                <button
                  key={s.key}
                  onClick={() => setSort(s.key)}
                  aria-pressed={sort === s.key}
                  className={cn(
                    'rounded-full px-3 py-1.5 text-[12px] font-medium transition-all duration-200',
                    sort === s.key ? 'bg-white text-black shadow-sm' : 'text-zinc-400 hover:text-white',
                  )}
                >
                  {s.label}
                </button>
              ))}
            </div>

            {(types.length > 1 || years.length > 1) && (
              <>
                <span className="mx-0.5 hidden h-5 w-px shrink-0 bg-white/10 sm:block" />
                {types.map(([name, count]) => (
                  <button
                    key={name}
                    onClick={() => setTypeFilter(typeFilter === name ? '' : name)}
                    aria-pressed={typeFilter === name}
                    className={cn(
                      'flex shrink-0 items-center gap-1.5 rounded-full border px-3 py-1.5 text-[12px] transition-all duration-200 active:scale-95',
                      typeFilter === name
                        ? 'border-white bg-white/10 text-white'
                        : 'border-line bg-white/[0.02] text-zinc-400 hover:border-white/25 hover:text-white',
                    )}
                  >
                    {name}
                    <span className="tabular-nums text-[10px] opacity-60">{count}</span>
                  </button>
                ))}
                {years.map((y) => (
                  <button
                    key={y}
                    onClick={() => setYearFilter(yearFilter === y ? 0 : y)}
                    aria-pressed={yearFilter === y}
                    className={cn(
                      'shrink-0 rounded-full border px-3 py-1.5 text-[12px] tabular-nums transition-all duration-200 active:scale-95',
                      yearFilter === y
                        ? 'border-white bg-white/10 text-white'
                        : 'border-line bg-white/[0.02] text-zinc-400 hover:border-white/25 hover:text-white',
                    )}
                  >
                    {y}
                  </button>
                ))}
              </>
            )}
          </div>
        )}
      </div>

      {/* Пустой запрос: нативный «дом» поиска */}
      {!q.trim() && (
        <div className="mx-auto mt-6 max-w-2xl">
          {recent.length > 0 && (
            <section className="mb-8">
              <div className="mb-3 flex items-center justify-between px-1">
                <div className="flex items-center gap-2 text-[13px] font-medium text-zinc-400">
                  <Icon.Clock className="h-4 w-4 text-zinc-500" />
                  История поиска
                </div>
                <button
                  onClick={() => {
                    try {
                      localStorage.removeItem(RECENT_KEY);
                    } catch {
                      /* ignore */
                    }
                    setRecent([]);
                  }}
                  className="text-[12px] text-zinc-600 transition hover:text-zinc-300"
                >
                  Очистить
                </button>
              </div>
              <div className="grid gap-1">
                {recent.map((r) => (
                  <div key={r} className="group flex items-center rounded-2xl transition-colors hover:bg-white/[0.04]">
                    <button
                      onClick={() => submit(r)}
                      className="flex min-w-0 flex-1 items-center gap-3 px-3 py-2.5 text-left"
                    >
                      <Icon.Search className="h-4 w-4 shrink-0 text-zinc-600" />
                      <span className="truncate text-[14px] text-zinc-200">{r}</span>
                    </button>
                    <button
                      onClick={() => {
                        removeRecent(r);
                        setRecent(readRecent());
                      }}
                      aria-label="Убрать из истории"
                      className="mr-1 grid h-8 w-8 shrink-0 place-items-center rounded-full text-zinc-600 opacity-0 transition hover:bg-white/10 hover:text-white group-hover:opacity-100"
                    >
                      <Icon.Close className="h-3.5 w-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </section>
          )}

          <section>
            <div className="mb-3 flex items-center gap-2 px-1 text-[13px] font-medium text-zinc-400">
              <Icon.Trend className="h-4 w-4 text-zinc-500" />
              Часто ищут
            </div>
            <div className="flex flex-wrap gap-2">
              {TRENDING.map((t) => (
                <button
                  key={t}
                  onClick={() => submit(t)}
                  className="rounded-full border border-line bg-white/[0.03] px-4 py-2 text-[13px] text-zinc-300 transition-all duration-200 hover:-translate-y-0.5 hover:border-white/25 hover:bg-white/[0.07] hover:text-white active:scale-95"
                >
                  {t}
                </button>
              ))}
            </div>
          </section>
        </div>
      )}

      {/* Заголовок результатов */}
      {q.trim() && (
        <div className="mt-5 flex flex-wrap items-center justify-between gap-2 px-1">
          <p className="text-[13px] text-zinc-500">
            {loading ? (
              'Ищем…'
            ) : (
              <>
                Найдено <span className="font-semibold tabular-nums text-zinc-200">{visible.length}</span>
                {visible.length !== items.length && <span className="tabular-nums"> из {items.length}</span>}
              </>
            )}
          </p>
          {hasFilters && (
            <button
              onClick={resetFilters}
              className="flex items-center gap-1.5 rounded-full bg-white/[0.05] px-3 py-1 text-[12px] text-zinc-300 transition hover:bg-white/10 active:scale-95"
            >
              <Icon.Close className="h-3 w-3" /> Сбросить фильтры
            </button>
          )}
        </div>
      )}

      {/* Результаты */}
      <div className="mt-4">
        {error ? (
          <ErrorBox message={error} onRetry={run} />
        ) : loading && q.trim() ? (
          <Grid>
            {Array.from({ length: 14 }).map((_, i) => (
              <CardSkeleton key={i} />
            ))}
          </Grid>
        ) : visible.length > 0 ? (
          <Grid>
            {visible.map((a, i) => (
              <div key={a.anime_id} className="animate-fade-up" style={{ animationDelay: `${Math.min(i, 18) * 22}ms` }}>
                <AnimeCard anime={a} badge={norm(a.title) === norm(q) ? 'Точное совпадение' : undefined} />
              </div>
            ))}
          </Grid>
        ) : (
          q.trim() && (
            <Empty
              icon={<Icon.Search className="h-6 w-6" />}
              title="Ничего не найдено"
              text="Попробуйте короче запрос, другое написание или оригинальное название на ромадзи."
              action={
                <div className="flex flex-wrap justify-center gap-2">
                  <button
                    onClick={() => submit(q.replace(/[^A-Za-zА-Яа-яЁё ]/g, '').split(' ')[0] || q)}
                    className={btn.ghost}
                  >
                    Упростить запрос
                  </button>
                  <a href={links.catalog()} className={btn.primary}>
                    Открыть каталог
                  </a>
                </div>
              }
            />
          )
        )}
      </div>
    </div>
  );
}

/* ---------- Избранное ---------- */
export function Favorites() {
  const { favs, toggle } = useFavorites();
  return (
    <div className="mx-auto max-w-[1400px] px-4 py-8 sm:px-6">
      <PageHeader title="Избранное" subtitle={favs.length ? `${favs.length} тайтлов` : 'Список пуст'} />
      {favs.length === 0 ? (
        <Empty
          icon={<Icon.Heart className="h-6 w-6" />}
          title="Пока пусто"
          text="Добавляйте аниме в избранное со страницы просмотра — они появятся здесь и в календаре."
          action={
            <a href={links.catalog()} className={btn.primary}>
              Перейти в каталог
            </a>
          }
        />
      ) : (
        <Grid>
          {favs.map((f) => (
            <div key={f.slug} className="group/item relative">
              <Card slug={f.slug} title={f.title} posterSrc={f.poster} year={f.year} type={f.type} />
              <button
                onClick={() => toggle(f)}
                className="absolute right-2 top-2 z-10 grid h-7 w-7 place-items-center rounded-md bg-black/70 text-white opacity-0 backdrop-blur transition group-hover/item:opacity-100"
                title="Убрать из избранного"
              >
                <Icon.Close className="h-3.5 w-3.5" />
              </button>
            </div>
          ))}
        </Grid>
      )}
    </div>
  );
}

/* ---------- История ---------- */
export function History() {
  const { history, remove, clear } = useHistory();
  return (
    <div className="mx-auto max-w-[1400px] px-4 py-8 sm:px-6">
      <PageHeader title="История просмотра" subtitle={history.length ? `${history.length} тайтлов` : 'История пуста'}>
        {history.length > 0 && (
          <button onClick={clear} className={btn.ghost}>
            Очистить
          </button>
        )}
      </PageHeader>
      {history.length === 0 ? (
        <Empty icon={<Icon.Play className="h-6 w-6" />} title="Вы ещё ничего не смотрели" text="Начните просмотр, и мы запомним, на какой серии вы остановились." />
      ) : (
        <Grid>
          {history.map((h) => (
            <div key={h.slug} className="group/item relative">
              <Card
                slug={h.slug}
                title={h.title}
                posterSrc={h.poster}
                subtitle={`Серия ${h.episode}${h.total ? ` из ${h.total}` : ''} · ${h.dubbing}`}
                progress={h.total ? parseFloat(h.episode) / h.total : undefined}
                href={links.anime(h.slug, { ep: h.episode, dub: h.dubbing })}
              />
              <button
                onClick={() => remove(h.slug)}
                className="absolute right-2 top-2 z-10 grid h-7 w-7 place-items-center rounded-md bg-black/70 text-white opacity-0 backdrop-blur transition group-hover/item:opacity-100"
              >
                <Icon.Close className="h-3.5 w-3.5" />
              </button>
            </div>
          ))}
        </Grid>
      )}
    </div>
  );
}

/* ---------- 404 ---------- */
export function NotFound() {
  return (
    <div className="mx-auto max-w-[1400px] px-4 py-24 text-center sm:px-6">
      <div className="text-7xl font-bold tracking-tighter text-white/10">404</div>
      <h1 className="mt-2 text-2xl font-semibold text-white">Страница не найдена</h1>
      <p className="mt-2 text-sm text-zinc-500">Возможно, ссылка устарела или была введена с ошибкой.</p>
      <a href={links.home} className={`${btn.primary} mt-8`}>
        На главную
      </a>
    </div>
  );
}

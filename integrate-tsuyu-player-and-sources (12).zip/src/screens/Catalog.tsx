'use client';
import { useEffect, useMemo, useRef, useState } from 'react';
import { yummy, type AnimeItem, type Genre } from '../api/yummy';
import { AnimeCard, CardSkeleton, ErrorBox, Grid, Icon } from '../components/AnimeCard';
import { navigate } from '../hooks/useHashRoute';
import { cn } from '../utils/cn';

const PAGE = 35;
const MAX_EMPTY_PAGES = 12; // защита при клиентской фильтрации по годам

const TYPES = [
  { value: 1, label: 'ТВ сериал' },
  { value: 2, label: 'Фильм' },
  { value: 3, label: 'OVA' },
  { value: 7, label: 'ONA' },
  { value: 5, label: 'Спешл' },
];

const STATUSES = [
  { value: '', label: 'Любой' },
  { value: 'ongoing', label: 'Онгоинг' },
  { value: 'released', label: 'Вышел' },
  { value: 'announcement', label: 'Анонс' },
];

const SORTS = [
  { value: 'top', label: 'Популярное' },
  { value: 'views', label: 'По просмотрам' },
  { value: 'rating', label: 'По рейтингу' },
];

const YEAR_PRESETS: { label: string; from: number; to: number }[] = [
  { label: '2026', from: 2026, to: 2100 },
  { label: '2025', from: 2025, to: 2025 },
  { label: '2024', from: 2024, to: 2024 },
  { label: '2023', from: 2023, to: 2023 },
  { label: '2022', from: 2022, to: 2022 },
  { label: '2020–2021', from: 2020, to: 2021 },
  { label: '2015–2019', from: 2015, to: 2019 },
  { label: '2010–2014', from: 2010, to: 2014 },
  { label: '2000-е', from: 2000, to: 2009 },
  { label: 'До 2000', from: 1900, to: 1999 },
];

// Жанры 18+ — показываем отдельной секцией
const ADULT_ALIASES = new Set(['etti', 'erotica', 'garem', 'garem-dlya-devochek', 'sukkuby', 'lolikon', 'trap', 'sedze-aj', 'senen-aj']);

// Синонимы для поиска по жанрам («хентай» → «Этти» и т.д.)
const GENRE_KEYWORDS: Record<string, string[]> = {
  etti: ['хентай', 'hentai', '18+', '18', 'эроти', 'epg'],
  erotica: ['хентай', 'hentai', '18+', '18', 'эроти'],
  garem: ['гарем', 'harem'],
  'garem-dlya-devochek': ['гарем', 'реверс'],
  sukkuby: ['сукуб'],
  'sedze-aj': ['юри'],
  'senen-aj': ['яой'],
  'lyudi-zveri': ['фурри', 'furry'],
  'ne-yaponskoe': ['корейское', 'китайское', 'cn', 'kr', 'хентай 3d', '3d'],
};

export function Catalog({ params }: { params: URLSearchParams }) {
  const sort = params.get('sort') || 'top';
  const status = params.get('status') || '';
  const ys = Number(params.get('ys')) || 0;
  const ye = Number(params.get('ye')) || 0;
  const genres = useMemo(() => params.getAll('genres').map(Number).filter(Boolean), [params]);
  const types = useMemo(() => params.getAll('types').map(Number).filter(Boolean), [params]);
  const key = params.toString();

  const [items, setItems] = useState<AnimeItem[]>([]);
  const [offset, setOffset] = useState(0);
  const [hasMore, setHasMore] = useState(true);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [allGenres, setAllGenres] = useState<Genre[]>([]);
  const [sheetOpen, setSheetOpen] = useState(false);
  const [genreQuery, setGenreQuery] = useState('');
  const sentinel = useRef<HTMLDivElement>(null);
  const loadingRef = useRef(false);

  useEffect(() => {
    yummy
      .genres()
      .then((g) => setAllGenres(g.genres || []))
      .catch(() => {});
  }, []);

  useEffect(() => {
    setItems([]);
    setOffset(0);
    setHasMore(true);
    setError('');
  }, [key]);

  const yearOk = (a: AnimeItem) => {
    if (!ys && !ye) return true;
    if (!a.year) return false;
    return a.year >= (ys || 0) && a.year <= (ye || 2200);
  };

  const loadMore = async (from: number) => {
    if (loadingRef.current) return;
    loadingRef.current = true;
    setLoading(true);
    setError('');
    try {
      let cursor = from;
      let added = 0;
      let attempts = 0;
      let more = true;
      const collected: AnimeItem[] = [];
      // при фильтре по годам продолжаем листать, пока не найдём совпадения
      while (attempts < MAX_EMPTY_PAGES) {
        const data = await yummy.list({ sort, status: status as never, genres, types, limit: PAGE, offset: cursor });
        cursor += data.length;
        const filtered = data.filter(yearOk);
        collected.push(...filtered);
        added += filtered.length;
        if (data.length < PAGE) {
          more = false;
          break;
        }
        if (added > 0) break;
        attempts++;
      }
      setItems((prev) => {
        const seen = new Set(prev.map((a) => a.anime_id));
        return [...prev, ...collected.filter((a) => !seen.has(a.anime_id))];
      });
      setOffset(cursor);
      setHasMore(more);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Ошибка');
    } finally {
      loadingRef.current = false;
      setLoading(false);
    }
  };

  useEffect(() => {
    if (items.length === 0 && hasMore && !loadingRef.current) loadMore(0);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key, items.length]);

  useEffect(() => {
    const el = sentinel.current;
    if (!el) return;
    const io = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && hasMore && !loadingRef.current && items.length > 0) loadMore(offset);
      },
      { rootMargin: '800px' },
    );
    io.observe(el);
    return () => io.disconnect();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [offset, hasMore, items.length]);

  const update = (mut: (sp: URLSearchParams) => void) => {
    const sp = new URLSearchParams(params.toString());
    mut(sp);
    navigate(`#/catalog${sp.toString() ? `?${sp}` : ''}`);
  };
  const toggleArr = (name: string, value: number) =>
    update((sp) => {
      const cur = sp.getAll(name).map(Number);
      sp.delete(name);
      const next = cur.includes(value) ? cur.filter((v) => v !== value) : [...cur, value];
      next.forEach((v) => sp.append(name, String(v)));
    });
  const setYears = (from: number, to: number, on: boolean) =>
    update((sp) => {
      if (on) {
        sp.set('ys', String(from));
        sp.set('ye', String(to));
      } else {
        sp.delete('ys');
        sp.delete('ye');
      }
    });

  const q = genreQuery.trim().toLowerCase();
  const matchQ = (g: Genre) =>
    !q ||
    g.title.toLowerCase().includes(q) ||
    g.more_titles.some((t) => t.toLowerCase().includes(q)) ||
    (GENRE_KEYWORDS[g.href] || []).some((k) => k.includes(q) || q.includes(k));
  const mainGenres = allGenres.filter((g) => g.group_id < 0 && !ADULT_ALIASES.has(g.href)).filter(matchQ);
  const themeGenres = allGenres.filter((g) => g.group_id >= 0 && !ADULT_ALIASES.has(g.href)).filter(matchQ);
  const adultGenres = allGenres.filter((g) => ADULT_ALIASES.has(g.href)).filter(matchQ);

  const genreTitle = (id: number) => allGenres.find((g) => g.value === id)?.title || `#${id}`;
  const activeYearPreset = YEAR_PRESETS.find((p) => p.from === ys && p.to === ye);
  const activeCount = genres.length + types.length + (status ? 1 : 0) + (ys || ye ? 1 : 0);

  return (
    <div className="mx-auto max-w-[1400px] px-4 py-4 sm:px-6">
      <h1 className="mb-4 text-2xl font-bold tracking-tight text-white">Каталог</h1>

      {/* Строка: кнопка фильтров + активные чипы */}
      <div className="no-scrollbar -mx-4 mb-5 flex items-center gap-2 overflow-x-auto px-4">
        <button
          onClick={() => setSheetOpen(true)}
          className={cn(
            'flex h-10 shrink-0 items-center gap-2 rounded-full px-4 text-[13px] font-semibold transition active:scale-95',
            activeCount > 0 ? 'bg-white text-black' : 'border border-line bg-white/[0.04] text-white',
          )}
        >
          <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" d="M4 7h16M7 12h10M10 17h4" />
          </svg>
          Фильтры
          {activeCount > 0 && <span className="grid h-5 w-5 place-items-center rounded-full bg-black text-[11px] text-white">{activeCount}</span>}
        </button>

        {SORTS.map((s) => (
          <button
            key={s.value}
            onClick={() => update((sp) => sp.set('sort', s.value))}
            className={cn(
              'h-10 shrink-0 rounded-full px-4 text-[13px] font-medium transition active:scale-95',
              sort === s.value ? 'bg-white/[0.12] text-white' : 'text-zinc-500 hover:text-zinc-300',
            )}
          >
            {s.label}
          </button>
        ))}
      </div>

      {/* Активные фильтры */}
      {activeCount > 0 && (
        <div className="no-scrollbar -mx-4 mb-5 flex gap-1.5 overflow-x-auto px-4">
          {status && (
            <Chip onRemove={() => update((sp) => sp.delete('status'))}>{STATUSES.find((s) => s.value === status)?.label}</Chip>
          )}
          {(ys || ye) && <Chip onRemove={() => setYears(0, 0, false)}>{activeYearPreset?.label || `${ys}–${ye}`}</Chip>}
          {types.map((t) => (
            <Chip key={t} onRemove={() => toggleArr('types', t)}>
              {TYPES.find((x) => x.value === t)?.label}
            </Chip>
          ))}
          {genres.map((id) => (
            <Chip key={id} onRemove={() => toggleArr('genres', id)}>
              {genreTitle(id)}
            </Chip>
          ))}
          <button onClick={() => navigate('#/catalog')} className="shrink-0 rounded-full px-3 py-1.5 text-[12px] text-zinc-500 hover:text-white">
            Сбросить всё
          </button>
        </div>
      )}

      {error && items.length === 0 ? (
        <ErrorBox message={error} onRetry={() => loadMore(0)} />
      ) : (
        <>
          <Grid>
            {items.map((a) => (
              <AnimeCard key={a.anime_id} anime={a} />
            ))}
            {loading && Array.from({ length: items.length ? 7 : 21 }).map((_, i) => <CardSkeleton key={`s${i}`} />)}
          </Grid>
          {!loading && items.length === 0 && !hasMore && <p className="py-20 text-center text-zinc-500">Ничего не найдено. Попробуйте ослабить фильтры.</p>}
          <div ref={sentinel} className="h-4" />
          {!hasMore && items.length > 0 && <p className="py-8 text-center text-xs text-zinc-600">Показано {items.length} тайтлов</p>}
        </>
      )}

      {/* ---------- Bottom Sheet фильтров (Android style) ---------- */}
      {sheetOpen && (
        <div className="fixed inset-0 z-50" onClick={() => setSheetOpen(false)}>
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm animate-fade-in" />
          <div
            className="animate-sheet-up absolute inset-x-0 bottom-0 mx-auto flex max-h-[88vh] w-full max-w-2xl flex-col rounded-t-[28px] border-t border-white/10 bg-[#101013]"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex shrink-0 flex-col items-center pt-3">
              <div className="h-1.5 w-10 rounded-full bg-white/20" />
              <div className="flex w-full items-center justify-between px-5 pb-3 pt-4">
                <h2 className="text-lg font-semibold text-white">Фильтры</h2>
                {activeCount > 0 && (
                  <button onClick={() => navigate('#/catalog')} className="text-[13px] text-zinc-500 hover:text-white">
                    Сбросить ({activeCount})
                  </button>
                )}
              </div>
            </div>

            <div className="flex-1 space-y-6 overflow-y-auto px-5 pb-6">
              <Section title="Статус">
                <div className="flex flex-wrap gap-2">
                  {STATUSES.map((s) => (
                    <SheetChip key={s.value} active={status === s.value} onClick={() => update((sp) => (s.value ? sp.set('status', s.value) : sp.delete('status')))}>
                      {s.label}
                    </SheetChip>
                  ))}
                </div>
              </Section>

              <Section title="Год выхода">
                <div className="flex flex-wrap gap-2">
                  {YEAR_PRESETS.map((p) => {
                    const on = p.from === ys && p.to === ye;
                    return (
                      <SheetChip key={p.label} active={on} onClick={() => setYears(p.from, p.to, !on)}>
                        {p.label}
                      </SheetChip>
                    );
                  })}
                </div>
              </Section>

              <Section title="Тип">
                <div className="flex flex-wrap gap-2">
                  {TYPES.map((t) => (
                    <SheetChip key={t.value} active={types.includes(t.value)} onClick={() => toggleArr('types', t.value)}>
                      {t.label}
                    </SheetChip>
                  ))}
                </div>
              </Section>

              <Section
                title="Жанры"
                right={
                  <div className="relative">
                    <Icon.Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-zinc-600" />
                    <input
                      value={genreQuery}
                      onChange={(e) => setGenreQuery(e.target.value)}
                      placeholder="Поиск жанра"
                      className="h-8 w-36 rounded-full border border-line bg-white/[0.04] pl-8 pr-3 text-[12px] text-white outline-none placeholder:text-zinc-600 focus:border-white/25"
                    />
                  </div>
                }
              >
                {allGenres.length === 0 && <div className="skeleton h-24 rounded-2xl" />}
                {mainGenres.length > 0 && (
                  <div className="flex flex-wrap gap-2">
                    {mainGenres.map((g) => (
                      <SheetChip key={g.value} active={genres.includes(g.value)} onClick={() => toggleArr('genres', g.value)}>
                        {g.title}
                      </SheetChip>
                    ))}
                  </div>
                )}
                {themeGenres.length > 0 && (
                  <>
                    <div className="mb-2 mt-4 text-[10px] font-semibold uppercase tracking-wider text-zinc-600">Темы</div>
                    <div className="flex flex-wrap gap-2">
                      {themeGenres.map((g) => (
                        <SheetChip key={g.value} active={genres.includes(g.value)} onClick={() => toggleArr('genres', g.value)}>
                          {g.title}
                        </SheetChip>
                      ))}
                    </div>
                  </>
                )}
                {adultGenres.length > 0 && (
                  <>
                    <div className="mb-2 mt-4 flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-wider text-rose-400/80">
                      18+ <span className="text-zinc-600 normal-case">«хентай» здесь называется «этти»</span>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {adultGenres.map((g) => (
                        <SheetChip key={g.value} active={genres.includes(g.value)} accent onClick={() => toggleArr('genres', g.value)}>
                          {g.title}
                        </SheetChip>
                      ))}
                    </div>
                  </>
                )}
              </Section>
            </div>

            <div className="pb-safe shrink-0 border-t border-line bg-[#101013] p-4">
              <button
                onClick={() => setSheetOpen(false)}
                className="h-12 w-full rounded-full bg-white text-[15px] font-semibold text-black transition active:scale-[0.98]"
              >
                Показать результаты
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function Section({ title, right, children }: { title: string; right?: React.ReactNode; children: React.ReactNode }) {
  return (
    <div>
      <div className="mb-2.5 flex items-center justify-between">
        <span className="text-[11px] font-semibold uppercase tracking-wider text-zinc-500">{title}</span>
        {right}
      </div>
      {children}
    </div>
  );
}

function SheetChip({ active, accent, onClick, children }: { active: boolean; accent?: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      className={cn(
        'rounded-full px-3.5 py-2 text-[13px] font-medium transition active:scale-95',
        active ? (accent ? 'bg-rose-400 text-black' : 'bg-white text-black') : 'bg-white/[0.05] text-zinc-300 hover:bg-white/[0.1]',
      )}
    >
      {children}
    </button>
  );
}

function Chip({ children, onRemove }: { children: React.ReactNode; onRemove: () => void }) {
  return (
    <button onClick={onRemove} className="flex shrink-0 items-center gap-1.5 rounded-full bg-white px-3 py-1.5 text-[12px] font-medium text-black active:scale-95">
      {children}
      <Icon.Close className="h-3 w-3" />
    </button>
  );
}

'use client';
import { useEffect, useState } from 'react';

export type Route =
  | { name: 'home' }
  | { name: 'catalog'; params: URLSearchParams }
  | { name: 'search'; q: string }
  | { name: 'watch'; slug: string; params: URLSearchParams }
  | { name: 'favorites' }
  | { name: 'calendar' }
  | { name: 'history' }
  | { name: 'notfound' };

function parse(hash: string): Route {
  const raw = hash.replace(/^#/, '') || '/';
  const [pathPart, queryPart = ''] = raw.split('?');
  const params = new URLSearchParams(queryPart);
  const segments = pathPart.split('/').filter(Boolean);

  if (segments.length === 0) return { name: 'home' };
  if (segments[0] === 'catalog') return { name: 'catalog', params };
  if (segments[0] === 'search') return { name: 'search', q: params.get('q') || '' };
  if (segments[0] === 'favorites') return { name: 'favorites' };
  if (segments[0] === 'history') return { name: 'history' };
  if (segments[0] === 'calendar' || segments[0] === 'schedule') return { name: 'calendar' };
  if (segments[0] === 'anime' && segments[1]) return { name: 'watch', slug: decodeURIComponent(segments[1]), params };
  return { name: 'notfound' };
}

export function useHashRoute(): Route {
  const [route, setRoute] = useState<Route>(() => parse(window.location.hash));
  useEffect(() => {
    const onChange = () => {
      setRoute(parse(window.location.hash));
      window.scrollTo({ top: 0 });
    };
    window.addEventListener('hashchange', onChange);
    return () => window.removeEventListener('hashchange', onChange);
  }, []);
  return route;
}

export function navigate(to: string) {
  window.location.hash = to.startsWith('#') ? to.slice(1) : to;
}

export const links = {
  home: '#/',
  catalog: (q = '') => `#/catalog${q ? `?${q}` : ''}`,
  search: (q: string) => `#/search?q=${encodeURIComponent(q)}`,
  anime: (slug: string, extra?: Record<string, string | number>) => {
    const sp = new URLSearchParams();
    if (extra) Object.entries(extra).forEach(([k, v]) => sp.set(k, String(v)));
    const s = sp.toString();
    return `#/anime/${encodeURIComponent(slug)}${s ? `?${s}` : ''}`;
  },
  favorites: '#/favorites',
  history: '#/history',
  calendar: '#/calendar',
};

'use client';
import { useCallback, useEffect, useState } from 'react';

export interface HistoryEntry {
  slug: string;
  id: number;
  title: string;
  poster: string;
  episode: string;
  dubbing: string;
  total?: number;
  updatedAt: number;
}

export interface FavEntry {
  slug: string;
  id: number;
  title: string;
  poster: string;
  year?: number;
  type?: string;
}

export interface Settings {
  preferredDub?: string;
  preferredPlayer?: string;
  autoNext: boolean;
  autoSwitch: boolean;
  theater: boolean;
}

const HISTORY_KEY = 'yw_history_v1';
const FAV_KEY = 'yw_favs_v1';
const WATCHED_KEY = 'yw_watched_v1';
const SETTINGS_KEY = 'yw_settings_v1';

function read<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function write(key: string, value: unknown) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
    window.dispatchEvent(new CustomEvent('yw-storage', { detail: key }));
  } catch {
    /* ignore */
  }
}

function useSynced<T>(key: string, fallback: T): [T, (v: T) => void] {
  const [value, setValue] = useState<T>(() => read(key, fallback));
  useEffect(() => {
    const handler = (e: Event) => {
      if ((e as CustomEvent).detail === key) setValue(read(key, fallback));
    };
    window.addEventListener('yw-storage', handler);
    return () => window.removeEventListener('yw-storage', handler);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key]);
  const set = useCallback(
    (v: T) => {
      setValue(v);
      write(key, v);
    },
    [key],
  );
  return [value, set];
}

export function useHistory() {
  const [history, setHistory] = useSynced<HistoryEntry[]>(HISTORY_KEY, []);
  const push = useCallback(
    (entry: Omit<HistoryEntry, 'updatedAt'>) => {
      const current = read<HistoryEntry[]>(HISTORY_KEY, []);
      const next = [{ ...entry, updatedAt: Date.now() }, ...current.filter((h) => h.slug !== entry.slug)].slice(0, 40);
      setHistory(next);
    },
    [setHistory],
  );
  const remove = useCallback(
    (slug: string) => setHistory(read<HistoryEntry[]>(HISTORY_KEY, []).filter((h) => h.slug !== slug)),
    [setHistory],
  );
  const clear = useCallback(() => setHistory([]), [setHistory]);
  const get = useCallback((slug: string) => read<HistoryEntry[]>(HISTORY_KEY, []).find((h) => h.slug === slug), []);
  return { history, push, remove, clear, get };
}

export function useFavorites() {
  const [favs, setFavs] = useSynced<FavEntry[]>(FAV_KEY, []);
  const isFav = useCallback((slug: string) => favs.some((f) => f.slug === slug), [favs]);
  const toggle = useCallback(
    (entry: FavEntry) => {
      const current = read<FavEntry[]>(FAV_KEY, []);
      const exists = current.some((f) => f.slug === entry.slug);
      setFavs(exists ? current.filter((f) => f.slug !== entry.slug) : [entry, ...current]);
    },
    [setFavs],
  );
  return { favs, isFav, toggle };
}

type WatchedMap = Record<string, string[]>;

export function useWatched(slug: string) {
  const [all, setAll] = useSynced<WatchedMap>(WATCHED_KEY, {});
  const watched = all[slug] || [];
  const mark = useCallback(
    (episode: string) => {
      const cur = read<WatchedMap>(WATCHED_KEY, {});
      const list = cur[slug] || [];
      if (list.includes(episode)) return;
      setAll({ ...cur, [slug]: [...list, episode] });
    },
    [slug, setAll],
  );
  const toggle = useCallback(
    (episode: string) => {
      const cur = read<WatchedMap>(WATCHED_KEY, {});
      const list = cur[slug] || [];
      setAll({ ...cur, [slug]: list.includes(episode) ? list.filter((e) => e !== episode) : [...list, episode] });
    },
    [slug, setAll],
  );
  const reset = useCallback(() => {
    const cur = read<WatchedMap>(WATCHED_KEY, {});
    delete cur[slug];
    setAll({ ...cur });
  }, [slug, setAll]);
  return { watched, mark, toggle, reset };
}

const DEFAULT_SETTINGS: Settings = { autoNext: true, autoSwitch: true, theater: false };

export function useSettings() {
  const [raw, setSettings] = useSynced<Settings>(SETTINGS_KEY, DEFAULT_SETTINGS);
  // нормализуем, если в хранилище лежат старые настройки без новых полей
  const merged: Settings = { ...DEFAULT_SETTINGS, ...raw };
  // автоподбор источника включён по умолчанию, в том числе для старых профилей
  const settings: Settings = {
    ...merged,
    autoNext: typeof raw?.autoNext === 'boolean' ? raw.autoNext : true,
    autoSwitch: raw?.autoSwitch === false ? false : true,
  };
  const update = useCallback(
    (patch: Partial<Settings>) => setSettings({ ...read<Settings>(SETTINGS_KEY, DEFAULT_SETTINGS), ...patch }),
    [setSettings],
  );
  return { settings, update };
}

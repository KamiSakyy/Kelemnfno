'use client';
// Клиент публичного API Yummy Anime (https://api.yani.tv)
// Swagger: https://yummy-anime.ru/api/swagger
// Все ответы обёрнуты в { response: ... }

export const API_BASE = 'https://api.yani.tv';

export interface Poster {
  fullsize: string;
  big: string;
  small: string;
  medium: string;
  huge: string;
  mega: string;
}

export interface Rating {
  average: number;
  counters: number;
  kp_rating: number;
  anidub_rating: number;
  myanimelist_rating: number;
  worldart_rating: number;
  shikimori_rating: number;
}

export interface GenreShort {
  title: string;
  url: string;
  id: number;
  alias: string;
}

export interface AnimeStatus {
  value: number;
  title: string;
  alias: 'released' | 'ongoing' | 'announcement' | string;
  class: string;
}

export interface AnimeType {
  name: string;
  value: number;
  shortname: string;
  alias: string;
}

export interface Episodes {
  count: number;
  aired: number;
  next_date: number;
  prev_date: number;
}

export interface SkipInfo {
  time: number;
  length: number;
}

export interface VideoItem {
  video_id: number;
  data: { player: string; dubbing: string; player_id: number };
  number: string;
  date: number;
  iframe_url: string;
  index: number;
  skips?: { opening?: SkipInfo | null; ending?: SkipInfo | null };
  views: number;
  duration: number;
}

export interface AnimeItem {
  description: string;
  poster: Poster;
  title: string;
  anime_url: string;
  anime_id: number;
  rating: Rating;
  genres: GenreShort[];
  year: number;
  min_age: { value: number; title_long: string; title: string };
  views: number;
  season: number;
  anime_status: AnimeStatus;
  type: AnimeType;
  top: { category: number; global: number };
  blocked_in: string[];
  remote_ids?: {
    worldart_id: number;
    shikimori_id: number;
    anidub_id: number;
    anilibria_alias: string;
    myanimelist_id: number;
    kp_id: number;
    worldart_type: string;
    sr_id: number;
  };
}

export interface ViewingOrderItem {
  anime_id: number;
  anime_url: string;
  data: { text: string; id: number; index: number };
  poster: Poster;
  title: string;
  anime_status: AnimeStatus;
  type: AnimeType;
  year: number;
  description: string;
  rating: number;
}

export interface AnimeFull extends AnimeItem {
  duration?: number;
  other_titles?: string[];
  creators?: { url: string; title: string; id: number }[];
  studios?: { url: string; title: string; id: number }[];
  original?: string;
  viewing_order?: ViewingOrderItem[];
  videos?: VideoItem[];
  episodes?: Episodes;
}

export interface ScheduleItem {
  description: string;
  poster: Poster;
  title: string;
  anime_url: string;
  anime_id: number;
  episodes: Episodes;
}

export interface Genre {
  title: string;
  href: string;
  value: number;
  more_titles: string[];
  group_id: number;
}

export interface GenresData {
  genres: Genre[];
  groups: { title: string; id: number }[];
}

export interface CatalogData {
  genres: GenresData;
  types: { count: number; type: AnimeType }[];
  data: AnimeItem[];
}

type ApiEnvelope<T> = { response: T; error?: string; error_title?: string; warnings?: unknown[] };

const CORS_FALLBACKS = [
  (u: string) => `https://corsproxy.io/?url=${encodeURIComponent(u)}`,
  (u: string) => `https://api.allorigins.win/raw?url=${encodeURIComponent(u)}`,
];

const cache = new Map<string, unknown>();

async function fetchJson<T>(url: string): Promise<T> {
  if (cache.has(url)) return cache.get(url) as T;

  const attempt = async (target: string, withHeaders: boolean) => {
    const res = await fetch(target, {
      headers: withHeaders ? { Accept: 'application/json, image/webp' } : undefined,
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const json = (await res.json()) as ApiEnvelope<T>;
    if (json.error) throw new Error(json.error_title || json.error);
    return json.response;
  };

  let lastErr: unknown;
  try {
    const data = await attempt(url, true);
    cache.set(url, data);
    return data;
  } catch (e) {
    lastErr = e;
  }
  for (const wrap of CORS_FALLBACKS) {
    try {
      const data = await attempt(wrap(url), false);
      cache.set(url, data);
      return data;
    } catch (e) {
      lastErr = e;
    }
  }
  throw lastErr instanceof Error ? lastErr : new Error('Ошибка сети');
}

function qs(params: Record<string, string | number | undefined | null | (string | number)[]>) {
  const sp = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) {
    if (v === undefined || v === null || v === '') continue;
    if (Array.isArray(v)) {
      if (v.length) v.forEach((item) => sp.append(k, String(item)));
    } else sp.set(k, String(v));
  }
  const s = sp.toString();
  return s ? `?${s}` : '';
}

export interface ListParams {
  q?: string;
  limit?: number;
  offset?: number;
  sort?: 'top' | 'rating' | 'views' | string;
  status?: 'ongoing' | 'released' | 'announcement' | '';
  genres?: number[];
  types?: number[];
}

export const yummy = {
  list: (params: ListParams) => fetchJson<AnimeItem[]>(`${API_BASE}/anime${qs({ ...params })}`),
  search: (q: string, limit = 20) => fetchJson<AnimeItem[]>(`${API_BASE}/anime${qs({ q, limit })}`),
  quickSearch: (q: string) => fetchJson<AnimeItem[]>(`${API_BASE}/search${qs({ q })}`),
  byIds: (ids: number[]) => fetchJson<AnimeItem[]>(`${API_BASE}/anime${qs({ ids })}`),
  schedule: () => fetchJson<ScheduleItem[]>(`${API_BASE}/anime/schedule`),
  anime: (urlOrId: string | number) =>
    fetchJson<AnimeFull>(`${API_BASE}/anime/${encodeURIComponent(String(urlOrId))}${qs({ need_videos: 'true' })}`),
  videos: (id: number) => fetchJson<VideoItem[]>(`${API_BASE}/anime/${id}/videos`),
  genres: () => fetchJson<GenresData>(`${API_BASE}/anime/genres`),
};

/* ---------- Скриншоты: Shikimori → Jikan(MAL) → AniList ---------- */

function withTimeout(ms: number): AbortSignal {
  const c = new AbortController();
  window.setTimeout(() => c.abort(), ms);
  return c.signal;
}

const shotsCache = new Map<string, string[]>();

export async function fetchScreenshots(shikimoriId?: number, malId?: number): Promise<string[]> {
  const key = `${shikimoriId}_${malId}`;
  if (shotsCache.has(key)) return shotsCache.get(key)!;

  const attempts: (() => Promise<string[]>)[] = [];

  const getTextSmart = async (url: string, headers?: Record<string, string>) => {
    const tryOne = async (target: string, withHeaders: boolean) => {
      const r = await fetch(target, { headers: withHeaders ? headers : undefined, signal: withTimeout(7000) });
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return (await r.text()) as string;
    };
    try {
      return await tryOne(url, true);
    } catch {
      for (const wrap of [
        (u: string) => `https://corsproxy.io/?url=${encodeURIComponent(u)}`,
        (u: string) => `https://api.allorigins.win/raw?url=${encodeURIComponent(u)}`,
      ]) {
        try {
          return await tryOne(wrap(url), false);
        } catch {
          /* next */
        }
      }
      throw new Error('fetch failed');
    }
  };

  // 1) Shikimori — публичная JSON-страница сайта (настоящие скриншоты из серий)
  if (shikimoriId) {
    attempts.push(async () => {
      const text = await getTextSmart(`https://shikimori.one/animes/${shikimoriId}.json?lang=ru`, {
        Accept: 'application/json',
      });
      const j = JSON.parse(text);
      const s: string[] = (j.screenshots || []).slice(0, 8).map((x: string) => x.replace(/^\/\//, 'https://'));
      if (!s.length) throw new Error('empty');
      return s;
    });
  }

  // 2) Shikimori API v1.4 (нужен ключ приложения — положите в localStorage: shikimori_client_id)
  if (shikimoriId) {
    attempts.push(async () => {
      const cid = localStorage.getItem('shikimori_client_id');
      const headers: Record<string, string> = { Accept: 'application/json' };
      if (cid) headers.Authorization = `Bearer ${cid}`;
      const r = await fetch(`https://api.shikimori.me/animes/${shikimoriId}?lang=ru`, { headers, signal: withTimeout(7000) });
      if (!r.ok) throw new Error('shikimori api ' + r.status);
      const j = await r.json();
      const s: string[] = (j.screenshots || []).slice(0, 8);
      if (!s.length) throw new Error('empty');
      return s;
    });
  }

  // 3) AniList — скриншоты серий (без ключа, CORS *)
  if (malId) {
    attempts.push(async () => {
      const r = await fetch('https://graphql.anilist.co/', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: `{ Media(idMAL: ${malId}, type: ANIME) { screenshots { location } } }` }),
        signal: withTimeout(7000),
      });
      if (!r.ok) throw new Error('anilist ' + r.status);
      const j = await r.json();
      const s: string[] = (j?.data?.data?.Media?.screenshots || []).slice(0, 8).map((x: { location: string }) => x.location);
      if (!s.length) throw new Error('empty');
      return s;
    });
  }

  // 4) Jikan / MyAnimeList — как последний запасной вариант
  if (malId) {
    attempts.push(async () => {
      const r = await fetch(`https://api.jikan.moe/v4/anime/${malId}/pictures`, { signal: withTimeout(7000) });
      if (!r.ok) throw new Error('jikan ' + r.status);
      const j = await r.json();
      const s: string[] = (j.data || []).slice(0, 8).map((d: { large: string }) => d.large);
      if (!s.length) throw new Error('empty');
      return s;
    });
  }

  for (const fn of attempts) {
    try {
      const s = await fn();
      shotsCache.set(key, s);
      return s;
    } catch {
      /* следующий источник */
    }
  }
  return [];
}

// Утилиты
export function absUrl(u: string | undefined | null): string {
  if (!u) return '';
  if (u.startsWith('//')) return 'https:' + u;
  if (u.startsWith('/')) return 'https://static.yani.tv' + u;
  return u;
}

export function posterUrl(p: Poster | undefined, size: keyof Poster = 'medium') {
  if (!p) return '';
  return absUrl(p[size] || p.medium || p.big || p.fullsize);
}

export function playerName(v: VideoItem) {
  const raw = v.data?.player || '';
  const cleaned = raw.replace(/^Плеер\s+/i, '').trim();
  if (cleaned) return cleaned;
  const url = v.iframe_url || '';
  if (url.includes('kodik')) return 'Kodik';
  if (url.includes('alloha')) return 'Alloha';
  if (url.includes('sibnet')) return 'Sibnet';
  if (url.includes('CVH') || url.includes('cvh')) return 'CVH';
  return 'Плеер';
}

export function dubbingName(v: VideoItem) {
  const raw = v.data?.dubbing || '';
  return raw.replace(/^Озвучка\s+/i, '').trim() || 'Без названия';
}

export function cleanDescription(d: string | undefined) {
  if (!d) return '';
  return d
    .replace(/\[\/?[a-z]+\]/gi, '')
    .replace(/@Shikimori/gi, '')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

export function formatViews(n: number | undefined) {
  if (!n) return '0';
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(1).replace('.0', '') + 'M';
  if (n >= 1_000) return (n / 1_000).toFixed(1).replace('.0', '') + 'K';
  return String(n);
}

export function formatDuration(sec: number | undefined) {
  if (!sec) return '';
  const m = Math.round(sec / 60);
  if (m >= 60) return `${Math.floor(m / 60)} ч ${m % 60} мин`;
  return `${m} мин`;
}

export const SEASONS = ['', 'Зима', 'Весна', 'Лето', 'Осень'];

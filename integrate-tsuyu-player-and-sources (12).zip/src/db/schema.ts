import { bigint, index, integer, jsonb, pgTable, text, timestamp } from "drizzle-orm/pg-core";

/** Маршруты озвучки (секретные данные источника) — только на сервере. */
export interface StoredRoute {
  episode: number;
  source: string;
  embed?: string;
  streams?: Record<string, string>;
  name?: string;
  duration?: number;
}

/** Собранная дорожка озвучки: пользователь видит только `voice`. */
export const tsuyuTracks = pgTable(
  "tsuyu_tracks",
  {
    id: text("id").primaryKey(),
    lookupKey: text("lookup_key").notNull(),
    voice: text("voice").notNull(),
    voiceKey: text("voice_key").notNull(),
    episodes: jsonb("episodes").$type<number[]>().notNull(),
    routes: jsonb("routes").$type<StoredRoute[]>().notNull(),
    score: integer("score").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("tsuyu_tracks_lookup_idx").on(t.lookupKey)],
);

/** Кэш уже распознанных потоков. */
export const tsuyuStreams = pgTable("tsuyu_streams", {
  key: text("key").primaryKey(),
  payload: jsonb("payload").$type<{ quality: number; url: string; referer: string }[]>().notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

/** Статистика источников — умное ранжирование (порт SourceEngine.score). */
export const tsuyuSourceStats = pgTable("tsuyu_source_stats", {
  source: text("source").primaryKey(),
  ok: integer("ok").notNull().default(0),
  fail: integer("fail").notNull().default(0),
  avgMs: integer("avg_ms").notNull().default(0),
  lastOk: bigint("last_ok", { mode: "number" }).notNull().default(0),
  lastBad: bigint("last_bad", { mode: "number" }).notNull().default(0),
  failRun: integer("fail_run").notNull().default(0),
});

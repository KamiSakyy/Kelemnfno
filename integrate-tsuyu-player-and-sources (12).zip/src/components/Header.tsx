'use client';
import { useEffect, useRef, useState } from 'react';
import { yummy, posterUrl, type AnimeItem } from '../api/yummy';
import { links, navigate } from '../hooks/useHashRoute';
import { cn } from '../utils/cn';
import { Icon } from './AnimeCard';

export function Header() {
  const [open, setOpen] = useState(false);
  const [randomBusy, setRandomBusy] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 10);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement)?.tagName;
      const typing = tag === 'INPUT' || tag === 'TEXTAREA';
      if ((e.key === 'k' && (e.metaKey || e.ctrlKey)) || (e.key === '/' && !typing)) {
        e.preventDefault();
        setOpen(true);
      }
      if (e.key === 'Escape') setOpen(false);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  const random = async () => {
    if (randomBusy) return;
    setRandomBusy(true);
    try {
      const offset = Math.floor(Math.random() * 400);
      const list = await yummy.list({ sort: 'top', limit: 1, offset });
      if (list[0]) navigate(links.anime(list[0].anime_url));
    } catch {
      /* ignore */
    } finally {
      setRandomBusy(false);
    }
  };

  return (
    <>
      <header
        className={cn(
          'sticky top-0 z-40 transition-colors duration-300',
          scrolled ? 'border-b border-line bg-bg/85 backdrop-blur-xl' : 'border-b border-transparent',
        )}
      >
        <div className="mx-auto flex h-14 max-w-[1400px] items-center justify-between px-4 sm:px-6">
          <a href={links.home} className="flex items-center gap-2.5">
            <span className="grid h-8 w-8 place-items-center rounded-[10px] bg-white text-base font-extrabold text-black">Y</span>
            <span className="text-[15px] font-semibold tracking-tight text-white">Аниме</span>
          </a>
          <div className="flex items-center gap-1.5">
            <button
              onClick={random}
              title="Случайное аниме"
              className={cn(
                'grid h-10 w-10 place-items-center rounded-full text-zinc-400 transition hover:bg-white/[0.06] hover:text-white active:scale-90',
                randomBusy && 'animate-pulse',
              )}
            >
              <Icon.Dice className="h-[20px] w-[20px]" />
            </button>
            <button
              onClick={() => setOpen(true)}
              title="Поиск"
              className="grid h-10 w-10 place-items-center rounded-full text-zinc-400 transition hover:bg-white/[0.06] hover:text-white active:scale-90"
            >
              <Icon.Search className="h-[20px] w-[20px]" />
            </button>
          </div>
        </div>
      </header>

      {open && <SearchOverlay onClose={() => setOpen(false)} />}
    </>
  );
}

/* ---------- Полноэкранный поиск (Android style) ---------- */
function SearchOverlay({ onClose }: { onClose: () => void }) {
  const [q, setQ] = useState('');
  const [results, setResults] = useState<AnimeItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [cursor, setCursor] = useState(0);
  const [recent, setRecent] = useState<string[]>([]);
  const inputRef = useRef<HTMLInputElement>(null);

  const RECENT_KEY = 'yw_recent_search';
  const TRENDING = ['Наруто', 'Ванпис', 'Магическая битва', 'Атака титанов', 'Клинок, рассекающий демонов', 'Фрирен'];

  useEffect(() => {
    inputRef.current?.focus();
    document.body.style.overflow = 'hidden';
    try {
      const raw = localStorage.getItem(RECENT_KEY);
      const list = raw ? (JSON.parse(raw) as string[]) : [];
      setRecent(Array.isArray(list) ? list.slice(0, 8) : []);
    } catch {
      /* ignore */
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [RECENT_KEY]);

  useEffect(() => {
    const query = q.trim();
    if (query.length < 2) {
      setResults([]);
      setLoading(false);
      return;
    }
    setLoading(true);
    const t = window.setTimeout(() => {
      yummy
        .search(query, 12)
        .then((r) => {
          setResults(r);
          setCursor(0);
        })
        .catch(() => setResults([]))
        .finally(() => setLoading(false));
    }, 300);
    return () => window.clearTimeout(t);
  }, [q]);

  const choose = (value: string) => {
    const clean = value.trim();
    if (clean.length < 2) return;
    try {
      const raw = localStorage.getItem(RECENT_KEY);
      const list = raw ? (JSON.parse(raw) as string[]) : [];
      const next = [clean, ...list.filter((x) => x.toLowerCase() !== clean.toLowerCase())].slice(0, 8);
      localStorage.setItem(RECENT_KEY, JSON.stringify(next));
      setRecent(next);
    } catch {
      /* ignore */
    }
    navigate(links.search(clean));
    onClose();
  };

  const go = (a?: AnimeItem) => {
    if (a) navigate(links.anime(a.anime_url));
    else if (q.trim().length >= 2) navigate(links.search(q.trim()));
    onClose();
  };

  const onKey = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setCursor((c) => Math.min(results.length - 1, c + 1));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setCursor((c) => Math.max(0, c - 1));
    } else if (e.key === 'Enter') {
      e.preventDefault();
      go(results[cursor]);
    }
  };

  const showHome = q.trim().length < 2;

  return (
    <div className="fixed inset-0 z-50 bg-bg animate-fade-in sm:bg-black/60 sm:p-4 sm:pt-[8vh] sm:backdrop-blur-sm" onClick={onClose}>
      <div
        className="mx-auto flex h-full w-full flex-col overflow-hidden bg-bg sm:h-auto sm:max-h-[80vh] sm:max-w-xl sm:rounded-3xl sm:border sm:border-white/10 sm:bg-surface sm:shadow-2xl sm:animate-fade-up"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Поле */}
        <div className="flex items-center gap-2 border-b border-line px-2 sm:px-3">
          <button
            onClick={onClose}
            aria-label="Назад"
            className="grid h-11 w-11 shrink-0 place-items-center rounded-full text-zinc-400 transition hover:bg-white/[0.06] hover:text-white"
          >
            <Icon.ChevronLeft className="h-5 w-5" />
          </button>
          <div className="flex flex-1 items-center gap-2.5">
            <Icon.Search className="h-5 w-5 shrink-0 text-zinc-500" />
            <input
              ref={inputRef}
              value={q}
              onChange={(e) => setQ(e.target.value)}
              onKeyDown={onKey}
              placeholder="Название аниме…"
              enterKeyHint="search"
              className="h-14 w-full bg-transparent text-[16px] text-white placeholder:text-zinc-600 outline-none"
            />
          </div>
          {loading ? (
            <span className="mr-1 h-4 w-4 shrink-0 animate-spin rounded-full border-2 border-zinc-700 border-t-white" />
          ) : (
            q && (
              <button
                onClick={() => setQ('')}
                aria-label="Очистить"
                className="grid h-11 w-11 shrink-0 place-items-center rounded-full text-zinc-500 transition hover:bg-white/[0.06] hover:text-white"
              >
                <Icon.Close className="h-4 w-4" />
              </button>
            )
          )}
        </div>

        <div className="flex-1 overflow-y-auto p-2">
          {/* Пустое состояние: история + тренды */}
          {showHome && (
            <div className="space-y-6 p-2">
              {recent.length > 0 && (
                <section>
                  <div className="mb-1 flex items-center justify-between px-2">
                    <div className="flex items-center gap-2 text-[12px] font-medium text-zinc-500">
                      <Icon.Clock className="h-3.5 w-3.5" /> Недавние
                    </div>
                    <button
                      onClick={() => {
                        try {
                          localStorage.removeItem(RECENT_KEY);
                        } catch {
                          /* ignore */
                        }
                        setRecent([]);
                      }}
                      className="text-[11px] text-zinc-600 transition hover:text-zinc-300"
                    >
                      Очистить
                    </button>
                  </div>
                  <div className="grid gap-0.5">
                    {recent.map((r) => (
                      <button
                        key={r}
                        onClick={() => choose(r)}
                        className="flex w-full items-center gap-3 rounded-2xl px-3 py-2.5 text-left text-[14px] text-zinc-200 transition hover:bg-white/[0.05] active:scale-[0.99]"
                      >
                        <Icon.Clock className="h-4 w-4 shrink-0 text-zinc-600" />
                        <span className="truncate">{r}</span>
                      </button>
                    ))}
                  </div>
                </section>
              )}
              <section>
                <div className="mb-2 flex items-center gap-2 px-2 text-[12px] font-medium text-zinc-500">
                  <Icon.Trend className="h-3.5 w-3.5" /> Часто ищут
                </div>
                <div className="flex flex-wrap gap-2 px-2">
                  {TRENDING.map((t) => (
                    <button
                      key={t}
                      onClick={() => choose(t)}
                      className="rounded-full border border-line bg-white/[0.03] px-3.5 py-1.5 text-[13px] text-zinc-300 transition hover:border-white/25 hover:bg-white/[0.07] hover:text-white active:scale-95"
                    >
                      {t}
                    </button>
                  ))}
                </div>
              </section>
            </div>
          )}

          {/* Результаты */}
          {!showHome && q.trim().length >= 2 && !loading && results.length === 0 && (
            <div className="px-3 py-12 text-center">
              <div className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-white/[0.04] text-zinc-500">
                <Icon.Search className="h-5 w-5" />
              </div>
              <p className="mt-3 text-sm text-zinc-500">Ничего не найдено по «{q.trim()}»</p>
            </div>
          )}
          {results.map((a, i) => (
            <button
              key={a.anime_id}
              onMouseEnter={() => setCursor(i)}
              onClick={() => go(a)}
              className={cn(
                'flex w-full items-center gap-3 rounded-2xl px-3 py-2.5 text-left transition active:scale-[0.99]',
                i === cursor ? 'bg-white/[0.07]' : 'hover:bg-white/[0.04]',
              )}
            >
              <div className="relative h-[68px] w-11 shrink-0 overflow-hidden rounded-lg bg-white/[0.04]">
                <img src={posterUrl(a.poster, 'small')} alt="" className="h-full w-full object-cover" loading="lazy" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="truncate text-[14px] font-medium text-white">{a.title}</div>
                <div className="mt-1 flex items-center gap-1.5 text-xs text-zinc-500">
                  <span>{a.year || '—'}</span>
                  <span className="text-zinc-700">·</span>
                  <span>{a.type?.shortname}</span>
                  {a.rating?.average > 0 && (
                    <span className="ml-auto flex items-center gap-0.5 font-medium text-zinc-300">
                      <Icon.Star className="h-3 w-3 text-amber-400" /> {a.rating.average.toFixed(1)}
                    </span>
                  )}
                </div>
              </div>
              {a.anime_status?.alias === 'ongoing' && (
                <span className="shrink-0 rounded-full bg-emerald-500/15 px-2 py-0.5 text-[10px] font-medium text-emerald-300">онгоинг</span>
              )}
              <span
                className={cn(
                  'grid h-8 w-8 shrink-0 place-items-center rounded-full bg-white text-black transition',
                  i === cursor ? 'scale-100 opacity-100' : 'scale-75 opacity-0',
                )}
              >
                <Icon.Play className="ml-0.5 h-3.5 w-3.5" />
              </span>
            </button>
          ))}
          {results.length > 0 && (
            <button
              onClick={() => go()}
              className="mt-1 flex w-full items-center justify-center gap-2 rounded-2xl px-3 py-3 text-[13px] font-medium text-zinc-400 transition hover:bg-white/[0.05] hover:text-white"
            >
              Все результаты по «{q.trim()}» <Icon.ChevronRight className="h-4 w-4" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

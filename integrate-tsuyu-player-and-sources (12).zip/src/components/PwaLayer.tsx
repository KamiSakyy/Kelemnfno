'use client';

import { useEffect, useState } from 'react';

interface InstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>;
}

/** Регистрация service worker, подсказка установки и индикатор офлайна. */
export default function PwaLayer() {
  const [deferred, setDeferred] = useState<InstallPromptEvent | null>(null);
  const [offline, setOffline] = useState(false);
  const [updateReady, setUpdateReady] = useState<ServiceWorker | null>(null);
  const [hidden, setHidden] = useState(true);

  useEffect(() => {
    if (!('serviceWorker' in navigator)) return;
    let cancelled = false;

    const register = async () => {
      try {
        const reg = await navigator.serviceWorker.register('/sw.js', { scope: '/' });
        if (cancelled) return;
        reg.addEventListener('updatefound', () => {
          const sw = reg.installing;
          if (!sw) return;
          sw.addEventListener('statechange', () => {
            if (sw.state === 'installed' && navigator.serviceWorker.controller) setUpdateReady(sw);
          });
        });
      } catch {
        /* SW не критичен для работы сайта */
      }
    };

    if (document.readyState === 'complete') register();
    else window.addEventListener('load', register, { once: true });

    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    const onPrompt = (e: Event) => {
      e.preventDefault();
      setDeferred(e as InstallPromptEvent);
      setHidden(localStorage.getItem('yw_install_hidden') === '1');
    };
    const onInstalled = () => {
      setDeferred(null);
      localStorage.setItem('yw_install_hidden', '1');
    };
    const sync = () => setOffline(!navigator.onLine);

    sync();
    window.addEventListener('beforeinstallprompt', onPrompt);
    window.addEventListener('appinstalled', onInstalled);
    window.addEventListener('online', sync);
    window.addEventListener('offline', sync);
    return () => {
      window.removeEventListener('beforeinstallprompt', onPrompt);
      window.removeEventListener('appinstalled', onInstalled);
      window.removeEventListener('online', sync);
      window.removeEventListener('offline', sync);
    };
  }, []);

  const install = async () => {
    if (!deferred) return;
    await deferred.prompt();
    await deferred.userChoice.catch(() => null);
    setDeferred(null);
  };

  const dismiss = () => {
    localStorage.setItem('yw_install_hidden', '1');
    setHidden(true);
  };

  return (
    <>
      {offline && (
        <div className="animate-fade-up fixed inset-x-0 top-0 z-[60] bg-amber-500/90 py-1.5 text-center text-[12px] font-medium text-black">
          Нет соединения — показываем сохранённые данные
        </div>
      )}

      {updateReady && (
        <div className="animate-fade-up fixed bottom-24 left-1/2 z-[60] -translate-x-1/2 md:bottom-6">
          <button
            onClick={() => {
              updateReady.postMessage('SKIP_WAITING');
              setUpdateReady(null);
              setTimeout(() => location.reload(), 250);
            }}
            className="rounded-full border border-white/15 bg-black/85 px-4 py-2.5 text-[13px] font-semibold text-white backdrop-blur transition active:scale-95"
          >
            Доступно обновление · Обновить
          </button>
        </div>
      )}

      {deferred && !hidden && (
        <div className="animate-fade-up pb-safe fixed inset-x-3 bottom-24 z-[60] md:inset-x-auto md:right-6 md:bottom-6 md:w-[380px]">
          <div className="flex items-center gap-3 rounded-2xl border border-line bg-surface/95 p-3 shadow-2xl backdrop-blur">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src="/icons/icon-96.png" alt="" width={44} height={44} className="h-11 w-11 rounded-xl" />
            <div className="min-w-0 flex-1">
              <p className="truncate text-[13px] font-semibold text-white">Установить приложение</p>
              <p className="truncate text-[11px] text-zinc-500">Полный экран, ярлык и быстрый запуск</p>
            </div>
            <button
              onClick={install}
              className="shrink-0 rounded-full bg-white px-4 py-2 text-[13px] font-semibold text-black transition active:scale-95"
            >
              Установить
            </button>
            <button
              onClick={dismiss}
              aria-label="Скрыть"
              className="shrink-0 rounded-full px-2 py-2 text-zinc-500 transition hover:text-white"
            >
              ✕
            </button>
          </div>
        </div>
      )}
    </>
  );
}

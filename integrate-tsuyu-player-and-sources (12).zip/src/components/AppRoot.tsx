'use client';
import { Header } from './Header';
import { BottomNav } from './BottomNav';
import { useHashRoute } from '../hooks/useHashRoute';
import { Home } from '../screens/Home';
import { Catalog } from '../screens/Catalog';
import { Watch } from '../screens/Watch';
import { Calendar } from '../screens/Calendar';
import { Favorites, History, NotFound, Search } from '../screens/Misc';

export default function App() {
  const route = useHashRoute();

  let page: React.ReactNode;
  switch (route.name) {
    case 'catalog':
      page = <Catalog key={route.params.toString()} params={route.params} />;
      break;
    case 'search':
      page = <Search key={route.q} q={route.q} />;
      break;
    case 'watch':
      page = <Watch key={route.slug} slug={route.slug} params={route.params} />;
      break;
    case 'favorites':
      page = <Favorites />;
      break;
    case 'history':
      page = <History />;
      break;
    case 'calendar':
      page = <Calendar />;
      break;
    case 'notfound':
      page = <NotFound />;
      break;
    default:
      page = <Home />;
  }

  return (
    <div className="flex min-h-screen flex-col bg-bg text-zinc-100">
      <Header />
      <main className="flex-1 animate-fade-in pb-28 md:pb-32" key={route.name}>
        {page}
      </main>

      <BottomNav active={route.name} />
    </div>
  );
}

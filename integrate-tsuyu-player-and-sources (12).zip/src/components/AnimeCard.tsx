'use client';
import { useRef, useState } from 'react';
import { posterUrl, type AnimeItem, type Poster } from '../api/yummy';
import { links } from '../hooks/useHashRoute';
import { cn } from '../utils/cn';

/* ---------- Иконки ---------- */
export const Icon = {
  Play: (p: { className?: string }) => (
    <svg className={p.className} viewBox="0 0 24 24" fill="currentColor">
      <path d="M8 5.14v13.72c0 .8.87 1.3 1.56.87l10.7-6.86a1 1 0 000-1.74L9.56 4.27C8.87 3.84 8 4.34 8 5.14z" />
    </svg>
  ),
  Star: (p: { className?: string }) => (
    <svg className={p.className} viewBox="0 0 24 24" fill="currentColor">
      <path d="M12 2.5l2.9 6.2 6.8.8-5 4.7 1.3 6.7L12 17.6l-6 3.3 1.3-6.7-5-4.7 6.8-.8z" />
    </svg>
  ),
  Heart: (p: { className?: string; filled?: boolean }) => (
    <svg className={p.className} viewBox="0 0 24 24" fill={p.filled ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth={1.8}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M4.3 6.3a4.5 4.5 0 000 6.4L12 20.4l7.7-7.7a4.5 4.5 0 00-6.4-6.4L12 7.6l-1.3-1.3a4.5 4.5 0 00-6.4 0z" />
    </svg>
  ),
  Check: (p: { className?: string }) => (
    <svg className={p.className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.5}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M5 12.5l4.5 4.5L19 7.5" />
    </svg>
  ),
  ChevronLeft: (p: { className?: string }) => (
    <svg className={p.className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M15 5l-7 7 7 7" />
    </svg>
  ),
  ChevronRight: (p: { className?: string }) => (
    <svg className={p.className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
    </svg>
  ),
  Search: (p: { className?: string }) => (
    <svg className={p.className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-4.3-4.3M17 11A6 6 0 115 11a6 6 0 0112 0z" />
    </svg>
  ),
  Close: (p: { className?: string }) => (
    <svg className={p.className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}>
      <path strokeLinecap="round" d="M6 18L18 6M6 6l12 12" />
    </svg>
  ),
  Alert: (p: { className?: string }) => (
    <svg className={p.className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.9}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v4m0 3.5h.01M10.3 3.9L2.6 17.2A1.9 1.9 0 004.3 20h15.4a1.9 1.9 0 001.7-2.8L13.7 3.9a1.9 1.9 0 00-3.4 0z" />
    </svg>
  ),
  Sparkle: (p: { className?: string }) => (
    <svg className={p.className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.7}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M12 3l1.6 4.6L18 9.2l-4.4 1.6L12 15.4l-1.6-4.6L6 9.2l4.4-1.6L12 3zM18.5 15l.8 2.2 2.2.8-2.2.8-.8 2.2-.8-2.2-2.2-.8 2.2-.8.8-2.2z" />
    </svg>
  ),
  Clock: (p: { className?: string }) => (
    <svg className={p.className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8}>
      <circle cx="12" cy="12" r="8.5" />
      <path strokeLinecap="round" strokeLinejoin="round" d="M12 7.5V12l3 2" />
    </svg>
  ),
  Sliders: (p: { className?: string }) => (
    <svg className={p.className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.9}>
      <path strokeLinecap="round" d="M4 8h9M17 8h3M4 16h3M11 16h9" />
      <circle cx="15" cy="8" r="2" />
      <circle cx="9" cy="16" r="2" />
    </svg>
  ),
  Trend: (p: { className?: string }) => (
    <svg className={p.className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.9}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M4 16l5-5 3.5 3.5L20 8" />
      <path strokeLinecap="round" strokeLinejoin="round" d="M15 8h5v5" />
    </svg>
  ),
  Calendar: (p: { className?: string }) => (
    <svg className={p.className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8}>
      <rect x="3" y="5" width="18" height="16" rx="3" />
      <path strokeLinecap="round" d="M3 10h18M8 3v4M16 3v4" />
    </svg>
  ),
  Dice: (p: { className?: string }) => (
    <svg className={p.className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8}>
      <rect x="4" y="4" width="16" height="16" rx="4" />
      <circle cx="9" cy="9" r="1.2" fill="currentColor" />
      <circle cx="15" cy="15" r="1.2" fill="currentColor" />
      <circle cx="15" cy="9" r="1.2" fill="currentColor" />
      <circle cx="9" cy="15" r="1.2" fill="currentColor" />
    </svg>
  ),
  Expand: (p: { className?: string }) => (
    <svg className={p.className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8}>
      <rect x="3" y="6" width="18" height="12" rx="2" />
    </svg>
  ),
  External: (p: { className?: string }) => (
    <svg className={p.className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M14 4h6v6M20 4l-9 9M19 14v5a1 1 0 01-1 1H5a1 1 0 01-1-1V6a1 1 0 011-1h5" />
    </svg>
  ),
  Share: (p: { className?: string }) => (
    <svg className={p.className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M4 12v7a1 1 0 001 1h14a1 1 0 001-1v-7M12 15V3m0 0L8 7m4-4l4 4" />
    </svg>
  ),
  Download: (p: { className?: string }) => (
    <svg className={p.className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M12 4v11m0 0l-4.5-4.5M12 15l4.5-4.5M4.5 20h15" />
    </svg>
  ),
};

/* ---------- Карточка ---------- */
interface CardProps {
  slug: string;
  title: string;
  poster?: Poster;
  posterSrc?: string;
  rating?: number;
  year?: number;
  type?: string;
  status?: string;
  badge?: string;
  subtitle?: string;
  progress?: number; // 0..1
  className?: string;
  href?: string;
}

export function Card({ slug, title, poster, posterSrc, rating, year, type, status, badge, subtitle, progress, className, href }: CardProps) {
  const src = posterSrc || posterUrl(poster, 'big');
  return (
    <a href={href || links.anime(slug)} className={cn('group block', className)}>
      <div className="relative aspect-[2/3] overflow-hidden rounded-xl bg-surface-2 ring-1 ring-line transition-all duration-300 group-hover:ring-white/20">
        <img
          src={src}
          alt={title}
          loading="lazy"
          className="h-full w-full object-cover transition duration-500 ease-out group-hover:scale-[1.04]"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
        <div className="absolute inset-0 grid place-items-center opacity-0 transition duration-300 group-hover:opacity-100">
          <span className="grid h-11 w-11 scale-90 place-items-center rounded-full bg-white text-black shadow-xl transition duration-300 group-hover:scale-100">
            <Icon.Play className="ml-0.5 h-4 w-4" />
          </span>
        </div>
        <div className="absolute left-2 top-2 flex gap-1">
          {rating !== undefined && rating > 0 && (
            <span className="flex items-center gap-1 rounded-md bg-black/60 px-1.5 py-0.5 text-[11px] font-semibold text-white backdrop-blur-md">
              <Icon.Star className="h-2.5 w-2.5 text-amber-400" />
              {rating.toFixed(1)}
            </span>
          )}
        </div>
        {badge && (
          <span className="absolute right-2 top-2 rounded-md bg-white px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wide text-black">
            {badge}
          </span>
        )}
        {status === 'ongoing' && !badge && (
          <span className="absolute right-2 top-2 flex items-center gap-1 rounded-md bg-black/60 px-1.5 py-0.5 text-[10px] font-semibold text-emerald-300 backdrop-blur-md">
            <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-400" /> онгоинг
          </span>
        )}
        {progress !== undefined && progress > 0 && (
          <div className="absolute inset-x-0 bottom-0 h-1 bg-white/10">
            <div className="h-full bg-accent" style={{ width: `${Math.min(100, progress * 100)}%` }} />
          </div>
        )}
      </div>
      <div className="mt-2.5 px-0.5">
        <h3 className="line-clamp-2 text-[13px] font-medium leading-snug text-zinc-100 transition group-hover:text-white">{title}</h3>
        <p className="mt-1 text-xs text-zinc-500">{subtitle ?? [year || null, type || null].filter(Boolean).join(' · ')}</p>
      </div>
    </a>
  );
}

export function AnimeCard({ anime, badge }: { anime: AnimeItem; badge?: string }) {
  return (
    <Card
      slug={anime.anime_url}
      title={anime.title}
      poster={anime.poster}
      rating={anime.rating?.average}
      year={anime.year || undefined}
      type={anime.type?.shortname}
      status={anime.anime_status?.alias}
      badge={badge}
    />
  );
}

export function CardSkeleton() {
  return (
    <div>
      <div className="skeleton aspect-[2/3] rounded-xl" />
      <div className="mt-2.5 space-y-1.5">
        <div className="skeleton h-3.5 w-4/5 rounded" />
        <div className="skeleton h-3 w-2/5 rounded" />
      </div>
    </div>
  );
}

export function Grid({ children }: { children: React.ReactNode }) {
  return <div className="grid grid-cols-3 gap-x-3 gap-y-6 sm:grid-cols-4 sm:gap-x-4 md:grid-cols-5 lg:grid-cols-6 xl:grid-cols-7">{children}</div>;
}

/* ---------- Горизонтальный ряд ---------- */
export function Row({ children }: { children: React.ReactNode }) {
  const ref = useRef<HTMLDivElement>(null);
  const [canL, setCanL] = useState(false);
  const [canR, setCanR] = useState(true);

  const update = () => {
    const el = ref.current;
    if (!el) return;
    setCanL(el.scrollLeft > 4);
    setCanR(el.scrollLeft + el.clientWidth < el.scrollWidth - 4);
  };
  const scroll = (dir: 1 | -1) => ref.current?.scrollBy({ left: dir * ref.current.clientWidth * 0.8, behavior: 'smooth' });

  return (
    <div className="group/row relative -mx-4 sm:-mx-6">
      <div ref={ref} onScroll={update} className="no-scrollbar flex snap-x gap-3 overflow-x-auto px-4 pb-1 sm:gap-4 sm:px-6">
        {children}
      </div>
      {canL && (
        <button
          onClick={() => scroll(-1)}
          className="absolute left-2 top-[38%] hidden h-10 w-10 -translate-y-1/2 place-items-center rounded-full bg-black/70 text-white opacity-0 ring-1 ring-white/10 backdrop-blur transition group-hover/row:opacity-100 md:grid"
        >
          <Icon.ChevronLeft className="h-5 w-5" />
        </button>
      )}
      {canR && (
        <button
          onClick={() => scroll(1)}
          className="absolute right-2 top-[38%] hidden h-10 w-10 -translate-y-1/2 place-items-center rounded-full bg-black/70 text-white opacity-0 ring-1 ring-white/10 backdrop-blur transition group-hover/row:opacity-100 md:grid"
        >
          <Icon.ChevronRight className="h-5 w-5" />
        </button>
      )}
    </div>
  );
}

export function RowItem({ children }: { children: React.ReactNode }) {
  return <div className="w-[128px] shrink-0 snap-start sm:w-[150px] lg:w-[164px]">{children}</div>;
}

/* ---------- Заголовки / состояния ---------- */
export function SectionTitle({ title, href, subtitle, action }: { title: string; href?: string; subtitle?: string; action?: React.ReactNode }) {
  return (
    <div className="mb-4 flex items-end justify-between gap-4">
      <div>
        <h2 className="text-lg font-semibold tracking-tight text-white sm:text-xl">{title}</h2>
        {subtitle && <p className="mt-0.5 text-[13px] text-zinc-500">{subtitle}</p>}
      </div>
      {action}
      {href && !action && (
        <a href={href} className="flex items-center gap-1 text-[13px] font-medium text-zinc-400 transition hover:text-white">
          Все <Icon.ChevronRight className="h-3.5 w-3.5" />
        </a>
      )}
    </div>
  );
}

export function ErrorBox({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <div className="rounded-2xl border border-line bg-surface p-8 text-center">
      <p className="text-sm text-zinc-300">{message}</p>
      {onRetry && (
        <button onClick={onRetry} className="mt-4 rounded-lg bg-white px-4 py-2 text-sm font-semibold text-black transition hover:bg-zinc-200">
          Повторить
        </button>
      )}
    </div>
  );
}

export function Empty({ icon, title, text, action }: { icon: React.ReactNode; title: string; text?: string; action?: React.ReactNode }) {
  return (
    <div className="rounded-2xl border border-dashed border-white/10 px-6 py-20 text-center">
      <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-surface-2 text-zinc-400">{icon}</div>
      <h3 className="mt-5 text-lg font-semibold text-white">{title}</h3>
      {text && <p className="mx-auto mt-1 max-w-sm text-sm text-zinc-500">{text}</p>}
      {action && <div className="mt-6">{action}</div>}
    </div>
  );
}

export function PageHeader({ title, subtitle, children }: { title: string; subtitle?: string; children?: React.ReactNode }) {
  return (
    <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-white sm:text-3xl">{title}</h1>
        {subtitle && <p className="mt-1 text-sm text-zinc-500">{subtitle}</p>}
      </div>
      {children}
    </div>
  );
}

export const btn = {
  primary: 'inline-flex items-center justify-center gap-2 rounded-lg bg-white px-4 py-2 text-sm font-semibold text-black transition hover:bg-zinc-200 disabled:opacity-40 disabled:hover:bg-white',
  ghost: 'inline-flex items-center justify-center gap-2 rounded-lg border border-line bg-white/[0.03] px-4 py-2 text-sm font-medium text-zinc-200 transition hover:bg-white/[0.08] disabled:opacity-40',
  icon: 'grid h-9 w-9 place-items-center rounded-lg border border-line bg-white/[0.03] text-zinc-300 transition hover:bg-white/[0.08] hover:text-white',
  chip: (active: boolean) =>
    cn(
      'rounded-lg px-3 py-1.5 text-[13px] font-medium transition',
      active ? 'bg-white text-black' : 'bg-white/[0.04] text-zinc-300 hover:bg-white/[0.09] hover:text-white',
    ),
};

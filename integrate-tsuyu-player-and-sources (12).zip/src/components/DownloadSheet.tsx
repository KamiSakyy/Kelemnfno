'use client';
import { useCallback, useEffect, useRef, useState } from 'react';
import { absUrl, type VideoItem } from '../api/yummy';
import { downloadHls, episodeTag, resolveDownloadSource, sanitizeFilename, type DownloadSource, type DlProgress } from '../lib/downloader';
import { cn } from '../utils/cn';
import { Icon } from './AnimeCard';

interface Props {
  video: VideoItem;
  title: string;
  initialSource?: DownloadSource;
  onClose: () => void;
}

type State = 'resolving' | 'ready' | 'downloading' | 'done' | 'error';

function fmtBytes(n: number) {
  if (n >= 1e9) return (n / 1e9).toFixed(2) + ' ГБ';
  if (n >= 1e6) return (n / 1e6).toFixed(1) + ' МБ';
  return Math.round(n / 1e3) + ' КБ';
}

export function DownloadSheet({ video, title, initialSource, onClose }: Props) {
  const [state, setState] = useState<State>(initialSource ? 'ready' : 'resolving');
  const [source, setSource] = useState<DownloadSource | null>(initialSource || null);
  const [error, setError] = useState('');
  const [progress, setProgress] = useState<DlProgress | null>(null);
  const [quality, setQuality] = useState(initialSource?.quality && initialSource.quality !== '—' ? initialSource.quality : '');
  const cancelRef = useRef({ cancel: false });
  const defaultQuality = (video.iframe_url || '').match(/\/(1080p|720p|480p|360p)\//i)?.[1] || '720p';
  const qualities = ['1080p', '720p', '480p', '360p'];

  const filename = `${sanitizeFilename(title)} ${episodeTag(video.number)} ${quality || defaultQuality} .ts`;

  const resolve = useCallback(
    async (q?: string) => {
      if (initialSource) {
        setSource(initialSource);
        setState('ready');
        return;
      }
      setState('resolving');
      setError('');
      try {
        const s = await resolveDownloadSource(video, q);
        setSource(s);
        setQuality(s.quality === '—' ? '' : s.quality);
        setState('ready');
      } catch (e) {
        setError(e instanceof Error ? e.message : 'Не удалось найти прямую ссылку');
        setState('error');
      }
    },
    [video, initialSource],
  );

  useEffect(() => {
    if (!initialSource) resolve();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const start = async () => {
    if (!source) return;
    cancelRef.current = { cancel: false };
    setState('downloading');
    setProgress(null);
    try {
      await downloadHls(source.url, filename, setProgress, cancelRef.current);
      setState('done');
    } catch (e) {
      const msg = e instanceof Error ? e.message : 'Ошибка скачивания';
      if (msg === 'cancelled') {
        setState('ready');
        return;
      }
      setError(msg);
      setState('error');
    }
  };

  const cancel = () => {
    cancelRef.current.cancel = true;
  };

  const playerUrl = absUrl(video.iframe_url);

  return (
    <div className="fixed inset-0 z-50" onClick={onClose}>
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm animate-fade-in" />
      <div
        className="animate-sheet-up absolute inset-x-0 bottom-0 mx-auto w-full max-w-lg rounded-t-[28px] border-t border-white/10 bg-[#101013] pb-safe"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex flex-col items-center pt-3">
          <div className="h-1.5 w-10 rounded-full bg-white/20" />
          <div className="flex w-full items-center justify-between px-5 pb-2 pt-4">
            <h2 className="text-lg font-semibold text-white">Скачать серию</h2>
            <button onClick={onClose} className="grid h-9 w-9 place-items-center rounded-full text-zinc-400 hover:bg-white/[0.06] hover:text-white">
              <Icon.Close className="h-4 w-4" />
            </button>
          </div>
        </div>

        <div className="space-y-4 px-5 pb-6">
          <div className="rounded-2xl bg-white/[0.04] p-3.5">
            <div className="line-clamp-1 text-[14px] font-medium text-white">{title}</div>
            <div className="mt-1 text-[12px] text-zinc-500">
              Серия {video.number}
              {video.duration ? ` · ${Math.round(video.duration / 60)} мин` : ''}
            </div>
          </div>

          {/* Качество — выбирается из доступных на сервере */}
          {state !== 'downloading' && (
            <div>
              <div className="mb-2 text-[11px] font-semibold uppercase tracking-wider text-zinc-500">Качество</div>
              <div className="flex gap-2">
                {qualities.map((q) => (
                  <button
                    key={q}
                    onClick={() => {
                      setQuality(q);
                      resolve(q);
                    }}
                    className={cn(
                      'flex-1 rounded-full py-2 text-[13px] font-medium transition active:scale-95',
                      quality === q ? 'bg-white text-black' : 'bg-white/[0.05] text-zinc-300',
                    )}
                  >
                    {q}
                  </button>
                ))}
              </div>
            </div>
          )}

          {state === 'resolving' && (
            <div className="flex items-center gap-3 rounded-2xl bg-white/[0.04] p-4">
              <span className="h-5 w-5 shrink-0 animate-spin rounded-full border-2 border-zinc-700 border-t-white" />
              <div className="min-w-0">
                <div className="text-[14px] font-medium text-white">Ищем прямую ссылку…</div>
                <div className="text-[12px] text-zinc-500">Ищем прямой адрес видео…</div>
              </div>
            </div>
          )}

          {state === 'ready' && source && (
            <>
              <div className="flex items-center gap-3 rounded-2xl bg-emerald-500/10 p-4 ring-1 ring-emerald-500/20">
                <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-emerald-500/20 text-emerald-300">
                  <Icon.Check className="h-4 w-4" />
                </span>
                <div className="min-w-0">
                  <div className="text-[14px] font-medium text-white">Прямой поток получен</div>
                  <div className="truncate text-[12px] text-zinc-500">
                    {source.kind === 'm3u8' ? 'HLS' : 'MP4'}
                    {source.quality !== '—' && ` · ${source.quality}`}
                  </div>
                </div>
              </div>
              <button onClick={start} className="flex h-12 w-full items-center justify-center gap-2 rounded-full bg-white text-[15px] font-semibold text-black transition active:scale-[0.98]">
                <Icon.Download className="h-5 w-5" /> Начать скачивание
              </button>
            </>
          )}

          {state === 'downloading' && (
            <>
              <div className="rounded-2xl bg-white/[0.04] p-4">
                <div className="flex items-center justify-between text-[13px]">
                  <span className="font-medium text-white">
                    Скачивание {progress ? `${progress.percent}%` : '…'}
                  </span>
                  <span className="tabular-nums text-zinc-400">{progress ? fmtBytes(progress.loadedBytes) : ''}</span>
                </div>
                <div className="mt-3 h-2 overflow-hidden rounded-full bg-white/10">
                  <div
                    className="h-full rounded-full bg-white transition-all duration-300"
                    style={{ width: `${progress?.percent ?? 0}%` }}
                  />
                </div>
                {progress && (
                  <div className="mt-2 text-right text-[11px] text-zinc-500">
                    Сегмент {progress.segments} из {progress.totalSegments}
                  </div>
                )}
              </div>
              <button onClick={cancel} className="h-12 w-full rounded-full border border-line bg-white/[0.04] text-[14px] font-medium text-zinc-300 transition active:scale-[0.98]">
                Отменить
              </button>
            </>
          )}

          {state === 'done' && (
            <>
              <div className="flex items-center gap-3 rounded-2xl bg-emerald-500/10 p-4 ring-1 ring-emerald-500/20">
                <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-emerald-500 text-black">
                  <Icon.Check className="h-4 w-4" />
                </span>
                <div className="min-w-0">
                  <div className="text-[14px] font-medium text-white">Файл сохранён!</div>
                  <div className="text-[12px] text-zinc-500">
                    Папка «Загрузки» · формат .ts — играет в VLC, MX Player или конвертируется в MP4
                  </div>
                </div>
              </div>
              <div className="flex gap-2">
                <button onClick={() => setState('ready')} className="h-12 flex-1 rounded-full border border-line bg-white/[0.04] text-[14px] font-medium text-zinc-300 active:scale-[0.98]">
                  Ещё раз
                </button>
                <button onClick={onClose} className="h-12 flex-1 rounded-full bg-white text-[14px] font-semibold text-black active:scale-[0.98]">
                  Готово
                </button>
              </div>
            </>
          )}

          {state === 'error' && (
            <>
              <div className="rounded-2xl bg-rose-500/10 p-4 ring-1 ring-rose-500/20">
                <div className="text-[14px] font-medium text-rose-200">Не удалось</div>
                <div className="mt-1 text-[12px] leading-relaxed text-zinc-400">{error}</div>
              </div>
              <div className="flex gap-2">
                <a
                  href={playerUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="h-12 flex-1 rounded-full border border-line bg-white/[0.04] text-[14px] font-medium text-zinc-300 active:scale-[0.98]"
                >
                  Открыть плеер
                </a>
                <button onClick={() => resolve()} className="h-12 flex-1 rounded-full bg-white text-[14px] font-semibold text-black active:scale-[0.98]">
                  Повторить
                </button>
              </div>
              <p className="text-[11px] leading-relaxed text-zinc-600">
                Совет для Android: откройте плеер в новой вкладке, а скачивание ведите через приложение-загрузчик (например, NewPipe или HLS-Downloader) или конвертируйте .ts в MP4 VLC.
              </p>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

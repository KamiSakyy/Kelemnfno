'use client';
import Hls from 'hls.js';
import { useCallback, useEffect, useRef, useState } from 'react';
import { cn } from '../utils/cn';
import { Icon } from './AnimeCard';

interface Props {
  src: string;
  /** hls — подключаем hls.js, mp4 — играем напрямую. Сервер знает тип точно. */
  kind?: 'hls' | 'mp4';
  episodeLabel: string;
  skipOpening?: { time: number; length: number } | null;
  onEnded: () => void;
  onTime?: (t: number, duration: number) => void;
  onFatal: () => void;
  /** есть ли следующая серия — показываем тизер автоперехода */
  hasNext?: boolean;
  onNext?: () => void;
}

const SPEEDS = [0.5, 0.75, 1, 1.25, 1.5, 2];

function fmt(s: number) {
  if (!isFinite(s) || s < 0) s = 0;
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = Math.floor(s % 60);
  return h > 0
    ? `${h}:${String(m).padStart(2, '0')}:${String(sec).padStart(2, '0')}`
    : `${m}:${String(sec).padStart(2, '0')}`;
}

export function CustomPlayer({
  src,
  kind,
  episodeLabel,
  skipOpening,
  onEnded,
  onTime,
  onFatal,
  hasNext,
  onNext,
}: Props) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const barRef = useRef<HTMLDivElement>(null);
  const hlsRef = useRef<Hls | null>(null);
  /** защита от повторной инициализации того же потока (двойной трафик) */
  const loadedForRef = useRef<string>('');
  const fatalRef = useRef(false);
  const netRetry = useRef(0);
  const mediaRetry = useRef(0);
  const hideTimer = useRef<number | null>(null);
  const tapTimer = useRef<number | null>(null);
  const holdTimer = useRef<number | null>(null);
  const holdingRef = useRef(false);

  const [playing, setPlaying] = useState(false);
  const [time, setTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [buffered, setBuffered] = useState(0);
  const [volume, setVolume] = useState(1);
  const [muted, setMuted] = useState(false);
  const [waiting, setWaiting] = useState(true);
  const [failed, setFailed] = useState(false);
  const [levels, setLevels] = useState<{ h: number; id: number }[]>([]);
  const [level, setLevel] = useState(-1);
  const [showUI, setShowUI] = useState(true);
  const [menu, setMenu] = useState<'none' | 'quality' | 'speed'>('none');
  const [speed, setSpeed] = useState(1);
  const [isFull, setIsFull] = useState(false);
  const [flash, setFlash] = useState<{ side: 'left' | 'right' | 'center'; text: string; id: number } | null>(null);
  const [hoverX, setHoverX] = useState<number | null>(null);
  const [dragging, setDragging] = useState(false);
  const [volOpen, setVolOpen] = useState(false);

  const poke = useCallback(() => {
    setShowUI(true);
    if (hideTimer.current) window.clearTimeout(hideTimer.current);
    hideTimer.current = window.setTimeout(() => {
      const v = videoRef.current;
      if (v && !v.paused && menu === 'none') setShowUI(false);
    }, 2600);
  }, [menu]);

  useEffect(() => {
    poke();
    return () => {
      if (hideTimer.current) window.clearTimeout(hideTimer.current);
    };
  }, [poke]);

  const doFlash = (side: 'left' | 'right' | 'center', text: string) => {
    setFlash({ side, text, id: Date.now() });
    window.setTimeout(() => setFlash(null), 620);
  };

  /* ---------- загрузка потока: строго один плеер, один запрос ---------- */
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const sig = `${kind || 'auto'}|${src}`;
    // тот же поток уже загружен — не дёргаем сеть повторно
    if (loadedForRef.current === sig && hlsRef.current) return;

    // полностью разбираем предыдущий плеер, чтобы не осталось двух активных
    if (hlsRef.current) {
      hlsRef.current.destroy();
      hlsRef.current = null;
    }
    loadedForRef.current = sig;
    fatalRef.current = false;
    netRetry.current = 0;
    mediaRetry.current = 0;
    setFailed(false);
    setWaiting(true);
    setTime(0);
    setDuration(0);
    setBuffered(0);
    setLevels([]);
    setLevel(-1);
    // критично: у <video> не должно быть своего src при игре через MSE,
    // иначе поток скачивается дважды
    video.removeAttribute('src');
    video.load();

    const isHls = kind ? kind === 'hls' : /\.m3u8($|\?)/i.test(src) || /\/api\/tsuyu\/proxy/i.test(src);

    const onFatalOnce = () => {
      if (fatalRef.current) return;
      fatalRef.current = true;
      setFailed(true);
      setWaiting(false);
      onFatal();
    };

    if (isHls && Hls.isSupported()) {
      const hls = new Hls({
        // экономия трафика: не качаем качество выше размера окна
        capLevelToPlayerSize: true,
        capLevelOnFPSDrop: true,
        maxBufferLength: 20,
        maxMaxBufferLength: 40,
        backBufferLength: 20,
        enableWorker: true,
        lowLatencyMode: false,
        fragLoadingTimeOut: 20000,
        fragLoadingMaxRetry: 3,
        manifestLoadingTimeOut: 12000,
        manifestLoadingMaxRetry: 2,
        levelLoadingMaxRetry: 3,
        startLevel: -1,
      });
      hlsRef.current = hls;
      hls.attachMedia(video);
      hls.on(Hls.Events.MEDIA_ATTACHED, () => hls.loadSource(src));
      hls.on(Hls.Events.MANIFEST_PARSED, (_e, data) => {
        setLevels((data.levels || []).map((l, i) => ({ h: l.height || 0, id: i })));
        video.play().catch(() => {});
      });
      hls.on(Hls.Events.LEVEL_SWITCHED, (_e, data) => setLevel(data.level));
      hls.on(Hls.Events.ERROR, (_e, data) => {
        if (!data.fatal) return;
        const h = hlsRef.current;
        if (!h) return onFatalOnce();
        if (data.type === Hls.ErrorTypes.NETWORK_ERROR && netRetry.current < 3) {
          netRetry.current += 1;
          window.setTimeout(() => {
            if (!fatalRef.current) h.startLoad();
          }, 800 * netRetry.current);
          return;
        }
        if (data.type === Hls.ErrorTypes.MEDIA_ERROR && mediaRetry.current < 2) {
          mediaRetry.current += 1;
          h.recoverMediaError();
          return;
        }
        onFatalOnce();
      });
    } else if (isHls && video.canPlayType('application/vnd.apple.mpegurl')) {
      // Safari: нативный HLS
      video.src = src;
      video.play().catch(() => {});
      video.onerror = onFatalOnce;
    } else {
      // прямой файл (mp4)
      video.src = src;
      video.play().catch(() => {});
      video.onerror = onFatalOnce;
    }

    const onPlay = () => {
      setPlaying(true);
      setWaiting(false);
      poke();
    };
    const onPause = () => {
      setPlaying(false);
      setShowUI(true);
    };
    const onWaitingEv = () => setWaiting(true);
    const onCanPlay = () => setWaiting(false);
    const onPlayingEv = () => {
      setWaiting(false);
      setFailed(false);
    };
    const onTimeUpdate = () => {
      const t = video.currentTime;
      const d = video.duration;
      setTime(t);
      if (d && isFinite(d)) setDuration(d);
      onTime?.(t, d);
      if (video.buffered.length) setBuffered(video.buffered.end(video.buffered.length - 1));
    };
    const onEnd = () => {
      setWaiting(false);
      setPlaying(false);
      onEnded();
    };
    const onVol = () => {
      setVolume(video.volume);
      setMuted(video.muted);
    };
    const onRate = () => setSpeed(video.playbackRate);
    const onLoadedMeta = () => {
      if (video.duration && isFinite(video.duration)) setDuration(video.duration);
    };

    video.addEventListener('play', onPlay);
    video.addEventListener('pause', onPause);
    video.addEventListener('waiting', onWaitingEv);
    video.addEventListener('canplay', onCanPlay);
    video.addEventListener('playing', onPlayingEv);
    video.addEventListener('timeupdate', onTimeUpdate);
    video.addEventListener('ended', onEnd);
    video.addEventListener('volumechange', onVol);
    video.addEventListener('ratechange', onRate);
    video.addEventListener('loadedmetadata', onLoadedMeta);

    return () => {
      video.removeEventListener('play', onPlay);
      video.removeEventListener('pause', onPause);
      video.removeEventListener('waiting', onWaitingEv);
      video.removeEventListener('canplay', onCanPlay);
      video.removeEventListener('playing', onPlayingEv);
      video.removeEventListener('timeupdate', onTimeUpdate);
      video.removeEventListener('ended', onEnd);
      video.removeEventListener('volumechange', onVol);
      video.removeEventListener('ratechange', onRate);
      video.removeEventListener('loadedmetadata', onLoadedMeta);
      video.onerror = null;
      if (hlsRef.current) {
        hlsRef.current.destroy();
        hlsRef.current = null;
      }
      loadedForRef.current = '';
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [src, kind]);

  /* ---------- полноэкранный режим ---------- */
  useEffect(() => {
    const onFs = () => setIsFull(!!document.fullscreenElement);
    document.addEventListener('fullscreenchange', onFs);
    return () => document.removeEventListener('fullscreenchange', onFs);
  }, []);

  /* ---------- управление ---------- */
  const togglePlay = () => {
    const v = videoRef.current;
    if (!v) return;
    if (v.paused) {
      v.play().catch(() => {});
      doFlash('center', '▶');
    } else {
      v.pause();
      doFlash('center', '❚❚');
    }
  };

  const seekBy = (delta: number) => {
    const v = videoRef.current;
    if (!v) return;
    const max = v.duration && isFinite(v.duration) ? v.duration : v.currentTime + delta;
    v.currentTime = Math.min(Math.max(0, v.currentTime + delta), max);
    doFlash(delta > 0 ? 'right' : 'left', `${delta > 0 ? '+' : ''}${delta} сек`);
  };

  const seekTo = (t: number) => {
    const v = videoRef.current;
    if (v && isFinite(t)) v.currentTime = Math.max(0, t);
  };

  const setVol = (x: number) => {
    const v = videoRef.current;
    if (!v) return;
    v.volume = x;
    v.muted = x === 0;
  };

  const bumpVolume = (delta: number) => {
    const v = videoRef.current;
    if (!v) return;
    const next = Math.min(1, Math.max(0, (v.muted ? 0 : v.volume) + delta));
    setVol(next);
    doFlash('center', `🔊 ${Math.round(next * 100)}%`);
  };

  const toggleMute = () => {
    const v = videoRef.current;
    if (!v) return;
    v.muted = !v.muted;
  };

  const fullscreen = () => {
    const el = wrapRef.current;
    if (!el) return;
    if (document.fullscreenElement) document.exitFullscreen().catch(() => {});
    else el.requestFullscreen().catch(() => {});
  };

  const pip = () => {
    const v = videoRef.current;
    if (!v) return;
    try {
      if (document.pictureInPictureElement) document.exitPictureInPicture().catch(() => {});
      else if (document.pictureInPictureEnabled) v.requestPictureInPicture().catch(() => {});
    } catch {
      /* PiP недоступен */
    }
  };

  const applySpeed = (x: number) => {
    const v = videoRef.current;
    if (v) v.playbackRate = x;
    setSpeed(x);
    setMenu('none');
    doFlash('center', `${x}×`);
  };

  const setQuality = (id: number) => {
    if (hlsRef.current) hlsRef.current.currentLevel = id;
    setLevel(id);
    setMenu('none');
  };

  /* ---------- клавиатура ---------- */
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement)?.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
      const v = videoRef.current;
      switch (e.key) {
        case ' ':
        case 'k':
        case 'K':
        case 'р':
        case 'Р':
          e.preventDefault();
          togglePlay();
          break;
        case 'ArrowRight':
          if (!e.shiftKey) seekBy(e.altKey ? 30 : 5);
          break;
        case 'ArrowLeft':
          if (!e.shiftKey) seekBy(e.altKey ? -30 : -5);
          break;
        case 'l':
        case 'L':
        case 'д':
        case 'Д':
          seekBy(10);
          break;
        case 'j':
        case 'J':
        case 'о':
        case 'О':
          seekBy(-10);
          break;
        case 'ArrowUp':
          e.preventDefault();
          bumpVolume(0.1);
          break;
        case 'ArrowDown':
          e.preventDefault();
          bumpVolume(-0.1);
          break;
        case 'm':
        case 'M':
        case 'ь':
        case 'Ь':
          toggleMute();
          break;
        case 'f':
        case 'F':
        case 'а':
        case 'А':
          fullscreen();
          break;
        case 'p':
        case 'P':
        case 'з':
        case 'З':
          pip();
          break;
        case '>':
          applySpeed(Math.min(2, speed * 1.25));
          break;
        case '<':
          applySpeed(Math.max(0.5, speed / 1.25));
          break;
        case 'Escape':
          setMenu('none');
          break;
        default:
          if (/^[0-9]$/.test(e.key) && v && v.duration) seekTo((v.duration * Number(e.key)) / 10);
      }
      poke();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [speed, poke]);

  /* ---------- тач: двойное касание и удержание ---------- */
  const onSurfaceClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (menu !== 'none') {
      setMenu('none');
      return;
    }
    const rect = e.currentTarget.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width;
    const now = Date.now();
    if (now - (tapTimer.current || 0) < 300) {
      // двойной клик: перемотка по краям, play/pause в центре
      if (x < 0.3) seekBy(-10);
      else if (x > 0.7) seekBy(10);
      else togglePlay();
      tapTimer.current = 0;
      return;
    }
    tapTimer.current = now;
    window.setTimeout(() => {
      if (tapTimer.current === now) togglePlay();
    }, 300);
  };

  const startHold = (side: 'left' | 'right') => {
    const v = videoRef.current;
    if (!v) return;
    holdTimer.current = window.setTimeout(() => {
      holdingRef.current = true;
      v.playbackRate = 2;
      doFlash(side, '2× удержание');
    }, 380);
  };

  const endHold = () => {
    if (holdTimer.current) window.clearTimeout(holdTimer.current);
    if (holdingRef.current) {
      holdingRef.current = false;
      const v = videoRef.current;
      if (v) v.playbackRate = speed;
    }
  };

  /* ---------- прогресс-бар ---------- */
  const pct = duration ? (time / duration) * 100 : 0;
  const bufPct = duration ? (buffered / duration) * 100 : 0;

  const posFromEvent = (clientX: number) => {
    const el = barRef.current;
    if (!el) return 0;
    const rect = el.getBoundingClientRect();
    return Math.min(1, Math.max(0, (clientX - rect.left) / rect.width));
  };

  const onBarDown = (e: React.PointerEvent<HTMLDivElement>) => {
    e.preventDefault();
    setDragging(true);
    const p = posFromEvent(e.clientX);
    setTime(p * duration);
    (e.currentTarget as HTMLElement).setPointerCapture?.(e.pointerId);
  };
  const onBarMove = (e: React.PointerEvent<HTMLDivElement>) => {
    const p = posFromEvent(e.clientX);
    setHoverX(p);
    if (dragging) setTime(p * duration);
  };
  const onBarUp = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!dragging) return;
    setDragging(false);
    seekTo(posFromEvent(e.clientX) * duration);
  };

  const inOpening = !!skipOpening && time >= skipOpening.time && time < skipOpening.time + skipOpening.length - 1;
  const currentLevelLabel = level >= 0 ? levels.find((l) => l.id === level)?.h || 0 : 0;
  const showNextTeaser = !!hasNext && !!onNext && duration > 30 && duration - time < 25 && duration - time > 0;

  return (
    <div
      ref={wrapRef}
      onMouseMove={poke}
      onMouseLeave={() => playing && menu === 'none' && setShowUI(false)}
      onTouchStart={poke}
      className={cn(
        'group/player relative w-full select-none overflow-hidden bg-black ring-1 ring-white/10',
        isFull ? 'h-screen w-screen rounded-none' : 'aspect-video max-sm:-mx-4 max-sm:w-auto sm:rounded-3xl',
        showUI || !playing ? 'cursor-default' : 'cursor-none',
      )}
    >
      {/* Единственный слой видео: никакого второго плеера внутри */}
      <div
        className="absolute inset-0"
        onClick={onSurfaceClick}
        onContextMenu={(e) => e.preventDefault()}
        onMouseDown={() => startHold('right')}
        onMouseUp={endHold}
        onMouseLeave={endHold}
        onTouchStart={() => startHold('right')}
        onTouchEnd={endHold}
        onTouchCancel={endHold}
      >
        <video
          ref={videoRef}
          className="h-full w-full bg-black object-contain"
          playsInline
          preload="auto"
          disablePictureInPicture={false}
        />
      </div>

      {/* Индикация перемотки/действий */}
      {flash && (
        <div
          className={cn(
            'pointer-events-none absolute inset-y-0 flex w-1/3 items-center justify-center',
            flash.side === 'left' && 'left-0 bg-gradient-to-r from-black/55 to-transparent',
            flash.side === 'right' && 'right-0 bg-gradient-to-l from-black/55 to-transparent',
            flash.side === 'center' && 'left-1/3 w-1/3',
          )}
        >
          <span key={flash.id} className="animate-pop rounded-2xl bg-black/70 px-4 py-2 text-[15px] font-semibold text-white backdrop-blur">
            {flash.text}
          </span>
        </div>
      )}

      {/* Верх: только название серии, без вложенных «карточек плеера» */}
      <div
        className={cn(
          'pointer-events-none absolute inset-x-0 top-0 flex items-start justify-between gap-3 bg-gradient-to-b from-black/75 via-black/25 to-transparent px-4 pb-8 pt-3.5 transition-opacity duration-300',
          showUI ? 'opacity-100' : 'opacity-0',
        )}
      >
        <span className="truncate text-[13px] font-medium text-white/90 drop-shadow">{episodeLabel}</span>
        <span className="shrink-0 rounded-md bg-black/45 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-white/70 backdrop-blur-sm">
          {levels.length ? (currentLevelLabel ? `${currentLevelLabel}p` : 'auto') : kind === 'mp4' ? 'mp4' : 'auto'}
        </span>
      </div>

      {/* Буферизация */}
      {waiting && !failed && (
        <div className="pointer-events-none absolute inset-0 grid place-items-center">
          <div className="relative h-12 w-12">
            <span className="absolute inset-0 animate-spin rounded-full border-[3px] border-white/15 border-t-white" />
            <span className="absolute inset-2 animate-ring rounded-full" />
          </div>
        </div>
      )}

      {/* Ошибка — её обрабатывает автоподбор, но даём и ручную кнопку */}
      {failed && (
        <div className="absolute inset-0 grid place-items-center bg-black/80 px-6 text-center">
          <div className="animate-fade-up">
            <div className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-white/8 text-zinc-300">
              <Icon.Alert className="h-5 w-5" />
            </div>
            <p className="mt-3 text-[14px] font-semibold text-white">Поток прервался</p>
            <p className="mt-1 text-[12px] text-zinc-500">Ищем рабочий вариант автоматически…</p>
            <button
              onClick={() => {
                loadedForRef.current = '';
                fatalRef.current = false;
                setFailed(false);
                setWaiting(true);
                onFatal();
              }}
              className="mt-4 rounded-full bg-white px-4 py-2 text-[13px] font-semibold text-black transition active:scale-95"
            >
              Повторить
            </button>
          </div>
        </div>
      )}

      {/* Большая кнопка пуска */}
      {!playing && !waiting && !failed && (
        <button
          onClick={togglePlay}
          aria-label="Воспроизвести"
          className="absolute inset-0 m-auto grid h-20 w-20 place-items-center rounded-full bg-white/92 text-black shadow-[0_18px_50px_-12px_rgba(0,0,0,0.9)] transition hover:scale-105 active:scale-95"
        >
          <Icon.Play className="ml-1 h-8 w-8" />
        </button>
      )}

      {/* Пропустить опенинг */}
      {inOpening && skipOpening && (
        <button
          onClick={() => seekTo(skipOpening.time + skipOpening.length)}
          className="animate-fade-up absolute bottom-24 right-4 flex items-center gap-2 rounded-full bg-white px-4 py-2 text-[13px] font-semibold text-black shadow-xl transition hover:scale-105 active:scale-95"
        >
          Пропустить опенинг <Icon.ChevronRight className="h-4 w-4" />
        </button>
      )}

      {/* Тизер следующей серии */}
      {showNextTeaser && !failed && (
        <button
          onClick={onNext}
          className="animate-fade-up absolute bottom-24 left-4 flex items-center gap-2 rounded-full bg-black/75 px-4 py-2 text-[13px] font-semibold text-white backdrop-blur transition hover:bg-white hover:text-black active:scale-95"
        >
          Следующая серия <Icon.ChevronRight className="h-4 w-4" />
        </button>
      )}

      {/* Нижняя панель — единый слой управления */}
      <div
        className={cn(
          'absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/92 via-black/55 to-transparent px-3 pb-2.5 pt-12 transition-all duration-300 sm:px-4',
          showUI || dragging ? 'translate-y-0 opacity-100' : 'pointer-events-none translate-y-3 opacity-0',
        )}
      >
        {/* Прогресс */}
        <div
          ref={barRef}
          role="slider"
          aria-label="Позиция воспроизведения"
          aria-valuemin={0}
          aria-valuemax={Math.round(duration)}
          aria-valuenow={Math.round(time)}
          tabIndex={0}
          onPointerDown={onBarDown}
          onPointerMove={onBarMove}
          onPointerUp={onBarUp}
          onPointerCancel={onBarUp}
          onPointerLeave={() => !dragging && setHoverX(null)}
          className="group/bar relative mb-1.5 h-5 cursor-pointer touch-none"
        >
          <div className="absolute inset-x-0 top-1/2 h-[5px] -translate-y-1/2 overflow-hidden rounded-full bg-white/20 transition-all group-hover/bar:h-[8px]">
            <div className="absolute inset-y-0 left-0 rounded-full bg-white/25" style={{ width: `${bufPct}%` }} />
            <div
              className="absolute inset-y-0 left-0 rounded-full bg-gradient-to-r from-violet-300 to-white"
              style={{ width: `${pct}%` }}
            />
          </div>
          <div
            className={cn(
              'absolute top-1/2 h-3.5 w-3.5 -translate-x-1/2 -translate-y-1/2 rounded-full bg-white shadow transition-opacity',
              showUI || dragging || hoverX !== null ? 'opacity-100' : 'opacity-0',
            )}
            style={{ left: `${pct}%` }}
          />
          {hoverX !== null && duration > 0 && (
            <div
              className="pointer-events-none absolute bottom-6 -translate-x-1/2 rounded-md bg-black/85 px-1.5 py-0.5 text-[11px] font-medium tabular-nums text-white"
              style={{ left: `${hoverX * 100}%` }}
            >
              {fmt(hoverX * duration)}
            </div>
          )}
        </div>

        <div className="flex items-center gap-1 sm:gap-1.5">
          <button
            onClick={togglePlay}
            aria-label={playing ? 'Пауза' : 'Воспроизвести'}
            className="grid h-10 w-10 shrink-0 place-items-center rounded-full text-white transition hover:bg-white/15 active:scale-90"
          >
            {playing ? (
              <svg className="h-5 w-5" viewBox="0 0 24 24" fill="currentColor">
                <rect x="6" y="5" width="4" height="14" rx="1" />
                <rect x="14" y="5" width="4" height="14" rx="1" />
              </svg>
            ) : (
              <Icon.Play className="ml-0.5 h-5 w-5" />
            )}
          </button>

          <button
            onClick={() => seekBy(-10)}
            aria-label="Назад 10 секунд"
            className="grid h-9 w-9 shrink-0 place-items-center rounded-full text-white transition hover:bg-white/15 active:scale-90"
          >
            <svg className="h-[18px] w-[18px]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.9}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M11 5L6 9l5 4V5z" fill="currentColor" stroke="none" />
              <path strokeLinecap="round" d="M6.5 9H14a4.5 4.5 0 110 9H8" />
            </svg>
          </button>
          <button
            onClick={() => seekBy(10)}
            aria-label="Вперёд 10 секунд"
            className="grid h-9 w-9 shrink-0 place-items-center rounded-full text-white transition hover:bg-white/15 active:scale-90"
          >
            <svg className="h-[18px] w-[18px]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.9}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M13 5l5 4-5 4V5z" fill="currentColor" stroke="none" />
              <path strokeLinecap="round" d="M17.5 9H10a4.5 4.5 0 100 9h6" />
            </svg>
          </button>

          <span className="ml-0.5 shrink-0 text-[12px] font-medium tabular-nums text-zinc-200">
            {fmt(time)} <span className="text-zinc-500">/ {fmt(duration)}</span>
          </span>

          <div className="ml-auto flex items-center gap-0.5 sm:gap-1">
            {/* Громкость */}
            <div
              className="flex items-center"
              onMouseEnter={() => setVolOpen(true)}
              onMouseLeave={() => setVolOpen(false)}
            >
              <button
                onClick={toggleMute}
                aria-label={muted ? 'Включить звук' : 'Выключить звук'}
                className="grid h-9 w-9 shrink-0 place-items-center rounded-full text-white transition hover:bg-white/15 active:scale-90"
              >
                {muted || volume === 0 ? (
                  <svg className="h-[18px] w-[18px]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M11 5L6 9H3v6h3l5 4V5zM22 9l-6 6m0-6l6 6" />
                  </svg>
                ) : (
                  <svg className="h-[18px] w-[18px]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M11 5L6 9H3v6h3l5 4V5zM15.5 8.5a5 5 0 010 7M18.5 5.5a9 9 0 010 13" />
                  </svg>
                )}
              </button>
              <input
                type="range"
                min={0}
                max={1}
                step={0.05}
                value={muted ? 0 : volume}
                onChange={(e) => setVol(Number(e.target.value))}
                aria-label="Громкость"
                className={cn(
                  'h-1 w-0 cursor-pointer appearance-none rounded-full bg-white/25 accent-white transition-all duration-200',
                  volOpen ? 'mx-1.5 w-16 sm:w-20' : 'sm:mx-1.5 sm:w-16',
                )}
              />
            </div>

            {/* Скорость */}
            <div className="relative">
              <button
                onClick={() => setMenu(menu === 'speed' ? 'none' : 'speed')}
                aria-label="Скорость воспроизведения"
                className={cn(
                  'h-9 rounded-full px-2.5 text-[12px] font-semibold tabular-nums transition active:scale-90',
                  speed !== 1 ? 'bg-white text-black' : 'text-white hover:bg-white/15',
                )}
              >
                {speed}×
              </button>
              {menu === 'speed' && (
                <div className="animate-pop absolute bottom-11 right-0 w-28 overflow-hidden rounded-xl border border-white/10 bg-black/92 py-1 backdrop-blur">
                  {SPEEDS.map((s) => (
                    <button
                      key={s}
                      onClick={() => applySpeed(s)}
                      className={cn(
                        'flex w-full items-center justify-between px-3 py-1.5 text-left text-[13px] transition hover:bg-white/10',
                        speed === s ? 'font-semibold text-white' : 'text-zinc-400',
                      )}
                    >
                      {s}×{speed === s && <Icon.Check className="h-3.5 w-3.5" />}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Качество */}
            {levels.length > 1 && (
              <div className="relative">
                <button
                  onClick={() => setMenu(menu === 'quality' ? 'none' : 'quality')}
                  aria-label="Качество"
                  className="h-9 rounded-full px-2.5 text-[12px] font-semibold text-white transition hover:bg-white/15 active:scale-90"
                >
                  {currentLevelLabel ? `${currentLevelLabel}p` : 'Auto'}
                </button>
                {menu === 'quality' && (
                  <div className="animate-pop absolute bottom-11 right-0 w-32 overflow-hidden rounded-xl border border-white/10 bg-black/92 py-1 backdrop-blur">
                    <button
                      onClick={() => setQuality(-1)}
                      className={cn(
                        'flex w-full items-center justify-between px-3 py-1.5 text-left text-[13px] transition hover:bg-white/10',
                        level === -1 ? 'font-semibold text-white' : 'text-zinc-400',
                      )}
                    >
                      Авто{level === -1 && <Icon.Check className="h-3.5 w-3.5" />}
                    </button>
                    {[...levels]
                      .filter((l) => l.h > 0)
                      .sort((a, b) => b.h - a.h)
                      .map((l) => (
                        <button
                          key={l.id}
                          onClick={() => setQuality(l.id)}
                          className={cn(
                            'flex w-full items-center justify-between px-3 py-1.5 text-left text-[13px] transition hover:bg-white/10',
                            level === l.id ? 'font-semibold text-white' : 'text-zinc-400',
                          )}
                        >
                          {l.h}p{level === l.id && <Icon.Check className="h-3.5 w-3.5" />}
                        </button>
                      ))}
                  </div>
                )}
              </div>
            )}

            <button
              onClick={pip}
              aria-label="Картинка в картинке"
              className="hidden h-9 w-9 place-items-center rounded-full text-white transition hover:bg-white/15 active:scale-90 sm:grid"
            >
              <svg className="h-[18px] w-[18px]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8}>
                <rect x="3" y="5" width="18" height="14" rx="2.5" />
                <rect x="12" y="12" width="7" height="5" rx="1.2" fill="currentColor" stroke="none" />
              </svg>
            </button>

            <button
              onClick={fullscreen}
              aria-label={isFull ? 'Выйти из полноэкранного режима' : 'Во весь экран'}
              className="grid h-9 w-9 shrink-0 place-items-center rounded-full text-white transition hover:bg-white/15 active:scale-90"
            >
              {isFull ? (
                <svg className="h-[18px] w-[18px]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.9}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M9 4v5H4M15 4v5h5M9 20v-5H4M15 20v-5h5" />
                </svg>
              ) : (
                <svg className="h-[18px] w-[18px]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.9}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5" />
                </svg>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

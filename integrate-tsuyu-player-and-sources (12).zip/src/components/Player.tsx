'use client';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { dubbingName, formatDuration, type VideoItem } from '../api/yummy';
import { cn } from '../utils/cn';
import { Icon } from './AnimeCard';
import { CustomPlayer } from './CustomPlayer';
import { DownloadSheet } from './DownloadSheet';
import type { DownloadSource } from '../lib/downloader';
import {
  fetchTsuyuStream,
  fetchTsuyuTracks,
  makeTsuyuRef,
  parseTsuyuRef,
  resolveViaServer,
  type TsuyuLookup,
  type TsuyuStreamSource,
} from '../lib/tsuyu';

interface Props {
  videos: VideoItem[];
  title: string;
  initialEpisode?: string;
  initialDubbing?: string;
  watched: string[];
  onToggleWatched: (ep: string) => void;
  autoNext: boolean;
  onAutoNextChange: (v: boolean) => void;
  theater: boolean;
  onTheaterChange: (v: boolean) => void;
  /** Автоподбор рабочего источника включён всегда — параметры оставлены для совместимости. */
  preferredPlayer?: string;
  onPlayerConfirmed?: (p: string) => void;
  autoSwitch?: boolean;
  onAutoSwitchChange?: (v: boolean) => void;
  onChange?: (state: { episode: string; dubbing: string; player: string; total: number }) => void;
  /** Данные для поиска озвучек (маршруты скрыты на сервере). */
  lookup?: TsuyuLookup;
}

/** Одна серия внутри озвучки: несколько запасных маршрутов на случай отказа. */
interface EpisodeSlot {
  number: string;
  num: number;
  duration: number;
  candidates: VideoItem[];
}

interface VoiceGroup {
  voice: string;
  episodes: EpisodeSlot[];
  total: number;
}

/** Плеер Kodik убран из интерфейса: такие маршруты идут последними и играют
 * только через наш плеер (сервер отдаёт прямой поток). */
const KODIK_ROUTE = /kodik|aniqit|kodikplayer/i;

function hashRef(value: string) {
  let h = 0;
  for (let i = 0; i < value.length; i++) h = (h * 31 + value.charCodeAt(i)) | 0;
  return h || 1;
}

function epNum(n: string) {
  const f = parseFloat(n);
  return Number.isNaN(f) ? Number.MAX_SAFE_INTEGER : f;
}

function fmtTime(s: number) {
  const m = Math.floor(s / 60);
  const sec = Math.floor(s % 60);
  return `${m}:${String(sec).padStart(2, '0')}`;
}

/** Надёжность маршрута: дорожка с серверным подбором → прямой файл → прочий embed. */
function routeRank(v: VideoItem) {
  const url = v.iframe_url || '';
  if (/\.(m3u8|mp4)(\?|$)/i.test(url)) return 0;
  if (parseTsuyuRef(url)) return 1;
  if (KODIK_ROUTE.test(url)) return 9;
  return 2;
}

function toSource(s: TsuyuStreamSource): DownloadSource {
  return {
    url: s.url,
    // тип потока сообщает сервер: по ссылке через прокси его не определить
    kind: s.kind === 'mp4' ? 'mp4' : 'm3u8',
    quality: s.quality ? `${s.quality}p` : 'auto',
    source: 'Player',
  };
}

/** Единая точка подбора потока: всё решает сервер, клиент адреса источников не видит. */
async function resolveCandidate(v: VideoItem): Promise<DownloadSource> {
  const ref = parseTsuyuRef(v.iframe_url);
  if (ref) {
    const sources = await fetchTsuyuStream(ref.track, ref.episode);
    if (!sources.length) throw new Error('empty');
    return toSource(sources[0]);
  }
  const sources = await resolveViaServer(v.iframe_url);
  if (!sources.length) throw new Error('empty');
  return toSource(sources[0]);
}

export function Player({
  videos,
  title,
  initialEpisode,
  initialDubbing,
  watched,
  onToggleWatched,
  autoNext,
  onAutoNextChange,
  theater,
  onTheaterChange,
  onChange,
  lookup,
}: Props) {
  /* ---------- Озвучки со всех источников: пользователю видны только названия ---------- */
  const [tsuyuVideos, setTsuyuVideos] = useState<VideoItem[]>([]);
  const [tsuyuLoading, setTsuyuLoading] = useState(false);
  /** версия памяти автоподбора — меняем, чтобы пересобрать порядок маршрутов */
  const [failVersion, setFailVersion] = useState(0);

  useEffect(() => {
    if (!lookup?.title) return;
    const ctrl = new AbortController();
    let alive = true;
    setTsuyuLoading(true);
    fetchTsuyuTracks(lookup, ctrl.signal)
      .then((tracks) => {
        if (!alive) return;
        const rows: VideoItem[] = [];
        for (const t of tracks) {
          t.episodes.forEach((n, i) => {
            rows.push({
              video_id: -Math.abs(hashRef(`${t.id}:${n}`)) - i,
              data: { player: 'auto', dubbing: t.voice, player_id: 0 },
              number: String(n),
              date: 0,
              iframe_url: makeTsuyuRef(t.id, n),
              index: i,
              views: 0,
              duration: 0,
            });
          });
        }
        setTsuyuVideos(rows);
      })
      .catch(() => {})
      .finally(() => {
        if (alive) setTsuyuLoading(false);
      });
    return () => {
      alive = false;
      ctrl.abort();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [lookup?.title, lookup?.malId, lookup?.yummyId]);

  const allVideos = useMemo(() => [...videos, ...tsuyuVideos], [videos, tsuyuVideos]);

  /* ---------- Группировка только по озвучке ----------
   * Все маршруты одной серии складываются в candidates: автоподбор перебирает их
   * по надёжности и берёт первый рабочий. Дублей кнопок при этом не возникает. */
  const groups = useMemo<VoiceGroup[]>(() => {
    const map = new Map<string, Map<number, EpisodeSlot>>();
    for (const v of allVideos) {
      const url = v.iframe_url || '';
      if (!url) continue;
      const num = epNum(v.number);
      if (!Number.isFinite(num) || num <= 0) continue;
      const voice = dubbingName(v) || 'Оригинал';
      if (!map.has(voice)) map.set(voice, new Map());
      const byNum = map.get(voice)!;
      const label = Number.isInteger(num) ? String(num) : v.number;
      let slot = byNum.get(num);
      if (!slot) {
        slot = { number: label, num, duration: 0, candidates: [] };
        byNum.set(num, slot);
      }
      if (!slot.candidates.some((c) => c.iframe_url === url)) slot.candidates.push(v);
      if (v.duration && v.duration > slot.duration) slot.duration = v.duration;
    }

    const out: VoiceGroup[] = [];
    for (const [voice, byNum] of map) {
      const episodes = [...byNum.values()].sort((a, b) => a.num - b.num);
      for (const slot of episodes) {
        slot.candidates.sort(
          (a, b) =>
            (failCount.get(b.iframe_url) || 0) - (failCount.get(a.iframe_url) || 0) ||
            routeRank(a) - routeRank(b),
        );
      }
      if (episodes.length) out.push({ voice, episodes, total: episodes.length });
    }
    return out.sort((a, b) => b.total - a.total || a.voice.localeCompare(b.voice, 'ru'));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [allVideos, failVersion]);

  const [dubbing, setDubbing] = useState('');
  const [episode, setEpisode] = useState('');
  const [allFailed, setAllFailed] = useState(false);
  const [copied, setCopied] = useState(false);
  const [dlOpen, setDlOpen] = useState(false);
  const [nativeSrc, setNativeSrc] = useState<string | null>(null);
  const [nativeQuality, setNativeQuality] = useState<DownloadSource | null>(null);
  const [resolving, setResolving] = useState(false);
  const [nativeTime, setNativeTime] = useState(0);
  const [attempts, setAttempts] = useState(0);
  const [retryKey, setRetryKey] = useState(0);
  const [statusText, setStatusText] = useState('');

  const epListRef = useRef<HTMLDivElement>(null);
  const failedVoices = useRef<Set<string>>(new Set());
  /** уже подобранные потоки: возврат к серии не должен качать данные заново */
  const resolvedCache = useRef<Map<string, DownloadSource>>(new Map());
  /** защита от двух одновременных подборов одной серии (двойной трафик) */
  const pickingRef = useRef<string>('');
  const dubbingRef = useRef('');
  const episodeRef = useRef('');
  const autoNextRef = useRef(autoNext);
  const goNextRef = useRef<() => void>(() => {});
  const markWatchedRef = useRef<(ep: string) => void>(() => {});
  dubbingRef.current = dubbing;
  episodeRef.current = episode;
  autoNextRef.current = autoNext;

  const currentGroup = groups.find((g) => g.voice === dubbing) || groups[0] || null;
  const episodes = currentGroup?.episodes || [];
  const current = episodes.find((e) => e.number === episode) || episodes.find((e) => e.number === initialEpisode) || episodes[0] || null;
  const currentIdx = current ? episodes.indexOf(current) : -1;

  markWatchedRef.current = (ep: string) => {
    if (!watched.includes(ep)) onToggleWatched(ep);
  };

  const goNext = useCallback(() => {
    if (currentIdx >= 0 && currentIdx < episodes.length - 1) setEpisode(episodes[currentIdx + 1].number);
  }, [currentIdx, episodes]);
  const goPrev = useCallback(() => {
    if (currentIdx > 0) setEpisode(episodes[currentIdx - 1].number);
  }, [currentIdx, episodes]);
  goNextRef.current = goNext;

  /* ---------- инициализация: выбор пользователя не сбрасывается ---------- */
  useEffect(() => {
    if (!groups.length) return;
    const keep = dubbingRef.current ? groups.find((g) => g.voice === dubbingRef.current) : undefined;
    const g = keep || groups.find((x) => x.voice === initialDubbing) || groups[0];
    const wanted = episodeRef.current || initialEpisode;
    const slot = g.episodes.find((e) => e.number === wanted) || g.episodes[0];
    if (g.voice !== dubbingRef.current) setDubbing(g.voice);
    if (slot && slot.number !== episodeRef.current) setEpisode(slot.number);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [groups]);

  useEffect(() => {
    if (current && onChange) {
      onChange({ episode: current.number, dubbing: currentGroup?.voice || '', player: 'auto', total: episodes.length });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [current?.number, currentGroup?.voice]);

  useEffect(() => {
    const el = epListRef.current?.querySelector<HTMLElement>('[data-active="true"]');
    el?.scrollIntoView({ block: 'nearest' });
  }, [current?.number]);

  /* ---------- АВТОПОДБОР РАБОЧЕГО ИСТОЧНИКА (всегда включён) ----------
   * 1) перебираем все запасные маршруты текущей серии;
   * 2) если озвучка целиком мертва — молча переходим на следующую с той же серией;
   * 3) если живых не осталось — показываем понятную панель повтора. */
  useEffect(() => {
    if (!current || !currentGroup) return;
    let alive = true;

    setNativeSrc(null);
    setNativeQuality(null);
    setNativeTime(0);
    setAllFailed(false);
    setResolving(true);
    setAttempts(0);

    const voice = currentGroup.voice;
    const wantedNum = current.num;

    // быстрый путь: поток для этой серии уже подобран — играем без сети
    const cacheKey = `${voice}:${wantedNum}`;
    const cached = resolvedCache.current.get(cacheKey);
    if (cached) {
      setNativeQuality(cached);
      setNativeSrc(cached.url);
      setResolving(false);
      setStatusText('');
      return;
    }

    // второй подбор той же серии не запускаем
    if (pickingRef.current === cacheKey) return;
    pickingRef.current = cacheKey;

    (async () => {
      let voiceName = voice;
      let slot: EpisodeSlot | null = current;
      let guard = 0;

      while (alive && guard++ < groups.length + 1) {
        const list = slot?.candidates || [];
        for (let i = 0; i < list.length; i++) {
          if (!alive) return;
          setAttempts(i + 1);
          setStatusText(
            list.length > 1 ? `Подбираем рабочий источник · вариант ${i + 1} из ${list.length}` : 'Подбираем рабочий источник…',
          );
          const candidate = list[i];
          try {
            const s = await resolveCandidate(candidate);
            if (!alive) return;
            rememberOk(candidate.iframe_url);
            resolvedCache.current.set(`${voiceName}:${wantedNum}`, s);
            pickingRef.current = '';
            if (voiceName !== dubbingRef.current) setDubbing(voiceName);
            setNativeQuality(s);
            setNativeSrc(s.url);
            setResolving(false);
            setStatusText('');
            return;
          } catch {
            if (!alive) return;
            rememberFail(candidate.iframe_url);
          }
        }

        // озвучка не отдала видео — ищем следующую, где есть эта же серия
        failedVoices.current.add(voiceName);
        const next = groups.find(
          (g) => !failedVoices.current.has(g.voice) && g.episodes.some((e) => e.num === wantedNum),
        );
        if (!next) break;
        voiceName = next.voice;
        slot = next.episodes.find((e) => e.num === wantedNum) || null;
        if (slot) setEpisode(slot.number);
        setDubbing(voiceName);
        setStatusText('Меняем озвучку на рабочую…');
      }

      if (!alive) return;
      pickingRef.current = '';
      setResolving(false);
      setStatusText('');
      setAllFailed(true);
    })();

    return () => {
      alive = false;
      if (pickingRef.current === cacheKey) pickingRef.current = '';
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [current?.number, currentGroup?.voice, retryKey]);

  /* ---------- ошибка самого плеера → следующий маршрут ---------- */
  const nativeFatal = useCallback(() => {
    setNativeSrc(null);
    setNativeQuality(null);
    // поток оказался нерабочим — убираем его из кэша, иначе повтор сыграет то же самое
    if (current && currentGroup) resolvedCache.current.delete(`${currentGroup.voice}:${current.num}`);
    pickingRef.current = '';
    if (current) {
      for (const c of current.candidates) rememberFail(c.iframe_url);
    }
    failedVoices.current.add(currentGroup?.voice || '');
    setRetryKey((k) => k + 1);
  }, [current, currentGroup?.voice]);

  const nativeTimeRef = useRef<(t: number, d: number) => void>(() => {});
  nativeTimeRef.current = (t: number, d: number) => {
    setNativeTime(t);
    if (current && d && t / d > 0.85) markWatchedRef.current(current.number);
  };

  const nativeEndedRef = useRef(() => {});
  nativeEndedRef.current = () => {
    if (current) markWatchedRef.current(current.number);
    if (autoNextRef.current) goNextRef.current();
  };

  /* ---------- горячие клавиши ---------- */
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement)?.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA') return;
      if (e.shiftKey && e.key === 'ArrowRight') goNext();
      if (e.shiftKey && e.key === 'ArrowLeft') goPrev();
      if (e.key === 't' || e.key === 'T' || e.key === 'е' || e.key === 'Е') onTheaterChange(!theater);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [goNext, goPrev, theater, onTheaterChange]);

  const selectDubbing = (voice: string) => {
    const g = groups.find((x) => x.voice === voice);
    if (!g) return;
    failedVoices.current.delete(voice);
    const slot = g.episodes.find((e) => e.num === current?.num) || g.episodes[0];
    setDubbing(voice);
    setEpisode(slot.number);
    setAllFailed(false);
  };

  const retryAll = () => {
    failCount.clear();
    resolvedCache.current.clear();
    pickingRef.current = '';
    setFailVersion((v) => v + 1);
    failedVoices.current.clear();
    setAllFailed(false);
    setRetryKey((k) => k + 1);
  };

  const share = async () => {
    try {
      await navigator.clipboard.writeText(window.location.href);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1600);
    } catch {
      /* ignore */
    }
  };

  if (!groups.length) {
    return (
      <div className="grid aspect-video w-full place-items-center rounded-3xl border border-line bg-surface">
        <div className="text-center">
          <div className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-white/5 text-zinc-500">
            <Icon.Play className="h-5 w-5" />
          </div>
          <p className="mt-3 text-sm text-zinc-400">{tsuyuLoading ? 'Подбираем озвучки…' : 'Видео пока не добавлено'}</p>
        </div>
      </div>
    );
  }

  const watchedCount = episodes.filter((e) => watched.includes(e.number)).length;
  const activeCandidate = current?.candidates[0];

  return (
    <div className="space-y-4">
      {/* Плеер: всегда свой, поток подбирается на сервере */}
      {nativeSrc ? (
        <CustomPlayer
          src={nativeSrc}
          kind={nativeQuality?.kind === 'mp4' ? 'mp4' : 'hls'}
          hasNext={currentIdx >= 0 && currentIdx < episodes.length - 1}
          onNext={goNext}
          episodeLabel={`${title} · Серия ${current?.number}`}
          skipOpening={activeCandidate?.skips?.opening ?? null}
          onEnded={() => nativeEndedRef.current()}
          onTime={(t, d) => nativeTimeRef.current(t, d)}
          onFatal={nativeFatal}
        />
      ) : (
        <div className="relative aspect-video w-full overflow-hidden bg-black ring-1 ring-white/10 max-sm:-mx-4 max-sm:w-auto sm:rounded-3xl">
          <div className="absolute inset-0 grid place-items-center bg-gradient-to-b from-zinc-950 to-black px-6">
            {allFailed ? (
              <div className="animate-fade-up max-w-sm text-center">
                <div className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-white/5 text-zinc-400">
                  <Icon.Alert className="h-5 w-5" />
                </div>
                <p className="mt-3 text-[15px] font-semibold text-white">Не удалось запустить видео</p>
                <p className="mt-1 text-[13px] leading-relaxed text-zinc-500">
                  Все доступные маршруты для этой серии сейчас не отвечают. Попробуйте другую озвучку или повторите
                  подбор.
                </p>
                <div className="mt-4 flex flex-wrap justify-center gap-2">
                  <button
                    onClick={retryAll}
                    className="rounded-full bg-white px-4 py-2 text-[13px] font-semibold text-black transition active:scale-95"
                  >
                    Повторить подбор
                  </button>
                </div>
              </div>
            ) : (
              <div className="text-center">
                <div className="mx-auto h-9 w-9 animate-spin rounded-full border-[3px] border-zinc-800 border-t-white" />
                <p className="mt-3 text-xs text-zinc-400">{statusText || 'Подбираем рабочий источник…'}</p>
                <p className="mt-1 text-[11px] text-zinc-600">Автоподбор включён — вмешиваться не нужно</p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Управление */}
      <div className="flex items-center gap-2">
        <div className="mr-auto min-w-0">
          <div className="text-[15px] font-semibold text-white">
            Серия {current?.number}
            <span className="ml-2 text-[13px] font-normal text-zinc-500">
              {currentIdx + 1}/{episodes.length}
            </span>
          </div>
          <div className="mt-0.5 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-zinc-500">
            {current?.duration ? <span>{formatDuration(current.duration)}</span> : null}
            {nativeSrc && <span className="tabular-nums text-zinc-400">{fmtTime(nativeTime)}</span>}
            {nativeQuality?.quality && nativeQuality.quality !== 'auto' && (
              <span className="rounded-full bg-white/[0.06] px-2 py-0.5 text-[10px] font-medium text-zinc-300">
                {nativeQuality.quality}
              </span>
            )}
            {nativeSrc && (
              <span className="flex items-center gap-1 rounded-full bg-emerald-500/10 px-2 py-0.5 text-[10px] font-medium text-emerald-300">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
                В эфире
              </span>
            )}
            {resolving && attempts > 1 && (
              <span className="tabular-nums text-zinc-600">проверено {attempts}</span>
            )}
          </div>
        </div>
        <button
          onClick={goPrev}
          disabled={currentIdx <= 0}
          className="grid h-11 w-11 place-items-center rounded-full border border-line bg-white/[0.03] text-white transition active:scale-90 disabled:opacity-30"
          title="Предыдущая серия (Shift + ←)"
        >
          <Icon.ChevronLeft className="h-5 w-5" />
        </button>
        <button
          onClick={goNext}
          disabled={currentIdx < 0 || currentIdx >= episodes.length - 1}
          className="flex h-11 items-center gap-1.5 rounded-full bg-white pl-5 pr-4 text-sm font-semibold text-black transition active:scale-95 disabled:opacity-30"
          title="Следующая серия (Shift + →)"
        >
          Далее <Icon.ChevronRight className="h-4 w-4" />
        </button>
      </div>

      {/* Озвучка */}
      <div>
        <div className="mb-2 flex items-center justify-between px-0.5">
          <span className="text-[11px] font-semibold uppercase tracking-wider text-zinc-500">Озвучка</span>
          <span className="flex items-center gap-2 text-[11px] text-zinc-600">
            {tsuyuLoading && <span className="loading-bar relative h-0.5 w-10 overflow-hidden rounded-full bg-white/10" aria-hidden />}
            {groups.length}
          </span>
        </div>
        <div className="no-scrollbar -mx-4 flex gap-2 overflow-x-auto px-4 pb-1 sm:mx-0 sm:flex-wrap sm:px-0">
          {groups.map((g, i) => {
            const active = g.voice === currentGroup?.voice;
            const dead = failedVoices.current.has(g.voice);
            return (
              <button
                key={g.voice}
                onClick={() => selectDubbing(g.voice)}
                style={{ animationDelay: `${Math.min(i, 16) * 25}ms` }}
                aria-pressed={active}
                className={cn(
                  'animate-slide-in flex shrink-0 items-center gap-2 rounded-full border px-4 py-2 text-[13px] font-medium transition-[transform,background-color,border-color,color] duration-200 active:scale-95',
                  active
                    ? 'border-white bg-white text-black shadow-[0_6px_20px_-8px_rgba(255,255,255,0.6)]'
                    : dead
                      ? 'border-line bg-white/[0.02] text-zinc-600 hover:border-white/15 hover:text-zinc-400'
                      : 'border-line bg-white/[0.03] text-zinc-300 hover:-translate-y-0.5 hover:border-white/20 hover:bg-white/[0.07] hover:text-white',
                )}
              >
                <span className="max-w-[190px] truncate">{g.voice}</span>
                <span className={cn('text-[11px] tabular-nums', active ? 'text-zinc-500' : 'text-zinc-600')}>{g.total}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Настройки */}
      <div className="rounded-2xl border border-line bg-surface p-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="mr-1 text-[11px] font-semibold uppercase tracking-wider text-zinc-500">Источник</span>
            <span className="flex items-center gap-1.5 rounded-full bg-white/[0.05] px-3 py-1.5 text-[13px] text-zinc-300">
              <span className={cn('h-1.5 w-1.5 rounded-full', resolving ? 'animate-ring bg-amber-300' : 'bg-emerald-400')} />
              Автоподбор
            </span>
            <span className="rounded-full bg-white/[0.03] px-2.5 py-1.5 text-[11px] text-zinc-600">всегда включён</span>
          </div>
          <label className="flex cursor-pointer items-center gap-2.5 text-[13px] text-zinc-300">
            Автопереход
            <span className="hidden text-[11px] text-zinc-600 sm:inline">к следующей серии</span>
            <button
              role="switch"
              aria-checked={autoNext}
              onClick={() => onAutoNextChange(!autoNext)}
              className={cn('relative h-6 w-11 shrink-0 rounded-full transition', autoNext ? 'bg-white' : 'bg-white/15')}
            >
              <span className={cn('absolute top-1 h-4 w-4 rounded-full transition-all', autoNext ? 'left-6 bg-black' : 'left-1 bg-white')} />
            </button>
          </label>
        </div>
        <div className="mt-3 flex flex-wrap items-center justify-between gap-3 border-t border-line pt-3">
          <p className="max-w-md text-[11px] leading-relaxed text-zinc-600">
            Плеер сам находит рабочую дорожку и переключается при сбое. Горячие клавиши: <kbd>Shift</kbd>+
            <kbd>→</kbd> следующая серия, <kbd>T</kbd> кинотеатр.
          </p>
          <div className="flex gap-1">
            <button
              onClick={() => current && onToggleWatched(current.number)}
              className={cn(
                'grid h-9 w-9 place-items-center rounded-full transition active:scale-90',
                current && watched.includes(current.number) ? 'bg-emerald-500/15 text-emerald-300' : 'bg-white/[0.05] text-zinc-400 hover:text-white',
              )}
              title="Просмотрено"
            >
              <Icon.Check className="h-4 w-4" />
            </button>
            <button
              onClick={() => onTheaterChange(!theater)}
              className={cn(
                'hidden h-9 w-9 place-items-center rounded-full transition active:scale-90 lg:grid',
                theater ? 'bg-white text-black' : 'bg-white/[0.05] text-zinc-400 hover:text-white',
              )}
              title="Кинотеатр (T)"
            >
              <Icon.Expand className="h-4 w-4" />
            </button>
            <button
              onClick={share}
              className={cn(
                'grid h-9 w-9 place-items-center rounded-full bg-white/[0.05] transition active:scale-90',
                copied ? 'text-emerald-300' : 'text-zinc-400 hover:text-white',
              )}
              title="Скопировать ссылку"
            >
              {copied ? <Icon.Check className="h-4 w-4" /> : <Icon.Share className="h-4 w-4" />}
            </button>
            <button
              onClick={() => current && activeCandidate && setDlOpen(true)}
              className="grid h-9 w-9 place-items-center rounded-full bg-white/[0.05] text-zinc-400 transition hover:text-white active:scale-90"
              title="Скачать серию"
            >
              <Icon.Download className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Серии */}
      <div>
        <div className="mb-2 flex items-center justify-between px-0.5">
          <span className="text-[11px] font-semibold uppercase tracking-wider text-zinc-500">Серии</span>
          <span className="text-[11px] text-zinc-600">
            {watchedCount}/{episodes.length} просмотрено
          </span>
        </div>
        <div
          ref={epListRef}
          className="grid max-h-[248px] grid-cols-[repeat(auto-fill,minmax(3rem,1fr))] gap-1.5 overflow-y-auto overscroll-contain pr-0.5"
        >
          {episodes.map((e, i) => {
            const isActive = e.number === current?.number;
            const isWatched = watched.includes(e.number);
            const long = e.number.length > 3;
            return (
              <button
                key={e.number}
                data-active={isActive}
                onClick={() => setEpisode(e.number)}
                style={{ animationDelay: `${Math.min(i, 24) * 12}ms` }}
                title={`Серия ${e.number}${e.duration ? ` · ${formatDuration(e.duration)}` : ''}`}
                aria-label={`Серия ${e.number}`}
                aria-current={isActive}
                className={cn(
                  'relative grid aspect-square min-w-0 animate-pop place-items-center rounded-xl font-semibold tabular-nums leading-none transition-[transform,background-color,color,box-shadow] duration-200 will-change-transform active:scale-[0.88]',
                  long ? 'text-[11px]' : 'text-[13px]',
                  isActive
                    ? 'bg-white text-black shadow-[0_0_0_2px_rgba(255,255,255,0.25),0_6px_18px_-6px_rgba(255,255,255,0.5)]'
                    : isWatched
                      ? 'bg-white/[0.035] text-zinc-500 hover:bg-white/[0.07] hover:text-zinc-300'
                      : 'bg-white/[0.06] text-zinc-200 hover:-translate-y-0.5 hover:bg-white/[0.12]',
                )}
              >
                <span className="pointer-events-none truncate px-1">{e.number}</span>
                {isWatched && !isActive && (
                  <span className="pointer-events-none absolute right-1 top-1 h-1.5 w-1.5 rounded-full bg-emerald-400/90 shadow-[0_0_6px_rgba(52,211,153,0.8)]" />
                )}
              </button>
            );
          })}
        </div>
      </div>

      {dlOpen && current && activeCandidate && (
        <DownloadSheet
          video={activeCandidate}
          title={title}
          initialSource={nativeQuality ?? undefined}
          onClose={() => setDlOpen(false)}
        />
      )}
    </div>
  );
}

/* ---------- Память автоподбора: какие маршруты отвечали, а какие нет ---------- */
const failCount = new Map<string, number>();

function rememberFail(url: string) {
  failCount.set(url, (failCount.get(url) || 0) + 1);
}

function rememberOk(url: string) {
  failCount.delete(url);
}

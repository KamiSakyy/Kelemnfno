'use client';

import dynamic from 'next/dynamic';

// SPA целиком живёт на клиенте (хеш-роутинг, localStorage, hls.js)
const AppRoot = dynamic(() => import('./AppRoot'), {
  ssr: false,
  loading: () => (
    <div className="flex min-h-screen items-center justify-center bg-bg">
      <div className="h-8 w-8 animate-spin rounded-full border-2 border-white/15 border-t-white" />
    </div>
  ),
});

export default function ClientApp() {
  return <AppRoot />;
}

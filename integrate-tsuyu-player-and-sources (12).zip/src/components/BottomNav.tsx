'use client';
import { links } from '../hooks/useHashRoute';
import { cn } from '../utils/cn';

const ITEMS = [
  {
    key: 'home',
    label: 'Главная',
    href: links.home,
    icon: (active: boolean) => (
      <svg viewBox="0 0 24 24" className="h-[22px] w-[22px]" fill={active ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth={active ? 0 : 1.8}>
        <path
          strokeLinecap="round"
          strokeLinejoin="round"
          d="M4 10.5L12 4l8 6.5V19a1.5 1.5 0 01-1.5 1.5H14v-5.5h-4V20.5H5.5A1.5 1.5 0 014 19v-8.5z"
        />
      </svg>
    ),
  },
  {
    key: 'catalog',
    label: 'Каталог',
    href: links.catalog(),
    icon: (active: boolean) => (
      <svg viewBox="0 0 24 24" className="h-[22px] w-[22px]" fill={active ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth={1.8}>
        <rect x="4" y="4" width="7" height="7" rx="2" />
        <rect x="13" y="4" width="7" height="7" rx="2" />
        <rect x="4" y="13" width="7" height="7" rx="2" />
        <rect x="13" y="13" width="7" height="7" rx="2" />
      </svg>
    ),
  },
  {
    key: 'favorites',
    label: 'Избранное',
    href: links.favorites,
    icon: (active: boolean) => (
      <svg viewBox="0 0 24 24" className="h-[22px] w-[22px]" fill={active ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth={active ? 0 : 1.8}>
        <path
          strokeLinecap="round"
          strokeLinejoin="round"
          d="M4.3 6.3a4.5 4.5 0 000 6.4L12 20.4l7.7-7.7a4.5 4.5 0 00-6.4-6.4L12 7.6l-1.3-1.3a4.5 4.5 0 00-6.4 0z"
        />
      </svg>
    ),
  },
  {
    key: 'calendar',
    label: 'Календарь',
    href: links.calendar,
    icon: (active: boolean) => (
      <svg viewBox="0 0 24 24" className="h-[22px] w-[22px]" fill="none" stroke="currentColor" strokeWidth={1.8}>
        <rect x="3.5" y="5" width="17" height="15.5" rx="3" fill={active ? 'currentColor' : 'none'} strokeWidth={active ? 0 : 1.8} />
        <path strokeLinecap="round" d="M3.5 10h17M8.5 3v3.5M15.5 3v3.5" stroke={active ? 'var(--color-bg)' : 'currentColor'} />
      </svg>
    ),
  },
];

export function BottomNav({ active }: { active: string }) {
  // watch/search/history подсвечивают ближайший раздел
  const mapped = active === 'watch' || active === 'search' ? 'catalog' : active === 'history' ? 'home' : active;

  return (
    <nav className="fixed inset-x-0 bottom-0 z-40 md:bottom-4 md:px-4">
      <div className="pb-safe border-t border-line bg-[#0c0c0f]/95 backdrop-blur-2xl md:mx-auto md:max-w-md md:rounded-[28px] md:border md:pb-0 md:shadow-2xl md:shadow-black/60">
        <div className="mx-auto grid h-[68px] max-w-md grid-cols-4 md:h-[72px]">
          {ITEMS.map((it) => {
            const isActive = mapped === it.key;
            return (
              <a key={it.key} href={it.href} className="group flex flex-col items-center justify-center gap-1" aria-label={it.label}>
                <span
                  className={cn(
                    'grid h-8 w-14 place-items-center rounded-full transition-all duration-300',
                    isActive ? 'bg-white text-black' : 'text-zinc-500 group-hover:bg-white/[0.06] group-hover:text-zinc-300 group-active:scale-90',
                  )}
                >
                  {it.icon(isActive)}
                </span>
                <span className={cn('text-[10.5px] font-medium leading-none transition-colors', isActive ? 'text-white' : 'text-zinc-600 group-hover:text-zinc-400')}>
                  {it.label}
                </span>
              </a>
            );
          })}
        </div>
      </div>
    </nav>
  );
}

/* Утилиты Tsuyu: нормализация ссылок, распознавание озвучки (порт ApiRepository). */

export function safeUrl(value?: string | null): string {
  if (!value) return "";
  let v = value.trim().replace(/\\\//g, "/").replace(/&amp;/g, "&").replace(/ /g, "%20");
  if (!v) return "";
  if (v.startsWith("//")) v = "https:" + v;
  if (!/^https?:\/\//i.test(v)) return "";
  try {
    return new URL(v).toString();
  } catch {
    return "";
  }
}

export function absolute(base: string, value?: string | null): string {
  if (!value) return "";
  let v = value.trim().replace(/\\\//g, "/").replace(/&amp;/g, "&").replace(/ /g, "%20");
  if (!v) return "";
  if (v.startsWith("//")) v = "https:" + v;
  try {
    return new URL(v, base).toString();
  } catch {
    return "";
  }
}

const KODIK_HOSTS = ["aniqit.com", "kodik.info", "kodik.cc", "kodik.biz"];

/** Порт ApiRepository.embed — вытаскивает src из iframe и канонизирует Kodik-хосты. */
export function embed(input?: string | null): string {
  if (!input) return "";
  let s = input.trim().replace(/&amp;/g, "&");
  const html = s.match(/src=["']([^"']+)/i);
  if (html) s = html[1];
  if (s.startsWith("//")) s = "https:" + s;
  const safe = safeUrl(s);
  if (!safe) return "";
  try {
    const u = new URL(safe);
    if (KODIK_HOSTS.includes(u.hostname)) {
      u.protocol = "https:";
      u.hostname = "kodikplayer.com";
      return u.toString();
    }
    return u.toString();
  } catch {
    return safe;
  }
}

export function plain(text?: string | null): string {
  return (text || "")
    .replace(/<br\s*\/?>/gi, " ")
    .replace(/<[^>]+>/g, "")
    .replace(/\[\/?[^\]]+\]/g, "")
    .replace(/&nbsp;/g, " ")
    .replace(/&quot;/g, '"')
    .replace(/&#34;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&laquo;/g, "«")
    .replace(/&raquo;/g, "»")
    .replace(/&mdash;/g, "—")
    .replace(/&ndash;/g, "–")
    .replace(/&amp;/g, "&")
    .replace(/\s+/g, " ")
    .trim();
}

export function plainName(text?: string | null): string {
  return (text || "")
    .toLowerCase()
    .replace(/[^\p{L}\p{N}]+/gu, " ")
    .trim();
}

/** Метки, которые обозначают не озвучку, а «маршрут»/источник — их пользователю не показываем. */
function routeLabel(value: string): boolean {
  const v = value.toLowerCase().replace(/ё/g, "е");
  return (
    v.includes("yoru") ||
    v.includes("yummy") ||
    v.includes("yani") ||
    v.includes("kodik") ||
    v.includes("aniqit") ||
    v.includes("cdnvideohub") ||
    v.includes("anix") ||
    v.includes("sekai") ||
    v.includes("tsuyu") ||
    v === "player" ||
    v === "iframe" ||
    v === "плеер" ||
    v === "вариант" ||
    v === "оригинал"
  );
}

/** Порт ApiRepository.voiceKey — приводит любое название озвучки к канону. */
export function voiceKey(value?: string | null): string {
  let v = (value || "").toLowerCase().replace(/ё/g, "е");
  v = v
    .replace(/анилибрия/g, "anilibria")
    .replace(/анилиберт/g, "aniliberty")
    .replace(/анимаунт/g, "animaunt")
    .replace(/анимевост/g, "animevost")
    .replace(/анимедиа/g, "animedia")
    .replace(/анидаб/g, "anidub")
    .replace(/субтитры/g, "subtitles")
    .replace(/сабы/g, "subtitles");
  if (v.includes("anilibria") || v.includes("aniliberty") || v.includes("cdnlibs")) {
    if (v.includes("classic")) return "anilibria-classic";
    if (v.includes("dub")) return "anilibria-dub";
    if (v.includes("hd") || v.includes("hiq")) return "anilibria-hd";
    return "anilibria";
  }
  if (v.includes("animaunt") || v.includes("ani maunt")) return "animaunt";
  if (v.includes("anirise") || v.includes("ani rise")) return "anirise";
  if (v.includes("anifilm") || v.includes("ani film")) return "anifilm";
  if (v.includes("aniplay") || v.includes("ani play")) return "aniplay";
  if (v.includes("amazing") && v.includes("dubbing")) return "amazing-dubbing";
  if (v.includes("animevost") || v.includes("anime vost")) return "animevost";
  if (v.includes("newstation") || v.includes("new station")) return "newstation";
  if (v.includes("onwave") || v.includes("on wave")) return "onwave";
  if (v.includes("anistar") && v.includes("deep")) return "anistar-deep";
  if (v.includes("beyond") && v.includes("studio")) return "beyond-studio";
  if (v.includes("dream") && v.includes("cast")) return "dreamcast";
  if (v.includes("anidub") || v.includes("ani dub")) return "anidub";
  if (v.includes("animedia") || v.includes("ani media")) return "animedia";
  if (v.includes("studioband") || v.includes("studio band") || v.includes("студийная банда")) return "studio-band";
  if (/\bjam\b/.test(v)) return "jam";
  if (v.includes("kansai")) return "kansai";
  if (v.includes("crunchyroll")) return "crunchyroll";
  if (v.includes("wakanim")) return "wakanim";
  if (v.includes("netflix")) return "netflix";
  if (v.includes("shiza")) return "shiza";
  if (v.includes("субтитр") || v.includes("subtitles") || v.includes("subtitle") || /\bsub\b/.test(v)) return "subtitles";
  if (routeLabel(v)) return "";
  const p = plainName(v);
  if (!p || p === "auto" || p === "avto" || p === "ozvuchka" || p === "perevod") return "";
  return p.replace(/\s+/g, "");
}

const TITLES: Record<string, string> = {
  "anilibria-classic": "AniLibria Classic",
  "anilibria-dub": "AniLibria Dub",
  "anilibria-hd": "AniLibria HD",
  anilibria: "AniLibria.TV",
  animaunt: "AniMaunt",
  anirise: "AniRise",
  anifilm: "AniFilm",
  aniplay: "AniPlay",
  "amazing-dubbing": "Amazing Dubbing",
  animevost: "AnimeVost",
  newstation: "NewStation",
  onwave: "OnWave",
  "anistar-deep": "AniStar & DEEP",
  "beyond-studio": "Beyond:Studio",
  dreamcast: "Dream Cast",
  anidub: "AniDUB",
  animedia: "AniMedia",
  "studio-band": "StudioBand",
  jam: "JAM",
  kansai: "Kansai",
  crunchyroll: "Crunchyroll",
  wakanim: "Wakanim",
  netflix: "Netflix",
  shiza: "SHIZA Project",
  subtitles: "Субтитры",
};

export function voiceTitle(value?: string | null): string {
  const key = voiceKey(value);
  if (!key) return "";
  if (TITLES[key]) return TITLES[key];
  const raw = (value || "").trim().replace(/\s+/g, " ");
  return raw.length > 1 ? raw.slice(0, 48) : "";
}

export function voiceMatches(wanted?: string | null, actual?: string | null): boolean {
  const w = voiceKey(wanted);
  if (!w) return true;
  const a = voiceKey(actual);
  if (!a) return false;
  if (w === a) return true;
  return a.includes(w) || w.includes(a);
}

export function cleanLabel(value?: string | null): string {
  const v = (value || "").trim();
  if (!v) return "";
  return plain(v).replace(/\s*[·|]\s*$/, "").trim();
}

export function qualityOf(url: string): number {
  const v = (url || "").toLowerCase();
  const direct = v.match(/(\d{3,4})p/);
  if (direct) return parseInt(direct[1], 10);
  if (v.includes("2160") || v.includes("4k") || v.includes("uhd")) return 2160;
  if (v.includes("1440")) return 1440;
  if (v.includes("1080") || v.includes("fullhd") || v.includes("fhd")) return 1080;
  if (v.includes("720") || v.includes("hd")) return 720;
  if (v.includes("480") || v.includes("sd")) return 480;
  if (v.includes("360")) return 360;
  if (v.includes("240")) return 240;
  return 0;
}

export function hostOf(url: string): string {
  try {
    return new URL(url.startsWith("//") ? "https:" + url : url).hostname.toLowerCase();
  } catch {
    return "";
  }
}

export function pathOf(url: string): string {
  try {
    return new URL(url.startsWith("//") ? "https:" + url : url).pathname;
  } catch {
    return "";
  }
}

export function originOf(url: string): string {
  try {
    return new URL(url).origin;
  } catch {
    return "";
  }
}

export function hostMatches(host: string, ...names: string[]): boolean {
  return names.some((n) => host === n || host.endsWith("." + n));
}

export function numberIn(text: string, fallback: number): number {
  const m = (text || "").match(/[0-9]+(?:\.[0-9]+)?/);
  if (!m) return fallback;
  const v = parseFloat(m[0]);
  return Number.isFinite(v) ? v : fallback;
}

export function cleanTitle(raw?: string | null): string {
  let t = plain(raw).replace(/\u00a0/g, " ").trim();
  t = t.replace(/\s*\/\s*/g, " / ");
  return t;
}

/** Варианты поискового запроса (порт searchTerms). */
export function searchTerms(title: string, original?: string): string[] {
  const out = new Set<string>();
  const push = (value?: string | null) => {
    const v = cleanTitle(value)
      .replace(/(?:смотреть|онлайн|аниме|сериал)/giu, " ")
      .replace(/\s*\([^)]*\)\s*/g, " ")
      .replace(/\s*\[[^\]]*]\s*/g, " ")
      .replace(/\s+/g, " ")
      .trim();
    if (v.length >= 2) out.add(v);
  };
  push(title);
  push(original);
  for (const raw of [title, original]) {
    if (!raw) continue;
    for (const part of raw.split("/")) push(part);
  }
  const short = cleanTitle(title).split(/[:—–-]/)[0]?.trim();
  if (short && short.length >= 3) out.add(short);
  return [...out].slice(0, 5);
}

import crypto from "node:crypto";

/* Подписанные непрозрачные токены: клиент получает только строку,
 * внутри — маршрут источника. Источники остаются секретом. */

const SECRET =
  process.env.TSUYU_SECRET ||
  process.env.DATABASE_URL ||
  "tsuyu-yoru-local-secret-v1";

function sign(payload: string): string {
  return crypto.createHmac("sha256", SECRET).update(payload).digest("base64url").slice(0, 27);
}

export function seal(data: unknown): string {
  const payload = Buffer.from(JSON.stringify(data), "utf8").toString("base64url");
  return `${payload}.${sign(payload)}`;
}

export function open<T>(token: string): T | null {
  if (!token || !token.includes(".")) return null;
  const idx = token.lastIndexOf(".");
  const payload = token.slice(0, idx);
  const mac = token.slice(idx + 1);
  if (sign(payload) !== mac) return null;
  try {
    return JSON.parse(Buffer.from(payload, "base64url").toString("utf8")) as T;
  } catch {
    return null;
  }
}

export interface ProxyTicket {
  u: string;
  r?: string;
  o?: string;
  m?: "hls" | "raw";
  e: number;
}

export function proxyUrl(url: string, referer?: string, kind: "hls" | "raw" = "raw"): string {
  const ticket: ProxyTicket = {
    u: url,
    r: referer,
    o: referer ? new URL(referer).origin : undefined,
    m: kind,
    e: Date.now() + 6 * 60 * 60 * 1000,
  };
  return `/api/tsuyu/proxy?t=${encodeURIComponent(seal(ticket))}`;
}

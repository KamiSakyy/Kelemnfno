/* Порт VideoResolver.java — превращает ссылку плеера в набор прямых потоков.
 * Поддержаны ВСЕ маршруты Tsuyu: Kodik, CDNVideoHub (Yummy), Alloha, Aksor,
 * Sibnet, Stormo, AniBoom, AniLib, Animetka, AniDUB(ladony/vid.php), VK, Rutube,
 * ZedFilm/Hlamer, а также прямые m3u8 / mpd / mp4. */

import { baseHeaders, request } from "./net";
import {
  absolute,
  embed,
  hostMatches,
  hostOf,
  originOf,
  pathOf,
  qualityOf,
  safeUrl,
} from "./util";

export type Streams = Record<number, string>;

export interface Resolved {
  streams: Streams;
  referer: string;
}

const M3U8_RE = /https?:\\?\/\\?\/[^"'\s\\<>]+?\.m3u8[^"'\s\\<>]*/gi;
const MP4_RE = /https?:\\?\/\\?\/[^"'\s\\<>]+?\.mp4[^"'\s\\<>]*/gi;

function unescape(s: string): string {
  return (s || "")
    .replace(/&quot;/g, '"')
    .replace(/&#34;/g, '"')
    .replace(/&amp;/g, "&")
    .replace(/\\"/g, '"')
    .replace(/\\\//g, "/");
}

function find(text: string, re: RegExp): string {
  const m = text.match(re);
  return m && m[1] ? m[1] : "";
}

function clean(out: Streams): Streams {
  const res: Streams = {};
  for (const [k, v] of Object.entries(out)) {
    const q = Number(k);
    const safe = safeUrl(v);
    if (safe) res[q] = safe;
  }
  return res;
}

function parseHls(manifest: string, url: string): Streams {
  const out: Streams = {};
  if (!manifest || !manifest.trim().startsWith("#EXTM3U")) return out;
  const lines = manifest.split(/\r?\n/);
  let height = 0;
  for (const raw of lines) {
    const l = raw.trim();
    if (l.startsWith("#EXT-X-STREAM-INF")) {
      const m = l.match(/RESOLUTION=\d+x(\d+)/);
      height = m ? parseInt(m[1], 10) : 0;
    } else if (l && !l.startsWith("#") && height > 0) {
      out[height] = absolute(url, l);
      height = 0;
    }
  }
  return clean(out);
}

async function direct(url: string, referer?: string): Promise<Streams> {
  const out: Streams = {};
  const lower = url.toLowerCase();
  const p = pathOf(url).toLowerCase();
  if (p.includes(".m3u8") || lower.includes(".m3u8")) {
    try {
      const manifest = await request(url, { headers: baseHeaders(originOf(url), referer), timeout: 9000 });
      Object.assign(out, parseHls(manifest, url));
    } catch {
      /* мастер-плейлист недоступен — отдадим как есть */
    }
    if (!Object.keys(out).length) out[qualityOf(url) || 720] = url;
  } else if (p.includes(".mpd") || lower.includes(".mpd")) {
    out[0] = url;
  } else if (/\.(mp4|mkv|webm)/.test(p) || /\.(mp4|mkv|webm)/.test(lower)) {
    out[qualityOf(url) || 720] = url;
  }
  return clean(out);
}

/* ---------------- Kodik ---------------- */

function endpointPath(script: string): string {
  const all = script.match(/atob\(\s*["']([A-Za-z0-9+/=]+)["']/g) || [];
  for (const a of all) {
    const b64 = a.replace(/[^A-Za-z0-9+/=]/g, "");
    try {
      const p = Buffer.from(b64, "base64").toString("utf8");
      if (p.startsWith("/") && p.length >= 2 && p.length < 40) return p;
    } catch {
      /* пропускаем */
    }
  }
  return "";
}

/** Шифр Kodik — сдвиг по алфавиту (штатный SHIFT=18) + base64. */
function shift(s: string, n: number): string {
  return s.replace(/[a-zA-Z]/g, (c) => {
    const base = c <= "Z" ? 65 : 97;
    return String.fromCharCode(((c.charCodeAt(0) - base + n) % 26) + base);
  });
}

function b64(value: string): string {
  try {
    return Buffer.from(value.replace(/-/g, "+").replace(/_/g, "/"), "base64").toString("utf8");
  } catch {
    return "";
  }
}

function kodikDecode(raw: string): string {
  const order = [18, 13, 21, 8, 3, ...Array.from({ length: 26 }, (_v, i) => i)];
  for (const n of order) {
    const decoded = b64(shift(raw, n));
    if (/^(https?:)?\/\//.test(decoded)) return safeUrl(decoded.startsWith("//") ? "https:" + decoded : decoded);
  }
  const plain = b64(raw);
  if (/^(https?:)?\/\//.test(plain)) return safeUrl(plain.startsWith("//") ? "https:" + plain : plain);
  return safeUrl(raw);
}

/** Kodik принимает часть полей уже в url-encoded виде — повторно кодировать нельзя. */
function looksEncoded(value: string): boolean {
  return /%[0-9a-fA-F]{2}/.test(value || "");
}

function formBody(rows: [string, string, boolean?][]): string {
  return rows
    .map(([k, v, raw]) => `${k}=${raw || looksEncoded(v) ? v : encodeURIComponent(v ?? "")}`)
    .join("&");
}

async function kodik(url: string): Promise<Streams> {
  const page = (
    await request(url, { headers: baseHeaders(originOf(url), "https://yani.tv/"), timeout: 12_000 })
  ).replace(/[\n\r]/g, "");

  const payload: Record<string, string> = {};
  let urlParams = find(page, /\burlParams\s*=\s*'([^']+)'/);
  if (!urlParams) urlParams = find(page, /\burlParams\s*=\s*"([^"]+)"/);
  if (urlParams) {
    try {
      const p = JSON.parse(unescape(urlParams)) as Record<string, string>;
      for (const k of ["d", "d_sign", "pd", "pd_sign", "ref", "ref_sign"]) payload[k] = p[k] || "";
    } catch {
      /* упадём на regex-вариант */
    }
  }
  if (!payload.d) {
    payload.d = find(page, /var\s+domain\s*=\s*["'](.+?)["']/);
    payload.d_sign = find(page, /var\s+d_sign\s*=\s*["'](.+?)["']/);
    payload.pd = find(page, /var\s+pd\s*=\s*["'](.+?)["']/);
    payload.pd_sign = find(page, /var\s+pd_sign\s*=\s*["'](.+?)["']/);
    payload.ref = find(page, /var\s+ref\s*=\s*["'](.+?)["']/);
    payload.ref_sign = find(page, /var\s+ref_sign\s*=\s*["'](.+?)["']/);
  }
  payload.type =
    find(page, /(?:videoInfo|vInfo)\.type\s*\+?=\s*["'](.+?)["']/) ||
    find(page, /["']type["']\s*:\s*["'](.+?)["']/);
  payload.hash =
    find(page, /(?:videoInfo|vInfo)\.hash\s*\+?=\s*["'](.+?)["']/) ||
    find(page, /["']hash["']\s*:\s*["'](.+?)["']/);
  payload.id =
    find(page, /(?:videoInfo|vInfo)\.id\s*\+?=\s*["'](.+?)["']/) ||
    find(page, /["']id["']\s*:\s*["'](.+?)["']/) ||
    find(page, /var\s+videoId\s*=\s*["'](\d+)["']/);

  let endpoint = originOf(url) + "/ftor";
  let script =
    find(page, /src=["']((?:\/\/[^"']+)?\/assets\/js\/app\.player_single[^"']+)["']/) ||
    find(page, /src=["']([^"']*app\.player_single[^"']+)["']/) ||
    find(page, /src=["']([^"']*assets\/js[^"']+)["']/);
  if (script) {
    try {
      const scriptUrl = absolute(url, script);
      const body = await request(scriptUrl, { headers: baseHeaders(originOf(url), url), timeout: 9000 });
      const p = endpointPath(body);
      if (p) endpoint = originOf(scriptUrl) + p;
    } catch {
      /* /ftor */
    }
  }

  for (const k of ["d", "d_sign", "pd", "pd_sign", "type", "hash", "id"]) {
    if (!payload[k]) throw new Error("kodik: нет параметров");
  }

  const body = formBody([
    ["d", payload.d],
    ["d_sign", payload.d_sign],
    ["pd", payload.pd],
    ["pd_sign", payload.pd_sign],
    ["ref", payload.ref || "", looksEncoded(payload.ref || "")],
    ["ref_sign", payload.ref_sign || ""],
    ["bad_user", "true"],
    ["cdn_is_working", "true"],
    ["type", payload.type],
    ["hash", payload.hash],
    ["id", payload.id],
    ["info", "{}"],
  ]);

  const bases = [endpoint, originOf(url) + "/ftor", "https://kodikplayer.com/ftor"].filter(
    (v, i, a) => a.indexOf(v) === i,
  );
  let links: Record<string, unknown> | null = null;
  for (const base of bases) {
    try {
      const text = await request(base, {
        method: "POST",
        body,
        form: true,
        headers: {
          ...baseHeaders(originOf(url), url),
          "X-Requested-With": "XMLHttpRequest",
          Accept: "application/json, text/javascript, */*; q=0.01",
        },
        timeout: 12_000,
      });
      const root = JSON.parse(text) as { links?: Record<string, unknown> };
      if (root.links && Object.keys(root.links).length) {
        links = root.links;
        break;
      }
    } catch {
      /* следующий хост */
    }
  }
  if (!links) throw new Error("kodik: нет ссылок");

  const out: Streams = {};
  for (const [key, value] of Object.entries(links)) {
    const q = parseInt(String(key).replace(/\D+/g, ""), 10) || 0;
    const rows = Array.isArray(value) ? value : [value];
    for (const row of rows) {
      const src =
        typeof row === "string"
          ? row
          : row && typeof row === "object"
            ? String((row as { src?: string }).src || "")
            : "";
      if (!src) continue;
      const decoded = kodikDecode(src) || safeUrl(src);
      if (decoded) out[q || qualityOf(decoded) || 720] = decoded;
    }
  }
  if (!Object.keys(out).length) throw new Error("kodik: не удалось декодировать");
  return clean(out);
}

/* ---------------- CDNVideoHub (Yummy) ---------------- */

function normalizeCvh(value: string, failover: string): string {
  const safe = safeUrl(value);
  if (!safe || !failover) return safe;
  try {
    const u = new URL(safe);
    if (u.protocol !== "https:" || !/^\d{1,3}(?:\.\d{1,3}){3}$/.test(u.hostname)) return safe;
    u.hostname = failover;
    return u.toString();
  } catch {
    return safe;
  }
}

async function cvh(url: string): Promise<Streams> {
  const uri = new URL(url.startsWith("//") ? "https:" + url : url);
  const animeId = uri.searchParams.get("anime_id") || uri.searchParams.get("id") || "";
  if (!animeId) throw new Error("cvh: нет id");
  const ep = parseInt(uri.searchParams.get("episode") || "1", 10) || 1;
  const dubbing = uri.searchParams.get("dubbing_code") || "";
  const h = {
    ...baseHeaders("https://ru.yummyani.me", "https://ru.yummyani.me/"),
    Accept: "application/json",
  };
  const playlist = JSON.parse(
    await request(
      `https://plapi.cdnvideohub.com/api/v1/player/sv/playlist?pub=745&id=${encodeURIComponent(animeId)}&aggr=mali`,
      { headers: h, timeout: 10_000 },
    ),
  ) as { items?: { episode?: number; voiceStudio?: string; vkId?: string }[] };
  let chosen: { vkId?: string } | null = null;
  for (const item of playlist.items || []) {
    if (item.episode !== ep) continue;
    if (!chosen) chosen = item;
    if (dubbing && (item.voiceStudio || "").toLowerCase() === dubbing.toLowerCase()) {
      chosen = item;
      break;
    }
  }
  if (!chosen?.vkId) throw new Error("cvh: серия не найдена");
  const video = JSON.parse(
    await request(`https://plapi.cdnvideohub.com/api/v1/player/sv/video/${encodeURIComponent(chosen.vkId)}`, {
      headers: h,
      timeout: 10_000,
    }),
  ) as { failoverHost?: string; sources?: Record<string, string> };
  const failover = video.failoverHost || "";
  const s = video.sources || {};
  const out: Streams = {};
  const put = (q: number, value?: string) => {
    const safe = normalizeCvh(value || "", failover);
    if (safe) out[q || qualityOf(safe) || 480] = safe;
  };
  put(240, s.mpegLowestUrl);
  put(360, s.mpegLowUrl);
  put(480, s.mpegMediumUrl);
  put(720, s.mpegHighUrl);
  put(1080, s.mpegFullHdUrl);
  put(1440, s.mpegQuadHdUrl || s.mpeg2kUrl);
  put(2160, s.mpegUltraHdUrl || s.mpegUhdUrl || s.mpeg4kUrl || s.mpegOriginalUrl);
  if (!Object.keys(out).length) throw new Error("cvh: нет вариантов");
  return clean(out);
}

/* ---------------- Alloha ---------------- */

async function alloha(url: string): Promise<Streams> {
  const page = await request(url, { headers: baseHeaders(originOf(url), "https://yani.tv/"), timeout: 12_000 });
  let id = find(page, /const\s+fileList\s*=\s*JSON\.parse\('\{"type":\s*"serial",\s*"active":\s*\{"id":\s*(\d+)/);
  if (!id) id = find(page, /"active"\s*:\s*\{\s*"id"\s*:\s*(\d+)/);
  const token = find(page, /const\s+userParam\s*=\s*\{[\s\S]*?token:\s*["'](.+?)["']/);
  const user = find(page, /<meta\s+name\s*=\s*["']user["']\s+content\s*=\s*["'](.+?)["']/);
  if (!id || !token || !user) throw new Error("alloha: нет параметров");
  const text = await request(`https://alloha.yani.tv/movie/${id}`, {
    method: "POST",
    form: true,
    body: `token=${encodeURIComponent(token)}&av1=true&autoplay=0&audio=&subtitle=`,
    headers: { ...baseHeaders("https://alloha.yani.tv", url), "Accepts-Controls": user },
    timeout: 12_000,
  });
  const root = JSON.parse(text) as { hlsSource?: { quality?: Record<string, string> }[] };
  const q = root.hlsSource?.[0]?.quality || {};
  const out: Streams = {};
  for (const [key, raw] of Object.entries(q)) {
    if (key.toLowerCase() === "object") continue;
    let link = String(raw);
    const cut = link.indexOf(" or ");
    if (cut >= 0) link = link.slice(0, cut);
    const safe = safeUrl(link);
    if (!safe) continue;
    out[parseInt(key.replace(/\D+/g, ""), 10) || qualityOf(safe) || 720] = safe;
  }
  if (!Object.keys(out).length) throw new Error("alloha: пусто");
  return clean(out);
}

/* ---------------- Aksor ---------------- */

async function aksor(url: string): Promise<Streams> {
  const origin = originOf(url);
  const out: Streams = {};
  try {
    const id = pathOf(url).split("/").filter(Boolean).pop() || "";
    if (id) {
      const j = JSON.parse(
        await request(`${origin}/api/video/${encodeURIComponent(id)}`, {
          headers: baseHeaders(origin, url),
          timeout: 9000,
        }),
      ) as { qualities?: Record<string, string>; sources?: { url?: string; src?: string; height?: number }[] };
      for (const [key, value] of Object.entries(j.qualities || {})) {
        const safe = safeUrl(value);
        if (safe) out[parseInt(key.replace(/\D+/g, ""), 10) || qualityOf(safe)] = safe;
      }
      for (const row of j.sources || []) {
        const safe = safeUrl(row.url || row.src || "");
        if (safe) out[row.height || qualityOf(safe)] = safe;
      }
    }
  } catch {
    /* fallback ниже */
  }
  if (Object.keys(out).length) return clean(out);
  const page = await request(url, { headers: baseHeaders(origin, "https://yani.tv/"), timeout: 9000 });
  const link = absolute(url, find(page, /var\s+videoUrl\s*=\s*["'](.+?)["']/));
  if (link) out[qualityOf(link) || 720] = link;
  return clean(out);
}

/* ---------------- Sibnet / Stormo / AniBoom / AniLib ---------------- */

async function sibnet(url: string): Promise<Streams> {
  const page = await request(url, { headers: baseHeaders(originOf(url), url), timeout: 10_000 });
  const out: Streams = {};
  for (const m of page.matchAll(/["'](\/v\/[a-z0-9]+\/[^"']+?\.m3u8)["']/gi)) {
    const safe = safeUrl("https://video.sibnet.ru" + m[1]);
    if (safe) out[qualityOf(safe) || 480] = safe;
  }
  for (const m of page.matchAll(/src:\s*["']\/(.+?\.mp4[^"']*)["']/gi)) {
    const safe = safeUrl("https://video.sibnet.ru/" + m[1].replace(/\\\//g, "/"));
    if (safe) out[qualityOf(safe) || 480] = safe;
  }
  if (!Object.keys(out).length) throw new Error("sibnet: пусто");
  return clean(out);
}

async function stormo(url: string): Promise<Streams> {
  const page = await request(url, { headers: baseHeaders(originOf(url), url), timeout: 10_000 });
  const out: Streams = {};
  for (const m of page.matchAll(/https?:\\?\/\\?\/www\.stormo\.tv\/get_file\/[^"'<>\s]+?\.mp4\/?/gi)) {
    const safe = safeUrl(m[0].replace(/\\\//g, "/"));
    if (safe) out[qualityOf(safe) || 480] = safe;
  }
  if (!Object.keys(out).length) return scan(url);
  return clean(out);
}

async function aniboom(url: string): Promise<Streams> {
  const page = await request(url, { headers: baseHeaders(originOf(url), "https://animego.org/"), timeout: 10_000 });
  const raw = find(page, /data-parameters\s*=\s*"([^"]+)"/);
  const out: Streams = {};
  if (raw) {
    try {
      const params = JSON.parse(unescape(raw)) as { hls?: string; dash?: string };
      const hls = params.hls ? (JSON.parse(params.hls) as Record<string, string>) : {};
      for (const value of Object.values(hls)) {
        const safe = safeUrl(value);
        if (safe) Object.assign(out, await direct(safe, url));
      }
    } catch {
      /* ниже общий скан */
    }
  }
  if (!Object.keys(out).length) return scan(url, "https://aniboom.one/");
  return clean(out);
}

async function anilib(url: string): Promise<Streams> {
  const out: Streams = {};
  const safe = safeUrl(url);
  if (safe) Object.assign(out, await direct(safe, "https://anilib.me/"));
  if (!Object.keys(out).length) out[qualityOf(safe) || 720] = safe;
  return clean(out);
}

/* ---------------- Animetka playlist ---------------- */

async function animetkaPlaylist(url: string): Promise<Streams> {
  const text = await request(url, {
    headers: {
      ...baseHeaders("https://animetka.com", "https://animetka.com/"),
      Accept: "application/json, text/plain, */*",
    },
    timeout: 10_000,
  });
  const out: Streams = {};
  try {
    const json = JSON.parse(text) as Record<string, unknown>;
    const walk = (value: unknown) => {
      if (typeof value === "string") {
        if (/\.(m3u8|mp4)/i.test(value)) {
          const safe = safeUrl(value.startsWith("//") ? "https:" + value : value);
          if (safe) out[qualityOf(safe) || 720] = safe;
        }
        return;
      }
      if (Array.isArray(value)) {
        value.forEach(walk);
        return;
      }
      if (value && typeof value === "object") Object.values(value).forEach(walk);
    };
    walk(json);
  } catch {
    /* не JSON — общий скан */
  }
  if (!Object.keys(out).length) {
    for (const m of text.matchAll(M3U8_RE)) {
      const safe = safeUrl(m[0].replace(/\\\//g, "/"));
      if (safe) out[qualityOf(safe) || 720] = safe;
    }
  }
  if (!Object.keys(out).length) throw new Error("animetka: пусто");
  return clean(out);
}

/* ---------------- VK / Rutube / ZedFilm ---------------- */

async function vk(url: string): Promise<Streams> {
  let page = await request(url, { headers: baseHeaders(originOf(url), "https://yani.tv/"), timeout: 12_000 });
  page = unescape(page);
  const ext =
    find(page, /(?:src|href)=["']([^"']*video_ext\.php[^"']+)["']/) ||
    find(page, /(https?:\\?\/\\?\/vk\.com\/video_ext\.php[^"'<>\s]+)/);
  if (ext) {
    try {
      page += "\n" + unescape(await request(absolute(url, ext), { headers: baseHeaders("https://vk.com", url) }));
    } catch {
      /* ок */
    }
  }
  const out: Streams = {};
  for (const m of page.matchAll(/["'](?:url|mp4_)(\d{3,4})["']\s*[:=]\s*["']([^"']+)["']/gi)) {
    const safe = safeUrl(m[2]);
    if (safe) out[parseInt(m[1], 10)] = safe;
  }
  for (const m of page.matchAll(/["'](?:hls_fmp4|hls|dash_sep)["']\s*[:=]\s*["']([^"']+)["']/gi)) {
    const safe = safeUrl(m[1]);
    if (safe) Object.assign(out, await direct(safe, url));
  }
  if (!Object.keys(out).length) throw new Error("vk: пусто");
  return clean(out);
}

function rutubeId(value: string): string {
  return (
    find(value, /rutube\.ru\/(?:play\/embed|video)\/([0-9a-f]{32})/i) || find(value, /([0-9a-f]{32})/i) || ""
  );
}

async function rutube(url: string): Promise<Streams> {
  let id = rutubeId(url);
  if (!id) {
    try {
      id = rutubeId(await request(url, { headers: baseHeaders("https://rutube.ru", "https://rutube.ru/") }));
    } catch {
      /* ок */
    }
  }
  if (!id) throw new Error("rutube: нет id");
  const root = JSON.parse(
    await request(
      `https://rutube.ru/api/play/options/${encodeURIComponent(id)}/?no_404=true&referer=${encodeURIComponent(url)}&pver=v2`,
      { headers: { ...baseHeaders("https://rutube.ru", url), Accept: "application/json,*/*" }, timeout: 10_000 },
    ),
  ) as { video_balancer?: Record<string, string> };
  const out: Streams = {};
  for (const value of Object.values(root.video_balancer || {})) {
    const safe = safeUrl(value);
    if (safe) Object.assign(out, await direct(safe, url));
  }
  if (!Object.keys(out).length) throw new Error("rutube: пусто");
  return clean(out);
}

/* ---------------- HLS-эндпоинт (AniDUB / ladony vid.php) ---------------- */

async function hlsEndpoint(url: string, referer: string): Promise<Streams> {
  const body = await request(url, {
    headers: baseHeaders(originOf(url), referer),
    timeout: 10_000,
  });
  if (body.trim().startsWith("#EXTM3U")) {
    const parsed = parseHls(body, url);
    if (Object.keys(parsed).length) return parsed;
    return clean({ [qualityOf(url) || 720]: url });
  }
  return scan(url, referer);
}

/* ---------------- Общий скан страницы ---------------- */

async function scan(url: string, referer?: string): Promise<Streams> {
  const page = await request(url, {
    headers: baseHeaders(originOf(url), referer || url),
    timeout: 12_000,
  });
  const out: Streams = {};
  const body = unescape(page);
  for (const m of body.matchAll(M3U8_RE)) {
    const safe = safeUrl(m[0].replace(/\\\//g, "/"));
    if (safe) out[qualityOf(safe) || 720] = safe;
  }
  if (!Object.keys(out).length) {
    for (const m of body.matchAll(MP4_RE)) {
      const safe = safeUrl(m[0].replace(/\\\//g, "/"));
      if (safe) out[qualityOf(safe) || 480] = safe;
    }
  }
  const file = find(body, /file\s*:\s*["']([^"']+)["']/);
  if (file) {
    const safe = absolute(url, file);
    if (safe) Object.assign(out, await direct(safe, url));
  }
  if (!Object.keys(out).length) throw new Error("не удалось найти поток");
  return clean(out);
}

/* ---------------- Точка входа ---------------- */

export async function resolveStreams(input: string): Promise<Resolved> {
  let url = embed(input);
  if (!url) url = safeUrl(input);
  if (!url) throw new Error("пустая ссылка");

  const host = hostOf(url);
  const path = pathOf(url).toLowerCase();
  const referer = originOf(url) + "/";

  const own = await direct(url, referer);
  if (Object.keys(own).length) return { streams: own, referer };

  let streams: Streams = {};
  if (hostMatches(host, "yummyani.me", "yani.tv") && path.includes("iframecvh")) streams = await cvh(url);
  else if (hostMatches(host, "cdnvideohub.com", "plapi.cdnvideohub.com")) streams = await cvh(url);
  else if (hostMatches(host, "animetka.com") && path.startsWith("/api/anime/playlist"))
    streams = await animetkaPlaylist(url);
  else if (hostMatches(host, "kodikplayer.com", "kodik.info", "kodik.cc", "kodik.biz", "aniqit.com"))
    streams = await kodik(url);
  else if (hostMatches(host, "alloha.yani.tv", "alloha.tv")) streams = await alloha(url);
  else if (hostMatches(host, "aksor.tv", "aksor.yani.tv", "player.aksor.tv")) streams = await aksor(url);
  else if (hostMatches(host, "video.sibnet.ru", "sibnet.ru")) streams = await sibnet(url);
  else if (hostMatches(host, "stormo.tv")) streams = await stormo(url);
  else if (host.includes("ladony") || path.includes("vid.php")) streams = await hlsEndpoint(url, "https://online.anidub.com/");
  else if (hostMatches(host, "vk.com", "vkvideo.ru", "vkvideo.com") || path.includes("iframevk"))
    streams = await vk(url);
  else if (hostMatches(host, "rutube.ru")) streams = await rutube(url);
  else if (hostMatches(host, "zedfilm.ru", "hlamer.ru")) streams = await scan(url);
  else if (hostMatches(host, "aniboom.one")) streams = await aniboom(url);
  else if (hostMatches(host, "video1.anilib.me", "video2.anilib.me", "anilib.me")) streams = await anilib(url);
  else streams = await scan(url);

  if (!Object.keys(streams).length) throw new Error("поток не найден");
  return { streams, referer };
}

/* ---------------- Проверка пригодности потока ---------------- */

/**
 * Некоторые источники отдают ссылки-заглушки (редиректы, страницы ошибок).
 * Проверяем первые байты: HLS обязан начинаться с #EXTM3U, MP4 — содержать ftyp.
 * Мусор отбрасывается сразу, чтобы плеер не тратил трафик впустую.
 */
export async function verify(url: string, referer: string, kind: "hls" | "mp4"): Promise<boolean> {
  try {
    const headers: Record<string, string> = baseHeaders(originOf(url), referer);
    if (kind === "mp4") headers["Range"] = "bytes=0-1024";
    const res = await fetch(url, { headers, redirect: "follow", signal: AbortSignal.timeout(9000) });
    if (!res.ok && res.status !== 206) return false;
    const type = (res.headers.get("content-type") || "").toLowerCase();
    if (kind === "hls") {
      if (type.includes("video/") || type.includes("mp4")) return false;
      const text = (await res.text()).trimStart();
      return text.startsWith("#EXTM3U");
    }
    if (type.includes("mpegurl")) return false;
    if (type.includes("video/") || type.includes("octet-stream")) return true;
    const buf = new Uint8Array(await res.arrayBuffer());
    const head = String.fromCharCode(...buf.slice(0, 64));
    return head.includes("ftyp") || head.includes("moov");
  } catch {
    return false;
  }
}

export function kindOf(url: string): "hls" | "mp4" {
  return /\.mp4(\?|$)/i.test(url) ? "mp4" : "hls";
}

/** Оставляет только реально играбельные потоки. */
export async function verifyStreams(streams: Streams, referer: string): Promise<Streams> {
  const entries = Object.entries(streams);
  const flags = await Promise.all(
    entries.map(async ([q, url]) => [Number(q), url, await verify(url, referer, kindOf(url))] as const),
  );
  const out: Streams = {};
  for (const [q, url, ok] of flags) if (ok) out[q] = url;
  return out;
}

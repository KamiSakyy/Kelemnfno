/* Сетевой слой Tsuyu (порт Net.java / ApiRepository.request).
 * Работает ТОЛЬКО на сервере — клиент никогда не видит адреса источников. */

export const CHROME =
  "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Mobile Safari/537.36";
export const ANIX_UA = "Anixart/8.5.2 (Android 13; Pixel 7)";

export interface ReqInit {
  method?: "GET" | "POST";
  body?: string;
  form?: boolean;
  json?: boolean;
  headers?: Record<string, string>;
  timeout?: number;
  referer?: string;
  origin?: string;
}

interface CacheRow {
  text: string;
  at: number;
}

const memory = new Map<string, CacheRow>();
const MEM_LIMIT = 600;

function ttlFor(url: string): number {
  const v = url.toLowerCase();
  if (v.includes("playlist") || v.includes("ftor") || v.includes("get-player")) return 3 * 60_000;
  if (v.includes("/episode") || v.includes("videos")) return 5 * 60_000;
  return 10 * 60_000;
}

function trim() {
  if (memory.size <= MEM_LIMIT) return;
  const keys = [...memory.keys()];
  for (let i = 0; i < keys.length - MEM_LIMIT; i++) memory.delete(keys[i]);
}

export function baseHeaders(origin?: string, referer?: string): Record<string, string> {
  const h: Record<string, string> = {
    "User-Agent": CHROME,
    Accept: "*/*",
    "Accept-Language": "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.6",
  };
  if (origin) h["Origin"] = origin;
  if (referer) h["Referer"] = referer;
  return h;
}

export async function request(url: string, init: ReqInit = {}): Promise<string> {
  const method = init.method || "GET";
  const key = `${method} ${url} ${init.body || ""} ${JSON.stringify(init.headers || {})}`;
  const now = Date.now();
  if (method === "GET") {
    const hit = memory.get(key);
    if (hit && now - hit.at < ttlFor(url)) return hit.text;
  }

  const headers: Record<string, string> = {
    ...baseHeaders(init.origin, init.referer),
    ...(init.headers || {}),
  };
  if (method === "POST") {
    headers["Content-Type"] = init.form
      ? "application/x-www-form-urlencoded; charset=UTF-8"
      : "application/json";
  }

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), init.timeout ?? 12_000);
  try {
    const res = await fetch(url, {
      method,
      headers,
      body: method === "POST" ? init.body : undefined,
      signal: controller.signal,
      redirect: "follow",
      cache: "no-store",
    });
    if (!res.ok && res.status >= 400) throw new Error(`HTTP ${res.status} ${url}`);
    const text = await res.text();
    if (method === "GET") {
      memory.set(key, { text, at: now });
      trim();
    }
    return text;
  } finally {
    clearTimeout(timer);
  }
}

export async function getJson<T = Record<string, unknown>>(url: string, init: ReqInit = {}): Promise<T> {
  const text = await request(url, {
    ...init,
    headers: { Accept: "application/json, text/plain, */*", ...(init.headers || {}) },
  });
  return JSON.parse(text) as T;
}

export async function postJson<T = Record<string, unknown>>(
  url: string,
  body: unknown,
  init: ReqInit = {},
): Promise<T> {
  const text = await request(url, {
    ...init,
    method: "POST",
    body: JSON.stringify(body),
    headers: { Accept: "application/json", ...(init.headers || {}) },
  });
  return JSON.parse(text) as T;
}

export async function postForm<T = Record<string, unknown>>(
  url: string,
  fields: Record<string, string>,
  init: ReqInit = {},
): Promise<T> {
  const body = new URLSearchParams(fields).toString();
  const text = await request(url, { ...init, method: "POST", body, form: true });
  return JSON.parse(text) as T;
}

export function query(base: string, params: Record<string, string | number | undefined | null>): string {
  const sp = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) {
    if (v === undefined || v === null || v === "") continue;
    sp.set(k, String(v));
  }
  const s = sp.toString();
  if (!s) return base;
  return base + (base.includes("?") ? "&" : "?") + s;
}

/** Выполняет задачи параллельно с общим дедлайном; падения игнорируются. */
export async function raceAll<T>(jobs: (() => Promise<T>)[], deadlineMs: number): Promise<T[]> {
  const out: T[] = [];
  const guard = new Promise<null>((resolve) => setTimeout(() => resolve(null), deadlineMs));
  await Promise.all(
    jobs.map(async (job) => {
      try {
        const value = await Promise.race([job(), guard]);
        if (value !== null && value !== undefined) out.push(value as T);
      } catch {
        /* источник промолчал — идём дальше */
      }
    }),
  );
  return out;
}

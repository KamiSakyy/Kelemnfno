/* Порт источников Tsuyu (ApiRepository + NativeSources + HentaiEngine).
 * Каждый адаптер отдаёт список серий с вариантами озвучки.
 * Имена источников НИКОГДА не покидают сервер. */

import { pickBest } from "./match";
import { ANIX_UA, baseHeaders, getJson, postForm, query, request } from "./net";
import {
  absolute,
  cleanLabel,
  cleanTitle,
  embed,
  numberIn,
  plain,
  plainName,
  safeUrl,
  searchTerms,
  voiceKey,
  voiceTitle,
} from "./util";

export interface VariantRow {
  /** Название озвучки (единственное, что увидит пользователь). */
  voice: string;
  /** Внутренний маршрут: прямые потоки либо ссылка плеера. */
  embed?: string;
  streams?: Record<number, string>;
  source: string;
  quality?: number;
}

export interface EpisodeRow {
  number: number;
  name?: string;
  poster?: string;
  duration?: number;
  variants: VariantRow[];
}

export interface SourceResult {
  source: string;
  episodes: EpisodeRow[];
}

export interface Lookup {
  title: string;
  original?: string;
  year?: number;
  malId?: number;
  shikimoriId?: number;
  yummyId?: number | string;
  kpId?: number;
  /** Точный псевдоним релиза в AniLibria — надёжнее матчинга по названию. */
  anilibriaAlias?: string;
}

type Json = Record<string, unknown>;

const num = (v: unknown, d = 0): number => {
  const n = typeof v === "number" ? v : parseFloat(String(v ?? ""));
  return Number.isFinite(n) ? n : d;
};
const str = (v: unknown, d = ""): string => (v === undefined || v === null ? d : String(v));

/** Ссылки-результаты поиска DLE-сайтов: относительные href + название во вложенных тегах. */
function searchLinks(html: string, base: string): { url: string; title: string }[] {
  const out: { url: string; title: string }[] = [];
  const seen = new Set<string>();
  const re = /<a[^>]+href="((?:https?:\/\/[^"]+)?\/[^"]*?\d+[^"/]*\.html)"[^>]*>([\s\S]{0,600}?)<\/a>/gi;
  for (const m of html.matchAll(re)) {
    const url = absolute(base, m[1]);
    if (!url || seen.has(url)) continue;
    const inner = plain(m[2]);
    const attr = /title="([^"]+)"/.exec(m[0])?.[1] || /alt="([^"]+)"/.exec(m[0])?.[1] || "";
    const title = (inner || plain(attr)).replace(/^[\d.,\s+]*/, "").trim();
    if (!title || title.length < 2) continue;
    seen.add(url);
    out.push({ url, title });
  }
  return out;
}

/** Shikimori ID из ссылки вида https://shikimori.one/animes/20 → 20. */
function shikiFromHref(href: string): number {
  const m = /animes\/(\d+)/.exec(href || "");
  return m ? parseInt(m[1], 10) : 0;
}

/** Строгий выбор кандидата: если уверенного совпадения нет — источник пропускается.
 * Лучше показать меньше озвучек, чем подсунуть другое аниме. */
function choose<T>(
  rows: T[] | undefined | null,
  l: Lookup,
  describe: (row: T) => { titles: (string | undefined | null)[]; year?: number; episodes?: number },
): T | null {
  return pickBest(rows, { title: l.title, original: l.original, year: l.year }, describe);
}

function push(map: Map<number, EpisodeRow>, number: number, variant: VariantRow, extra?: Partial<EpisodeRow>) {
  if (!Number.isFinite(number) || number <= 0) return;
  if (!variant.embed && !variant.streams) return;
  let row = map.get(number);
  if (!row) {
    row = { number, variants: [], ...extra };
    map.set(number, row);
  }
  const key = variant.embed || JSON.stringify(variant.streams);
  if (row.variants.some((v) => (v.embed || JSON.stringify(v.streams)) === key)) return;
  row.variants.push(variant);
}

const done = (source: string, map: Map<number, EpisodeRow>): SourceResult => ({
  source,
  episodes: [...map.values()].sort((a, b) => a.number - b.number),
});

/* ============ 1. Yummy (api.yani.tv) ============ */

export async function yummySource(l: Lookup): Promise<SourceResult> {
  const map = new Map<number, EpisodeRow>();
  let id = l.yummyId ? String(l.yummyId) : "";
  const shiki = l.shikimoriId || l.malId || 0;
  if (!id && shiki) {
    // поиск строго по shikimori_id; берём только точное совпадение id
    const found = await getJson<{ response?: Json[] }>(
      `https://api.yani.tv/anime?shikimori_ids=${shiki}&limit=20`,
      { timeout: 9000 },
    ).catch(() => ({ response: [] as Json[] }));
    const exact = (found.response || []).find(
      (r) => num((r.remote_ids as Json)?.shikimori_id) === shiki,
    );
    if (exact) id = str(exact.anime_id);
  }
  if (!id) {
    const found = await getJson<{ response?: Json[] }>(
      `https://api.yani.tv/anime?q=${encodeURIComponent(l.title)}&limit=20`,
      { timeout: 9000 },
    ).catch(() => ({ response: [] as Json[] }));
    const best = choose(found.response, l, (r) => ({
      titles: [str(r.title), ...((r.other_titles as string[]) || [])],
      year: num(r.year),
    }));
    if (best) id = str(best.anime_id);
  }
  if (!id) return done("yummy", map);

  const detail = await getJson<{ response?: Json }>(
    `https://api.yani.tv/anime/${encodeURIComponent(id)}?need_videos=true`,
    { timeout: 10_000 },
  );
  const videos = (detail.response?.videos as Json[] | undefined) || [];
  for (const v of videos) {
    const iframe = embed(str(v.iframe_url));
    if (!iframe) continue;
    const data = (v.data as Json) || {};
    const voice = voiceTitle(str(data.dubbing)) || "Оригинал";
    push(map, numberIn(str(v.number), 0), { voice, embed: iframe, source: "yummy" }, {
      name: str(v.number) ? `Серия ${str(v.number)}` : undefined,
      duration: num(v.duration),
    });
  }
  return done("yummy", map);
}

/* ============ 2. AniLibria (anilibria.top) ============ */

export async function anilibriaSource(l: Lookup): Promise<SourceResult> {
  const map = new Map<number, EpisodeRow>();
  let release: Json | null = null;
  // 1) Точный псевдоним релиза — берём напрямую, без поиска по названию.
  if (l.anilibriaAlias) {
    const byAlias = await getJson<{ data?: Json }>(
      `https://anilibria.top/api/v1/anime/releases/${encodeURIComponent(l.anilibriaAlias)}`,
      { timeout: 9000 },
    ).catch(() => ({ data: undefined }));
    if (byAlias.data && Object.keys(byAlias.data).length) release = byAlias.data;
  }
  // 2) Иначе — строгий матчинг по названию.
  if (!release) {
    for (const term of searchTerms(l.title, l.original)) {
      const data = await getJson<{ data?: Json[] }>(
        query("https://anilibria.top/api/v1/anime/catalog/releases", { limit: 12, page: 1, "f[search]": term }),
        { timeout: 9000 },
      ).catch(() => ({ data: [] as Json[] }));
      const hit = choose(data.data, l, (r) => {
        const name = (r.name as Json) || {};
        return {
          titles: [str(name.main), str(name.english), str(name.alternative)],
          year: num(r.year),
        };
      });
      if (hit) {
        release = hit;
        break;
      }
    }
  }
  if (!release) return done("anilibria", map);

  const full = await getJson<Json>(
    `https://anilibria.top/api/v1/anime/releases/${encodeURIComponent(str(release.alias) || str(release.id))}`,
    { timeout: 10_000 },
  );
  const eps = (full.episodes as Json[] | undefined) || [];
  for (const e of eps) {
    const streams: Record<number, string> = {};
    for (const [q, key] of [
      [480, "hls_480"],
      [720, "hls_720"],
      [1080, "hls_1080"],
    ] as [number, string][]) {
      const safe = safeUrl(str(e[key]));
      if (safe) streams[q] = safe;
    }
    if (!Object.keys(streams).length) continue;
    push(
      map,
      num(e.ordinal),
      { voice: "AniLibria.TV", streams, source: "anilibria", quality: Math.max(...Object.keys(streams).map(Number)) },
      { name: str(e.name) || undefined, duration: num(e.duration) },
    );
  }
  return done("anilibria", map);
}

/* ============ 3. AnimeVost ============ */

export async function animevostSource(l: Lookup): Promise<SourceResult> {
  const map = new Map<number, EpisodeRow>();
  let id = "";
  for (const term of searchTerms(l.title, l.original)) {
    const data = await postForm<{ data?: Json[] }>("https://api.animevost.org/v1/search", { name: term }, {
      timeout: 9000,
    }).catch(() => ({ data: [] as Json[] }));
    const hit = choose(data.data, l, (r) => ({
      titles: [str(r.title), ...str(r.title).split("/")],
      year: num(r.year),
    }));
    if (hit) {
      id = str(hit.id);
      break;
    }
  }
  if (!id) return done("animevost", map);

  const text = await request("https://api.animevost.org/v1/playlist", {
    method: "POST",
    form: true,
    body: `id=${encodeURIComponent(id)}`,
    timeout: 10_000,
  });
  const list = JSON.parse(text) as Json[];
  list.forEach((e, i) => {
    const streams: Record<number, string> = {};
    const std = safeUrl(str(e.std));
    const hd = safeUrl(str(e.hd));
    if (std) streams[480] = std;
    if (hd) streams[720] = hd;
    if (!Object.keys(streams).length) return;
    push(
      map,
      numberIn(str(e.name), i + 1),
      { voice: "AnimeVost", streams, source: "animevost", quality: hd ? 720 : 480 },
      { name: str(e.name) || undefined },
    );
  });
  return done("animevost", map);
}

/* ============ 4/5. AniLib + AniLib Ultra (api.cdnlibs.org) ============ */

async function animelibEpisodes(l: Lookup, ultra: boolean): Promise<SourceResult> {
  const source = ultra ? "animelib4k" : "animelib";
  const map = new Map<number, EpisodeRow>();
  let slug = "";
  for (const term of searchTerms(l.title, l.original)) {
    const data = await getJson<{ data?: Json[] }>(
      query("https://api.cdnlibs.org/api/anime", { page: 1, q: term }),
      { timeout: 9000, headers: { Accept: "application/json" } },
    ).catch(() => ({ data: [] as Json[] }));
    const rows = data.data || [];
    if (l.shikimoriId) {
      const byId = rows.find((r) => shikiFromHref(str(r.shikimori_href)) === l.shikimoriId);
      if (byId) {
        slug = str(byId.slug_url) || str(byId.slug) || str(byId.id);
        break;
      }
    }
    const hit = choose(rows, l, (r) => ({
      titles: [str(r.rus_name), str(r.name), str(r.eng_name)],
      year: num(r.releaseDate) || num(String(r.releaseDate || "").slice(0, 4)),
    }));
    if (hit) {
      slug = str(hit.slug_url) || str(hit.slug) || str(hit.id);
      break;
    }
  }
  if (!slug) return done(source, map);

  const eps = await getJson<{ data?: Json[] }>(
    `https://api.cdnlibs.org/api/episodes?anime_id=${encodeURIComponent(slug)}`,
    { timeout: 10_000, headers: { Accept: "application/json" } },
  ).catch(() => ({ data: [] as Json[] }));

  const rows = (eps.data || []).slice(0, ultra ? 60 : 40);
  await Promise.all(
    rows.map(async (e) => {
      const n = num(e.number, -1);
      if (n < 0) return;
      const detail = await getJson<{ data?: Json }>(
        `https://api.cdnlibs.org/api/episodes/${encodeURIComponent(str(e.id))}`,
        { timeout: 9000, headers: { Accept: "application/json" } },
      ).catch(() => ({ data: undefined }));
      const players = (detail.data?.players as Json[] | undefined) || [];
      for (const p of players) {
        const u = embed(str(p.src));
        if (!u) continue;
        const team = (p.team as Json) || {};
        const type = (p.translation_type as Json) || {};
        const teamName = str(team.name) || str(team.title);
        const typeName = str(type.label) || str(type.title) || "Озвучка";
        const label = cleanLabel(`${typeName} ${teamName}`.trim());
        const voice = voiceTitle(teamName) || voiceTitle(label) || (teamName ? cleanLabel(teamName) : "Озвучка");
        push(map, n, { voice, embed: u, source }, { name: str(e.name) || undefined });
      }
    }),
  );
  return done(source, map);
}

export const animelibSource = (l: Lookup) => animelibEpisodes(l, false);
export const animelib4kSource = (l: Lookup) => animelibEpisodes(l, true);

/* ============ 6. AniMedia (amd.online) — NativeSources.java ============ */

export async function animediaSource(l: Lookup): Promise<SourceResult> {
  const map = new Map<number, EpisodeRow>();
  const base = "https://amd.online";
  let page = "";
  for (const term of searchTerms(l.title, l.original)) {
    const html = await request(`${base}/index.php?do=search`, {
      method: "POST",
      form: true,
      body: `do=search&subaction=search&full_search=0&result_from=1&search_start=1&story=${encodeURIComponent(term)}`,
      headers: baseHeaders(base, base + "/"),
      timeout: 10_000,
    }).catch(() => "");
    const hit = choose(searchLinks(html, base), l, (row) => ({ titles: [row.title] }));
    if (hit) {
      page = hit.url;
      break;
    }
  }
  if (!page) return done("animedia", map);

  const html = await request(page, { headers: baseHeaders(base, base + "/"), timeout: 10_000 }).catch(() => "");
  const rows = [...html.matchAll(/data-vid="([^"]+)"[^>]*data-vlnk="([^"]+)"/gi)];
  for (const row of rows.slice(0, 120)) {
    const n = parseFloat(row[1]);
    const vod = absolute(base, row[2]);
    if (!Number.isFinite(n) || n < 1 || !vod.includes("/vod/")) continue;
    push(map, n, { voice: "AniMedia", embed: vod, source: "animedia" });
  }
  return done("animedia", map);
}

/* ============ 7. Animetka ============ */

export async function animetkaSource(l: Lookup): Promise<SourceResult> {
  const map = new Map<number, EpisodeRow>();
  const headers = {
    ...baseHeaders("https://animetka.com", "https://animetka.com/"),
    Accept: "application/json, text/plain, */*",
  };
  let material: Json | null = null;
  for (const term of searchTerms(l.title, l.original)) {
    const data = await getJson<Json>(
      query("https://animetka.com/api/anime/search", { query: term, q: term, limit: 12 }),
      { headers, timeout: 9000 },
    ).catch(() => ({}) as Json);
    const rows = ((data.data || data.results || data.items) as Json[] | undefined) || [];
    const hit = choose(rows, l, (r) => ({
      titles: [str(r.title), str(r.name), str(r.title_orig), str(r.original)],
      year: num(r.year),
    }));
    if (hit) {
      material = hit;
      break;
    }
  }
  if (!material) return done("animetka", map);

  const id = str(material.animetka_id) || str(material.id);
  const detail = await getJson<Json>(`https://animetka.com/api/anime/${encodeURIComponent(id)}`, {
    headers,
    timeout: 9000,
  }).catch(() => ({}) as Json);

  const translations =
    ((detail.translations || detail.voices || detail.dubs) as Json[] | undefined) || [];
  const total = Math.max(1, Math.min(200, num(detail.episodes_count, num(material.episodes, 0)) || 12));
  const materialId = num(detail.material_id, num(material.material_id, num(id, 0)));

  for (const t of translations.slice(0, 8)) {
    const tid = num(t.id, num(t.translation_id, 0));
    if (!tid) continue;
    const voice = voiceTitle(str(t.title) || str(t.name)) || cleanLabel(str(t.title) || str(t.name)) || "Озвучка";
    for (let ep = 1; ep <= total; ep++) {
      const url = query("https://animetka.com/api/anime/playlist", {
        material: materialId,
        translation: tid,
        episode: ep,
      });
      push(map, ep, { voice, embed: url, source: "animetka" });
    }
  }
  return done("animetka", map);
}

/* ============ 8. AniDUB (online.anidub.com) ============ */

export async function anidubSource(l: Lookup): Promise<SourceResult> {
  const map = new Map<number, EpisodeRow>();
  const base = "https://online.anidub.com";
  let page = "";
  for (const term of searchTerms(l.title, l.original)) {
    const html = await request(`${base}/index.php?do=search`, {
      method: "POST",
      form: true,
      body: `do=search&subaction=search&search_start=1&full_search=0&result_from=1&story=${encodeURIComponent(term)}`,
      headers: baseHeaders(base, base + "/"),
      timeout: 10_000,
    }).catch(() => "");
    const hit = choose(searchLinks(html, base), l, (row) => ({ titles: [row.title] }));
    if (hit) {
      page = hit.url;
      break;
    }
  }
  if (!page) return done("anidub", map);

  const html = await request(page, { headers: baseHeaders(base, base + "/"), timeout: 10_000 }).catch(() => "");
  const embedUrl = (html.match(/https?:\/\/[^"'<>\s]*?\/index\.php\?v=[^"'<>\s]+/i) || [""])[0]
    .replace(/&amp;/g, "&")
    .replace(/&playlist.*$/i, "");
  if (!embedUrl) return done("anidub", map);

  // страница плеера со списком серий: <span data="sN/hash">1 серия</span>
  const playlist = await request(`${embedUrl}&playlist`, {
    headers: baseHeaders(new URL(embedUrl).origin, base + "/"),
    timeout: 10_000,
  }).catch(() => "");
  const origin = new URL(embedUrl).origin;
  const spans = [...playlist.matchAll(/<span[^>]+data="([^"]+)"[^>]*>([\s\S]{0,60}?)<\/span>/gi)];

  if (spans.length) {
    spans.forEach((row, i) => {
      const hash = row[1].replace(/^\/+/, "");
      const label = plain(row[2]);
      const n = numberIn(label, i + 1);
      push(map, n, { voice: "AniDUB", embed: `${origin}/vid.php?v=/${hash}`, source: "anidub" }, {
        name: label || undefined,
      });
    });
  } else {
    const single = embedUrl.match(/[?&]v=\/?([^&]+)/);
    if (single) {
      push(map, 1, { voice: "AniDUB", embed: `${origin}/vid.php?v=/${single[1]}`, source: "anidub" });
    }
  }
  return done("anidub", map);
}

/* ============ 10. AnixSekai ============ */

const ANIX_BASES = ["https://api-s.anixsekai.com", "https://api.anixsekai.com"];

function anixHeaders(base: string): Record<string, string> {
  return {
    Accept: "application/json",
    "User-Agent": ANIX_UA,
    Origin: base,
    Referer: base + "/",
    "Accept-Language": "ru-RU,ru;q=0.9,en;q=0.5",
  };
}

async function anixGet(path: string): Promise<Json> {
  let last: unknown;
  for (const base of ANIX_BASES) {
    try {
      const root = JSON.parse(await request(base + path, { headers: anixHeaders(base), timeout: 9000 })) as Json;
      if (root.code !== undefined && num(root.code, 0) !== 0) throw new Error("anix code");
      return root;
    } catch (e) {
      last = e;
    }
  }
  throw last instanceof Error ? last : new Error("anix");
}

async function anixPost(path: string, body: Json): Promise<Json> {
  let last: unknown;
  for (const base of ANIX_BASES) {
    try {
      const root = JSON.parse(
        await request(base + path, {
          method: "POST",
          body: JSON.stringify(body),
          headers: anixHeaders(base),
          timeout: 9000,
        }),
      ) as Json;
      if (root.code !== undefined && num(root.code, 0) !== 0) throw new Error("anix code");
      return root;
    } catch (e) {
      last = e;
    }
  }
  throw last instanceof Error ? last : new Error("anix");
}

function firstArray(root: Json | undefined, ...keys: string[]): Json[] | null {
  if (!root) return null;
  for (const k of keys) {
    const v = root[k];
    if (Array.isArray(v)) return v as Json[];
    if (v && typeof v === "object") {
      const nested = firstArray(v as Json, "releases", "content", "data", "list", "items", "types", "sources", "episodes");
      if (nested) return nested;
    }
  }
  return null;
}

export async function anixSource(l: Lookup): Promise<SourceResult> {
  const map = new Map<number, EpisodeRow>();
  let release: Json | null = null;
  for (const term of searchTerms(l.title, l.original)) {
    // штатный поиск каталога (/filter игнорирует строку запроса)
    const root = await anixPost("/search/releases/0", { query: term, searchBy: 0 }).catch(() => null);
    const rows = root ? firstArray(root, "releases", "content", "data", "list", "items") : null;
    if (!rows?.length) continue;
    const hit = choose(rows, l, (r) => ({
      titles: [str(r.title_ru), str(r.title), str(r.title_original), str(r.title_en)],
      year: num(r.year),
    }));
    if (hit) {
      release = hit;
      break;
    }
  }
  if (!release) return done("anixsekai", map);
  const id = str(release.id) || str(release.releaseId);
  if (!id) return done("anixsekai", map);

  const types = firstArray(await anixGet(`/episode/${encodeURIComponent(id)}`).catch(() => ({})), "types", "data", "items") || [];
  const list = types
    .filter((t) => voiceTitle(str(t.name) || str(t.title)))
    .sort((a, b) => num(b.episodes_count) - num(a.episodes_count))
    .slice(0, 8);

  for (const type of list) {
    const voice = voiceTitle(str(type.name) || str(type.title));
    const typeId = num(type.id, 0);
    if (!typeId) continue;
    const sources = firstArray(
      await anixGet(`/episode/${encodeURIComponent(id)}/${typeId}`).catch(() => ({})),
      "sources",
      "data",
      "items",
    );
    if (!sources?.length) continue;
    // Kodik исключён: сначала любой не-Kodik маршрут, иначе первый доступный
    const chosen =
      sources.find((s) => num(s.id) !== 12 && !(str(s.name) + str(s.title)).toLowerCase().includes("kodik")) ||
      sources[0];
    const sourceId = num(chosen.id, 0);
    if (!sourceId) continue;
    const eps = firstArray(
      await anixGet(`/episode/${encodeURIComponent(id)}/${typeId}/${sourceId}`).catch(() => ({})),
      "episodes",
      "data",
      "items",
    );
    (eps || []).forEach((e, i) => {
      const u = embed(str(e.url) || str(e.link) || str(e.iframe_url));
      if (!u) return;
      const n = num(e.position, num(e.episode, num(e.number, i + 1)));
      push(map, n > 0 ? n : i + 1, { voice, embed: u, source: "anixsekai" }, {
        name: str(e.title) || str(e.name) || undefined,
        duration: num(e.duration),
      });
    });
  }
  return done("anixsekai", map);
}

/* ============ 11. Hanime / Tsuyu H (18+, включается только для хентая) ============ */

export async function hanimeSource(l: Lookup): Promise<SourceResult> {
  const map = new Map<number, EpisodeRow>();
  const body = {
    search_text: l.title,
    tags: [],
    tags_mode: "AND",
    brands: [],
    blacklist: [],
    order_by: "created_at_unix",
    ordering: "desc",
    page: 0,
  };
  const root = await request("https://search.htv-services.com/", {
    method: "POST",
    body: JSON.stringify(body),
    headers: { ...baseHeaders("https://hanime.tv", "https://hanime.tv/"), Accept: "application/json" },
    timeout: 9000,
  }).catch(() => "");
  if (!root) return done("hanime", map);
  let hits: Json[] = [];
  try {
    const parsed = JSON.parse(root) as { hits?: string };
    hits = parsed.hits ? (JSON.parse(parsed.hits) as Json[]) : [];
  } catch {
    return done("hanime", map);
  }
  const best = choose(hits, l, (h) => ({ titles: [str(h.name), str(h.titles)] }));
  if (!best) return done("hanime", map);
  const slug = str(best.slug);
  if (!slug) return done("hanime", map);

  const detail = await getJson<Json>(`https://hanime.tv/api/v8/video?id=${encodeURIComponent(slug)}`, {
    headers: baseHeaders("https://hanime.tv", "https://hanime.tv/"),
    timeout: 9000,
  }).catch(() => ({}) as Json);
  const servers = ((detail.videos_manifest as Json)?.servers as Json[] | undefined) || [];
  const streams: Record<number, string> = {};
  for (const s of servers) {
    for (const st of (s.streams as Json[] | undefined) || []) {
      const u = safeUrl(str(st.url));
      if (!u) continue;
      streams[num(st.height, num(st.width, 720))] = u;
    }
  }
  if (Object.keys(streams).length) push(map, 1, { voice: "Оригинал", streams, source: "hanime" });
  return done("hanime", map);
}

/* ============ Реестр ============ */

export const SOURCES: { id: string; run: (l: Lookup) => Promise<SourceResult>; adult?: boolean }[] = [
  { id: "yummy", run: yummySource },
  { id: "anilibria", run: anilibriaSource },
  { id: "anixsekai", run: anixSource },
  { id: "animevost", run: animevostSource },
  { id: "animelib", run: animelibSource },
  { id: "animelib4k", run: animelib4kSource },
  { id: "animedia", run: animediaSource },
  { id: "animetka", run: animetkaSource },
  { id: "anidub", run: anidubSource },
  { id: "hanime", run: hanimeSource, adult: true },
];

/** Базовые веса SourceEngine.BASE — для умного объединения. */
export const SOURCE_BASE: Record<string, number> = {
  yoru: 106,
  yummy: 100,
  anilibria: 94,
  anixsekai: 90,
  animevost: 88,
  animelib4k: 84,
  animelib: 80,
  animedia: 72,
  animetka: 66,
  anidub: 64,
  kodik: 58,
  hanime: 40,
};

export { cleanTitle, voiceKey };

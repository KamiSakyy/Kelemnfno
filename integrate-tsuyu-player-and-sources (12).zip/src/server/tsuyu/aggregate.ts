/* Умное автоматическое объединение всех источников Tsuyu в дорожки озвучки.
 * Наружу уходит только название озвучки — сами источники остаются секретом. */

import crypto from "node:crypto";
import { and, eq, lt, sql } from "drizzle-orm";
import { db } from "@/db";
import { tsuyuSourceStats, tsuyuTracks, type StoredRoute } from "@/db/schema";
import { SOURCES, SOURCE_BASE, type EpisodeRow, type Lookup, type SourceResult } from "./sources";
import { voiceKey, voiceTitle } from "./util";

export interface PublicTrack {
  /** Непрозрачный идентификатор дорожки. */
  id: string;
  /** Название озвучки — единственное, что видит пользователь. */
  voice: string;
  episodes: number[];
  total: number;
  maxQuality: number;
}

const TRACK_TTL_MS = 45 * 60 * 1000;

/** Источники, матчащие аниме по точному ID (Shikimori / Yummy) — их маршруты
 *  гарантированно принадлежат нужному тайтлу, поэтому резолвим их первыми. */
const ID_SOURCES = new Set(["yummy", "anilibria", "animelib", "animelib4k"]);

export function lookupKeyOf(l: Lookup): string {
  return crypto
    .createHash("sha1")
    .update(`${l.malId || 0}|${l.shikimoriId || 0}|${l.yummyId || ""}|${(l.title || "").toLowerCase()}`)
    .digest("hex");
}

async function stats(): Promise<Record<string, { ok: number; fail: number; avgMs: number; lastBad: number; failRun: number }>> {
  try {
    const rows = await db.select().from(tsuyuSourceStats);
    const out: Record<string, { ok: number; fail: number; avgMs: number; lastBad: number; failRun: number }> = {};
    for (const r of rows) out[r.source] = { ok: r.ok, fail: r.fail, avgMs: r.avgMs, lastBad: Number(r.lastBad), failRun: r.failRun };
    return out;
  } catch {
    return {};
  }
}

export async function noteSource(source: string, ok: boolean, ms: number) {
  try {
    await db
      .insert(tsuyuSourceStats)
      .values({
        source,
        ok: ok ? 1 : 0,
        fail: ok ? 0 : 1,
        avgMs: ms,
        lastOk: ok ? Date.now() : 0,
        lastBad: ok ? 0 : Date.now(),
        failRun: ok ? 0 : 1,
      })
      .onConflictDoUpdate({
        target: tsuyuSourceStats.source,
        set: {
          ok: sql`${tsuyuSourceStats.ok} + ${ok ? 1 : 0}`,
          fail: sql`${tsuyuSourceStats.fail} + ${ok ? 0 : 1}`,
          avgMs: sql`(${tsuyuSourceStats.avgMs} + ${ms}) / 2`,
          lastOk: ok ? sql`${Date.now()}` : tsuyuSourceStats.lastOk,
          lastBad: ok ? tsuyuSourceStats.lastBad : sql`${Date.now()}`,
          failRun: ok ? sql`0` : sql`${tsuyuSourceStats.failRun} + 1`,
        },
      });
  } catch {
    /* статистика не критична */
  }
}

/** Порт SourceEngine.score — чем выше, тем раньше используем источник. */
function scoreOf(
  source: string,
  snapshot: Record<string, { ok: number; fail: number; avgMs: number; lastBad: number; failRun: number }>,
): number {
  let v = SOURCE_BASE[source] ?? 45;
  const row = snapshot[source];
  if (row) {
    const total = row.ok + row.fail;
    if (total > 0) v += Math.floor((row.ok * 46) / Math.max(1, total)) - Math.min(42, row.fail * 7);
    if (row.avgMs > 0) v -= Math.min(30, Math.floor(row.avgMs / 850));
    if (row.lastBad > Date.now() - 20 * 60 * 1000) v -= 24;
    if (row.failRun >= 2) v -= Math.min(76, row.failRun * 19);
    if (total >= 5 && row.fail > row.ok) v -= Math.min(52, (row.fail - row.ok) * 9);
    if (total >= 3 && row.ok > row.fail) v += Math.min(24, (row.ok - row.fail) * 6);
  }
  return v;
}

interface Bucket {
  voice: string;
  voiceKey: string;
  routes: StoredRoute[];
  episodes: Set<number>;
  score: number;
  maxQuality: number;
  /** сколько серий дал каждый источник — нужен «основной» источник дорожки */
  perSource: Map<string, Set<number>>;
}

/** Плеер Kodik удалён из интерфейса: такие embed'ы остаются лишь невидимым
 * запасным маршрутом, который сервер сам превращает в прямой поток. */
const KODIK_ROUTE = /kodik|aniqit|kodikplayer/i;

function mergeInto(buckets: Map<string, Bucket>, result: SourceResult, score: number) {
  for (const ep of result.episodes) {
    for (const v of ep.variants) {
      const rawVoice = v.voice || "Оригинал";
      const key = voiceKey(rawVoice) || `src:${result.source}`;
      const title = voiceTitle(rawVoice) || rawVoice || "Оригинал";
      let bucket = buckets.get(key);
      if (!bucket) {
        bucket = {
          voice: title,
          voiceKey: key,
          routes: [],
          episodes: new Set(),
          score: 0,
          maxQuality: 0,
          perSource: new Map(),
        };
        buckets.set(key, bucket);
      }
      let owned = bucket.perSource.get(result.source);
      if (!owned) {
        owned = new Set<number>();
        bucket.perSource.set(result.source, owned);
      }
      owned.add(ep.number);
      bucket.score = Math.max(bucket.score, score);
      const streams = v.streams
        ? Object.fromEntries(Object.entries(v.streams).map(([q, u]) => [String(q), u]))
        : undefined;
      if (streams) {
        const best = Math.max(...Object.keys(streams).map(Number));
        if (Number.isFinite(best)) bucket.maxQuality = Math.max(bucket.maxQuality, best);
      }
      bucket.routes.push({
        episode: ep.number,
        source: result.source,
        embed: v.embed,
        streams,
        name: ep.name,
        duration: ep.duration,
      });
      bucket.episodes.add(ep.number);
    }
  }
}

function dedupeEpisodes(rows: EpisodeRow[]): EpisodeRow[] {
  return rows;
}

export async function collectTracks(lookup: Lookup, adult = false): Promise<PublicTrack[]> {
  const key = lookupKeyOf(lookup);

  // Свежий результат из кэша
  try {
    const cached = await db
      .select()
      .from(tsuyuTracks)
      .where(and(eq(tsuyuTracks.lookupKey, key), sql`${tsuyuTracks.createdAt} > now() - interval '45 minutes'`));
    if (cached.length) {
      return cached
        .sort((a, b) => b.score - a.score || b.episodes.length - a.episodes.length)
        .map((r) => ({
          id: r.id,
          voice: r.voice,
          episodes: r.episodes,
          total: r.episodes.length,
          maxQuality: 0,
        }));
    }
  } catch {
    /* БД может быть ещё не готова — продолжаем без кэша */
  }

  const snapshot = await stats();
  const pool = SOURCES.filter((s) => (adult ? true : !s.adult)).sort(
    (a, b) => scoreOf(b.id, snapshot) - scoreOf(a.id, snapshot),
  );

  const buckets = new Map<string, Bucket>();
  const deadline = new Promise<null>((r) => setTimeout(() => r(null), 16_000));

  await Promise.all(
    pool.map(async (s) => {
      const started = Date.now();
      try {
        const res = (await Promise.race([s.run(lookup), deadline])) as SourceResult | null;
        if (!res || !res.episodes.length) {
          await noteSource(s.id, false, Date.now() - started);
          return;
        }
        res.episodes = dedupeEpisodes(res.episodes);
        mergeInto(buckets, res, scoreOf(s.id, snapshot));
        await noteSource(s.id, true, Date.now() - started);
      } catch {
        await noteSource(s.id, false, Date.now() - started);
      }
    }),
  );

  const list = [...buckets.values()]
    .filter((b) => b.routes.length)
    .sort((a, b) => b.episodes.size - a.episodes.size || b.score - a.score);

  const tracks: PublicTrack[] = [];
  const rows = list.map((b) => {
    const id = crypto.randomBytes(12).toString("base64url");
    const episodes = [...b.episodes].sort((x, y) => x - y);

    /* Основной источник дорожки. Приоритет у источников с точным ID
     * (гарантированно верное аниме), затем — тот, что дал больше серий.
     * Благодаря этому чужое аниме из неточного матчинга играет никогда не
     * раньше, чем верный вариант. */
    let primary = "";
    let primaryCount = -1;
    for (const [source, eps] of b.perSource) {
      const weight = (ID_SOURCES.has(source) ? 1_000_000 : 0) + eps.size * 1000 + (SOURCE_BASE[source] ?? 45);
      if (weight > primaryCount) {
        primaryCount = weight;
        primary = source;
      }
    }

    b.routes.sort(
      (x, y) =>
        (ID_SOURCES.has(y.source) ? 1 : 0) - (ID_SOURCES.has(x.source) ? 1 : 0) ||
        (y.source === primary ? 1 : 0) - (x.source === primary ? 1 : 0) ||
        (y.streams ? 1 : 0) - (x.streams ? 1 : 0) ||
        (SOURCE_BASE[y.source] ?? 45) - (SOURCE_BASE[x.source] ?? 45),
    );
    tracks.push({ id, voice: b.voice, episodes, total: episodes.length, maxQuality: b.maxQuality });
    return {
      id,
      lookupKey: key,
      voice: b.voice,
      voiceKey: b.voiceKey,
      episodes,
      routes: b.routes.slice(0, 4000),
      score: b.score,
    };
  });

  if (rows.length) {
    try {
      await db.delete(tsuyuTracks).where(eq(tsuyuTracks.lookupKey, key));
      await db.insert(tsuyuTracks).values(rows);
      await db.delete(tsuyuTracks).where(lt(tsuyuTracks.createdAt, new Date(Date.now() - 6 * TRACK_TTL_MS)));
    } catch {
      /* без БД дорожки будут пересобираться при каждом запросе */
    }
  }

  return tracks;
}

/** Сортирует маршруты серии так, чтобы первыми шли самые надёжные.
 * Учитывает живую статистику источников и наличие прямых потоков. */
export async function rankRoutes(routes: StoredRoute[]): Promise<StoredRoute[]> {
  let rows: { source: string; ok: number; fail: number; avgMs: number; lastBad: bigint | number; failRun: number }[] = [];
  try {
    rows = await db.select().from(tsuyuSourceStats);
  } catch {
    rows = [];
  }
  const map = new Map(rows.map((r) => [r.source, r]));

  const score = (r: StoredRoute) => {
    let v = SOURCE_BASE[r.source] ?? 45;
    // прямой поток надёжнее и быстрее, чем разбор страницы плеера
    if (r.streams && Object.keys(r.streams).length) v += 28;
    // запасной маршрут, который в интерфейсе больше не показывается
    if (r.embed && KODIK_ROUTE.test(r.embed)) v -= 70;
    const s = map.get(r.source);
    if (s) {
      const total = s.ok + s.fail;
      if (total > 0) v += Math.floor((s.ok * 40) / Math.max(1, total)) - Math.min(40, s.fail * 6);
      if (s.avgMs > 0) v -= Math.min(25, Math.floor(s.avgMs / 900));
      if (Number(s.lastBad) > Date.now() - 15 * 60 * 1000) v -= 20;
      if (s.failRun >= 2) v -= Math.min(60, s.failRun * 15);
    }
    return v;
  };

  return [...routes].sort((a, b) => score(b) - score(a));
}

export async function trackById(id: string) {
  try {
    const rows = await db.select().from(tsuyuTracks).where(eq(tsuyuTracks.id, id)).limit(1);
    return rows[0] || null;
  } catch {
    return null;
  }
}

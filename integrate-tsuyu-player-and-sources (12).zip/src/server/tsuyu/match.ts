/* Строгое сопоставление аниме между источниками.
 * Раньше при неточном поиске брался первый результат — из-за этого в дорожку
 * озвучки могло попасть ЧУЖОЕ аниме. Теперь кандидат принимается только при
 * совпадении названия, сезона и года. */

const STOP = new Set([
  "tv",
  "тв",
  "the",
  "a",
  "an",
  "of",
  "and",
  "и",
  "season",
  "сезон",
  "part",
  "часть",
  "cour",
  "аниме",
  "anime",
  "смотреть",
  "онлайн",
  "series",
  "серия",
  "серии",
  "movie",
  "фильм",
  "ova",
  "ona",
  "special",
  "спешл",
  "dub",
  "sub",
  "русская",
  "озвучка",
]);

const ROMAN: Record<string, number> = {
  i: 1,
  ii: 2,
  iii: 3,
  iv: 4,
  v: 5,
  vi: 6,
  vii: 7,
  viii: 8,
  ix: 9,
  x: 10,
};

export function normTitle(raw?: string | null): string {
  return (raw || "")
    .toLowerCase()
    .replace(/ё/g, "е")
    .replace(/[^\p{L}\p{N}]+/gu, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function tokensOf(raw: string): string[] {
  return normTitle(raw)
    .split(" ")
    .filter((t) => t.length > 1 && !STOP.has(t));
}

/** Номер сезона из названия. null = не указан явно (базовый тайтл), иначе 0..N.
 *  «Магическая битва» → null, «Магическая битва 0» → 0, «Атака титанов 2» → 2. */
export function seasonOf(raw?: string | null): number | null {
  const v = normTitle(raw);
  if (!v) return null;
  let m = v.match(/(\d{1,2})\s*(?:й|ый|ой|я|ая)?\s*сезон/);
  if (m) return parseInt(m[1], 10);
  m = v.match(/сезон\s*(\d{1,2})/);
  if (m) return parseInt(m[1], 10);
  m = v.match(/season\s*(\d{1,2})/);
  if (m) return parseInt(m[1], 10);
  m = v.match(/(\d{1,2})\s*(?:st|nd|rd|th)\s*season/);
  if (m) return parseInt(m[1], 10);
  m = v.match(/(?:^|\s)s(\d{1,2})(?:\s|$)/);
  if (m) return parseInt(m[1], 10);
  m = v.match(/(\d{1,2})\s*(?:й|ая)?\s*часть/);
  if (m) return parseInt(m[1], 10);
  const words = v.split(" ");
  const last = words[words.length - 1];
  if (last && ROMAN[last]) return ROMAN[last];
  if (last && /^[0-9]{1,2}$/.test(last)) return parseInt(last, 10);
  return null;
}

/** Сезон по набору названий: максимум явных, null если явных нет. */
function seasonOfList(list: string[]): number | null {
  let best: number | null = null;
  for (const t of list) {
    const s = seasonOf(t);
    if (s !== null && (best === null || s > best)) best = s;
  }
  return best;
}

function levenshtein(a: string, b: string): number {
  if (a === b) return 0;
  if (!a.length) return b.length;
  if (!b.length) return a.length;
  let prev = Array.from({ length: b.length + 1 }, (_v, i) => i);
  for (let i = 1; i <= a.length; i++) {
    const row = [i];
    for (let j = 1; j <= b.length; j++) {
      row[j] = Math.min(prev[j] + 1, row[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
    }
    prev = row;
  }
  return prev[b.length];
}

function ratio(a: string, b: string): number {
  const max = Math.max(a.length, b.length);
  if (!max) return 0;
  return 1 - levenshtein(a, b) / max;
}

/** Похожесть двух названий: 0..1.
 *  Осознанно консервативная: лучше пропустить дорожку, чем подменить аниме. */
export function similarity(a: string, b: string): number {
  const na = normTitle(a);
  const nb = normTitle(b);
  if (!na || !nb) return 0;
  if (na === nb) return 1;
  const A = new Set(tokensOf(a));
  const B = new Set(tokensOf(b));
  if (!A.size || !B.size) return 0;
  let inter = 0;
  for (const t of A) if (B.has(t)) inter++;
  const union = new Set([...A, ...B]).size;
  const jaccard = inter / union;
  const contain = inter / Math.min(A.size, B.size);
  const tokenScore = jaccard * 0.5 + contain * 0.5;
  // Levenshtein-похожесть учитываем лишь при общих токенах — иначе короткие
  // созвучные, но разные названия («битва»/«битва ангелов») дают ложное совпадение.
  const ratioScore = inter >= 1 ? ratio(na, nb) : ratio(na, nb) * 0.35;
  return Math.max(tokenScore, ratioScore);
}

export interface MatchTarget {
  title: string;
  original?: string;
  year?: number;
}

export interface Candidate {
  titles: (string | undefined | null)[];
  year?: number;
  episodes?: number;
}

export const ACCEPT = 0.8;

/** Оценка кандидата относительно искомого аниме. 0 = точно не оно. */
export function matchScore(candidate: Candidate, target: MatchTarget): number {
  const candTitles = candidate.titles.filter((t): t is string => !!t && t.trim().length > 1);
  if (!candTitles.length) return 0;
  const wanted = [target.title, target.original].filter((t): t is string => !!t && t.trim().length > 1);
  if (!wanted.length) return 0;

  // Сезон/часть: «Атака титанов» ≠ «Атака титанов 2», «Магическая битва» ≠ «Магическая битва 0»
  const candSeason = seasonOfList(candTitles);
  const wantSeason = seasonOfList(wanted);
  if (candSeason !== wantSeason) return 0;

  let best = 0;
  for (const c of candTitles) {
    for (const w of wanted) {
      const s = similarity(c, w);
      if (s > best) best = s;
    }
  }
  if (best <= 0) return 0;

  // Год: расхождение больше года — почти наверняка другое произведение
  if (candidate.year && target.year) {
    const diff = Math.abs(candidate.year - target.year);
    if (diff >= 3) return 0;
    if (diff === 2) best *= 0.7;
    else if (diff === 1) best *= 0.92;
  }

  return best;
}

/** Выбирает уверенного кандидата либо null (лучше ничего, чем чужое аниме). */
export function pickBest<T>(
  rows: T[] | undefined | null,
  target: MatchTarget,
  describe: (row: T) => Candidate,
): T | null {
  let best: T | null = null;
  let bestScore = 0;
  for (const row of rows || []) {
    const score = matchScore(describe(row), target);
    if (score > bestScore) {
      bestScore = score;
      best = row;
    }
  }
  return bestScore >= ACCEPT ? best : null;
}

'use client';
import { absUrl, type VideoItem } from '../api/yummy';
import { resolveViaServer } from './tsuyu';

/* ============================================================
 * Скачивание серий: достаём прямую ссылку (m3u8/mp4) из плеера
 * и скачиваем поток сегменты-за-сегментом в один файл.
 * ============================================================ */

const PROXIES: ((u: string) => string)[] = [
  (u) => `https://corsproxy.io/?url=${encodeURIComponent(u)}`,
  (u) => `https://api.allorigins.win/raw?url=${encodeURIComponent(u)}`,
  (u) => `https://api.codetabs.com/v1/proxy?quest=${encodeURIComponent(u)}`,
];

const M3U8_RE = /https?:\/\/[^"'\s\\]+?\.m3u8[^"'\s\\]*/;
const MP4_RE = /https?:\/\/[^"'\s\\]+?\.mp4[^"'\s\\]*/;

async function fetchTextSmart(url: string, timeoutMs = 9000): Promise<string> {
  const attempt = async (target: string) => {
    const c = new AbortController();
    const t = window.setTimeout(() => c.abort(), timeoutMs);
    try {
      const r = await fetch(target, { signal: c.signal });
      if (r.ok) {
        const text = await r.text();
        if (text) return text;
      }
    } finally {
      window.clearTimeout(t);
    }
    throw new Error('fail');
  };
  try {
    return await attempt(url);
  } catch {
    /* continue */
  }
  for (const p of PROXIES) {
    try {
      return await attempt(p(url));
    } catch {
      /* next */
    }
  }
  throw new Error('unreachable');
}

function findMediaUrl(text: string): { url: string; kind: 'm3u8' | 'mp4' } | null {
  let m = text.match(M3U8_RE);
  if (m) return { url: m[0].replace(/\\\//g, '/').replace(/&amp;/g, '&'), kind: 'm3u8' };
  m = text.match(MP4_RE);
  if (m) return { url: m[0].replace(/\\\//g, '/').replace(/&amp;/g, '&'), kind: 'mp4' };
  return null;
}

export interface DownloadSource {
  url: string;
  kind: 'm3u8' | 'mp4';
  quality: string;
  source: string; // Kodik / Alloha / Sibnet
}

const QUALITY_RE = /\/(1080p|720p|480p|360p)\//i;

/** Прямой поток для скачивания. Распознаёт сервер — клиент адреса источников не видит. */
export async function resolveDownloadSource(v: VideoItem, quality?: string): Promise<DownloadSource> {
  const url = absUrl(v.iframe_url);
  if (!url) throw new Error('Нет ссылки на видео');

  const sources = await resolveViaServer(url);
  if (!sources.length) throw new Error('Прямой поток не найден');

  const wanted = (quality || '').toLowerCase().replace(/[^0-9]/g, '');
  const pick =
    (wanted ? sources.find((s) => String(s.quality) === wanted) : undefined) ||
    sources.find((s) => s.quality === 720) ||
    sources[0];

  return {
    url: pick.url,
    kind: /\.mp4/i.test(pick.url) ? 'mp4' : 'm3u8',
    quality: pick.quality ? `${pick.quality}p` : '—',
    source: 'Player',
  };
}

/* ---------- HLS-загрузка ---------- */

export interface DlProgress {
  percent: number;
  loadedBytes: number;
  segments: number;
  totalSegments: number;
}

interface CancelRef {
  cancel: boolean;
}

async function fetchBytes(url: string, cancel: CancelRef): Promise<ArrayBuffer> {
  if (cancel.cancel) throw new Error('cancelled');
  const attempt = async (target: string) => {
    const r = await fetch(target);
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return await r.arrayBuffer();
  };
  try {
    return await attempt(url);
  } catch {
    /* direct failed */
  }
  for (const p of PROXIES) {
    try {
      return await attempt(p(url));
    } catch {
      /* next */
    }
  }
  throw new Error('segment: ' + url);
}

export async function downloadHls(
  sourceUrl: string,
  filename: string,
  onProgress: (p: DlProgress) => void,
  cancelRef: CancelRef,
) {
  // 1. Получаем плейлист
  let listText: string;
  let playlistUrl = toAbsolute(sourceUrl);
  if (sourceUrl.toLowerCase().endsWith('.mp4') || sourceUrl.includes('.mp4?')) {
    // Прямой mp4 — просто скачиваем целиком
    const buf = await fetchBytes(sourceUrl, cancelRef);
    saveBlob(new Blob([buf], { type: 'video/mp4' }), filename);
    onProgress({ percent: 100, loadedBytes: buf.byteLength, segments: 1, totalSegments: 1 });
    return;
  }

  listText = await fetchTextSmart(sourceUrl);
  if (listText.includes('#EXT-X-STREAM-INF')) {
    // мастер-плейлист: берём последний вариант (обычно максимальное качество)
    const urls = listText.split('\n').map((l) => l.trim()).filter((l) => l && !l.startsWith('#'));
    if (urls.length) {
      playlistUrl = new URL(urls[urls.length - 1], sourceUrl).href;
      listText = await fetchTextSmart(playlistUrl);
    }
  }
  if (/#EXT-X-KEY/.test(listText) && /METHOD=AES/i.test(listText)) {
    throw new Error('Поток зашифрован — скачивание невозможно');
  }

  const segments: string[] = [];
  for (const raw of listText.split('\n')) {
    const l = raw.trim();
    if (l && !l.startsWith('#')) segments.push(new URL(l, playlistUrl).href);
  }
  if (!segments.length) throw new Error('В плейлисте нет сегментов');

  // 2. Скачиваем сегменты пулом из 6 параллельных запросов
  const chunks: ArrayBuffer[] = new Array(segments.length);
  let done = 0;
  let loadedBytes = 0;
  let idx = 0;
  const CONCURRENCY = 6;

  const worker = async () => {
    while (true) {
      if (cancelRef.cancel) throw new Error('cancelled');
      const i = idx++;
      if (i >= segments.length) return;
      const buf = await fetchBytes(segments[i], cancelRef);
      chunks[i] = buf;
      done++;
      loadedBytes += buf.byteLength;
      onProgress({ percent: Math.round((done / segments.length) * 100), loadedBytes, segments: done, totalSegments: segments.length });
    }
  };

  await Promise.all(Array.from({ length: Math.min(CONCURRENCY, segments.length) }, worker));

  // 3. Собираем файл
  if (cancelRef.cancel) throw new Error('cancelled');
  const blob = new Blob(chunks as BlobPart[], { type: 'video/mp2t' });
  saveBlob(blob, filename);
}

/** Наш прокси отдаёт относительные пути — приводим их к абсолютным. */
function toAbsolute(u: string) {
  if (/^https?:/i.test(u)) return u;
  if (typeof window === 'undefined') return u;
  try {
    return new URL(u, window.location.origin).href;
  } catch {
    return u;
  }
}

function saveBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 60000);
}

export function sanitizeFilename(name: string) {
  return name.replace(/[\\/:*?"<>|]+/g, '').replace(/\s+/g, ' ').trim().slice(0, 120) || 'video';
}

export function episodeTag(number: string) {
  return `E${String(number).padStart(2, '0').replace(/[^0-9A-Za-z]/g, '_')}`;
}

'use client';

/* Клиентский мост к движку подбора.
 * Наружу приходят ТОЛЬКО названия озвучек и готовые ссылки на поток —
 * какие источники за этим стоят, знает только сервер. */

export interface TsuyuTrack {
  id: string;
  voice: string;
  episodes: number[];
  total: number;
  maxQuality: number;
}

export interface TsuyuLookup {
  title: string;
  original?: string;
  year?: number;
  malId?: number;
  shikimoriId?: number;
  yummyId?: number | string;
  kpId?: number;
  anilibriaAlias?: string;
  genres?: string[];
}

export interface TsuyuStreamSource {
  quality: number;
  url: string;
  /** hls — нужен hls.js, mp4 — играет напрямую */
  kind?: 'hls' | 'mp4';
}

const trackCache = new Map<string, TsuyuTrack[]>();
const streamCache = new Map<string, TsuyuStreamSource[]>();
/** id дорожки → озвучка и запрос: нужно, чтобы повторить подбор после сбоя */
const trackMeta = new Map<string, { voice: string; lookup: TsuyuLookup }>();
const inflight = new Map<string, Promise<TsuyuTrack[]>>();

function keyOf(l: TsuyuLookup) {
  return `${l.malId || 0}|${l.shikimoriId || 0}|${l.yummyId || ''}|${l.title}`;
}

export async function fetchTsuyuTracks(
  lookup: TsuyuLookup,
  signal?: AbortSignal,
  force = false,
): Promise<TsuyuTrack[]> {
  const key = keyOf(lookup);
  if (!force) {
    const hit = trackCache.get(key);
    if (hit) return hit;
    // параллельные вызовы одной карточки не должны дублировать тяжёлый запрос
    const pending = inflight.get(key);
    if (pending) return pending;
  }

  const job = (async () => {
    const res = await fetch('/api/tsuyu/tracks', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(lookup),
      signal,
    });
    if (!res.ok) throw new Error('tracks failed');
    const json = (await res.json()) as { tracks?: TsuyuTrack[] };
    const tracks = json.tracks || [];
    trackCache.set(key, tracks);
    for (const t of tracks) trackMeta.set(t.id, { voice: t.voice, lookup });
    return tracks;
  })();

  inflight.set(key, job);
  try {
    return await job;
  } finally {
    inflight.delete(key);
  }
}

async function requestStream(track: string, episode: number): Promise<{ sources: TsuyuStreamSource[]; stale: boolean }> {
  const res = await fetch('/api/tsuyu/stream', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ track, episode }),
  });
  const json = (await res.json().catch(() => ({}))) as {
    sources?: TsuyuStreamSource[];
    stale?: boolean;
    error?: string;
  };
  if (!res.ok || !json.sources?.length) {
    return { sources: [], stale: !!json.stale };
  }
  return { sources: json.sources, stale: false };
}

/** Поток серии. Если маршруты устарели — пересобираем дорожки и пробуем ещё раз. */
export async function fetchTsuyuStream(track: string, episode: number, retried = false): Promise<TsuyuStreamSource[]> {
  const key = `${track}:${episode}`;
  const hit = streamCache.get(key);
  if (hit) return hit;

  const first = await requestStream(track, episode);
  if (first.sources.length) {
    streamCache.set(key, first.sources);
    return first.sources;
  }

  if (first.stale && !retried) {
    const meta = trackMeta.get(track);
    trackCache.clear();
    streamCache.clear();
    const staleMeta = [...trackMeta.entries()];
    trackMeta.clear();
    if (meta) {
      const tracks = await fetchTsuyuTracks(meta.lookup, undefined, true).catch(() => [] as TsuyuTrack[]);
      const same = tracks.find((t) => t.voice === meta.voice) || tracks[0];
      if (same) return fetchTsuyuStream(same.id, episode, true);
    } else if (staleMeta.length) {
      // мета потеряна, но запрос известен — повторяем подбор с новым id
      const any = staleMeta[0][1];
      const tracks = await fetchTsuyuTracks(any.lookup, undefined, true).catch(() => [] as TsuyuTrack[]);
      if (tracks[0]) return fetchTsuyuStream(tracks[0].id, episode, true);
    }
  }

  throw new Error('stream failed');
}

/** Серверное распознавание обычного варианта каталога. */
export async function resolveViaServer(url: string): Promise<TsuyuStreamSource[]> {
  const hit = streamCache.get(url);
  if (hit) return hit;
  const res = await fetch('/api/tsuyu/resolve', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ url }),
  });
  if (!res.ok) throw new Error('resolve failed');
  const json = (await res.json()) as { sources?: TsuyuStreamSource[] };
  const sources = json.sources || [];
  if (!sources.length) throw new Error('resolve empty');
  streamCache.set(url, sources);
  return sources;
}

export const TSUYU_PREFIX = 'tsuyu:';

export function isTsuyuRef(url: string | undefined | null): boolean {
  return !!url && url.startsWith(TSUYU_PREFIX);
}

export function parseTsuyuRef(url: string): { track: string; episode: number } | null {
  if (!isTsuyuRef(url)) return null;
  const rest = url.slice(TSUYU_PREFIX.length);
  const idx = rest.lastIndexOf(':');
  if (idx < 0) return null;
  const track = rest.slice(0, idx);
  const episode = Number(rest.slice(idx + 1));
  if (!track || !Number.isFinite(episode)) return null;
  return { track, episode };
}

export function makeTsuyuRef(track: string, episode: number): string {
  return `${TSUYU_PREFIX}${track}:${episode}`;
}

'use client';
import { useEffect, useState } from 'react';

/** Точный отсчёт: «через 1 час 17 минут», «через 2 дня 4 часа» */
export function formatCountdown(targetTs: number, nowMs: number = Date.now()): string {
  const diff = targetTs - nowMs;
  if (diff <= 0) return 'прямо сейчас';
  const m = Math.floor(diff / 60000);
  if (m < 1) return 'менее минуты';
  if (m < 60) return `через ${m} мин`;
  const h = Math.floor(m / 60);
  const rm = m % 60;
  if (h < 24) return rm > 0 ? `через ${h} ч ${rm} мин` : `через ${h} ч`;
  const d = Math.floor(h / 24);
  const rh = h % 24;
  return rh > 0 ? `через ${d} д ${rh} ч` : `через ${d} д`;
}

export function fmtDateTime(ts: number) {
  const d = new Date(ts);
  return `${d.toLocaleDateString('ru-RU', { weekday: 'short', day: 'numeric', month: 'short' })}, ${d.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })}`;
}

/** Тикающее «сейчас» для живых отсчётов */
export function useNow(intervalMs = 30000) {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const id = window.setInterval(() => setNow(Date.now()), intervalMs);
    return () => window.clearInterval(id);
  }, [intervalMs]);
  return now;
}

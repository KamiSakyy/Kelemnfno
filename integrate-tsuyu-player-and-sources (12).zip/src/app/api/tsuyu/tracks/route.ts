import { NextResponse } from "next/server";
import { collectTracks } from "@/server/tsuyu/aggregate";
import type { Lookup } from "@/server/tsuyu/sources";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 60;

interface Body extends Lookup {
  genres?: string[];
}

export async function POST(req: Request) {
  let body: Body;
  try {
    body = (await req.json()) as Body;
  } catch {
    return NextResponse.json({ error: "bad request" }, { status: 400 });
  }
  if (!body?.title || typeof body.title !== "string") {
    return NextResponse.json({ error: "title required" }, { status: 400 });
  }

  const adult = (body.genres || []).some((g) => /хентай|hentai/i.test(g || ""));

  try {
    const tracks = await collectTracks(
      {
        title: body.title.slice(0, 200),
        original: body.original?.slice(0, 200),
        year: body.year,
        malId: body.malId,
        shikimoriId: body.shikimoriId,
        yummyId: body.yummyId,
        kpId: body.kpId,
        anilibriaAlias: body.anilibriaAlias,
      },
      adult,
    );
    return NextResponse.json(
      { tracks },
      { headers: { "Cache-Control": "private, max-age=60" } },
    );
  } catch (e) {
    return NextResponse.json(
      { tracks: [], error: e instanceof Error ? e.message : "не удалось собрать озвучки" },
      { status: 200 },
    );
  }
}

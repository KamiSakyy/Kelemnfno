import { baseHeaders } from "@/server/tsuyu/net";
import { open, proxyUrl, type ProxyTicket } from "@/server/tsuyu/token";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 60;

/* Прокси потока: клиент никогда не видит исходный хост источника.
 * Для HLS плейлист переписывается так, чтобы сегменты тоже шли через нас. */

function rewritePlaylist(text: string, baseUrl: string, referer?: string): string {
  const out: string[] = [];
  for (const raw of text.split(/\r?\n/)) {
    const line = raw.trim();
    if (!line) {
      out.push(raw);
      continue;
    }
    if (line.startsWith("#")) {
      // URI="..." внутри тегов (ключи, субтитры, аудио)
      const replaced = line.replace(/URI="([^"]+)"/g, (_m, uri: string) => {
        const abs = new URL(uri, baseUrl).toString();
        return `URI="${proxyUrl(abs, referer, abs.includes(".m3u8") ? "hls" : "raw")}"`;
      });
      out.push(replaced);
      continue;
    }
    try {
      const abs = new URL(line, baseUrl).toString();
      out.push(proxyUrl(abs, referer, abs.includes(".m3u8") ? "hls" : "raw"));
    } catch {
      out.push(raw);
    }
  }
  return out.join("\n");
}

export async function GET(req: Request) {
  const url = new URL(req.url);
  const token = url.searchParams.get("t") || "";
  const ticket = open<ProxyTicket>(token);
  if (!ticket || !ticket.u || ticket.e < Date.now()) {
    return new Response("ссылка устарела", { status: 403 });
  }

  const headers: Record<string, string> = baseHeaders(ticket.o, ticket.r);
  const range = req.headers.get("range");
  if (range) headers["Range"] = range;
  headers["Accept"] = "*/*";

  let upstream: Response;
  try {
    upstream = await fetch(ticket.u, { headers, redirect: "follow", cache: "no-store" });
  } catch {
    return new Response("источник недоступен", { status: 502 });
  }

  const type = upstream.headers.get("content-type") || "";
  const isPlaylist =
    ticket.m === "hls" ||
    ticket.u.includes(".m3u8") ||
    type.includes("mpegurl") ||
    type.includes("vnd.apple");

  if (isPlaylist) {
    const text = await upstream.text();
    if (text.trim().startsWith("#EXTM3U")) {
      const body = rewritePlaylist(text, upstream.url || ticket.u, ticket.r);
      return new Response(body, {
        status: 200,
        headers: {
          "Content-Type": "application/vnd.apple.mpegurl",
          "Cache-Control": "no-store",
          "Access-Control-Allow-Origin": "*",
        },
      });
    }
    return new Response(text, { status: upstream.status, headers: { "Cache-Control": "no-store" } });
  }

  const out = new Headers();
  for (const key of ["content-type", "content-length", "content-range", "accept-ranges", "etag"]) {
    const value = upstream.headers.get(key);
    if (value) out.set(key, value);
  }
  // Сегменты неизменяемы: разрешаем браузеру кэшировать их,
  // чтобы перемотка назад и повторный просмотр не качали данные заново.
  out.set("Cache-Control", "private, max-age=3600");
  out.set("Access-Control-Allow-Origin", "*");
  return new Response(upstream.body, { status: upstream.status, headers: out });
}

export async function HEAD(req: Request) {
  const res = await GET(req);
  return new Response(null, { status: res.status, headers: res.headers });
}

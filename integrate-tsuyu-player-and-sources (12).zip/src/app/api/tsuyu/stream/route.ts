import { NextResponse } from "next/server";
import { eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { tsuyuStreams, tsuyuTracks } from "@/db/schema";
import { noteSource, rankRoutes, trackById } from "@/server/tsuyu/aggregate";
import { kindOf, resolveStreams, verifyStreams } from "@/server/tsuyu/resolver";
import { proxyUrl } from "@/server/tsuyu/token";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 60;

interface Body {
  track?: string;
  episode?: number;
}

interface CachedRow {
  quality: number;
  url: string;
  referer: string;
  /** реальный тип потока — клиент по нему выбирает hls.js или прямое воспроизведение */
  kind: "hls" | "mp4";
}

export async function POST(req: Request) {
  let body: Body;
  try {
    body = (await req.json()) as Body;
  } catch {
    return NextResponse.json({ error: "bad request" }, { status: 400 });
  }
  const trackId = String(body.track || "");
  const episode = Number(body.episode);
  if (!trackId || !Number.isFinite(episode)) {
    return NextResponse.json({ error: "track/episode required" }, { status: 400 });
  }

  const track = await trackById(trackId);
  if (!track) return NextResponse.json({ error: "дорожка устарела" }, { status: 404 });

  const cacheKey = `${trackId}:${episode}`;
  try {
    const hit = await db
      .select()
      .from(tsuyuStreams)
      .where(sql`${tsuyuStreams.key} = ${cacheKey} and ${tsuyuStreams.createdAt} > now() - interval '20 minutes'`)
      .limit(1);
    if (hit[0]) {
      const rows = (hit[0].payload || []) as CachedRow[];
      if (rows.length) {
        return NextResponse.json({
          voice: track.voice,
          sources: rows.map((r) => {
            const kind = r.kind || (/\.m3u8|hls/i.test(r.url) ? "hls" : "mp4");
            return {
              quality: r.quality,
              kind,
              url: proxyUrl(r.url, r.referer, kind === "hls" ? "hls" : "raw"),
            };
          }),
        });
      }
    }
  } catch {
    /* кэш не обязателен */
  }

  const routes = await rankRoutes(track.routes.filter((r) => Math.abs(r.episode - episode) < 0.001));
  if (!routes.length) return NextResponse.json({ error: "серия недоступна" }, { status: 404 });

  // автоподбор: идём по маршрутам от надёжного к запасному, пока не получим видео
  const collected: CachedRow[] = [];
  for (const route of routes.slice(0, 12)) {
    const started = Date.now();
    try {
      let candidates: Record<string, string> = {};
      let referer = "";

      if (route.streams && Object.keys(route.streams).length) {
        candidates = Object.fromEntries(Object.entries(route.streams).map(([q, u]) => [q, String(u)]));
        const first = Object.values(candidates)[0];
        referer = first ? new URL(first).origin + "/" : "";
      } else if (route.embed) {
        const resolved = await resolveStreams(route.embed);
        candidates = resolved.streams;
        referer = resolved.referer;
      }

      // отбрасываем ссылки-заглушки: плеер не должен качать мусор
      const valid = Object.keys(candidates).length ? await verifyStreams(candidates, referer) : {};

      for (const [q, url] of Object.entries(valid)) {
        collected.push({ quality: Number(q) || 0, url, referer, kind: kindOf(url) });
      }

      if (collected.length) await noteSource(route.source, true, Date.now() - started);
      else await noteSource(route.source, false, Date.now() - started);
    } catch {
      await noteSource(route.source, false, Date.now() - started);
      continue;
    }
    if (collected.length) break;
  }

  if (!collected.length) {
    // Маршруты устарели (токены в ссылках живут недолго) — сбрасываем дорожку,
    // чтобы следующий запрос собрал свежие. Клиент повторит подбор сам.
    try {
      await db.delete(tsuyuTracks).where(eq(tsuyuTracks.id, trackId));
    } catch {
      /* ок */
    }
    return NextResponse.json({ error: "источник пока не отдал видео", stale: true }, { status: 502 });
  }

  const unique = new Map<number, CachedRow>();
  for (const row of collected) if (!unique.has(row.quality)) unique.set(row.quality, row);
  const payload = [...unique.values()].sort((a, b) => b.quality - a.quality);

  try {
    await db
      .insert(tsuyuStreams)
      .values({ key: cacheKey, payload })
      .onConflictDoUpdate({
        target: tsuyuStreams.key,
        set: { payload, createdAt: new Date() },
      });
    await db.delete(tsuyuStreams).where(sql`${tsuyuStreams.createdAt} < now() - interval '2 hours'`);
  } catch {
    /* ок */
  }

  return NextResponse.json({
    voice: track.voice,
    sources: payload.map((r) => ({
      quality: r.quality,
      kind: r.kind,
      url: proxyUrl(r.url, r.referer, r.kind === "hls" ? "hls" : "raw"),
    })),
  });
}

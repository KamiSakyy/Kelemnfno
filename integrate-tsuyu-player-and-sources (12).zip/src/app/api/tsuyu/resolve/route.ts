import { NextResponse } from "next/server";
import { resolveStreams, verifyStreams } from "@/server/tsuyu/resolver";
import { proxyUrl } from "@/server/tsuyu/token";
import { embed } from "@/server/tsuyu/util";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 60;

/** Серверное распознавание потока для обычного iframe каталога. */
export async function POST(req: Request) {
  let body: { url?: string };
  try {
    body = (await req.json()) as { url?: string };
  } catch {
    return NextResponse.json({ error: "bad request" }, { status: 400 });
  }
  const url = embed(body.url || "");
  if (!url) return NextResponse.json({ error: "url required" }, { status: 400 });

  try {
    const resolved = await resolveStreams(url);
    const checked = await verifyStreams(resolved.streams, resolved.referer);
    const sources = Object.entries(Object.keys(checked).length ? checked : resolved.streams)
      .map(([q, u]) => {
        const kind = /\.m3u8|hls/i.test(u) ? ("hls" as const) : ("mp4" as const);
        return {
          quality: Number(q) || 0,
          kind,
          url: proxyUrl(u, resolved.referer, kind === "hls" ? "hls" : "raw"),
        };
      })
      .sort((a, b) => b.quality - a.quality);
    if (!sources.length) return NextResponse.json({ error: "пусто" }, { status: 502 });
    return NextResponse.json({ sources });
  } catch (e) {
    return NextResponse.json({ error: e instanceof Error ? e.message : "нет потока" }, { status: 502 });
  }
}

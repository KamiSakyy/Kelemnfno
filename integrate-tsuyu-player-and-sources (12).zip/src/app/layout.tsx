import type { Metadata, Viewport } from "next";
import { headers } from "next/headers";
import type { ReactNode } from "react";
import PwaLayer from "@/components/PwaLayer";
import "./globals.css";

const SITE_NAME = "Аниме";
const DESCRIPTION =
  "Смотрите аниме онлайн: большой каталог, календарь выхода серий, избранное, история просмотра, выбор озвучки и собственный видеоплеер.";

/** Абсолютные URL (OG-картинка, manifest) строим от реального хоста запроса. */
function baseUrl(host?: string | null, proto?: string | null): URL {
  const h = (host || "localhost:3000").replace(/[^a-zA-Z0-9.:-]/g, "");
  const p = proto === "http:" ? "http:" : "https:";
  try {
    return new URL(`${p}//${h}`);
  } catch {
    return new URL("https://localhost:3000");
  }
}

export async function generateMetadata(): Promise<Metadata> {
  const h = await headers();
  const base = baseUrl(
    h.get("x-forwarded-host") || h.get("host"),
    h.get("x-forwarded-proto"),
  );
  return metadataWithBase(base);
}

function metadataWithBase(base: URL): Metadata {
  return {
  metadataBase: base,
  applicationName: SITE_NAME,
  title: {
    default: "Смотреть аниме онлайн",
    template: "%s | Аниме",
  },
  description: DESCRIPTION,
  manifest: "/manifest.webmanifest",
  appleWebApp: {
    capable: true,
    title: SITE_NAME,
    statusBarStyle: "black-translucent",
  },
  formatDetection: { telephone: false, address: false, email: false },
  icons: {
    icon: [
      { url: "/icons/favicon-16.png", sizes: "16x16", type: "image/png" },
      { url: "/icons/favicon-32.png", sizes: "32x32", type: "image/png" },
      { url: "/icons/icon-192.png", sizes: "192x192", type: "image/png" },
      { url: "/icons/icon-512.png", sizes: "512x512", type: "image/png" },
    ],
    apple: [{ url: "/icons/apple-touch-icon.png", sizes: "180x180", type: "image/png" }],
  },
  openGraph: {
    type: "website",
    siteName: SITE_NAME,
    locale: "ru_RU",
    title: "Смотреть аниме онлайн",
    description: DESCRIPTION,
    images: [{ url: "/screenshots/wide-1280x720.png", width: 1280, height: 720 }],
  },
  twitter: {
    card: "summary_large_image",
    title: "Смотреть аниме онлайн",
    description: DESCRIPTION,
    images: ["/screenshots/wide-1280x720.png"],
  },
  other: {
    "mobile-web-app-capable": "yes",
    "msapplication-TileColor": "#09090b",
    "msapplication-TileImage": "/icons/icon-192.png",
  },
  };
}

export const viewport: Viewport = {
  themeColor: [
    { media: "(prefers-color-scheme: dark)", color: "#09090b" },
    { media: "(prefers-color-scheme: light)", color: "#09090b" },
  ],
  colorScheme: "dark",
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
  userScalable: true,
  viewportFit: "cover",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ru" dir="ltr">
      <body>
        {children}
        <PwaLayer />
      </body>
    </html>
  );
}

"use client";

import React, { useEffect, useState } from"react";
import { useParams } from"next/navigation";
import { MarkdownRenderer } from"@/components/MarkdownRenderer";
import { ImageGallery } from"@/components/ImageGallery";

interface SharedMsg {
 id: number;
 role:"user"|"assistant";
 content: string;
 providerName?: string | null;
 imagesData?: { image: string; thumbnail: string; title: string; source: string }[] | null;
 attachmentDataUrl?: string | null;
 createdAt: string;
}

export default function SharedChatPage() {
 const params = useParams<{ shareId: string }>();
 const [data, setData] = useState<{ title: string; messages: SharedMsg[] } | null>(null);
 const [err, setErr] = useState(false);

 useEffect(() => {
 fetch(`/api/share?shareId=${encodeURIComponent(params.shareId)}`).then((r) => (r.ok? r.json() : Promise.reject())).then(setData).catch(() => setErr(true));
 }, [params.shareId]);

 return (<div className="min-h-[100dvh] bg-[#050505] text-zinc-100">
 <header className="sticky top-0 z-10 border-b border-white/[0.08] bg-[#050505]/90 backdrop-blur">
 <div className="max-w-[760px] mx-auto px-4 h-14 flex items-center gap-3">
 {/* eslint-disable-next-line @next/next/no-img-element */}
 <img src="/lumi-avatar.jpg"alt="Люми"className="w-8 h-8 rounded-xl object-cover border border-white/10"/>
 <div className="min-w-0">
 <div className="text-[13.5px] font-bold truncate">{data?.title ||"Диалог с Люми"}</div>
 <div className="text-[10.5px] text-zinc-600">поделились диалогом · lumi.chat</div>
 </div>
 <a href="/"className="ml-auto h-9 px-3.5 rounded-xl bg-white text-black text-[12.5px] font-semibold inline-flex items-center">
 Поговорить с Люми 
 </a>
 </div>
 </header>

 <main className="max-w-[760px] mx-auto px-4 py-8 space-y-7">
 {err && (<div className="min-h-[40vh] grid place-items-center text-center">
 <div>
 <p className="text-[15px] text-zinc-300">Ссылка неактивна или диалог удалён </p>
 <a href="/"className="mt-3 inline-block text-[13px] text-fuchsia-300 underline">К Люми →</a>
 </div>
 </div>)}
 {!data &&!err && (<div className="min-h-[40vh] grid place-items-center">
 <span className="w-5 h-5 rounded-full border-2 border-zinc-700 border-t-white animate-spin"/>
 </div>)}
 {data?.messages.map((m) =>
 m.role ==="user"? (<div key={m.id} className="flex justify-end animate-fade-in">
 <div className="max-w-[85%] rounded-2xl rounded-br-md bg-[#17171a] border border-white/[0.07] overflow-hidden">
 {m.attachmentDataUrl && (// eslint-disable-next-line @next/next/no-img-element
 <img src={m.attachmentDataUrl} alt=""className="max-h-60 w-full object-cover border-b border-white/[0.07]"/>)}
 <p className="px-4 py-2.5 text-[14.5px] whitespace-pre-wrap">{m.content}</p>
 </div>
 </div>) : (<article key={m.id} className="animate-fade-in">
 <MarkdownRenderer content={m.content} />
 {m.imagesData && m.imagesData.length > 0 && <ImageGallery images={m.imagesData} />}
 <div className="mt-1.5 text-[11px] font-mono text-zinc-600">{m.providerName ||"Люми"}</div>
 </article>))}
 {data && (<p className="text-center text-[11.5px] text-zinc-600 pt-4">
 Диалог создан с Люми — аниме-подругой ИИ. <a href="/"className="text-fuchsia-300 underline">Такая же может быть и у тебя!</a>
 </p>)}
 </main>
 </div>);
}

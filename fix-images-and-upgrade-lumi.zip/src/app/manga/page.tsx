"use client";

export const dynamic = "force-dynamic";

// Люми · Манга и Ранобэ: полный каталог (MangaDex API, ~200 000 тайтлов),
// поиск, фильтры по жанрам/статусу/рейтингу/годам, читалка глав внутри сайта,
// связь с аниме (из карточки аниме → подходящая манга).
import React, { Suspense, useCallback, useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import {
  ArrowLeft, Book, BookOpen, Calendar, ChevronLeft, ChevronRight, Flame, Heart, Layers,
  Loader2, Play, Search, Star, Tag, X, Zap,
} from "lucide-react";
import {
  browseMangaDex, getMangaInfo, getMangaChapters, getReaderData, readerPageUrl, getMangaTags,
  MANGA_RATINGS, type MangaTile, type MangaDetails, type Chapter, type ReaderInfo, type MangaTag,
} from "@/lib/mangadex";

const RU_STATUS: Record<string, string> = { ongoing: "Выходит", completed: "Завершена", hiatus: "Хиатус", cancelled: "Отменена" };
const RU_RATING: Record<string, string> = { safe: "Безопасная", suggestive: "Откровенная", erotica: "+18 легкое", pornographic: "+18 хард" };
const TOP_TAGS = ["Action", "Adventure", "Comedy", "Drama", "Fantasy", "Horror", "Isekai", "Josei", "Mystery", "Romance", "Sci-Fi", "Seinen", "Shoujo", "Shounen", "Slice of Life", "Supernatural", "Thriller", "Yuri", "Yaoi", "Ecchi"];
const YEARS = ["Все годы", ...Array.from({ length: 30 }, (_, i) => String(2026 - i))];

function statusClass(s: string) {
  switch (s) {
    case "completed": return "bg-emerald-500/20 text-emerald-300";
    case "ongoing": return "bg-sky-500/20 text-sky-300";
    case "hiatus": return "bg-amber-500/20 text-amber-300";
    default: return "bg-zinc-500/20 text-zinc-300";
  }
}
function ratingClass(r: string) {
  if (r === "pornographic" || r === "erotica") return "bg-rose-500/25 text-rose-300";
  if (r === "suggestive") return "bg-fuchsia-500/20 text-fuchsia-300";
  return "bg-white/[0.08] text-zinc-400";
}

const FK = "lumi:manga-favs";
const readFavs = (): string[] => { try { return JSON.parse(localStorage.getItem(FK) || "[]"); } catch { return []; } };
const toggleFav = (id: string): string[] => {
  const list = readFavs();
  const i = list.indexOf(id);
  if (i >= 0) list.splice(i, 1); else list.unshift(id);
  localStorage.setItem(FK, JSON.stringify(list.slice(0, 500)));
  window.dispatchEvent(new Event("lumi:manga-favs"));
  return list;
};

// ── Карточка манги ───────────────────────────────────────────────────────────
function MangaCard({ m, onOpen, fav, onToggleFav }: { m: MangaTile; onOpen: () => void; fav: boolean; onToggleFav: () => void }) {
  return (
    <div className="group text-left cursor-pointer animate-fade-in" onClick={onOpen}>
      <div className="relative aspect-[2/3] rounded-xl overflow-hidden border border-white/[0.07] bg-[#111]">
        {m.poster ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={m.poster}
            onError={(e) => { const el = e.currentTarget as HTMLImageElement; el.style.opacity = "0"; }}
            alt=""
            loading="lazy"
            className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
          />
        ) : (
          <div className="w-full h-full grid place-items-center text-zinc-700"><Book className="w-8 h-8" /></div>
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-transparent to-transparent" />
        {m.rating !== "safe" && <span className={`absolute top-1.5 left-1.5 px-1.5 py-0.5 rounded-md text-[9px] font-bold ${ratingClass(m.rating)}`}>18+</span>}
        <button
          onClick={(e) => { e.stopPropagation(); onToggleFav(); }}
          className={`absolute top-1.5 right-1.5 w-7 h-7 rounded-lg grid place-items-center backdrop-blur transition ${fav ? "bg-pink-500/85 text-white" : "bg-black/55 text-zinc-300 opacity-0 group-hover:opacity-100 hover:text-white"}`}
          title="В избранное"
        >
          <Heart className={`w-3.5 h-3.5 ${fav ? "fill-current" : ""}`} />
        </button>
        <span className={`absolute bottom-1.5 left-1.5 px-1.5 py-0.5 rounded text-[9.5px] font-semibold ${statusClass(m.status)}`}>{RU_STATUS[m.status] || m.status}</span>
        <div className="absolute inset-0 grid place-items-center opacity-0 group-hover:opacity-100 transition pointer-events-none">
          <span className="w-12 h-12 rounded-full bg-pink-500/90 text-white grid place-items-center shadow-lg"><BookOpen className="w-5 h-5" /></span>
        </div>
        {m.score && m.score > 0 && (
          <span className="absolute bottom-1.5 right-1.5 inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded bg-black/70 text-[11px] font-bold text-amber-300">
            <Star className="w-3 h-3 fill-current" />{m.score}
          </span>
        )}
      </div>
      <div className="mt-1.5 text-[12.5px] text-zinc-200 leading-tight line-clamp-2 group-hover:text-white">{m.title}</div>
      <div className="text-[10.5px] text-zinc-500 truncate">
        {m.year || "—"}{m.follows ? ` · ${m.follows.toLocaleString("ru-RU")} чит.` : ""}
      </div>
      <div className="text-[9.5px] text-zinc-600 truncate mt-0.5">{m.tags.slice(0, 3).join(" · ")}</div>
    </div>
  );
}

// ── Читалка (модал на весь экран) —───────────────────────────────────────────
function ReaderModal({ chapter, reader, onClose, onPage }: { chapter: Chapter; reader: ReaderInfo; onClose: () => void; onPage: (n: number) => void }) {
  const [page, setPage] = useState(1);
  const total = chapter.pages || reader.pages.length;

  useEffect(() => { onPage(page); }, [page, onPage]);
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if (e.key === "ArrowRight" || e.key === "d") setPage((p) => Math.min(total, p + 1));
      if (e.key === "ArrowLeft" || e.key === "a") setPage((p) => Math.max(1, p - 1));
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [total, onClose]);

  const url = readerPageUrl(reader, page, "data");

  return (
    <div className="fixed inset-0 z-[90] bg-black flex flex-col" onContextMenu={(e) => e.preventDefault()}>
      <div className="h-12 shrink-0 px-3 sm:px-5 flex items-center gap-2.5 bg-[#0a0a0d] border-b border-white/[0.08]">
        <button onClick={onClose} className="w-9 h-9 rounded-lg grid place-items-center text-zinc-400 hover:text-white hover:bg-white/[0.06]"><X className="w-4 h-4" /></button>
        <div className="min-w-0 flex-1 text-center">
          <div className="text-[12.5px] font-semibold truncate">{chapter.title || `Глава ${chapter.number}`}</div>
          <div className="text-[9.5px] text-zinc-600">MangaDex · {chapter.scanlator || "официальная"}</div>
        </div>
        <div className="text-[11px] font-mono text-zinc-500 shrink-0">{page}/{total}</div>
      </div>

      <div className="flex-1 min-h-0 relative bg-black" onClick={(e) => {
        const x = (e.clientX / window.innerWidth);
        if (x > 0.5) setPage((p) => Math.min(total, p + 1)); else setPage((p) => Math.max(1, p - 1));
      }}>
        {url ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            key={page}
            src={url}
            alt=""
            className="absolute inset-0 m-auto max-h-full max-w-full object-contain animate-fade-in"
          />
        ) : (
          <div className="absolute inset-0 grid place-items-center"><Loader2 className="w-5 h-5 animate-spin text-zinc-500" /></div>
        )}
      </div>

      <div className="shrink-0 border-t border-white/[0.08] bg-[#0a0a0d] px-3 py-2 flex items-center gap-2">
        <button onClick={() => setPage((p) => Math.max(1, p - 1))} className="h-8 px-3 rounded-lg bg-white/[0.05] text-[12px] text-zinc-300 hover:bg-white/[0.1] inline-flex items-center gap-1">
          <ChevronLeft className="w-3.5 h-3.5" /> Назад
        </button>
        <input
          type="range"
          min={1}
          max={total}
          value={page}
          onChange={(e) => setPage(Number(e.target.value))}
          className="flex-1 accent-pink-500"
        />
        <button onClick={() => setPage((p) => Math.min(total, p + 1))} className="h-8 px-3 rounded-lg bg-pink-500 text-white text-[12px] font-semibold inline-flex items-center gap-1">
          Вперёд <ChevronRight className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
}

// ── Деталь манги (модал) ─────────────────────────────────────────────────────
function MangaDetailsModal({ id, onClose, onUnread }: { id: string; onClose: () => void; onUnread: (ch: Chapter, reader: ReaderInfo) => void }) {
  const [det, setDet] = useState<MangaDetails | null>(null);
  const [chapters, setChapters] = useState<Chapter[]>([]);
  const [loading, setLoading] = useState(true);
  const [fav, setFav] = useState(() => readFavs().includes(id));
  const [readerBusy, setReaderBusy] = useState<string | null>(null);

  useEffect(() => {
    let dead = false;
    (async () => {
      setLoading(true);
      const [d, ch] = await Promise.all([getMangaInfo(id), getMangaChapters(id)]);
      if (dead) return;
      setDet(d);
      setChapters(ch);
      setLoading(false);
    })();
    return () => { dead = true; };
  }, [id]);

  const openChapter = async (c: Chapter) => {
    setReaderBusy(c.id);
    const r = await getReaderData(c.id);
    setReaderBusy(null);
    if (r) onUnread(c, r);
  };

  useEffect(() => {
    document.body.style.overflow = "hidden";
    return () => { document.body.style.overflow = ""; };
  }, []);

  return (
    <div className="fixed inset-0 z-[70] bg-black/85 backdrop-blur-sm overflow-y-auto animate-fade-in" onClick={onClose}>
      <div className="min-h-full grid place-items-center p-3 sm:p-6">
        <div className="relative w-full max-w-5xl rounded-2xl border border-white/[0.1] bg-[#0b0b0d] overflow-hidden" onClick={(e) => e.stopPropagation()}>
          {loading && <div className="h-96 grid place-items-center"><Loader2 className="w-6 h-6 animate-spin text-zinc-500" /></div>}
          {!loading && !det && <div className="p-6 text-center text-[13px] text-zinc-500">Не удалось загрузить мангу 😔</div>}
          {det && (
            <div className="grid md:grid-cols-[240px_1fr]">
              <div className="relative aspect-[2/3] md:aspect-auto md:min-h-[420px]">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={det.poster} alt="" className="absolute inset-0 w-full h-full object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0b0b0d] via-transparent to-transparent" />
                {det.follows && det.follows > 0 && (
                  <span className="absolute bottom-2 left-2 px-2 py-1 rounded-lg bg-black/70 text-[10px] text-zinc-300">{det.follows.toLocaleString("ru-RU")} читателей</span>
                )}
              </div>

              <div className="p-4 sm:p-5 max-h-[85vh] overflow-y-auto">
                <div className="flex items-start gap-2">
                  <div className="min-w-0 flex-1">
                    <h2 className="text-[19px] sm:text-[22px] font-bold leading-tight">{det.title}</h2>
                    <p className="text-[11px] text-zinc-500 mt-1 truncate">
                      {det.author}{det.artist && det.artist !== det.author ? ` · ${det.artist}` : ""}
                      {det.year ? ` · ${det.year}` : ""}
                      {det.chTotal ? ` · ${det.chTotal} гл.` : ""}
                      {det.chLastDate ? ` · последняя ${det.chLastDate}` : ""}
                    </p>
                  </div>
                  <button
                    onClick={() => setFav(toggleFav(id).includes(id))}
                    className={`w-9 h-9 rounded-xl grid place-items-center shrink-0 transition ${fav ? "bg-pink-500/[0.15] text-pink-400" : "bg-white/[0.05] text-zinc-400 hover:text-pink-300"}`}
                    title="В избранное"
                  >
                    <Heart className={`w-4 h-4 ${fav ? "fill-current" : ""}`} />
                  </button>
                </div>

                <div className="mt-2.5 flex flex-wrap gap-1.5">
                  <span className={`px-1.5 py-0.5 rounded text-[10px] font-semibold ${statusClass(det.status)}`}>{RU_STATUS[det.status] || det.status}</span>
                  <span className={`px-1.5 py-0.5 rounded text-[10px] font-semibold ${ratingClass(det.rating)}`}>{RU_RATING[det.rating] || det.rating}</span>
                  {det.score && det.score > 0 && <span className="px-1.5 py-0.5 rounded bg-amber-500/20 text-[10px] font-semibold text-amber-300 inline-flex items-center gap-0.5"><Star className="w-3 h-3 fill-current" />{det.score}</span>}
                  {det.tags.map((tg) => <span key={tg} className="px-1.5 py-0.5 rounded bg-white/[0.05] text-[10px] text-zinc-400">{tg}</span>)}
                </div>

                {det.altNamesEn.length > 0 && <p className="mt-2 text-[11px] text-zinc-500">Другие названия: {det.altNamesEn.join(" · ")}</p>}
                {det.description && <p className="mt-2.5 text-[12.5px] leading-relaxed text-zinc-400">{det.description}</p>}

                <div className="mt-3.5 border-t border-white/[0.08] pt-3">
                  <div className="text-[11px] uppercase tracking-wider text-zinc-500 mb-2 flex items-center gap-1.5">
                    <Layers className="w-3.5 h-3.5" /> Главы ({chapters.length})
                  </div>
                  <div className="space-y-1 max-h-72 overflow-y-auto pr-1">
                    {chapters.length === 0 && !loading && (
                      <p className="text-[12px] text-zinc-600 py-3">Глав для чтения онлайн не найдено сходу — скорее всего scanlator-группы не опубликовали перевод этой части изначально.</p>
                    )}
                    {chapters.map((c) => (
                      c.externalUrl ? (
                        <a
                          key={c.id}
                          href={c.externalUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center gap-2.5 rounded-lg border border-white/[0.07] bg-[#101013] px-3 py-2 text-[12.5px] hover:border-white/[0.16] transition group"
                        >
                          <Play className="w-3.5 h-3.5 text-pink-400 shrink-0 fill-current" />
                          <span className="min-w-0 flex-1 truncate">Глава {c.number ?? "—"}{c.title ? ` · ${c.title}` : ""}</span>
                          <span className="text-[9px] font-mono px-1 py-0.5 rounded bg-white/[0.06] text-zinc-500 shrink-0">ВНЕШ.</span>
                          <span className="text-[9.5px] text-zinc-500 shrink-0">{c.pages} стр.</span>
                        </a>
                      ) : (
                        <button
                          key={c.id}
                          onClick={() => void openChapter(c)}
                          disabled={readerBusy === c.id}
                          className="w-full flex items-center gap-2.5 rounded-lg border border-white/[0.07] bg-[#101013] px-3 py-2 text-left text-[12.5px] hover:border-white/[0.16] transition disabled:opacity-50"
                        >
                          {readerBusy === c.id ? <Loader2 className="w-3.5 h-3.5 text-pink-400 shrink-0 animate-spin" /> : <Play className="w-3.5 h-3.5 text-pink-400 shrink-0 fill-current" />}
                          <span className="min-w-0 flex-1 truncate">Глава {c.number ?? "—"}{c.title ? ` · ${c.title}` : ""}</span>
                          {c.language === "ru" && <span className="text-[9px] font-mono px-1 py-0.5 rounded bg-emerald-500/15 text-emerald-300 shrink-0">RU</span>}
                          <span className="text-[9.5px] text-zinc-500 shrink-0">{c.pages} стр.</span>
                        </button>
                      )
                    ))}
                  </div>
                </div>

                <div className="mt-3.5 flex items-center justify-between text-[11px] text-zinc-600">
                  <a href={`https://mangadex.org/title/${id}`} target="_blank" rel="noopener noreferrer" className="text-pink-400 hover:underline">Открыть на MangaDex ↗</a>
                  <button onClick={onClose} className="text-zinc-500 hover:text-white">Закрыть</button>
                </div>
              </div>
            </div>
          )}
          <button onClick={onClose} className="absolute top-3 right-3 w-9 h-9 rounded-xl bg-black/60 backdrop-blur grid place-items-center text-zinc-300 hover:text-white z-10">
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Главная страница ─────────────────────────────────────────────────────────
function MangaLibraryInner() {
  const params = useSearchParams();
  const [tab, setTab] = useState<"catalog" | "search" | "favs">("catalog");
  const [q, setQ] = useState(params.get("q") || "");
  const [year, setYear] = useState(params.get("year") || "Все годы");
  const [status, setStatus] = useState<string>(params.get("status") || "");
  const [rating, setRating] = useState<string>(params.get("rating") || "");
  const [genre, setGenre] = useState<string>(params.get("genre") || "");
  const [order, setOrder] = useState<"latest" | "popular" | "rating">((params.get("order") as "latest" | "popular" | "rating") || "latest");
  const [genres, setGenres] = useState<MangaTag[]>([]);
  const [items, setItems] = useState<MangaTile[]>([]);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(false);
  const [canMore, setCanMore] = useState(true);
  const [openId, setOpenId] = useState<string | null>(params.get("manga") || null);
  const [favs, setFavs] = useState<string[]>([]);
  const [favItems, setFavItems] = useState<MangaTile[]>([]);
  const [favsLoading, setFavsLoading] = useState(false);
  const [note, setNote] = useState("");
  const [reader, setReader] = useState<{ chapter: Chapter; reader: ReaderInfo } | null>(null);
  const busyRef = useRef(false);
  const listRef = useRef<HTMLDivElement>(null);
  const isSearch = q.trim().length >= 2;

  useEffect(() => {
    getMangaTags().then(setGenres);
    setFavs(readFavs());
    const f = () => setFavs(readFavs());
    window.addEventListener("lumi:manga-favs", f);
    return () => window.removeEventListener("lumi:manga-favs", f);
  }, []);

  const load = useCallback(async (p: number, reset: boolean) => {
    if (busyRef.current) return;
    busyRef.current = true;
    setLoading(true);
    try {
      const genreIds = genre ? [genre] : [];
      const r = await browseMangaDex({
        q: isSearch ? q.trim() : undefined,
        genreIds,
        status: status ? [status] : undefined,
        rating: rating ? [rating] : undefined,
        order,
        page: p,
        limit: 24,
        yearFrom: year !== "Все годы" ? Number(year) : null,
      });
      const augmented = await Promise.all(r.items.map(async (m) => {
        return m;
      }));
      setItems((old) => (reset ? augmented : [...old, ...augmented.filter((x) => !old.some((o) => o.id === x.id))]));
      setCanMore(r.total > p * 24 && augmented.length >= 20);
      setPage(p);
      setNote(isSearch && reset ? `Найдено: ${r.total}+` : "");
    } catch {
      setCanMore(false);
    } finally {
      busyRef.current = false;
      setLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [q, genre, status, rating, order, year, isSearch]);

  const tRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  useEffect(() => {
    if (tRef.current) clearTimeout(tRef.current);
    tRef.current = setTimeout(() => load(1, true), 450);
    return () => { if (tRef.current) clearTimeout(tRef.current); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [q, year, genre, status, rating, order]);

  useEffect(() => {
    const el = listRef.current;
    if (!el) return;
    const onScroll = () => {
      if (!canMore || loading || busyRef.current) return;
      if (el.scrollTop + el.clientHeight > el.scrollHeight - 700) load(page + 1, false);
    };
    el.addEventListener("scroll", onScroll);
    return () => el.removeEventListener("scroll", onScroll);
  }, [canMore, loading, page, load]);

  // избранное
  useEffect(() => {
    if (tab !== "favs") return;
    let dead = false;
    (async () => {
      const favIds = readFavs().slice(0, 30);
      if (!favIds.length) { setFavItems([]); return; }
      setFavsLoading(true);
      const fetched: MangaTile[] = [];
      for (const id of favIds) {
        try {
          const info = await getMangaInfo(id);
          if (info) fetched.push(info);
        } catch { /* skip */ }
      }
      if (!dead) { setFavItems(fetched); setFavsLoading(false); }
    })();
    return () => { dead = true; };
  }, [tab, favs]);

  const sel = "h-9 rounded-lg bg-white/[0.05] border border-white/[0.08] px-2.5 text-[12.5px] text-zinc-200 outline-none focus:border-pink-400/40";

  return (
    <div className="h-[100dvh] overflow-hidden bg-[#050505] text-zinc-100 flex flex-col">
      <header className="h-14 shrink-0 px-3 sm:px-5 border-b border-white/[0.08] flex items-center gap-2.5">
        <Link href="/" className="w-9 h-9 rounded-lg grid place-items-center text-zinc-500 hover:text-white hover:bg-white/[0.06]"><ArrowLeft className="w-[18px] h-[18px]" /></Link>
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src="/lumi-avatar.jpg" alt="Люми" className="w-8 h-8 rounded-xl object-cover border border-white/10" />
        <div className="leading-tight min-w-0">
          <div className="text-[13.5px] font-bold flex items-center gap-1.5"><BookOpen className="w-4 h-4 text-pink-400" />Манга · Ранобэ</div>
          <div className="text-[10px] text-zinc-600 flex items-center gap-1"><Flame className="w-2.5 h-2.5 text-pink-400" />MangaDex · 200 000+ тайтлов · читалка внутри</div>
        </div>
        <span className="ml-auto text-[11px] font-mono text-zinc-600">{note}</span>
      </header>

      <div className="shrink-0 px-3 sm:px-5 pt-2.5 pb-2 flex gap-1.5">
        {(
          [
            { id: "catalog" as const, label: "Каталог", icon: Layers },
            { id: "search" as const, label: "Поиск", icon: Search },
            { id: "favs" as const, label: "Избранное", icon: Heart },
          ]
        ).map((t) => {
          const Icon = t.icon;
          return (
            <button key={t.id} onClick={() => setTab(t.id)} className={`flex-1 h-9 rounded-xl text-[12px] font-medium inline-flex items-center justify-center gap-1.5 transition ${tab === t.id ? "bg-white text-black" : "bg-white/[0.04] text-zinc-400 hover:text-zinc-200"}`}>
              <Icon className="w-3.5 h-3.5" />{t.label}
            </button>
          );
        })}
      </div>

      {tab !== "favs" && (
        <div className="shrink-0 px-3 sm:px-5 pb-2.5 flex flex-wrap items-center gap-2 bg-[#070708] border-b border-white/[0.08] pt-2">
          <span className="relative flex-1 min-w-[170px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-600" />
            <input
              value={q}
              onChange={(e) => { setQ(e.target.value); if (tab === "catalog") setTab("search"); }}
              onKeyDown={(e) => { if (e.key === "Enter" && tab === "catalog") setTab("search"); }}
              placeholder="Название — любое количество слов…"
              className="w-full h-10 pl-9 pr-3 rounded-xl bg-white/[0.04] border border-white/[0.08] text-[13.5px] text-zinc-100 placeholder:text-zinc-600 outline-none focus:border-pink-400/40"
            />
          </span>
          <select value={order} onChange={(e) => setOrder(e.target.value as "latest" | "popular" | "rating")} className={sel}>
            <option value="latest">Свежие главы</option>
            <option value="popular">Популярные</option>
            <option value="rating">По рейтингу</option>
          </select>
          <select value={status} onChange={(e) => setStatus(e.target.value)} className={sel}>
            <option value="">Все статусы</option>
            {Object.entries(RU_STATUS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
          </select>
          <select value={rating} onChange={(e) => setRating(e.target.value)} className={sel}>
            <option value="">Все рейтинги</option>
            {Object.entries(RU_RATING).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
          </select>
          <select value={year} onChange={(e) => setYear(e.target.value)} className={sel}>
            {YEARS.map((y) => <option key={y} value={y}>{y}{y !== "Все годы" ? " год" : ""}</option>)}
          </select>
        </div>
      )}

      {tab !== "favs" && (
        <div className="shrink-0 px-3 sm:px-5 py-2 flex flex-wrap gap-1.5 border-b border-white/[0.08] bg-[#070708] max-h-[72px] overflow-y-auto">
          <button
            onClick={() => setGenre("")}
            className={`h-7 px-2.5 rounded-full text-[11px] border transition ${!genre ? "bg-pink-500 text-white border-pink-400/40" : "border-white/[0.1] text-zinc-400 hover:text-zinc-200 bg-white/[0.04]"}`}
          >
            Все жанры
          </button>
          {genres.filter((g) => TOP_TAGS.includes(g.name)).slice(0, 20).map((g) => (
            <button
              key={g.id}
              onClick={() => setGenre(genre === g.id ? "" : g.id)}
              className={`h-7 px-2.5 rounded-full text-[11px] border transition ${genre === g.id ? "bg-pink-500 text-white border-pink-400/40" : "border-white/[0.1] text-zinc-400 hover:text-zinc-200 bg-white/[0.04]"}`}
              title={g.name}
            >
              {g.name}
            </button>
          ))}
        </div>
      )}

      <div ref={listRef} className="flex-1 min-h-0 overflow-y-auto px-3 sm:px-5 py-4">
        {tab === "favs" ? (
          <>
            {favsLoading && <div className="flex justify-center py-12"><Loader2 className="w-5 h-5 animate-spin text-zinc-500" /></div>}
            {!favsLoading && favItems.length === 0 && (
              <div className="min-h-[50vh] grid place-items-center text-center">
                <div>
                  <Heart className="w-8 h-8 text-zinc-700 mx-auto mb-3" />
                  <p className="text-[13px] text-zinc-500">Избранных манг пока нет.<br />Жми на сердечко на любой карточке — и она появится здесь.</p>
                </div>
              </div>
            )}
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 2xl:grid-cols-7 gap-3">
              {favItems.map((m) => (
                <MangaCard key={m.id} m={m} onOpen={() => setOpenId(m.id)} fav={favs.includes(m.id)} onToggleFav={() => setFavs((prev) => { const n = toggleFav(m.id); return n; })} />
              ))}
            </div>
          </>
        ) : (
          <>
            {items.length === 0 && !loading && (
              <div className="min-h-[40vh] grid place-items-center text-center">
                <div>
                  <BookOpen className="w-8 h-8 text-zinc-700 mx-auto mb-3" />
                  <p className="text-[13px] text-zinc-500">
                    {isSearch ? <>По «{q.trim()}» ничего не нашла.<br />Попробуй другое написание: romaji, английский или японские кандзи.</> : <>Ничего по выбранным фильтрам не найдено.<br />Попробуй убрать часть условий.</>}
                  </p>
                </div>
              </div>
            )}
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 2xl:grid-cols-7 gap-3">
              {items.map((m) => (
                <MangaCard key={m.id} m={m} onOpen={() => setOpenId(m.id)} fav={favs.includes(m.id)} onToggleFav={() => setFavs(() => toggleFav(m.id))} />
              ))}
            </div>
            {loading && (
              <div className="flex justify-center py-6 text-zinc-500 gap-2 items-center">
                <Loader2 className="w-4 h-4 animate-spin" />
                <span className="text-[12px]">{isSearch ? "Ищу по базам…" : "Листаю каталог MangaDex…"}</span>
              </div>
            )}
            {!isSearch && canMore && items.length > 0 && !loading && (
              <div className="flex justify-center py-5">
                <button onClick={() => load(page + 1, false)} className="h-10 px-6 rounded-xl border border-white/[0.1] text-[13px] text-zinc-300 hover:bg-white/[0.05]">
                  Загрузить ещё
                </button>
              </div>
            )}
          </>
        )}
      </div>

      {openId && (
        <MangaDetailsModal
          id={openId}
          onClose={() => setOpenId(null)}
          onUnread={(ch, r) => { setOpenId(null); setReader({ chapter: ch, reader: r }); }}
        />
      )}

      {reader && (
        <ReaderModal
          chapter={reader.chapter}
          reader={reader.reader}
          onClose={() => setReader(null)}
          onPage={() => { /* noop */ }}
        />
      )}
    </div>
  );
}

export default function MangaLibrary() {
  return (
    <Suspense fallback={<div className="min-h-[100dvh] bg-[#050505] grid place-items-center"><div className="w-6 h-6 rounded-full border-2 border-zinc-700 border-t-pink-400 animate-spin" /></div>}>
      <MangaLibraryInner />
    </Suspense>
  );
}

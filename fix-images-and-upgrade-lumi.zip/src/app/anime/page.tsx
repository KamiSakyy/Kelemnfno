"use client";

// Аниме-библиотека Люми: Shikimori (поиск+жанры+хентай) + мульти-источники видео:
// AniLibria (HLS с качествами 360p–2K и весом в МБ), YummyAnime (60 000+, iframe),
// Kodik (все озвучки), AnimeVost (mp4). Сезон подбирается точно по названию/году.
import React, { useCallback, useEffect, useRef, useState } from "react";
import Link from "next/link";
import dynamic from "next/dynamic";
import {
  ArrowLeft, BellCheck, BellPlus, Download, Flame, Loader2, Magnet, Play, Search, Star, Tv, X,
} from "lucide-react";
import { getEpisodesClient, searchAniLibriaClient, type AniLibEpisode } from "@/lib/anilibria-client";
import { getTorrentsClient } from "@/lib/anilibria-catalog";
import { searchKodikDubs, getKodikLinks, searchAnimeVost, type DubSource, type DubLinks, type VostRelease } from "@/lib/media-hub-client";
import { matchSeason } from "@/lib/yummy-server";
import { yummySearchClient, yummyVideosClient, type YumiClientItem, type YumiClientVideo } from "@/lib/media-hub-client";
type YumiItem = YumiClientItem;
type YumiVideo = YumiClientVideo;
import { isSubscribed, addSub, removeSub } from "@/lib/lumi-store";

const CustomVideoPlayer = dynamic(() => import("@/components/VideoPlayer").then((m) => m.CustomVideoPlayer), { ssr: false });

interface AnimeCard {
  id: number; russian: string; name: string; image: string; score: number;
  episodes: number; episodesAired: number; status: string; kind: string; airedOn: string | null;
}
interface Details extends AnimeCard { description: string; genres: string[]; rating: string }
interface Genre { id: number; name: string; russian: string }

const YEARS = ["Все годы", ...Array.from({ length: 38 }, (_, i) => String(2026 - i))];
const STATUS = [
  { id: "", label: "Все" },
  { id: "ongoing", label: "Онгоинги" },
  { id: "released", label: "Завершённые" },
  { id: "anons", label: "Анонсы" },
];
const KINDS = [
  { id: "", label: "Любой тип" },
  { id: "tv", label: "Сериал (TV)" },
  { id: "movie", label: "Фильм" },
  { id: "ova", label: "OVA" },
  { id: "ona", label: "ONA" },
];
const ORDERS = [
  { id: "popularity", label: "По популярности" },
  { id: "ranked", label: "По рейтингу" },
  { id: "aired_on", label: "По новизне" },
];

const statusLabel = (s: string) => (s === "released" ? "Вышло" : s === "ongoing" ? "Онгоинг" : s === "anons" ? "Анонс" : s);

// ── Карточка ─────────────────────────────────────────────────────────────────
function GridCard({ card, onOpen }: { card: AnimeCard; onOpen: () => void }) {
  const [followed, setFollowed] = useState(() => isSubscribed(card.russian || card.name));
  const toggle = (e: React.MouseEvent) => {
    e.stopPropagation();
    const t = card.russian || card.name;
    if (followed) removeSub(t);
    else addSub(t, card.image);
    setFollowed((v) => !v);
  };
  return (
    <div className="group relative text-left cursor-pointer animate-fade-in" onClick={onOpen}>
      <div className="relative aspect-[2/3] rounded-xl overflow-hidden border border-white/[0.06] bg-[#111]">
        {card.image ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={`/${"api/img"}?u=${encodeURIComponent(card.image)}`}
            onError={(e) => { const el = e.currentTarget as HTMLImageElement; if (el.dataset.fallbackSrcDone !== "1") { el.dataset.fallbackSrcDone = "1"; el.src = card.image; } }}
            alt=""
            loading="lazy"
            className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
          />
        ) : (
          <div className="w-full h-full grid place-items-center text-zinc-700"><Tv className="w-8 h-8" /></div>
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-transparent to-transparent" />
        {card.score > 0 && (
          <span className="absolute top-1.5 left-1.5 inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded-md bg-black/70 backdrop-blur text-[11px] font-semibold text-amber-300">
            <Star className="w-3 h-3 fill-current" />{card.score}
          </span>
        )}
        <button
          onClick={toggle}
          className={`absolute top-1.5 right-1.5 w-7 h-7 rounded-lg grid place-items-center backdrop-blur transition ${
            followed ? "bg-fuchsia-500/85 text-white" : "bg-black/55 text-zinc-300 opacity-0 group-hover:opacity-100 hover:text-white"
          }`}
          title={followed ? "Отписаться" : "Следить за сериями"}
        >
          {followed ? <BellCheck className="w-3.5 h-3.5" /> : <BellPlus className="w-3.5 h-3.5" />}
        </button>
        <span className="absolute bottom-1.5 left-1.5 px-1.5 py-0.5 rounded bg-black/60 backdrop-blur text-[9px] font-mono text-zinc-200">{statusLabel(card.status)}</span>
        <div className="absolute inset-0 grid place-items-center opacity-0 group-hover:opacity-100 transition pointer-events-none">
          <span className="w-12 h-12 rounded-full bg-fuchsia-500/90 text-white grid place-items-center shadow-lg"><Play className="w-5 h-5 fill-current ml-0.5" /></span>
        </div>
      </div>
      <div className="mt-1.5 text-[12.5px] text-zinc-200 leading-tight line-clamp-2 group-hover:text-white">{card.russian || card.name}</div>
      <div className="text-[10.5px] text-zinc-500">
        {card.airedOn?.slice(0, 4) || "—"}{card.episodes ? ` · ${card.episodes} эп.` : ""}{card.kind ? ` · ${card.kind.toUpperCase()}` : ""}
      </div>
    </div>
  );
}

// ── Качества скачивания + вес в МБ ───────────────────────────────────────────
function QualityRow({ ep, title }: { ep: AniLibEpisode; title: string }) {
  const quals: { label: string; raw: string }[] = [];
  if (ep.raw1080) quals.push({ label: "1080p", raw: ep.raw1080 });
  if (ep.raw720) quals.push({ label: "720p", raw: ep.raw720 });
  if (ep.raw480) quals.push({ label: "480p", raw: ep.raw480 });
  for (const x of ep.extras || []) quals.push(x);
  const score = (l: string) => (/2k|2160/i.test(l) ? 6 : /1440/.test(l) ? 5 : /1080/.test(l) ? 4 : /720/.test(l) ? 3 : /480/.test(l) ? 2 : /360/.test(l) ? 1 : 0);
  quals.sort((a, b) => score(b.label) - score(a.label));
  const seen = new Set<string>();

  const [sizes, setSizes] = useState<Record<string, number | null>>({});
  const key = ep.ordinal;
  useEffect(() => {
    let dead = false;
    setSizes({});
    const probe = async (tag: string, raw: string) => {
      try {
        const r = await fetch(`/api/stream-size?u=${encodeURIComponent(raw)}`, { cache: "no-store", signal: AbortSignal.timeout(28000) });
        const d = await r.json();
        if (!dead) setSizes((s) => ({ ...s, [tag]: typeof d.mb === "number" ? d.mb : null }));
      } catch {
        if (!dead) setSizes((s) => ({ ...s, [tag]: null }));
      }
    };
    void probe("low", quals[quals.length - 1]?.raw || "");
    void probe("high", quals[0]?.raw || "");
    return () => { dead = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key]);

  const lo = sizes["low"], hi = sizes["high"];
  return (
    <div className="mt-2.5">
      <div className="text-[11px] text-zinc-500 mb-1.5 flex items-center gap-1.5 flex-wrap">
        <Download className="w-3 h-3" />
        Скачать серию {ep.ordinal} (единый .ts-файл)
        {typeof lo === "number" && lo > 0 && typeof hi === "number" && hi > 0 && hi !== lo && <span className="text-[10px] text-zinc-500">(эпизод ≈ {lo} — {hi} МБ трафика)</span>}
        {typeof lo === "number" && lo > 0 && (hi === lo || typeof hi !== "number") && <span className="text-[10px] text-zinc-500">(эпизод ≈ {lo} МБ трафика)</span>}
        {lo == null && hi == null && <Loader2 className="w-3 h-3 animate-spin text-zinc-600" />}
      </div>
      <div className="flex flex-wrap gap-1.5">
        {quals.filter((q) => (seen.has(q.label) ? false : (seen.add(q.label), true))).map((q, i) => {
          const size = i === 0 ? hi : i === quals.length - 1 ? lo : undefined;
          return (
            <a
              key={`${q.label}-${q.raw.slice(-8)}-${i}`}
              href={`/api/download?u=${encodeURIComponent(q.raw)}&name=${encodeURIComponent(`${title.replace(/[^\wа-яё.-]+/gi, "_").slice(0, 30)}_эп${ep.ordinal}_${q.label}`)}`}
              className="h-8 px-3 rounded-lg bg-white/[0.05] hover:bg-white/[0.12] border border-white/[0.1] text-[12px] text-zinc-200 inline-flex items-center gap-1.5 transition"
              title={typeof size === "number" ? `≈ ${size} МБ трафика` : "размер уточняется…"}
            >
              <Download className="w-3.5 h-3.5" />{q.label}
              {/2k|2160/i.test(q.label) && <span className="text-[9px] font-bold text-amber-300">UHD</span>}
              {typeof size === "number" && <span className="text-[10px] font-mono text-zinc-500">≈{size} МБ</span>}
            </a>
          );
        })}
        {quals.length === 0 && <span className="text-[11.5px] text-zinc-600">прямых файлов нет — попробуй магнет ниже</span>}
      </div>
    </div>
  );
}

// ── Модал «Смотреть» ─────────────────────────────────────────────────────────
function WatchView({ card, onClose }: { card: AnimeCard; onClose: () => void }) {
  const [det, setDet] = useState<Details | null>(null);
  const [episodes, setEpisodes] = useState<AniLibEpisode[]>([]);
  const [ep, setEp] = useState<AniLibEpisode | null>(null);
  const [phase, setPhase] = useState<"loading" | "info" | "notfound">("loading");
  const [relName, setRelName] = useState("");
  const [relId, setRelId] = useState(0);
  const [torrents, setTorrents] = useState<{ label: string; magnet: string; sizeGb: number | null }[]>([]);
  // мульти-источники
  const [dubs, setDubs] = useState<DubSource[]>([]);
  const [dubsLoading, setDubsLoading] = useState(true);
  const [vost, setVost] = useState<VostRelease[]>([]);
  const [activeDub, setActiveDub] = useState<string>("libria"); // libria | dubId | vost | yummy
  const [dubBusy, setDubBusy] = useState(false);
  const [dubOpenLinks, setDubOpenLinks] = useState<DubLinks[]>([]);
  const voidRef = useRef(0);
  const [dubEpNum, setDubEpNum] = useState(1);
  const [activeVost, setActiveVost] = useState<VostRelease | null>(null);
  const [vostEp, setVostEp] = useState<string>("");
  // yummy
  const [yumi, setYumi] = useState<YumiItem[]>([]);
  const [activeYumi, setActiveYumi] = useState<YumiItem | null>(null);
  const [yumiLoading, setYumiLoading] = useState(false);
  const [yumiVideos, setYumiVideos] = useState<YumiVideo[]>([]);
  const [yumiEp, setYumiEp] = useState<number>(1);
  const [activeYumiDub, setActiveYumiDub] = useState<string>("");

  useEffect(() => {
    document.body.style.overflow = "hidden";
    return () => { document.body.style.overflow = ""; };
  }, []);

  const cardYear = card.airedOn ? Number(String(card.airedOn).slice(0, 4)) : null;

  useEffect(() => {
    let dead = false;
    (async () => {
      setPhase("loading");
      try { const d = await fetch(`/api/anime?action=details&id=${card.id}`).then((r) => r.json()); if (!dead && d.details) setDet(d.details); } catch { /* optional */ }
      let releases = await searchAniLibriaClient(card.russian || card.name, 8);
      if (releases.length === 0 && card.name) releases = await searchAniLibriaClient(card.name, 8);
      if (releases.length === 0 && card.name) {
        const short = card.name.split(/[:(]/)[0].trim();
        if (short.length >= 3) releases = await searchAniLibriaClient(short, 8);
      }
      const matched = matchSeason(releases, { russian: card.russian || card.name, name: card.name, year: cardYear });
      const rel = (matched as unknown) as typeof releases[number] || releases[0];
      if (!rel) {
        if (!dead) setPhase("notfound");
      } else {
        const e = await getEpisodesClient(rel.id);
        if (dead) return;
        if (!e.episodes.length) { setPhase("notfound"); }
        else {
          setRelName(rel.name);
          setRelId(rel.id);
          setEpisodes(e.episodes);
          setEp(e.episodes[0]);
          setPhase("info");
          setTorrents([]);
          getTorrentsClient(rel.id).then((t) => { if (!dead) setTorrents(t); }).catch(() => undefined);
        }
      }

      // Дополнительные озвучки и источники — параллельно
      (async () => {
        try {
          setDubsLoading(true);
          const [kds, vds] = await Promise.all([
            searchKodikDubs(card.russian || card.name, card.name),
            searchAnimeVost(card.russian || card.name, card.name),
          ]);
          if (!dead) { setDubs(kds); setVost(vds); setDubsLoading(false); }
        } catch { if (!dead) setDubsLoading(false); }
        try {
          const items = await yummySearchClient(card.russian || card.name, card.name);
          if (!dead && items.length) {
            const matchedY = (matchSeason(items as YumiItem[], { russian: card.russian || card.name, name: card.name, year: cardYear }) as unknown as YumiItem) || items[0];
            setYumi(items);
            setActiveYumi(matchedY);
          }
        } catch { /* yummy optional */ }
      })();
    })();
    return () => { dead = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [card.id]);

  // действия с источниками
  const pickDub = async (d: DubSource) => {
    setActiveDub(d.id);
    // сброс всех альтернативных состояний, чтобы не выпрыгивал не тот сезон/не та серия
    setDubOpenLinks([]);
    setDubEpNum(1);
    setActiveVost(null);
    setVostEp("");
    setYumiVideos([]);
    setYumiEp(1);
    setDubBusy(true);
    voidRef.current = ++voidRef.current;
    const links = await getKodikLinks(d.link);
    setDubBusy(false);
    setDubOpenLinks(links);
    setDubEpNum(1);
  };
  const pickVost = (r: VostRelease, firstEp?: string) => {
    setActiveDub("vost");
    // сброс остальных источников
    setDubOpenLinks([]);
    setYumiVideos([]);
    setYumiEp(1);
    setActiveYumiDub("");
    setActiveVost(r);
    setVostEp(firstEp || r.episodes[0]?.num || "1");
  };
  const openYumi = async (item: YumiItem) => {
    setActiveYumi(item);
    setActiveDub("yummy");
    // полный сброс: сезон из Yummy-карточки сам — серии берём начиная с 1
    setDubOpenLinks([]);
    setActiveVost(null);
    setVostEp("");
    setYumiVideos([]);
    setYumiEp(1);
    setActiveYumiDub("");
    setYumiLoading(true);
    try {
      const vids = await yummyVideosClient(item.id);
      setYumiVideos(vids);
      const dubsList = [...new Set(vids.map((v) => v.dubbing))];
      setActiveYumiDub(dubsList[0] || "");
      setYumiEp(1);
    } finally {
      setYumiLoading(false);
    }
  };

  const dubSources = dubOpenLinks.length
    ? dubOpenLinks.map((l) => ({ url: `/api/stream?u=${encodeURIComponent(l.src)}`, label: l.q }))
    : [];
  const vostEpObj = activeVost?.episodes.find((e) => e.num === vostEp);
  const vostSources = vostEpObj
    ? [
        ...(vostEpObj.hd ? [{ url: `/api/stream?u=${encodeURIComponent(vostEpObj.hd)}`, label: "720p mp4" }] : []),
        ...(vostEpObj.std ? [{ url: `/api/stream?u=${encodeURIComponent(vostEpObj.std)}`, label: "480p mp4" }] : []),
      ]
    : [];

  const sources = activeDub === "vost"
    ? vostSources
    : activeDub !== "libria" && activeDub !== "yummy" && dubSources.length
      ? dubSources
      : ep
        ? [
            ...(ep.hls1080 ? [{ url: ep.hls1080, label: "1080p" }] : []),
            ...(ep.hls720 ? [{ url: ep.hls720, label: "720p" }] : []),
            ...(ep.hls480 ? [{ url: ep.hls480, label: "480p" }] : []),
            ...((ep.extras || []).map((x) => ({ url: `/api/stream?u=${encodeURIComponent(x.raw)}`, label: x.label }))),
          ]
        : [];

  const poster = det?.image || card.image;
  const torrid = torrents.find((t) => t.magnet);
  const curYumi = yumiVideos.find((v) => v.number === yumiEp && v.dubbing === activeYumiDub)
    || yumiVideos.find((v) => v.dubbing === activeYumiDub)
    || null;
  const yumiDubList = [...new Set(yumiVideos.map((v) => v.dubbing))];
  const yumiNums = [...new Set(yumiVideos.filter((v) => (activeYumiDub ? v.dubbing === activeYumiDub : true)).map((v) => v.number))].sort((a, b) => a - b);

  return (
    <div className="fixed inset-0 z-[70] bg-black/85 backdrop-blur-sm overflow-y-auto animate-fade-in" onClick={onClose}>
      <div className="min-h-full grid place-items-center p-3 sm:p-6">
        <div className="relative w-full max-w-4xl rounded-2xl border border-white/[0.1] bg-[#0b0b0d] overflow-hidden" onClick={(e) => e.stopPropagation()}>
          {poster && (
            <div className="relative h-40 sm:h-52 overflow-hidden">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={`/${"api/img"}?u=${encodeURIComponent(poster)}`} alt="" className="w-full h-full object-cover blur-md scale-110 opacity-40" />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0b0b0d]" />
              <div className="absolute bottom-3 left-4 right-4 flex items-end gap-3">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={`/${"api/img"}?u=${encodeURIComponent(poster)}`} alt="" className="w-16 sm:w-20 aspect-[2/3] rounded-lg object-cover border border-white/20 shadow-xl" />
                <div className="min-w-0 flex-1 pb-1">
                  <h2 className="text-[17px] sm:text-[20px] font-bold text-white leading-tight">{card.russian || card.name}</h2>
                  <p className="text-[11.5px] text-zinc-400 truncate">{card.name}</p>
                  <div className="mt-1 flex flex-wrap items-center gap-x-2.5 text-[11px] text-zinc-400">
                    {card.score > 0 && <span className="inline-flex items-center gap-0.5 text-amber-300"><Star className="w-3 h-3 fill-current" />{card.score}</span>}
                    {card.airedOn && <span>{card.airedOn.slice(0, 4)}</span>}
                    {det?.rating && <span className="px-1.5 py-0.5 rounded bg-rose-500/[0.2] text-rose-300 text-[9.5px]">{det.rating}</span>}
                    {det?.genres?.slice(0, 4).map((g) => <span key={g} className="text-zinc-500">{g}</span>)}
                  </div>
                </div>
              </div>
            </div>
          )}
          <div className="p-3.5 sm:p-4">
            {phase === "loading" && <div className="h-44 grid place-items-center text-zinc-500"><Loader2 className="w-5 h-5 animate-spin" /></div>}
            {phase === "notfound" && (
              <p className="text-[13px] text-zinc-500 text-center py-6">
                Прямой HLS в AniLibria не нашёлся — выбери источник ниже (Yummy обычно имеет все 24-серийные сезоны с нужной дорожкой).
              </p>
            )}
            {phase === "info" && ep && (
              <>
                {activeDub === "yummy" && activeYumi ? (
                  <div>
                    {yumiLoading ? (
                      <div className="aspect-video grid place-items-center rounded-xl bg-black/40"><Loader2 className="w-5 h-5 animate-spin text-zinc-500" /></div>
                    ) : curYumi ? (
                      <>
                        <div className="aspect-video rounded-xl overflow-hidden bg-black border border-white/[0.08]">
                          <iframe
                            key={`${curYumi.number}|${curYumi.dubbing}`}
                            src={curYumi.iframe}
                            allowFullScreen
                            className="w-full h-full"
                            title={`${activeYumi.title} · серия ${curYumi.number}`}
                            allow="autoplay; encrypted-media; fullscreen; picture-in-picture"
                          />
                        </div>
                        <div className="mt-2 text-[11px] text-zinc-500">
                          Yummy · {curYumi.dubbing} · Серия {curYumi.number}{activeYumi.season ? ` · сезон ${activeYumi.season}` : ""}{activeYumi.year ? ` · ${activeYumi.year}` : ""}{curYumi.duration ? ` · ${Math.round(curYumi.duration / 60)} мин` : ""}
                        </div>
                      </>
                    ) : (
                      <div className="aspect-video grid place-items-center rounded-xl bg-black/40 text-zinc-500 text-[12px] px-4 text-center">
                        Серия у этой дорожки не найдена — выбери другую или другой источник выше.
                      </div>
                    )}
                  </div>
                ) : (
                  <CustomVideoPlayer key={ep.ordinal} poster={poster} sources={sources} />
                )}

                {ep && activeDub !== "yummy" && <QualityRow ep={ep} title={card.russian || card.name} />}

                {/* ————— Мульти-источники / Озвучки ————— */}
                <div className="mt-3.5 border-t border-white/[0.07] pt-3">
                  <div className="text-[11px] uppercase tracking-wider text-zinc-500 mb-2">Источники и озвучки</div>
                  <div className="flex flex-wrap gap-1.5">
                    <button
                      onClick={() => { setActiveDub("libria"); setDubOpenLinks([]); setActiveVost(null); setVostEp(""); setYumiVideos([]); setYumiEp(1); setActiveYumiDub(""); }}
                      className={`h-8 px-2.5 rounded-lg text-[11.5px] border transition ${activeDub === "libria" ? "border-fuchsia-400/40 bg-fuchsia-500/[0.1] text-fuchsia-100" : "border-white/[0.1] text-zinc-400 hover:text-zinc-200 bg-white/[0.04]"}`}
                    >
                      AniLibria · дорожка автора
                    </button>
                    {yumi.map((y) => (
                      <button
                        key={`yumi-${y.id}`}
                        onClick={() => void openYumi(y)}
                        className={`h-8 px-2.5 rounded-lg text-[11.5px] border transition ${activeDub === "yummy" && activeYumi?.id === y.id ? "border-fuchsia-400/40 bg-fuchsia-500/[0.1] text-fuchsia-100" : "border-white/[0.1] text-zinc-400 hover:text-zinc-200 bg-white/[0.04]"}`}
                        title={`${y.title} | ${y.year || "?"} | до ${y.episodesCount ?? "?"} эп.`}
                      >
                        Yummy{y.season ? ` · ${y.season} сезон` : ""}
                      </button>
                    ))}
                    {dubsLoading && <Loader2 className="w-4 h-4 animate-spin text-zinc-600 self-center" />}
                    {dubs.map((d) => (
                      <button
                        key={d.id}
                        onClick={() => void pickDub(d)}
                        className={`h-8 px-2.5 rounded-lg text-[11.5px] border transition inline-flex items-center gap-1.5 ${activeDub === d.id ? "border-fuchsia-400/40 bg-fuchsia-500/[0.1] text-fuchsia-100" : "border-white/[0.1] text-zinc-400 hover:text-zinc-200 bg-white/[0.04]"}`}
                        title={`${d.quality}${d.type === "subtitles" ? " · субтитры" : ""}`}
                      >
                        {d.title}
                        {d.type === "subtitles" && <span className="text-[9px] font-mono px-1 rounded bg-sky-500/15 text-sky-300">SUB</span>}
                      </button>
                    ))}
                    {vost.map((r) => (
                      <button
                        key={`vost-${r.id}`}
                        onClick={() => pickVost(r)}
                        className={`h-8 px-2.5 rounded-lg text-[11.5px] border transition ${activeDub === "vost" ? "border-emerald-400/30 bg-emerald-500/[0.1] text-emerald-200" : "border-white/[0.1] text-zinc-400 hover:text-zinc-200 bg-white/[0.04]"}`}
                      >
                        AnimeVost · {r.title.slice(0, 20)}
                      </button>
                    ))}
                    {!dubsLoading && dubs.length === 0 && vost.length === 0 && yumi.length === 0 && (
                      <span className="text-[11px] text-zinc-600 self-center">Рядом нашлись источники выше — выбери зайку из каталога.</span>
                    )}
                  </div>

                  {dubBusy && <div className="flex items-center gap-2 mt-2 text-[12px] text-zinc-500"><Loader2 className="w-3.5 h-3.5 animate-spin" />Разбираю прямые потоки Kodik…</div>}
                  {activeDub !== "libria" && activeDub !== "vost" && activeDub !== "yummy" && !dubBusy && activeDub !== "" && dubOpenLinks.length === 0 && !dubBusy && voidRef.current > 0 && (
                    <p className="mt-2 text-[11.5px] text-zinc-500">
                      Разбор потоков Kodik сейчас недоступен с этого IP. Официальный плеер Kodik:
                      <a href={`https:${dubs.find((x) => x.id === activeDub)?.link || ""}`} target="_blank" rel="noopener noreferrer" className="ml-1.5 text-fuchsia-300 underline">kodik-embed ↗</a>
                    </p>
                  )}

                  {/* серии Yummy */}
                  {activeDub === "yummy" && yumiVideos.length > 0 && (
                    <div className="mt-2.5">
                      {yumiDubList.length > 1 && (
                        <div className="flex flex-wrap gap-1.5 mb-2">
                          {yumiDubList.map((db) => (
                            <button
                              key={`ytdb-${db}`}
                              onClick={() => setActiveYumiDub(db)}
                              className={`h-7 px-2 rounded-md text-[10.5px] border transition ${activeYumiDub === db ? "border-fuchsia-400/30 bg-fuchsia-500/[0.1] text-fuchsia-200" : "border-white/[0.1] text-zinc-500 hover:text-zinc-300 bg-white/[0.04]"}`}
                            >
                              {db}
                            </button>
                          ))}
                        </div>
                      )}
                      <div className="flex flex-wrap gap-1 max-h-28 overflow-y-auto">
                        {yumiNums.map((n) => (
                          <button
                            key={`ytep-${n}`}
                            onClick={() => setYumiEp(n)}
                            className={`w-9 h-9 rounded-md text-[11px] font-mono transition ${yumiEp === n ? "bg-fuchsia-500 text-white" : "bg-white/[0.05] text-zinc-300 hover:bg-white/[0.1]"}`}
                          >
                            {n}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* серии AnimeVost */}
                  {activeDub === "vost" && activeVost && activeVost.episodes.length > 0 && (
                    <div className="mt-2.5">
                      <div className="text-[11px] text-zinc-500 mb-1.5">АнимеВаст · выбери серию:</div>
                      <div className="flex flex-wrap gap-1 max-h-28 overflow-y-auto">
                        {activeVost.episodes.map((e) => (
                          <button
                            key={`vep-${e.num}`}
                            onClick={() => setVostEp(e.num)}
                            className={`w-9 h-9 rounded-md text-[11px] font-mono transition ${vostEp === e.num ? "bg-emerald-500 text-white" : "bg-white/[0.05] text-zinc-300 hover:bg-white/[0.1]"}`}
                          >
                            {e.num}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {torrid && (
                  <div className="mt-2.5 flex items-center gap-2 flex-wrap">
                    <a href={torrid.magnet} className="h-8 px-3 rounded-lg bg-emerald-500/[0.12] hover:bg-emerald-500/[0.2] border border-emerald-400/25 text-[12px] text-emerald-300 inline-flex items-center gap-1.5 transition">
                      <Magnet className="w-3.5 h-3.5" />
                      Магнет всех серий{torrid.sizeGb ? ` · ${torrid.sizeGb} ГБ` : ""}
                    </a>
                    <span className="text-[10.5px] text-zinc-600">для загрузчиков (qBittorrent и т.п.)</span>
                  </div>
                )}
                {det?.description && <p className="mt-3 text-[12.5px] leading-relaxed text-zinc-500 line-clamp-4">{det.description}</p>}
                <div className="mt-3 flex items-center justify-between text-[11px] text-zinc-600">
                  <span>
                    Серий: {activeDub === "yummy" && activeYumi ? `до ${yumiNums.length || "?"} из ${activeYumi.episodesCount ?? "?"}` : episodes.length > 0 ? episodes.length : "?"}
                    {activeDub !== "yummy" && relName ? ` · ${relName}${relId ? ` · #${relId}` : ""}` : ""}
                  </span>
                  <button onClick={onClose} className="text-zinc-500 hover:text-white">Закрыть</button>
                </div>
                {activeDub !== "yummy" && episodes.length > 1 && (
                  <div className="flex flex-wrap gap-1 max-h-28 overflow-y-auto mt-2">
                    {episodes.map((e) => (
                      <button
                        key={e.ordinal}
                        onClick={() => setEp(e)}
                        className={`w-9 h-9 rounded-md text-[11px] font-mono transition ${ep.ordinal === e.ordinal ? "bg-fuchsia-500 text-white" : "bg-white/[0.05] text-zinc-300 hover:bg-white/[0.1]"}`}
                      >
                        {e.ordinal}
                      </button>
                    ))}
                  </div>
                )}
              </>
            )}
          </div>
          <button onClick={onClose} className="absolute top-3 right-3 w-9 h-9 rounded-xl bg-black/60 backdrop-blur grid place-items-center text-zinc-300 hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Главная ──────────────────────────────────────────────────────────────────
export default function AnimeLibrary() {
  const [q, setQ] = useState("");
  const [year, setYear] = useState("Все годы");
  const [genre, setGenre] = useState("");
  const [kind, setKind] = useState("");
  const [status, setStatus] = useState("");
  const [order, setOrder] = useState("popularity");
  const [genres, setGenres] = useState<Genre[]>([]);
  const [items, setItems] = useState<AnimeCard[]>([]);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(false);
  const [canMore, setCanMore] = useState(true);
  const [open, setOpen] = useState<AnimeCard | null>(null);
  const [note, setNote] = useState("");
  const busyRef = useRef(false);
  const listRef = useRef<HTMLDivElement>(null);
  const isSearch = q.trim().length >= 2;

  useEffect(() => {
    fetch("/api/anime?action=genres")
      .then((r) => r.json())
      .then((d) => setGenres(Array.isArray(d.genres) ? d.genres : []))
      .catch(() => undefined);
  }, []);

  const load = useCallback(
    async (p: number, reset: boolean) => {
      if (busyRef.current) return;
      busyRef.current = true;
      setLoading(true);
      try {
        const params = new URLSearchParams({ order, page: String(p) });
        if (status) params.set("status", status);
        if (kind) params.set("kind", kind);
        if (genre) params.set("genre", genre);
        if (year !== "Все годы") params.set("season", year);

        let results: AnimeCard[] = [];
        if (isSearch) {
          const d = await fetch(`/api/anime?action=search&q=${encodeURIComponent(q.trim())}`).then((r) => r.json());
          results = Array.isArray(d.results) ? d.results : [];
          setCanMore(false);
          setNote(results.length ? `Найдено: ${results.length}` : "");
        } else {
          const d = await fetch(`/api/anime?action=browse&${params.toString()}`).then((r) => r.json());
          results = Array.isArray(d.results) ? d.results : [];
          setCanMore(results.length >= 20);
          setNote("");
        }
        setItems((old) => (reset ? results : [...old, ...results.filter((r) => !old.some((o) => o.id === r.id))]));
        setPage(p);
      } catch {
        setCanMore(false);
      } finally {
        busyRef.current = false;
        setLoading(false);
      }
    },
    [genre, isSearch, kind, order, q, status, year]
  );

  const tRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  useEffect(() => {
    if (tRef.current) clearTimeout(tRef.current);
    tRef.current = setTimeout(() => load(1, true), isSearch ? 750 : 350);
    return () => { if (tRef.current) clearTimeout(tRef.current); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [q, year, genre, kind, status, order]);

  useEffect(() => {
    const el = listRef.current;
    if (!el) return;
    const onScroll = () => {
      if (!canMore || loading || busyRef.current) return;
      if (el.scrollTop + el.clientHeight > el.scrollHeight - 600) load(page + 1, false);
    };
    el.addEventListener("scroll", onScroll);
    return () => el.removeEventListener("scroll", onScroll);
  }, [canMore, loading, page, load]);

  const sel = "h-9 rounded-lg bg-white/[0.05] border border-white/[0.08] px-2.5 text-[12.5px] text-zinc-200 outline-none focus:border-fuchsia-400/40";

  return (
    <div className="h-[100dvh] overflow-hidden bg-[#050505] text-zinc-100 flex flex-col">
      <header className="h-14 shrink-0 px-3 sm:px-5 border-b border-white/[0.08] flex items-center gap-2.5">
        <Link href="/" className="w-9 h-9 rounded-lg grid place-items-center text-zinc-500 hover:text-white hover:bg-white/[0.06]"><ArrowLeft className="w-[18px] h-[18px]" /></Link>
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src="/lumi-avatar.jpg" alt="Люми" className="w-8 h-8 rounded-xl object-cover border border-white/10" />
        <div className="leading-tight">
          <div className="text-[13.5px] font-bold">Аниме-библиотека</div>
          <div className="text-[10px] text-zinc-600 flex items-center gap-1"><Flame className="w-2.5 h-2.5 text-fuchsia-400" />Shikimori · Yummy · Kodik · AniLibria · AnimeVost</div>
        </div>
        <Link href="/songs" className="ml-auto h-8 px-3 rounded-lg bg-pink-500/[0.12] border border-pink-400/30 text-[12px] text-pink-200 inline-flex items-center gap-1.5 hover:bg-pink-500/[0.2] transition">
          Песни аниме
        </Link>
        <span className="text-[11px] font-mono text-zinc-600">{note}</span>
      </header>

      <div className="shrink-0 px-3 sm:px-5 py-2.5 border-b border-white/[0.08] flex flex-wrap items-center gap-2 bg-[#070708]">
        <span className="relative flex-1 min-w-[180px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-600" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Поиск по названию — любое количество слов…"
            className="w-full h-10 pl-9 pr-3 rounded-xl bg-white/[0.04] border border-white/[0.08] text-[13.5px] text-zinc-100 placeholder:text-zinc-600 outline-none focus:border-fuchsia-400/40"
          />
        </span>
        <select value={genre} onChange={(e) => setGenre(e.target.value)} className={sel} title="Жанр — все жанры Shikimori">
          <option value="">Все жанры</option>
          {genres.map((g) => <option key={g.id} value={String(g.id)}>{g.russian}</option>)}
        </select>
        <select value={year} onChange={(e) => setYear(e.target.value)} className={sel}>
          {YEARS.map((y) => <option key={y} value={y}>{y}{y !== "Все годы" ? " год" : ""}</option>)}
        </select>
        <select value={kind} onChange={(e) => setKind(e.target.value)} className={sel}>
          {KINDS.map((k) => <option key={k.id} value={k.id}>{k.label}</option>)}
        </select>
        <select value={status} onChange={(e) => setStatus(e.target.value)} className={sel}>
          {STATUS.map((s) => <option key={s.id} value={s.id}>{s.label}</option>)}
        </select>
        <select value={order} onChange={(e) => setOrder(e.target.value)} className={sel} disabled={isSearch} title={isSearch ? "В поиске сортировка по релевантности" : undefined}>
          {ORDERS.map((o) => <option key={o.id} value={o.id}>{o.label}</option>)}
        </select>
      </div>

      <div ref={listRef} className="flex-1 min-h-0 overflow-y-auto px-3 sm:px-5 py-4">
        {items.length === 0 && !loading && (
          <div className="min-h-[40vh] grid place-items-center text-center">
            <div>
              <Tv className="w-6 h-6 text-zinc-700 mx-auto mb-3" />
              <p className="text-[13px] text-zinc-500">
                {isSearch ? <>По запросу «{q.trim()}» ничего не нашла.<br />Попробуй другое написание или убери часть фильтров.</> : <>Ничего по выбранным фильтрам не найдено.<br />Попробуй убрать часть условий.</>}
              </p>
            </div>
          </div>
        )}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 2xl:grid-cols-7 gap-3">
          {items.map((c) => (
            <GridCard key={c.id} card={c} onOpen={() => setOpen(c)} />
          ))}
        </div>
        {loading && (
          <div className="flex justify-center py-6 text-zinc-500 gap-2 items-center">
            <Loader2 className="w-4 h-4 animate-spin" />
            <span className="text-[12px]">{isSearch ? "Ищу по базам…" : "Листаю каталог…"}</span>
          </div>
        )}
        {!isSearch && canMore && items.length > 0 && !loading && (
          <div className="flex justify-center py-5">
            <button onClick={() => load(page + 1, false)} className="h-10 px-6 rounded-xl border border-white/[0.1] text-[13px] text-zinc-300 hover:bg-white/[0.05]">
              Загрузить ещё
            </button>
          </div>
        )}
      </div>

      {open && <WatchView card={open} onClose={() => setOpen(null)} />}
    </div>
  );
}

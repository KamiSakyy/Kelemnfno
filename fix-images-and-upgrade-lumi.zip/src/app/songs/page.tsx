"use client";

// Люми · Аниме-песни: живой каталог OP/ED/OST (AniList + iTunes-превью 30с).
// Нативный чёрный интерфейс как приложение: липкие плеер-бар снизу + большие
// обложки + избранное + поиск по аниме и песням. Без ключей, 100% рабочий.
import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import {
  ArrowLeft, Disc3, Flame, Heart, Loader2, Music2, Play, Pause, Search, SkipBack, SkipForward,
  Sparkles, Star, Tv, ExternalLink, Disc2, Volume2, VolumeX, ListMusic, Bookmark,
} from "lucide-react";
import {
  searchAnimeList, topSections, searchSongsByAnime, animeSongsOf,
  type AL_Anime, type AL_Anime as Anime, type SongItem, type SongSection, type AL_TopSection,
} from "@/lib/anilist";

// ── избранное (localStorage) —───────────────────────────────────────────────
const FK = "lumi:song-favs";
const getFavs = (): SongItem[] => {
  if (typeof window === "undefined") return [];
  try { return JSON.parse(localStorage.getItem(FK) || "[]"); } catch { return []; }
};
const saveFavs = (list: SongItem[]) => { localStorage.setItem(FK, JSON.stringify(list.slice(0, 400))); window.dispatchEvent(new Event("lumi:song-favs")); };
const isFav = (list: SongItem[], id: string) => list.some((f) => f.id === id);

// ── аудио-движок (одно живое <audio>) —──────────────────────────────────────
const fmt = (sec: number) => `${Math.floor(sec / 60)}:${String(Math.floor(sec % 60)).padStart(2, "0")}`;

export default function SongsLibrary() {
  const [q, setQ] = useState("");
  const [animes, setAnimes] = useState<AL_Anime[]>([]);
  const [animeLoading, setAnimeLoading] = useState(false);
  const [activeAnime, setActiveAnime] = useState<AL_Anime | null>(null);
  const [songs, setSongs] = useState<SongItem[]>([]);
  const [songsLoading, setSongsLoading] = useState(false);
  const [sections, setSections] = useState<SongSection[]>([]);
  const [tops, setTops] = useState<AL_TopSection[]>([]);
  const [favs, setFavs] = useState<SongItem[]>([]);
  const [tab, setTab] = useState<"search" | "tops" | "favs">("search");

  // аудио
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [queue, setQueue] = useState<SongItem[]>([]);
  const [qi, setQi] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [cur, setCur] = useState(0);
  const [dur, setDur] = useState(0);
  const [muted, setMuted] = useState(false);

  useEffect(() => { setFavs(getFavs()); const f = () => setFavs(getFavs()); window.addEventListener("lumi:song-favs", f); return () => window.removeEventListener("lumi:song-favs", f); }, []);
  useEffect(() => {
    topSections().then(setTops);
  }, []);

  useEffect(() => {
    const a = audioRef.current || (audioRef.current = new Audio());
    a.volume = muted ? 0 : 1;
  }, [muted]);

  const playSong = useCallback((idx: number, list: SongItem[]) => {
    const a = audioRef.current || (audioRef.current = new Audio());
    if (list) setQueue(list);
    const q = (list && list.length ? list : queue);
    const song = q[idx];
    if (!song) return;
    setQi(idx);
    a.src = song.preview;
    a.play().then(() => setPlaying(true)).catch(() => setPlaying(false));
    setCur(0);
    a.onended = () => {
      if (idx + 1 < q.length) playSong(idx + 1, q);
      else setPlaying(false);
    };
  }, [queue]);

  const toggle = useCallback(() => {
    const a = audioRef.current;
    if (!a || !a.src) return;
    if (playing) { a.pause(); setPlaying(false); }
    else { a.play().then(() => setPlaying(true)); }
  }, [playing]);

  const next = useCallback(() => { if (queue.length) playSong((qi + 1) % queue.length, queue); }, [queue, qi, playSong]);
  const prev = useCallback(() => { if (queue.length) playSong((qi - 1 + queue.length) % queue.length, queue); }, [queue, qi, playSong]);

  useEffect(() => {
    const t = window.setInterval(() => {
      const a = audioRef.current;
      if (!a) return;
      setCur(a.currentTime || 0);
      setDur(a.duration || 0);
    }, 500);
    return () => window.clearInterval(t);
  }, []);

  const curSong = queue[qi];

  // поиск аниме
  const tRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  useEffect(() => {
    if (tRef.current) clearTimeout(tRef.current);
    const s = q.trim();
    if (s.length < 2) { setAnimes([]); return; }
    tRef.current = setTimeout(async () => {
      setAnimeLoading(true);
      const r = await searchAnimeList(s, 10);
      setAnimes(r);
      setAnimeLoading(false);
    }, 450);
    return () => { if (tRef.current) clearTimeout(tRef.current); };
  }, [q]);

  const loadSongs = async (a: AL_Anime) => {
    setActiveAnime(a);
    setSongsLoading(true);
    setSongs([]);
    const list = await searchSongsByAnime(a);
    setSongs(list);
    setQueue(list);
    setSongsLoading(false);
    if (list.length) playSong(0, list);
    window.dispatchEvent(new Event("lumi:song-favs"));
  };

  useEffect(() => {
    if (tab !== "tops" || tops.length === 0 || sections.length > 0) return;
    let dead = false;
    (async () => {
      const first = tops[0];
      if (!first) return;
      const secs = await animeSongsOf(first.items, 4, 6);
      if (!dead) setSections(secs);
    })();
    return () => { dead = true; };
  }, [tab, tops, sections.length]);

  const songCard = (s: SongItem, list: SongItem[]) => {
    const fav = isFav(favs, s.id);
    const isCur = curSong?.id === s.id;
    return (
      <div key={s.id} className={`group relative flex gap-3 p-2.5 rounded-2xl border transition ${isCur ? "border-fuchsia-400/40 bg-fuchsia-500/[0.07]" : "border-white/[0.08] bg-[#101013] hover:border-white/[0.16]"}`}>
        <button onClick={playing && isCur ? toggle : () => playSong(list.indexOf(s), list)} className="relative shrink-0 w-14 h-14 sm:w-16 sm:h-16 rounded-xl overflow-hidden border border-white/[0.08]">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={s.bigCover || s.cover} alt="" loading="lazy" className="w-full h-full object-cover" />
          <span className={`absolute inset-0 grid place-items-center transition ${isCur && (playing) ? "bg-black/50 opacity-100" : "bg-black/0 group-hover:bg-black/40 opacity-0 group-hover:opacity-100"}`}>
            {isCur && playing ? <Pause className="w-5 h-5 text-white fill-current" /> : <Play className="w-5 h-5 text-white fill-current ml-0.5" />}
          </span>
        </button>
        <div className="min-w-0 flex-1">
          <div className="text-[13px] font-semibold text-zinc-100 truncate">{s.title}</div>
          <div className="text-[11px] text-zinc-500 truncate">{s.artist}</div>
          <div className="mt-1 flex items-center gap-2 text-[10px] font-mono">
            <span className={`px-1.5 py-0.5 rounded font-bold ${s.type === "OP" ? "bg-fuchsia-500/20 text-fuchsia-300" : s.type === "ED" ? "bg-amber-500/20 text-amber-300" : s.type === "OST" ? "bg-sky-500/15 text-sky-300" : "bg-white/[0.08] text-zinc-400"}`}>
              {s.type}
            </span>
            {s.duration ? <span className="text-zinc-600">{fmt(s.duration)}</span> : null}
            {s.anime && <span className="text-zinc-600 truncate">· {s.anime.slice(0, 26)}</span>}
          </div>
        </div>
        <div className="flex flex-col items-center justify-center gap-1.5 shrink-0">
          <button
            onClick={() => {
              const list2 = favs.slice();
              const idx = list2.findIndex((x) => x.id === s.id);
              if (idx >= 0) list2.splice(idx, 1); else list2.unshift(s);
              saveFavs(list2);
            }}
            className={`w-8 h-8 rounded-lg grid place-items-center transition ${fav ? "text-pink-400 bg-pink-500/[0.1]" : "text-zinc-600 hover:text-pink-300 hover:bg-white/[0.06]"}`}
            title={fav ? "Убрать из избранного" : "В избранное"}
          >
            <Heart className={`w-4 h-4 ${fav ? "fill-current" : ""}`} />
          </button>
          {s.appleUrl && (
            <a href={s.appleUrl} target="_blank" rel="noopener noreferrer" className="w-8 h-8 rounded-lg grid place-items-center text-zinc-600 hover:text-fuchsia-300 hover:bg-white/[0.06]" title="Полная версия в Apple Music">
              <ExternalLink className="w-4 h-4" />
            </a>
          )}
        </div>
      </div>
    );
  };

  const progress = dur > 0 ? Math.min(100, (cur / dur) * 100) : 0;

  return (
    <div className="min-h-[100dvh] bg-[#050505] text-zinc-100 flex flex-col">
      {/* header */}
      <header className="sticky top-0 z-20 h-14 shrink-0 px-3 sm:px-5 border-b border-white/[0.08] flex items-center gap-2.5 bg-[#050505]/95 backdrop-blur">
        <Link href="/" className="w-9 h-9 rounded-lg grid place-items-center text-zinc-500 hover:text-white hover:bg-white/[0.06]">
          <ArrowLeft className="w-[18px] h-[18px]" />
        </Link>
        <Link href="/anime" className="hidden sm:block">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src="/lumi-avatar.jpg" alt="Люми" className="w-8 h-8 rounded-xl object-cover border border-white/10" />
        </Link>
        <div className="leading-tight min-w-0">
          <div className="text-[13.5px] font-bold flex items-center gap-1.5"><Disc3 className="w-4 h-4 text-pink-400" />Аниме-песни</div>
          <div className="text-[10px] text-zinc-600">Опенинги · Эндинги · OST · превью полных форматов</div>
        </div>
        <span className="ml-auto text-[10px] font-mono text-pink-300/80 hidden sm:inline">SOURCES: ANILIST · APPLE MUSIC PREVIEWS</span>
      </header>

      {/* tab bar */}
      <div className="shrink-0 px-3 sm:px-5 pt-3 pb-2 flex gap-1.5">
        {(
          [
            { id: "search" as const, label: "Поиск", icon: Search },
            { id: "tops" as const, label: "Топы недели", icon: Flame },
            { id: "favs" as const, label: "Избранное", icon: Bookmark },
          ]
        ).map((t) => {
          const Icon = t.icon;
          return (
            <button key={t.id} onClick={() => setTab(t.id)} className={`flex-1 h-9 rounded-xl text-[12px] font-medium inline-flex items-center justify-center gap-1.5 transition ${tab === t.id ? "bg-white text-black" : "bg-white/[0.04] text-zinc-400 hover:text-zinc-200"}`}>
              <Icon className="w-3.5 h-3.5" />{t.label}
            </button>
          );
        })}
      </div>

      <main className="flex-1 min-h-0 overflow-y-auto px-3 sm:px-5 pb-[90px] pt-2">
        {/* ── ПОИСК ── */}
        {tab === "search" && (
          <>
            <div className="relative max-w-2xl">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-600" />
              <input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Аниме или песня: Наруто, О болизнью из слизи, Gurenge…"
                className="w-full h-11 pl-10 pr-3 rounded-2xl bg-white/[0.04] border border-white/[0.08] text-[14px] text-zinc-100 placeholder:text-zinc-600 outline-none focus:border-pink-400/40"
              />
            </div>

            {/* найденные аниме */}
            {animes.length > 0 && (
              <div className="mt-3 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2.5">
                {animes.map((a) => (
                  <button
                    key={a.id}
                    onClick={() => loadSongs(a)}
                    className={`group relative rounded-2xl overflow-hidden border transition text-left ${activeAnime?.id === a.id ? "border-pink-400/40 bg-pink-500/[0.06]" : "border-white/[0.08] bg-[#101013] hover:border-white/[0.18]"}`}
                  >
                    <div className="relative aspect-[2/3] overflow-hidden">
                      {a.cover ? (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img src={a.cover} alt="" loading="lazy" className="w-full h-full object-cover group-hover:scale-105 transition duration-300" />
                      ) : (
                        <div className="w-full h-full grid place-items-center text-zinc-700"><Music2 className="w-8 h-8" /></div>
                      )}
                      <div className="absolute inset-0 bg-gradient-to-t from-black/85 to-transparent" />
                      <span className="absolute bottom-2 left-2 right-2 text-[12px] font-semibold leading-tight line-clamp-2">{a.romaji}</span>
                      {a.score && <span className="absolute top-1.5 right-1.5 px-1.5 py-0.5 rounded bg-black/70 text-[10px] font-bold text-amber-300 inline-flex items-center gap-0.5"><Star className="w-2.5 h-2.5 fill-current" />{a.score}</span>}
                    </div>
                    <div className="px-2.5 py-2 text-[10.5px] text-zinc-500 truncate">
                      {a.year ?? "—"}{a.episodes ? ` · ${a.episodes} эп.` : ""}{a.genres[0] ? ` · ${a.genres[0]}` : ""}
                    </div>
                  </button>
                ))}
              </div>
            )}
            {animeLoading && <div className="flex items-center gap-2 py-6 text-zinc-500"><Loader2 className="w-4 h-4 animate-spin" />Ищу аниме…</div>}

            {/* секции песен по аниме-выборке */}
            {activeAnime && (
              <div className="mt-4">
                <div className="flex items-center gap-2 text-[13px] font-bold text-zinc-200">
                  <ListMusic className="w-4 h-4 text-pink-400" />
                  {activeAnime.romaji} · Песни
                  {songsLoading && <Loader2 className="w-4 h-4 animate-spin text-zinc-500" />}
                </div>
                <div className="mt-2.5 grid sm:grid-cols-2 lg:grid-cols-3 gap-2">
                  {songs.map((s) => songCard(s, songs))}
                  {!songsLoading && songs.length === 0 && (
                    <p className="text-[12px] text-zinc-600 col-span-full">По этому аниме песни-превью не найдены — попробуй другое название или часть (romaji).</p>
                  )}
                </div>
              </div>
            )}

            {!isSearchResult && !animeLoading && q.trim().length < 2 && tops.length > 0 && (
              <>
                {tops.map((sec) => (
                  <div key={sec.title} className="mt-6">
                    <div className="text-[13px] font-bold text-zinc-200 mb-2.5 flex items-center gap-2"><Flame className="w-4 h-4 text-pink-400" />{sec.title}</div>
                    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2.5">
                      {sec.items.map((a) => (
                        <button
                          key={a.id}
                          onClick={() => loadSongs(a)}
                          className={`group relative rounded-2xl overflow-hidden border transition text-left ${activeAnime?.id === a.id ? "border-pink-400/40" : "border-white/[0.08] hover:border-white/[0.18] bg-[#101013]"}`}
                        >
                          <div className="relative aspect-[2/3] overflow-hidden">
                            {a.cover && (
                              // eslint-disable-next-line @next/next/no-img-element
                              <img src={a.cover} alt="" loading="lazy" className="w-full h-full object-cover group-hover:scale-105 transition duration-300" />
                            )}
                            <div className="absolute inset-0 bg-gradient-to-t from-black/85 to-transparent" />
                            <span className="absolute bottom-2 left-2 right-2 text-[12px] font-semibold leading-tight line-clamp-2">{a.romaji}</span>
                          </div>
                          <div className="px-2.5 py-2 text-[10.5px] text-zinc-500 truncate">
                            {a.year ?? "—"}{a.genres[0] ? ` · ${a.genres[0]}` : ""}
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>
                ))}
              </>
            )}
          </>
        )}

        {/* ── ТОПЫ НЕДЕЛИ ── */}
        {tab === "tops" && (
          <>
            {!sections.length && <div className="flex items-center gap-2 py-8 text-zinc-500"><Loader2 className="w-4 h-4 animate-spin" />Собираю хиты недели…</div>}
            {sections.map((sec) => (
              <div key={sec.anime.id} className="mt-5">
                <div className="flex items-center gap-2 text-[13px] font-bold text-zinc-200 mb-2.5">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  {sec.anime.cover && <img src={sec.anime.cover} alt="" className="w-8 h-8 rounded-lg object-cover" />}
                  {sec.anime.romaji}
                  <span className="text-[10.5px] font-normal text-zinc-600">{sec.anime.year ?? ""}</span>
                </div>
                <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-2">
                  {sec.songs.map((s) => songCard(s, sec.songs))}
                </div>
              </div>
            ))}
          </>
        )}

        {/* ── ИЗБРАННОЕ ── */}
        {tab === "favs" && (
          <>
            {favs.length === 0 ? (
              <div className="min-h-[50vh] grid place-items-center text-center">
                <div>
                  <Heart className="w-8 h-8 text-zinc-700 mx-auto mb-3" />
                  <p className="text-[13px] text-zinc-500">Избранного пока пусто.<br />Жми на сердечко у любой песни — и она появится здесь.</p>
                </div>
              </div>
            ) : (
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-2 pt-1">
                {favs.map((s) => songCard(s, favs))}
              </div>
            )}
          </>
        )}
      </main>

      {/* ► Нижняя нативная плеер-панель */}
      {curSong && (
        <div className="fixed bottom-0 inset-x-0 z-30 border-t border-white/[0.08] bg-[#0a0a0c]/96 backdrop-blur">
          <div className="h-1 bg-white/[0.04]">
            <div className="h-full bg-gradient-to-r from-pink-500 to-fuchsia-400 transition-all duration-300" style={{ width: `${progress}%` }} />
          </div>
          <div className="max-w-5xl mx-auto px-3 py-2 flex items-center gap-3">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={curSong.bigCover || curSong.cover} alt="" className="w-11 h-11 rounded-xl object-cover border border-white/[0.08]" />
            <div className="min-w-0 flex-1">
              <div className="text-[13px] font-semibold truncate">{curSong.title}</div>
              <div className="text-[10.5px] text-zinc-500 truncate">{curSong.artist} · {fmt(cur)} / {dur ? fmt(dur) : "…"}</div>
            </div>
            <button onClick={prev} className="w-9 h-9 rounded-xl grid place-items-center text-zinc-400 hover:text-white hover:bg-white/[0.06]">
              <SkipBack className="w-4 h-4 fill-current" />
            </button>
            <button onClick={toggle} className="w-11 h-11 rounded-full bg-white text-black grid place-items-center active:scale-95 transition">
              {playing ? <Pause className="w-4 h-4 fill-current" /> : <Play className="w-4 h-4 fill-current ml-0.5" />}
            </button>
            <button onClick={next} className="w-9 h-9 rounded-xl grid place-items-center text-zinc-400 hover:text-white hover:bg-white/[0.06]">
              <SkipForward className="w-4 h-4 fill-current" />
            </button>
            <button onClick={() => setMuted((v) => !v)} className="w-9 h-9 rounded-xl grid place-items-center text-zinc-500 hover:text-zinc-200 hover:bg-white/[0.06]" title="Громкость">
              {muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

const isSearchResult = false;

import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

const fontVars = {
  "--font-jakarta": "system-ui, -apple-system, 'Segoe UI', Roboto, 'Noto Sans', sans-serif",
  "--font-inter": "system-ui, -apple-system, 'Segoe UI', Roboto, 'Noto Sans', sans-serif",
  "--font-mono": "'JetBrains Mono', ui-monospace, SFMono-Regular, Menlo, Consolas, monospace",
} as const;

export const metadata: Metadata = {
  title: "Люми — аниме-подруга и ИИ-программист",
  description:
    "Люми (18) — милая аниме-девушка ИИ. Ищет и рисует арты, находит персонажей, показывает аниме, следит за выходом серий, пишет код без ошибок и отвечает коротко и по делу.",
  applicationName: "Люми",
  icons: { icon: "/lumi-avatar.jpg", apple: "/lumi-avatar.jpg" },
  appleWebApp: { capable: true, statusBarStyle: "black-translucent", title: "Люми" },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  viewportFit: "cover",
  themeColor: "#050505",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ru" className="dark">
      <head>
        <style>{`:root{font-family:var(--font-jakarta)}:root{`}</style>
      </head>
      <body className="bg-[#050505] text-zinc-100 antialiased selection:bg-white/20 selection:text-white">
        {children}
      </body>
    </html>
  );
}

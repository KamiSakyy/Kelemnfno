import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { chatSessions, chatMessages } from "@/db/schema";
import { ensureSeededDatabase } from "@/lib/ai-router";
import { sanitizeForDisplay } from "@/lib/display";
import { asc, desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

const DEFAULT_TITLE = "Новый диалог";

async function listSessions() {
  return db
    .select()
    .from(chatSessions)
    .orderBy(desc(chatSessions.isPinned), desc(chatSessions.updatedAt));
}

async function listMessages(sessionId: number) {
  return db
    .select()
    .from(chatMessages)
    .where(eq(chatMessages.sessionId, sessionId))
    .orderBy(asc(chatMessages.createdAt), asc(chatMessages.id));
}

export async function GET(req: NextRequest) {
  try {
    await ensureSeededDatabase();
    const { searchParams } = new URL(req.url);
    const sessionIdParam = searchParams.get("sessionId");

    const sessions = await listSessions();
    let activeSession = sessions[0] || null;
    if (sessionIdParam) {
      const found = sessions.find((s) => s.id === Number(sessionIdParam));
      if (found) activeSession = found;
    }
    const messages = activeSession ? await listMessages(activeSession.id) : [];
    return NextResponse.json({ sessions, activeSession, messages: sanitizeForDisplay(messages) });
  } catch (error) {
    console.error("GET /api/sessions error:", error);
    return NextResponse.json({ error: "Failed to fetch sessions" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    await ensureSeededDatabase();
    const body = await req.json().catch(() => ({}));
    const title = typeof body.title === "string" && body.title.trim() ? body.title.trim() : DEFAULT_TITLE;

    const validModes = ["chat", "battle", "dialogue", "github"];
    const chatMode = validModes.includes(body.chatMode) ? body.chatMode : "chat";
    const [created] = await db
      .insert(chatSessions)
      .values({
        title,
        routingMode: body.routingMode || "auto",
        systemPersona: body.systemPersona || "universal",
        chatMode,
        repoFullName: typeof body.repoFullName === "string" ? body.repoFullName : null,
        repoBranch: typeof body.repoBranch === "string" ? body.repoBranch : null,
      })
      .returning();

    return NextResponse.json({ session: created, sessions: await listSessions(), messages: [] });
  } catch (error) {
    console.error("POST /api/sessions error:", error);
    return NextResponse.json({ error: "Failed to create session" }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const body = await req.json();
    const sessionId = Number(body.sessionId);
    if (!sessionId) return NextResponse.json({ error: "Missing sessionId" }, { status: 400 });

    const updates: Partial<typeof chatSessions.$inferInsert> = {};
    if (typeof body.routingMode === "string") updates.routingMode = body.routingMode;
    if (typeof body.systemPersona === "string") updates.systemPersona = body.systemPersona;
    if (typeof body.title === "string" && body.title.trim()) updates.title = body.title.trim().slice(0, 80);
    if (typeof body.isPinned === "boolean") updates.isPinned = body.isPinned;
    if (typeof body.chatMode === "string") updates.chatMode = body.chatMode;
    if (typeof body.repoFullName === "string") updates.repoFullName = body.repoFullName;
    if (typeof body.repoBranch === "string") updates.repoBranch = body.repoBranch;
    if (body.touch === true) updates.updatedAt = new Date();

    const [updated] = await db.update(chatSessions).set(updates).where(eq(chatSessions.id, sessionId)).returning();
    return NextResponse.json({ session: updated, sessions: await listSessions() });
  } catch (error) {
    console.error("PATCH /api/sessions error:", error);
    return NextResponse.json({ error: "Failed to update session" }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const deleteAll = searchParams.get("all") === "1";
    if (deleteAll) {
      await db.delete(chatMessages);
      await db.delete(chatSessions);
      return NextResponse.json({ sessions: [], activeSession: null, messages: [] });
    }
    const sessionId = Number(searchParams.get("sessionId"));
    const clearMessages = searchParams.get("clear") === "1";
    if (!sessionId) return NextResponse.json({ error: "Missing sessionId" }, { status: 400 });

    if (clearMessages) {
      await db.delete(chatMessages).where(eq(chatMessages.sessionId, sessionId));
      await db
        .update(chatSessions)
        .set({ messageCount: 0, totalTokens: 0, updatedAt: new Date() })
        .where(eq(chatSessions.id, sessionId));
      const sessions = await listSessions();
      const activeSession = sessions.find((s) => s.id === sessionId) || sessions[0] || null;
      return NextResponse.json({ sessions, activeSession, messages: [] });
    }

    // Cascade delete removes messages via FK; also clear explicitly to be safe.
    await db.delete(chatMessages).where(eq(chatMessages.sessionId, sessionId));
    await db.delete(chatSessions).where(eq(chatSessions.id, sessionId));
    const sessions = await listSessions();
    // Don't force-create a dummy chat — let the UI show a clean empty state.
    const activeSession = sessions[0] || null;
    const messages = activeSession ? await listMessages(activeSession.id) : [];
    return NextResponse.json({ sessions, activeSession, messages: sanitizeForDisplay(messages) });
  } catch (error) {
    console.error("DELETE /api/sessions error:", error);
    return NextResponse.json({ error: "Failed to delete session" }, { status: 500 });
  }
}

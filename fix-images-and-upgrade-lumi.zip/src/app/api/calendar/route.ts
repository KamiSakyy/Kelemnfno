// Календарь выхода серий на ближайшие дни (Shikimori, живые данные).
import { NextResponse } from "next/server";
import { getAnimeCalendar } from "@/lib/anime";

export const dynamic = "force-dynamic";
export const maxDuration = 30;

export async function GET() {
  const items = await getAnimeCalendar(16);
  // сортируем по дате выхода серии
  items.sort((a, b) => +new Date(a.nextEpisodeAt) - +new Date(b.nextEpisodeAt));
  return NextResponse.json({ items });
}

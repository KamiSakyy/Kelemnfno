import { NextRequest } from "next/server";

export const dynamic = "force-dynamic";
export const maxDuration = 120;

const ALLOWED_HOST = /(^|\.)libria\.fun$|(^|\.)anilibria\.(top|tv)$|(^|\.)wwnd\.space$/i;

// Proxy AniLibria HLS so playback works with guaranteed CORS + no ad params.
// - .m3u8: rewrite every segment/child-playlist URL to go back through us
// - .ts / other: stream bytes with permissive CORS headers
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const target = searchParams.get("u");
  if (!target) return new Response("Missing u", { status: 400 });

  let url: URL;
  try {
    url = new URL(target);
  } catch {
    return new Response("Bad url", { status: 400 });
  }
  if (!ALLOWED_HOST.test(url.hostname)) {
    return new Response("Host not allowed", { status: 403 });
  }

  const upstream = await fetch(url.toString(), {
    headers: {
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124.0 Safari/537.36",
      Accept: "*/*",
      Referer: "https://anilibria.top/",
    },
    signal: AbortSignal.timeout(60000),
  }).catch(() => null);

  if (!upstream || !upstream.ok) {
    return new Response("Upstream error", { status: 502 });
  }

  const ct = upstream.headers.get("content-type") || "";
  const isPlaylist = url.pathname.endsWith(".m3u8") || ct.includes("mpegurl");

  const cors = {
    "Access-Control-Allow-Origin": "*",
    "Cache-Control": "public, max-age=60",
  };

  if (isPlaylist) {
    const text = await upstream.text();
    const base = url.href.slice(0, url.href.lastIndexOf("/") + 1);
    const rewritten = text
      .split("\n")
      .map((line) => {
        const t = line.trim();
        if (!t || t.startsWith("#")) {
          // rewrite URI="..." inside EXT tags (keys, maps)
          return line.replace(/URI="([^"]+)"/g, (_m, u) => {
            const abs = u.startsWith("http") ? u : base + u;
            return `URI="/api/stream?u=${encodeURIComponent(abs)}"`;
          });
        }
        // segment or child playlist line
        const abs = t.startsWith("http") ? t : base + t;
        return `/api/stream?u=${encodeURIComponent(abs)}`;
      })
      .join("\n");
    return new Response(rewritten, {
      status: 200,
      headers: { ...cors, "Content-Type": "application/vnd.apple.mpegurl" },
    });
  }

  // Binary segment — stream through
  return new Response(upstream.body, {
    status: 200,
    headers: {
      ...cors,
      "Content-Type": ct || "video/mp2t",
    },
  });
}

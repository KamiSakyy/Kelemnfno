// YummyAnime bridge: поиск и серии для модуля мульти-источников.
// GET ?action=search&q=... | ?action=videos&id=...
import { NextRequest, NextResponse } from "next/server";
import { yummySearch, yummyVideos } from "@/lib/yummy-server";

export const dynamic = "force-dynamic";
export const maxDuration = 30;

export async function GET(req: NextRequest) {
  const p = req.nextUrl.searchParams;
  const action = p.get("action");
  try {
    if (action === "search") {
      const q = p.get("q") || "";
      const alt = p.get("alt") || undefined;
      return NextResponse.json({ items: await yummySearch(q, alt) });
    }
    if (action === "videos") {
      const id = Number(p.get("id"));
      if (!id) return NextResponse.json({ videos: [] });
      return NextResponse.json({ videos: await yummyVideos(id) });
    }
    return NextResponse.json({ error: "action?" }, { status: 400 });
  } catch {
    return NextResponse.json({ error: "yummy unavailable" }, { status: 502 });
  }
}

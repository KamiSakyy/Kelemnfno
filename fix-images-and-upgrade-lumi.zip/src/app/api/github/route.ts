import { NextRequest } from "next/server";
import {
  verifyToken,
  saveToken,
  getStoredToken,
  clearToken,
  listRepos,
  listTree,
  readFile,
} from "@/lib/github";

export const dynamic = "force-dynamic";

// GET: connection status + repos (+ tree/file when requested)
export async function GET(req: NextRequest) {
  const stored = await getStoredToken();
  if (!stored) return Response.json({ connected: false });

  const { searchParams } = new URL(req.url);
  const action = searchParams.get("action");

  if (action === "repos") {
    const repos = await listRepos(stored.token);
    return Response.json({ connected: true, user: stored.user, repos });
  }

  if (action === "tree") {
    const full = searchParams.get("repo") || "";
    const branch = searchParams.get("branch") || "main";
    const tree = await listTree(stored.token, full, branch);
    return Response.json({ connected: true, tree });
  }

  if (action === "file") {
    const full = searchParams.get("repo") || "";
    const path = searchParams.get("path") || "";
    const branch = searchParams.get("branch") || "main";
    const file = await readFile(stored.token, full, path, branch);
    return Response.json({ connected: true, file });
  }

  return Response.json({ connected: true, user: stored.user });
}

// POST: connect with a token
export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const token = String(body.token || "").trim();
  if (!token || token.length < 20) {
    return Response.json({ error: "Введите корректный GitHub-токен" }, { status: 400 });
  }
  const user = await verifyToken(token);
  if (!user) {
    return Response.json({ error: "Токен недействителен или нет доступа" }, { status: 401 });
  }
  await saveToken(token, user);
  const repos = await listRepos(token);
  return Response.json({ connected: true, user, repos });
}

// DELETE: disconnect
export async function DELETE() {
  await clearToken();
  return Response.json({ connected: false });
}

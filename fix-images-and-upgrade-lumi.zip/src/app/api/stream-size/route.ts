// Оценка размера HLS-серии: парсит плейлист и замеряет размер по сегментам (HEAD-запросы),
// чтобы показать пользователю «≈245 МБ» ДО начала скачивания.
import { NextRequest, NextResponse } from "next/server";

export const dynamic = "force-dynamic";
export const maxDuration = 40;

const ALLOWED = /(^|\.)libria\.fun$|(^|\.)anilibria\.(top|tv)$|kodik|aniqit|animevost|animetop|kodik-storage|(^|\.)kodik\.|(^|\.)anix\.|(^|\.)sameband\./i;
const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124.0 Safari/537.36";

async function headSize(url: string): Promise<number | null> {
  try {
    // Сначала пробуем HEAD; если запрещён — тянем только первый байт через Range.
    let res = await fetch(url, { method: "HEAD", headers: { "User-Agent": UA, Referer: "https://anilibria.top/" }, signal: AbortSignal.timeout(7000) });
    let len = Number(res.headers.get("content-length") || 0);
    if (len > 100) return len;
    res = await fetch(url, { headers: { "User-Agent": UA, Range: "bytes=0-255", Referer: "https://anilibria.top/" }, signal: AbortSignal.timeout(7000) });
    len = Number(res.headers.get("content-range")?.split("/")[1] || 0);
    try { await res.body?.cancel(); } catch { /* ignore */ }
    return len > 0 ? len : null;
  } catch {
    return null;
  }
}

export async function GET(req: NextRequest) {
  const raw = req.nextUrl.searchParams.get("u");
  if (!raw) return NextResponse.json({ error: "u?" }, { status: 400 });
  let target: URL;
  try {
    target = new URL(raw);
  } catch {
    return NextResponse.json({ error: "bad url" }, { status: 400 });
  }
  if (!ALLOWED.test(target.hostname)) return NextResponse.json({ error: "host" }, { status: 403 });

  try {
    const headers = { "User-Agent": UA, Referer: "https://anilibria.top/" };
    let listText = await (await fetch(target.toString(), { headers, signal: AbortSignal.timeout(9000) })).text();
    const baseOf = (href: string) => href.slice(0, href.lastIndexOf("/") + 1);

    // Мастер-плейлист? Берём первый вариант.
    if (/#EXT-X-STREAM-INF/.test(listText)) {
      const variant = listText.split("\n").find((l) => l.trim() && !l.trim().startsWith("#"));
      if (variant) {
        const vUrl = new URL(variant.trim(), baseOf(target.toString())).toString();
        listText = await (await fetch(vUrl, { headers, signal: AbortSignal.timeout(9000) })).text();
        target = new URL(vUrl);
      }
    }

    const lines = listText.split("\n").map((l) => l.trim());
    const segUrls: string[] = [];
    let curDur: string | null = null;
    for (const line of lines) {
      if (line.startsWith("#EXT-X-KEY")) {
        curDur = line.match(/URI="([^"]+)"/)?.[1] || null;
      } else if (line && !line.startsWith("#")) {
        segUrls.push(new URL(line, baseOf(target.toString())).toString());
        if (curDur) {
          curDur = null;
        }
      }
    }
    if (!segUrls.length) return NextResponse.json({ mb: null, segments: 0 });

    // Замеряем до 8 равномерно распределённых сегментов параллельно
    const step = Math.max(1, Math.floor(segUrls.length / 8));
    const sampleIdx = new Set<number>([0, segUrls.length - 1]);
    for (let i = 0; i < segUrls.length; i += step) sampleIdx.add(i);
    const sizes = await Promise.all([...sampleIdx].map((i) => headSize(segUrls[i])));
    const valid = sizes.filter((s): s is number => !!s && s > 0);
    if (!valid.length) return NextResponse.json({ mb: null, segments: segUrls.length });

    const avg = valid.reduce((a, b) => a + b, 0) / valid.length;
    const total = avg * segUrls.length;
    const mb = Math.round((total / 1_048_576) * 10) / 10;
    return NextResponse.json({ mb, segments: segUrls.length, sampled: valid.length });
  } catch {
    return NextResponse.json({ mb: null, segments: 0 });
  }
}

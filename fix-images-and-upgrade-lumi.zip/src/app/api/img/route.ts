// Прокси обложек: Shikimori/AniLibria/Yummy/CDN-image могут резать хотлинк/регеон.
// Всё идёт через нас — так у карточек всегда есть постеры.
import { NextRequest } from "next/server";

export const dynamic = "force-dynamic";
export const maxDuration = 25;

const HOST_OK = /(^|\.)shikimori\.(io|one)$|(^|\.)anilibria\.(top|tv)$|(^|\.)static\.yani\.tv$|(^|\.)yani\.tv$|(^|\.)i\.kodik\.biz$|(^|\.)kodik\.|(^|\.)image\.pollinations\.ai$|(^|\.)donmai\.us$|(^|\.)konachan\.(net|com)$|(^|\.)yande\.re$|(^|\.)safebooru\.org$|(^|\.)openverse\.org$|(^|\.)waifu\.pics$/i;
const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124.0 Safari/537.36";

export async function GET(req: NextRequest) {
  const u = req.nextUrl.searchParams.get("u");
  if (!u) return new Response("u?", { status: 400 });
  let target: URL;
  try {
    target = new URL(u.startsWith("//") ? `https:${u}` : u);
  } catch {
    return new Response("bad url", { status: 400 });
  }
  if (target.protocol !== "https:" || !HOST_OK.test(target.hostname)) {
    return new Response("host not allowed", { status: 403 });
  }
  try {
    const r = await fetch(target.toString(), {
      headers: { "User-Agent": UA, Accept: "image/*,*/*", Referer: `${target.protocol}//${target.hostname}/` },
      signal: AbortSignal.timeout(14000),
      redirect: "follow",
    });
    if (!r.ok || !r.body) return new Response("img error", { status: 502 });
    const ct = (r.headers.get("content-type") || "image/jpeg").split(";")[0];
    return new Response(r.body, {
      headers: {
        "Content-Type": ct,
        "Cache-Control": "public, max-age=86400, s-maxage=86400",
        "Cross-Origin-Resource-Policy": "same-origin",
      },
    });
  } catch {
    return new Response("img error", { status: 502 });
  }
}

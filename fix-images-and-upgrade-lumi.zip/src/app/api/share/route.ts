// Публичный шеринг чата ссылкой. POST {sessionId, enable} → выдать/отключить ссылку; GET ?shareId → посмотреть.
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { chatMessages, chatSessions } from "@/db/schema";
import { sanitizeForDisplay } from "@/lib/display";
import { asc, eq } from "drizzle-orm";
import { randomBytes } from "crypto";

export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}));
    const sessionId = Number(body.sessionId);
    const enable = body.enable !== false;
    if (!sessionId) return NextResponse.json({ error: "sessionId?" }, { status: 400 });

    const [s] = await db.select().from(chatSessions).where(eq(chatSessions.id, sessionId));
    if (!s) return NextResponse.json({ error: "not found" }, { status: 404 });

    if (!enable) {
      await db.update(chatSessions).set({ isShared: false }).where(eq(chatSessions.id, sessionId));
      return NextResponse.json({ shared: false });
    }
    const shareId = s.shareId || randomBytes(6).toString("base64url");
    await db.update(chatSessions).set({ isShared: true, shareId }).where(eq(chatSessions.id, sessionId));
    return NextResponse.json({ shared: true, shareId });
  } catch {
    return NextResponse.json({ error: "share failed" }, { status: 500 });
  }
}

export async function GET(req: NextRequest) {
  try {
    const shareId = req.nextUrl.searchParams.get("shareId") || "";
    if (!shareId) return NextResponse.json({ error: "shareId?" }, { status: 400 });
    const sessions = await db.select().from(chatSessions).where(eq(chatSessions.shareId, shareId));
    const s = sessions[0];
    if (!s || !s.isShared) return NextResponse.json({ error: "not found" }, { status: 404 });
    const messages = await db
      .select()
      .from(chatMessages)
      .where(eq(chatMessages.sessionId, s.id))
      .orderBy(asc(chatMessages.createdAt), asc(chatMessages.id));
    return NextResponse.json({
      title: s.title,
      updatedAt: s.updatedAt,
      messages: sanitizeForDisplay(messages).map((m) => ({
        id: m.id,
        role: m.role,
        content: m.content,
        providerName: m.providerName,
        imagesData: m.imagesData,
        attachmentDataUrl: m.attachmentDataUrl,
        createdAt: m.createdAt,
      })),
    });
  } catch {
    return NextResponse.json({ error: "not found" }, { status: 404 });
  }
}

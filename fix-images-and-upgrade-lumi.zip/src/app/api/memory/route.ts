// Долгосрочная память Люми: список фактов, удаление.
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { lumiMemory } from "@/db/schema";
import { asc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const facts = await db.select().from(lumiMemory).orderBy(asc(lumiMemory.id));
    return NextResponse.json({ facts });
  } catch {
    return NextResponse.json({ facts: [] });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const id = req.nextUrl.searchParams.get("id");
    if (id === "all" || !id) {
      await db.delete(lumiMemory);
    } else {
      await db.delete(lumiMemory).where(eq(lumiMemory.id, Number(id))).catch(() => undefined);
    }
    const facts = await db.select().from(lumiMemory).orderBy(asc(lumiMemory.id));
    return NextResponse.json({ facts });
  } catch {
    return NextResponse.json({ error: "delete failed" }, { status: 500 });
  }
}

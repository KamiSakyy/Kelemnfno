// Голос Люми. Цепочка TTS-движков (всё без ключей):
//  1) Pollinations openai-audio — самый красивый женский голос (аккуратный таймаут)
//  2) Google Translate TTS — стабильный запасной (частит длинный текст и склеивает mp3)
//  3) 502 → клиент сам включает голос браузера
import { NextRequest } from "next/server";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36";

function splitForGoogle(text: string, max = 180): string[] {
  const parts: string[] = [];
  // режем по предложениям; длинные предложения — по запятым/словам
  const sentences = text.match(/[^.!?。…\n]+[.!?。…]?/g) || [text];
  let cur = "";
  const flush = () => {
    if (cur.trim()) parts.push(cur.trim());
    cur = "";
  };
  for (const s of sentences) {
    if ((cur + " " + s).trim().length <= max) {
      cur = (cur + " " + s).trim();
    } else {
      flush();
      if (s.length <= max) {
        cur = s;
      } else {
        // совсем длинное — грубо по словам
        let acc = "";
        for (const w of s.split(/\s+/)) {
          if ((acc + " " + w).trim().length > max) {
            parts.push(acc.trim());
            acc = w;
          } else {
            acc = (acc + " " + w).trim();
          }
        }
        cur = acc;
      }
    }
  }
  flush();
  return parts.slice(0, 8); // не больше 8 кусков, чтобы не злоупотреблять
}

async function fromPollinations(text: string): Promise<Buffer | null> {
  try {
    const res = await fetch(
      `https://text.pollinations.ai/${encodeURIComponent(text.slice(0, 600))}?model=openai-audio&voice=alloy`,
      { headers: { "User-Agent": "LumiChat/2.0" }, signal: AbortSignal.timeout(9000) }
    );
    const type = (res.headers.get("content-type") || "").toLowerCase();
    if (!res.ok || !type.startsWith("audio/")) return null;
    return Buffer.from(await res.arrayBuffer());
  } catch {
    return null;
  }
}

async function fromGoogle(text: string): Promise<Buffer | null> {
  try {
    const chunks = splitForGoogle(text);
    const bufs: Buffer[] = [];
    for (const chunk of chunks) {
      const res = await fetch(
        `https://translate.google.com/translate_tts?ie=UTF-8&tl=ru&client=tw-ob&q=${encodeURIComponent(chunk)}`,
        { headers: { "User-Agent": UA }, signal: AbortSignal.timeout(9000) }
      );
      const type = (res.headers.get("content-type") || "").toLowerCase();
      if (!res.ok || !type.includes("audio")) return null;
      bufs.push(Buffer.from(await res.arrayBuffer()));
    }
    return bufs.length ? Buffer.concat(bufs) : null;
  } catch {
    return null;
  }
}

export async function GET(req: NextRequest) {
  const text = (req.nextUrl.searchParams.get("text") || "").slice(0, 900).trim();
  if (!text) return new Response("empty", { status: 400 });

  const audio = (await fromPollinations(text)) || (await fromGoogle(text));
  if (!audio || audio.length < 500) {
    return new Response("tts unavailable", { status: 502 });
  }
  return new Response(new Uint8Array(audio), {
    headers: {
      "Content-Type": "audio/mpeg",
      "Content-Length": String(audio.length),
      "Cache-Control": "public, max-age=300",
    },
  });
}

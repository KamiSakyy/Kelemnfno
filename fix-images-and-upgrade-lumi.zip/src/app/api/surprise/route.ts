// «Арт дня» — Люми удивляет случайным топовым аниме-артом.
// Источники: Danbooru (топ по рейтингу, безопасные) + Safebooru.
import { NextRequest, NextResponse } from "next/server";

export const dynamic = "force-dynamic";
export const maxDuration = 25;

const UA = "LumiChat/2.0 (surprise-art)";

const POOL = [
  "1girl score:>=80",
  "scenery score:>=50",
  "original score:>=60",
  "1girl smile score:>=100",
  "landscape score:>=40",
  "touhou score:>=80",
  "vocaloid score:>=80",
];

interface ArtItem {
  image: string;
  thumbnail: string;
  title: string;
  source: string;
}

async function alive(url: string): Promise<boolean> {
  try {
    const res = await fetch(url, {
      headers: { "User-Agent": UA, Range: "bytes=0-128" },
      signal: AbortSignal.timeout(6000),
    });
    const type = (res.headers.get("content-type") || "").toLowerCase();
    try {
      await res.body?.cancel();
    } catch {
      /* ignore */
    }
    return (res.ok || res.status === 206) && type.startsWith("image/");
  } catch {
    return false;
  }
}

async function fromDanbooru(tag: string, page?: number): Promise<ArtItem[]> {
  try {
    const p = page ?? 1 + Math.floor(Math.random() * 4);
    const res = await fetch(
      `https://danbooru.donmai.us/posts.json?tags=${encodeURIComponent(tag + " rating:s")}&limit=12&page=${p}`,
      { headers: { "User-Agent": UA }, signal: AbortSignal.timeout(9000) }
    );
    if (!res.ok) return [];
    const data = (await res.json()) as Array<Record<string, unknown>>;
    return (Array.isArray(data) ? data : [])
      .filter((p) => typeof p.file_url === "string" && !/\.(zip|webm|mp4|swf|gif)$/i.test(String(p.file_url)))
      .map((p) => ({
        image: String(p.file_url),
        thumbnail: String(p.large_file_url || p.preview_file_url || p.file_url),
        title: `${String(p.tag_string_artist || "unknown").replace(/_/g, " ")} — топ-арт с Danbooru`,
        source: `https://danbooru.donmai.us/posts/${p.id}`,
      }));
  } catch {
    return [];
  }
}

async function fromSafebooru(): Promise<ArtItem[]> {
  try {
    const pid = Math.floor(Math.random() * 60);
    const res = await fetch(
      `https://safebooru.org/index.php?page=dapi&s=post&q=index&json=1&limit=12&pid=${pid}&tags=${encodeURIComponent("1girl solo score:>=50")}`,
      { headers: { "User-Agent": UA }, signal: AbortSignal.timeout(9000) }
    );
    if (!res.ok) return [];
    const data = (await res.json()) as Array<Record<string, unknown>>;
    return (Array.isArray(data) ? data : [])
      .filter((p) => p.directory && p.image && !/\.(zip|webm|mp4|swf|gif)$/i.test(String(p.image)))
      .map((p) => ({
        image: `https://safebooru.org/images/${p.directory}/${encodeURIComponent(String(p.image))}`,
        thumbnail: `https://safebooru.org/images/${p.directory}/${encodeURIComponent(String(p.image))}`,
        title: "Топ-арт с Safebooru",
        source: `https://safebooru.org/index.php?page=post&s=view&id=${p.id}`,
      }));
  } catch {
    return [];
  }
}

export async function GET(req: NextRequest) {
  const mode = req.nextUrl.searchParams.get("mode");

  // ── «Арт дня»: один и тот же топовый арт для всех в течение суток ──
  if (mode === "daily") {
    const dayNum = Math.floor(Date.now() / 86400000);
    const tag = POOL[dayNum % POOL.length];
    const page = (dayNum % 3) + 1;
    const candidates = await fromDanbooru(tag, page);
    if (candidates.length) {
      const start = dayNum % candidates.length;
      for (let i = 0; i < Math.min(4, candidates.length); i++) {
        const art = candidates[(start + i) % candidates.length];
        if (await alive(art.image)) {
          const dateStr = new Date().toLocaleDateString("ru-RU", { day: "numeric", month: "long" });
          return NextResponse.json({ art: { ...art, title: `Арт дня · ${dateStr} — ${art.title}` }, daily: true });
        }
      }
    }
    // если вдруг не вышло — молча падаем в случайный режим
  }

  // ── Случайный сюрприз ──
  const pool = [...POOL].sort(() => Math.random() - 0.5);
  let candidates: ArtItem[] = [];
  for (const tag of pool.slice(0, 3)) {
    candidates = await fromDanbooru(tag);
    if (candidates.length) break;
  }
  if (!candidates.length) candidates = await fromSafebooru();

  for (const art of candidates.sort(() => Math.random() - 0.5).slice(0, 5)) {
    if (await alive(art.image)) {
      return NextResponse.json({ art });
    }
  }
  return NextResponse.json({ art: null }, { status: 404 });
}

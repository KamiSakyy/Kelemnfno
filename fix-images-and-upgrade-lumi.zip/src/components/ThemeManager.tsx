"use client";

// Атмосфера Люми: тема интерфейса + лёгкие частицы (лепестки, звёзды, пузыри, угли).
import React, { useEffect, useRef, useState } from "react";
import { getTheme, LumiTheme } from "@/lib/lumi-store";

const PARTICLE_COUNT = 34;

interface Particle {
  x: number; // 0..1
  y: number; // 0..1
  size: number;
  dur: number;
  delay: number;
  sway: number;
  opacity: number;
  rotate?: number;
}

function makeParticles(kind: LumiTheme): Particle[] {
  return Array.from({ length: PARTICLE_COUNT }, () => ({
    x: Math.random(),
    y: Math.random(),
    size: kind === "sakura" ? 6 + Math.random() * 8 : kind === "night" ? 1 + Math.random() * 2 : 2.5 + Math.random() * 4,
    dur: kind === "sakura" ? 14 + Math.random() * 16 : kind === "night" ? 3 + Math.random() * 4 : 16 + Math.random() * 14,
    delay: -Math.random() * 20,
    sway: (Math.random() - 0.5) * 160,
    opacity: kind === "night" ? 0.25 + Math.random() * 0.5 : 0.25 + Math.random() * 0.35,
    rotate: Math.random() * 360,
  }));
}

const COLORS: Record<LumiTheme, string[]> = {
  night: ["#c4b5fd", "#a5b4fc", "#f0abfc"],
  sakura: ["#fda4af", "#f9a8d4", "#fecdd3", "#fbcfe8"],
  ocean: ["#67e8f9", "#7dd3fc", "#a5f3fc"],
  sunset: ["#fdba74", "#fda4af", "#fcd34d"],
};

export function ThemeManager() {
  const [theme, setThemeState] = useState<LumiTheme>("night");
  const [particles, setParticles] = useState<Particle[]>([]);
  const reduced = useRef(false);

  useEffect(() => {
    reduced.current = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const apply = () => {
      const t = getTheme();
      setThemeState(t);
      document.documentElement.dataset.theme = t;
      setParticles(reduced.current ? [] : makeParticles(t));
    };
    apply();
    window.addEventListener("lumi:theme", apply);
    return () => window.removeEventListener("lumi:theme", apply);
  }, []);

  if (!particles.length) return null;
  const colors = COLORS[theme];

  return (
    <div aria-hidden className="fixed inset-0 z-[2] pointer-events-none overflow-hidden">
      {particles.map((p, i) => {
        const color = colors[i % colors.length];
        if (theme === "night") {
          return (
            <span
              key={i}
              className="absolute rounded-full"
              style={{
                left: `${p.x * 100}%`,
                top: `${p.y * 100}%`,
                width: p.size,
                height: p.size,
                background: color,
                boxShadow: `0 0 ${p.size * 3}px ${color}`,
                animation: `lumi-twinkle ${p.dur}s ease-in-out infinite`,
                animationDelay: `${p.delay}s`,
              }}
            />
          );
        }
        if (theme === "sakura") {
          return (
            <span
              key={i}
              className="absolute"
              style={{
                left: `${p.x * 100}%`,
                top: "-6vh",
                width: p.size,
                height: p.size * 0.72,
                background: color,
                borderRadius: "80% 20% 80% 20%",
                opacity: p.opacity + 0.25,
                animation: `lumi-petal-fall ${p.dur}s linear infinite`,
                animationDelay: `${p.delay}s`,
                ["--sway" as string]: `${p.sway}px`,
              }}
            />
          );
        }
        // ocean — пузырьки вверх, sunset — угли вверх
        return (
          <span
            key={i}
            className={`absolute ${theme === "ocean" ? "rounded-full border" : "rotate-45 rounded-[2px]"}`}
            style={{
              left: `${p.x * 100}%`,
              top: "100%",
              width: p.size,
              height: p.size,
              ["--o" as string]: p.opacity,
              ["--sway" as string]: `${p.sway}px`,
              animation: `lumi-rise ${p.dur}s linear infinite`,
              animationDelay: `${p.delay}s`,
              ...(theme === "ocean"
                ? { borderColor: color, background: `${color}22` }
                : { background: color, boxShadow: `0 0 ${p.size * 2.4}px ${color}` }),
            }}
          />
        );
      })}
    </div>
  );
}

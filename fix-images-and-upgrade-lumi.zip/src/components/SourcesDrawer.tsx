"use client";

import React, { useState } from "react";
import { ChevronDown, RefreshCw, X } from "lucide-react";
import { AIProvider } from "@/lib/types";

const GATEWAY_LABELS: Record<string, string> = {
  pollinations: "Pollinations",
  llm7: "LLM7",
  kilo: "Kilo",
};

function Switch({ on, onClick, label }: { on: boolean; onClick: () => void; label: string }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={on}
      aria-label={label}
      onClick={onClick}
      className={`relative w-9 h-[20px] rounded-full border transition shrink-0 ${
        on ? "bg-white border-white" : "bg-[#1a1a1c] border-white/10"
      }`}
    >
      <span
        className={`absolute top-[2px] w-[14px] h-[14px] rounded-full transition-all ${on ? "left-[21px] bg-black" : "left-[2px] bg-zinc-500"}`}
      />
    </button>
  );
}

export function SourcesDrawer({
  open,
  onClose,
  providers,
  isPinging,
  simulateFailover,
  onToggleProvider,
  onToggleFailover,
  onPing,
  onEnableAll,
  onResetStats,
}: {
  open: boolean;
  onClose: () => void;
  providers: AIProvider[];
  isPinging: boolean;
  simulateFailover: boolean;
  onToggleProvider: (provider: AIProvider) => void;
  onToggleFailover: () => void;
  onPing: () => void;
  onEnableAll: () => void;
  onResetStats: () => void;
}) {
  const [expanded, setExpanded] = useState<string | null>(null);
  const enabled = providers.filter((p) => p.isEnabled);
  const gateways = new Set(providers.map((p) => p.gateway));

  return (
    <>
      {open && <button aria-label="Закрыть" className="fixed inset-0 z-40 bg-black/70 backdrop-blur-[2px]" onClick={onClose} />}

      <aside
        className={`fixed inset-y-0 right-0 z-50 w-[min(92vw,368px)] bg-[#0a0a0b] border-l border-white/[0.08] flex flex-col transition-transform duration-200 ${
          open ? "translate-x-0 animate-slide-right" : "translate-x-full pointer-events-none"
        }`}
      >
        <div className="h-14 px-4 border-b border-white/[0.08] flex items-center justify-between shrink-0">
          <div>
            <p className="text-[13px] font-semibold text-zinc-100">Источники</p>
            <p className="font-mono text-[10px] text-zinc-600 mt-0.5">
              {enabled.length} из {providers.length} · {gateways.size} шлюза
            </p>
          </div>
          <button type="button" onClick={onClose} className="w-9 h-9 rounded-lg grid place-items-center text-zinc-500 hover:text-white hover:bg-white/[0.06]" aria-label="Закрыть">
            <X className="w-[18px] h-[18px]" />
          </button>
        </div>

        <div className="flex-1 min-h-0 overflow-y-auto">
          <ul className="divide-y divide-white/[0.05]">
            {providers.map((provider) => {
              const isOpen = expanded === provider.slug;
              return (
                <li key={provider.slug} className={provider.isEnabled ? "" : "opacity-45"}>
                  <div className="px-4 py-3 flex items-center gap-3">
                    <button type="button" onClick={() => setExpanded(isOpen ? null : provider.slug)} className="flex-1 min-w-0 text-left">
                      <div className="flex items-center gap-2 min-w-0">
                        <span className={`w-1.5 h-1.5 rounded-full shrink-0 ${provider.isEnabled ? "bg-zinc-200" : "bg-zinc-600"}`} />
                        <span className="text-[13px] font-medium text-zinc-100 truncate">{provider.name}</span>
                        <span className="ml-auto shrink-0 font-mono text-[10px] text-zinc-600">{provider.avgLatencyMs} мс</span>
                        <ChevronDown className={`w-3.5 h-3.5 text-zinc-600 shrink-0 transition ${isOpen ? "rotate-180" : ""}`} />
                      </div>
                      <p className="mt-1 pl-3.5 font-mono text-[10px] text-zinc-600 truncate">
                        {GATEWAY_LABELS[provider.gateway] || provider.gateway} · {provider.modelId}
                      </p>
                    </button>
                    <Switch on={provider.isEnabled} onClick={() => onToggleProvider(provider)} label={`${provider.name}: ${provider.isEnabled ? "выключить" : "включить"}`} />
                  </div>

                  {isOpen && (
                    <div className="px-4 pb-3.5 pl-[26px] space-y-2 animate-fade-in">
                      <p className="text-[11.5px] leading-relaxed text-zinc-500">{provider.description}</p>
                      <div className="flex flex-wrap gap-x-3 gap-y-1 font-mono text-[10px] text-zinc-600">
                        <span>успех {provider.successRate}%</span>
                        <span>запросов {provider.totalRequests}</span>
                        <span>контекст {Math.round(provider.contextWindow / 1000)}k</span>
                        {provider.supportsVision && <span className="text-zinc-200">зрение</span>}
                        {provider.supportsStream && <span>поток</span>}
                      </div>
                      <p className="font-mono text-[10px] text-zinc-700 break-all">{provider.publicKeyLabel}</p>
                    </div>
                  )}
                </li>
              );
            })}
          </ul>

          <div className="px-4 py-4 space-y-3 border-t border-white/[0.08]">
            <div className="flex items-center justify-between gap-3">
              <div className="min-w-0">
                <p className="text-[12px] font-medium text-zinc-200">Тест сбоя</p>
                <p className="text-[10.5px] leading-relaxed text-zinc-600">Первый узел вернёт 503, запрос уйдёт в резерв</p>
              </div>
              <Switch on={simulateFailover} onClick={onToggleFailover} label="Тест сбоя" />
            </div>

            <div className="grid grid-cols-3 gap-1.5">
              <button
                type="button"
                onClick={onPing}
                disabled={isPinging}
                className="h-9 rounded-lg border border-white/[0.08] bg-[#101011] text-[11px] text-zinc-300 hover:text-white inline-flex items-center justify-center gap-1.5 disabled:opacity-60"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isPinging ? "animate-spin" : ""}`} />
                Пинг
              </button>
              <button
                type="button"
                onClick={onEnableAll}
                className="h-9 rounded-lg border border-white/[0.08] bg-[#101011] text-[11px] text-zinc-300 hover:text-white"
              >
                Все вкл
              </button>
              <button
                type="button"
                onClick={onResetStats}
                className="h-9 rounded-lg border border-white/[0.08] bg-[#101011] text-[11px] text-zinc-300 hover:text-white"
              >
                Сброс
              </button>
            </div>

            <p className="text-[10.5px] leading-relaxed text-zinc-600">
              Выбор модели, анализ изображений и генерация картинок определяются автоматически по смыслу запроса. Ключи встроены на сервере.
            </p>
          </div>
        </div>
      </aside>
    </>
  );
}

"use client";

import React, { useState } from"react";
import { Brain, Check, ChevronDown, ChevronUp, Copy, Download, Heart, Pencil, RefreshCw, Share2, Sparkles, Square, Volume2 } from"lucide-react";
import { MarkdownRenderer } from"@/components/MarkdownRenderer";
import { AnimeResultCard, AnimeCalendar } from"@/components/AnimePlayer";
import { ImageGallery } from"@/components/ImageGallery";
import { ChatMessage, formatLatency } from"@/lib/types";
import { speakText, stopLumiVoice, toggleFav } from"@/lib/lumi-store";
import { stripAssistantMemory } from"@/lib/display";

type AnimeCardData = { id: number; russian: string; name: string; image: string; score: number; episodes: number; status: string; airedOn: string | null };
type CalendarData = { animeId: number; russian: string; name: string; image: string; nextEpisode: number; nextEpisodeAt: string };

function MetaButton({
 label,
 onClick,
 active,
 children,
}: {
 label: string;
 onClick: () => void;
 active?: boolean;
 children: React.ReactNode;
}) {
 return (<button
 type="button"onClick={onClick}
 title={label}
 aria-label={label}
 className={`w-7 h-7 rounded-lg grid place-items-center transition active:scale-95 ${
 active?"text-white":"text-zinc-600 hover:text-zinc-200 hover:bg-white/[0.06]"}`}
 >
 {children}
 </button>);
}

// Reusable copy button + small text-message bubble usable in every mode.
export function CopyChip({ text }: { text: string }) {
 const [copied, setCopied] = React.useState(false);
 return (<button
 type="button"onClick={async () => {
 try {
 await navigator.clipboard.writeText(text);
 setCopied(true);
 window.setTimeout(() => setCopied(false), 1600);
 } catch {
 /* ignore */
 }
 }}
 title="Скопировать"className="w-6 h-6 rounded-md grid place-items-center text-zinc-600 hover:text-zinc-200 hover:bg-white/[0.06] transition">
 {copied? <Check className="w-3 h-3 text-emerald-400"/> : <Copy className="w-3 h-3"/>}
 </button>);
}

export function UserMessageRow({ content, onEdit }: { content: string; onEdit?: (c: string) => void }) {
 return (<div className="group flex flex-col items-end animate-fade-in">
 <div className="max-w-[85%] rounded-2xl rounded-br-md bg-[#17171a] border border-white/[0.07] px-3.5 py-2 text-[14px] text-zinc-100 whitespace-pre-wrap">
 {content}
 </div>
 <div className="mt-1 flex items-center gap-0.5 lg:opacity-0 lg:group-hover:opacity-100 transition">
 {onEdit && (<button type="button"onClick={() => onEdit(content)} title="Изменить и отправить"className="w-6 h-6 rounded-md grid place-items-center text-zinc-600 hover:text-zinc-200 hover:bg-white/[0.06]">
 <Pencil className="w-3 h-3"/>
 </button>)}
 <CopyChip text={content} />
 </div>
 </div>);
}

export function AssistantMessageRow({ children, content }: { children: React.ReactNode; content: string }) {
 return (<div className="group animate-fade-in">
 {children}
 <div className="mt-1 lg:opacity-0 lg:group-hover:opacity-100 transition">
 <CopyChip text={content} />
 </div>
 </div>);
}

export function UserBubble({ message, onEdit }: { message: ChatMessage; onEdit?: (content: string) => void }) {
 const [copied, setCopied] = useState(false);

 const copy = async () => {
 try {
 await navigator.clipboard.writeText(message.content);
 setCopied(true);
 window.setTimeout(() => setCopied(false), 1800);
 } catch {
 // ignore
 }
 };

 return (<div className="group flex flex-col items-end animate-fade-in">
 <div className="max-w-[86%] sm:max-w-[76%] rounded-2xl rounded-br-lg bg-[#17171a] border border-white/[0.07] overflow-hidden">
 {message.attachmentDataUrl && (// eslint-disable-next-line @next/next/no-img-element
 <img src={message.attachmentDataUrl} alt=""className="max-h-60 w-full object-cover border-b border-white/[0.07]"/>)}
 <p className="px-4 py-2.5 text-[14.5px] leading-relaxed text-zinc-100 whitespace-pre-wrap">{message.content}</p>
 </div>
 <div className="mt-1 flex items-center gap-0.5 lg:opacity-0 lg:group-hover:opacity-100 lg:focus-within:opacity-100 transition">
 {onEdit && (<MetaButton label="Изменить и отправить"onClick={() => onEdit(message.content)}>
 <Pencil className="w-3.5 h-3.5"/>
 </MetaButton>)}
 <MetaButton label="Скопировать"onClick={copy} active={copied}>
 {copied? <Check className="w-3.5 h-3.5"/> : <Copy className="w-3.5 h-3.5"/>}
 </MetaButton>
 </div>
 </div>);
}

export function AssistantBlock({
 message,
 traceOpen,
 onToggleTrace,
 copied,
 onCopy,
 onRegenerate,
 onShare,
 onQuickReply,
 canShare,
 busy,
 compact,
}: {
 message: ChatMessage;
 traceOpen: boolean;
 onToggleTrace: () => void;
 copied: boolean;
 onCopy: () => void;
 onRegenerate: () => void;
 onShare: () => void;
 onQuickReply?: (text: string) => void;
 canShare: boolean;
 busy: boolean;
 compact?: boolean;
}) {
 const hasTrace = Boolean(message.reasoningTrace?.trim());
 const isImage = message.kind ==="image"&& Boolean(message.imageUrl);
 const hops = message.failoverLog || [];
 const hadFailover = hops.some((hop) => hop.status!=="success");
 const [speaking, setSpeaking] = useState(false);

 const provider = message.providerName ||"";
 const gallery = message.imagesData || [];
 const quickChips: { label: string; send: string }[] = [];
 if (onQuickReply && gallery.length && /Поиск картинок|Персонажи/.test(provider)) {
 quickChips.push({ label:"Ещё артов", send:"ещё"});
 }
 const favAll = () => {
 gallery.slice(0, 12).forEach((im) => toggleFav(im));
 };
 const toggleSpeak = () => {
 if (speaking) {
 stopLumiVoice();
 setSpeaking(false);
 return;
 }
 setSpeaking(speakText(message.content, () => setSpeaking(false)) && true);
 };

 return (<article className="group animate-fade-in">
 {hasTrace && (<div className="mb-2">
 <button
 type="button"onClick={onToggleTrace}
 className="inline-flex items-center gap-1.5 text-[11px] text-zinc-600 hover:text-zinc-300 transition">
 <Brain className="w-3 h-3"/>
 Ход мысли
 {traceOpen? <ChevronUp className="w-3 h-3"/> : <ChevronDown className="w-3 h-3"/>}
 </button>
 {traceOpen && (<div className="mt-2 pl-3 border-l border-white/[0.08] max-h-64 overflow-y-auto text-[11.5px] leading-relaxed font-mono text-zinc-500 whitespace-pre-wrap">
 {message.reasoningTrace}
 </div>)}
 </div>)}

 {isImage? (<div>
 {/* eslint-disable-next-line @next/next/no-img-element */}
 <img
 src={message.imageUrl ||""}
 alt={message.content}
 loading="lazy"className="w-full max-h-[560px] object-contain rounded-2xl border border-white/[0.08] bg-[#0a0a0b]"/>
 </div>) : (<div>
 <MarkdownRenderer content={stripAssistantMemory(message.content)} compact={compact} />
 {message.imagesData && message.imagesData.length > 0 && <ImageGallery images={message.imagesData} />}
 {(quickChips.length > 0 || gallery.length > 0) &&!isImage && (<div className="mt-2 flex flex-wrap items-center gap-1.5">
 {quickChips.map((chip) => (<button
 key={chip.label}
 type="button"onClick={() => onQuickReply!(chip.send)}
 disabled={busy}
 className="h-7 px-2.5 rounded-full border border-fuchsia-400/25 bg-fuchsia-500/[0.06] text-[11.5px] text-fuchsia-200 hover:bg-fuchsia-500/[0.14] transition disabled:opacity-40 inline-flex items-center gap-1">
 <Sparkles className="w-3 h-3"/>
 {chip.label}
 </button>))}
 {gallery.length > 0 && (<button
 type="button"onClick={favAll}
 className="h-7 px-2.5 rounded-full border border-white/[0.1] text-[11.5px] text-zinc-400 hover:text-pink-300 hover:border-pink-400/30 transition inline-flex items-center gap-1">
 <Heart className="w-3 h-3"/>
 Все в избранное
 </button>)}
 </div>)}
 {message.animeData?.type ==="cards"&& (<div className="mt-2">
 {(message.animeData.items as AnimeCardData[]).map((a) => (<AnimeResultCard key={a.id} card={a} />))}
 </div>)}
 {message.animeData?.type ==="calendar"&& (<AnimeCalendar entries={message.animeData.items as CalendarData[]} />)}
 </div>)}

 <div className="mt-2 flex items-center gap-2.5">
 <span className="text-[11px] font-mono text-zinc-600 truncate">{message.providerName ||"Люми"}</span>
 {message.latencyMs? <span className="text-[11px] font-mono text-zinc-700">{formatLatency(message.latencyMs)}</span> : null}
 {hadFailover && (<span className="text-[11px] font-mono text-zinc-600"title={hops.map((h) => `${h.providerName}: ${h.status}`).join("→")}>
 · резервный узел
 </span>)}
 {isImage && (<a
 href={message.imageUrl ||"#"}
 target="_blank"rel="noopener noreferrer"download
 className="inline-flex items-center gap-1 text-[11px] font-mono text-zinc-500 hover:text-white transition">
 <Download className="w-3 h-3"/>
 открыть
 </a>)}

 <div className="ml-auto flex items-center gap-0.5 lg:opacity-0 lg:group-hover:opacity-100 lg:focus-within:opacity-100 transition">
 {!isImage && (<MetaButton label={speaking?"Остановить озвучку":"Озвучить голосом Люми"} onClick={toggleSpeak} active={speaking}>
 {speaking? <Square className="w-3 h-3 fill-current"/> : <Volume2 className="w-3.5 h-3.5"/>}
 </MetaButton>)}
 {!isImage && (<MetaButton label="Скопировать"onClick={onCopy} active={copied}>
 {copied? <Check className="w-3.5 h-3.5"/> : <Copy className="w-3.5 h-3.5"/>}
 </MetaButton>)}
 <MetaButton label={isImage?"Ещё вариант":"Ответить заново"} onClick={onRegenerate}>
 <RefreshCw className={`w-3.5 h-3.5 ${busy?"opacity-40":""}`} />
 </MetaButton>
 {canShare && (<MetaButton label="Поделиться"onClick={onShare}>
 <Share2 className="w-3.5 h-3.5"/>
 </MetaButton>)}
 </div>
 </div>
 </article>);
}

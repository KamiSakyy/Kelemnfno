"use client";

import React, { useState } from "react";
import { Check, Copy, Play, Code2, EyeOff, Download } from "lucide-react";

const LANG_EXT: Record<string, string> = {
  html: "html", xml: "xml", svg: "svg", css: "css", javascript: "js", js: "js",
  typescript: "ts", ts: "ts", tsx: "tsx", jsx: "jsx", json: "json", python: "py",
  py: "py", kotlin: "kt", kt: "kt", java: "java", c: "c", cpp: "cpp", "c++": "cpp",
  csharp: "cs", cs: "cs", go: "go", rust: "rs", rs: "rs", php: "php", ruby: "rb",
  swift: "swift", sql: "sql", sh: "sh", bash: "sh", yaml: "yml", yml: "yml", md: "md",
  markdown: "md", text: "txt",
};

function guessFileName(lang: string, code: string): string {
  // Try to detect a filename hint from the first comment lines
  const hint = code.slice(0, 200).match(/(?:\/\/|#|<!--)\s*([\w.-]+\.[a-z0-9]{1,5})/i);
  if (hint) return hint[1];
  const ext = LANG_EXT[lang] || "txt";
  if (ext === "html" || code.includes("<!DOCTYPE") || code.includes("<html")) return "index.html";
  return `code.${ext}`;
}

function CodeBlock({ language, code }: { language: string; code: string }) {
  const [copied, setCopied] = useState(false);
  const [preview, setPreview] = useState(false);
  const lang = (language || "text").toLowerCase().trim();
  const canPreview =
    lang === "html" || lang === "svg" || code.includes("<html") || (code.includes("<div") && code.includes("<style"));

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    } catch {
      // ignore
    }
  };

  const download = () => {
    const name = guessFileName(lang, code);
    const type = name.endsWith(".html") ? "text/html" : "text/plain";
    const url = URL.createObjectURL(new Blob([code], { type: `${type};charset=utf-8` }));
    const a = document.createElement("a");
    a.href = url;
    a.download = name;
    a.click();
    URL.revokeObjectURL(url);
  };

  const fileName = guessFileName(lang, code);

  return (
    <div className="my-3 rounded-xl overflow-hidden border border-white/[0.08] bg-[#0a0a0b]">
      <div className="h-9 px-3 flex items-center justify-between bg-[#101011] border-b border-white/[0.08]">
        <div className="flex items-center gap-2 min-w-0">
          <Code2 className="w-3.5 h-3.5 shrink-0 text-zinc-500" />
          <span className="font-mono text-[10px] text-zinc-400 font-medium truncate">{fileName}</span>
          <span className="font-mono text-[10px] text-zinc-700">{code.split("\n").length} стр.</span>
        </div>
        <div className="flex items-center gap-1">
          {canPreview && (
            <button
              type="button"
              onClick={() => setPreview((v) => !v)}
              className="h-6 px-2 rounded-md text-[10px] font-medium text-white hover:bg-white/10 inline-flex items-center gap-1 active:scale-95"
            >
              {preview ? <EyeOff className="w-3 h-3" /> : <Play className="w-3 h-3 fill-current" />}
              {preview ? "Код" : "Запустить"}
            </button>
          )}
          <button
            type="button"
            onClick={download}
            title={`Скачать ${fileName}`}
            className="h-6 px-2 rounded-md text-[10px] font-medium text-emerald-300 hover:bg-emerald-400/10 inline-flex items-center gap-1 active:scale-95"
          >
            <Download className="w-3 h-3" /> Скачать
          </button>
          <button
            type="button"
            onClick={copy}
            className="h-6 px-2 rounded-md text-[10px] font-medium text-zinc-500 hover:text-zinc-200 hover:bg-white/[0.06] inline-flex items-center gap-1"
          >
            {copied ? <Check className="w-3 h-3 text-white" /> : <Copy className="w-3 h-3" />}
            {copied ? "Готово" : "Копировать"}
          </button>
        </div>
      </div>
      {preview ? (
        <div className="bg-white p-1.5">
          <iframe title="Предпросмотр" srcDoc={code} className="w-full h-72 rounded-lg bg-white" sandbox="allow-scripts" />
        </div>
      ) : (
        <pre className="p-3.5 overflow-x-auto text-[12.5px] leading-[1.7] font-mono text-zinc-300">
          <code>{code}</code>
        </pre>
      )}
    </div>
  );
}

function inline(text: string, keyPrefix = "i"): React.ReactNode[] {
  const parts = text.split(/(`[^`]+`|\*\*[^*]+\*\*|\[[^\]]+\]\([^)]+\)|(?<![\w*])\*[^*\n]+\*(?![\w*])|(?<!\w)_[^_\n]+_(?!\w))/g);
  return parts.map((part, idx) => {
    const key = `${keyPrefix}-${idx}`;
    if (!part) return null;
    if (part.startsWith("`") && part.endsWith("`") && part.length > 2) {
      return (
        <code key={key} className="px-1.5 py-0.5 mx-0.5 rounded-md bg-[#161618] border border-white/[0.08] font-mono text-[12px] text-zinc-200">
          {part.slice(1, -1)}
        </code>
      );
    }
    if (part.startsWith("**") && part.endsWith("**") && part.length > 4) {
      return (
        <strong key={key} className="font-semibold text-zinc-50">
          {part.slice(2, -2)}
        </strong>
      );
    }
    const link = part.match(/^\[([^\]]+)\]\(([^)]+)\)$/);
    if (link) {
      return (
        <a key={key} href={link[2]} target="_blank" rel="noopener noreferrer" className="underline decoration-zinc-600 underline-offset-2 text-zinc-100 hover:decoration-white">
          {link[1]}
        </a>
      );
    }
    if ((part.startsWith("*") && part.endsWith("*") && part.length > 2) || (part.startsWith("_") && part.endsWith("_") && part.length > 2)) {
      return (
        <em key={key} className="italic text-zinc-400">
          {part.slice(1, -1)}
        </em>
      );
    }
    return <React.Fragment key={key}>{part}</React.Fragment>;
  });
}

function Table({ rows }: { rows: string[] }) {
  const parse = (line: string) =>
    line
      .trim()
      .replace(/^\|/, "")
      .replace(/\|$/, "")
      .split("|")
      .map((c) => c.trim());
  const header = parse(rows[0]);
  const body = rows.slice(1).filter((r) => !/^\s*\|?\s*:?-{2,}/.test(r)).map(parse);
  return (
    <div className="my-3 overflow-x-auto rounded-xl border border-white/[0.08]">
      <table className="w-full text-[13px] border-collapse">
        <thead>
          <tr className="bg-[#101011]">
            {header.map((h, i) => (
              <th key={i} className="text-left px-3 py-2 font-semibold text-zinc-200 border-b border-white/[0.08] whitespace-nowrap">
                {inline(h, `th${i}`)}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {body.map((r, ri) => (
            <tr key={ri} className="odd:bg-transparent even:bg-white/[0.02]">
              {header.map((_, ci) => (
                <td key={ci} className="px-3 py-2 align-top text-zinc-300 border-b border-white/[0.04]">
                  {inline(r[ci] || "", `td${ri}-${ci}`)}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export function MarkdownRenderer({ content, compact = false }: { content: string; compact?: boolean }) {
  const segments: Array<{ type: "code"; language: string; code: string } | { type: "prose"; text: string }> = [];
  const fence = /```([a-zA-Z0-9_+#-]*)[^\n]*\n([\s\S]*?)(?:```|$)/g;
  let last = 0;
  let m: RegExpExecArray | null;
  while ((m = fence.exec(content)) !== null) {
    if (m.index > last) segments.push({ type: "prose", text: content.slice(last, m.index) });
    segments.push({ type: "code", language: m[1] || "code", code: m[2].replace(/\n$/, "") });
    last = fence.lastIndex;
  }
  if (last < content.length) segments.push({ type: "prose", text: content.slice(last) });

  const textSize = compact ? "text-[13.5px]" : "text-[14.5px]";

  return (
    <div className={`${textSize} leading-[1.7] text-zinc-300 break-words`}>
      {segments.map((seg, si) => {
        if (seg.type === "code") return <CodeBlock key={si} language={seg.language} code={seg.code} />;

        const lines = seg.text.split("\n");
        const nodes: React.ReactNode[] = [];
        let i = 0;
        while (i < lines.length) {
          const raw = lines[i];
          const line = raw.trim();

          if (!line) {
            i++;
            continue;
          }

          // Tables
          if (line.startsWith("|") && i + 1 < lines.length && /^\s*\|?\s*:?-{2,}/.test(lines[i + 1])) {
            const rows: string[] = [];
            while (i < lines.length && lines[i].trim().startsWith("|")) {
              rows.push(lines[i]);
              i++;
            }
            nodes.push(<Table key={`t${si}-${i}`} rows={rows} />);
            continue;
          }

          if (/^-{3,}$|^\*{3,}$/.test(line)) {
            nodes.push(<hr key={`hr${si}-${i}`} className="my-4 border-white/[0.08]" />);
            i++;
            continue;
          }

          const img = line.match(/^!\[([^\]]*)\]\(([^)]+)\)$/);
          if (img) {
            nodes.push(
              // eslint-disable-next-line @next/next/no-img-element
              <img key={`img${si}-${i}`} src={img[2]} alt={img[1]} className="my-3 rounded-xl border border-white/[0.08] max-w-full" />
            );
            i++;
            continue;
          }

          if (line.startsWith("### ")) {
            nodes.push(
              <h3 key={`h3${si}-${i}`} className="mt-5 mb-2 text-[15px] font-semibold text-zinc-100 font-[family-name:var(--font-jakarta)]">
                {inline(line.slice(4))}
              </h3>
            );
            i++;
            continue;
          }
          if (line.startsWith("## ")) {
            nodes.push(
              <h2 key={`h2${si}-${i}`} className="mt-5 mb-2 text-[16px] font-semibold text-zinc-100 font-[family-name:var(--font-jakarta)]">
                {inline(line.slice(3))}
              </h2>
            );
            i++;
            continue;
          }
          if (line.startsWith("# ")) {
            nodes.push(
              <h1 key={`h1${si}-${i}`} className="mt-5 mb-2 text-[17px] font-bold text-zinc-50 font-[family-name:var(--font-jakarta)]">
                {inline(line.slice(2))}
              </h1>
            );
            i++;
            continue;
          }

          if (line.startsWith("> ")) {
            const quote: string[] = [];
            while (i < lines.length && lines[i].trim().startsWith(">")) {
              quote.push(lines[i].trim().replace(/^>\s?/, ""));
              i++;
            }
            nodes.push(
              <blockquote key={`q${si}-${i}`} className="my-2 pl-3 border-l border-white/[0.14] text-zinc-400">
                {quote.map((q, qi) => (
                  <p key={qi}>{inline(q, `q${qi}`)}</p>
                ))}
              </blockquote>
            );
            continue;
          }

          const bullet = raw.match(/^(\s*)[-*•]\s+(.*)/);
          if (bullet) {
            const depth = Math.min(3, Math.floor(bullet[1].replace(/\t/g, "  ").length / 2));
            nodes.push(
              <div key={`b${si}-${i}`} className="flex items-start gap-2.5 my-1" style={{ paddingLeft: depth * 14 }}>
                <span className={`mt-[9px] w-1 h-1 rounded-full shrink-0 ${depth === 0 ? "bg-zinc-300" : "bg-zinc-600"}`} />
                <div className="flex-1 min-w-0">{inline(bullet[2])}</div>
              </div>
            );
            i++;
            continue;
          }

          const numbered = raw.match(/^(\s*)(\d+)[.)]\s+(.*)/);
          if (numbered) {
            const depth = Math.min(3, Math.floor(numbered[1].replace(/\t/g, "  ").length / 2));
            nodes.push(
              <div key={`n${si}-${i}`} className="flex items-start gap-2.5 my-1" style={{ paddingLeft: depth * 14 }}>
                <span className="mt-[3px] min-w-[20px] h-5 px-1 rounded-md bg-[#161618] border border-white/[0.08] font-mono text-[10px] font-medium text-zinc-400 grid place-items-center shrink-0">
                  {numbered[2]}
                </span>
                <div className="flex-1 min-w-0">{inline(numbered[3])}</div>
              </div>
            );
            i++;
            continue;
          }

          // Paragraph: merge consecutive plain lines
          const para: string[] = [line];
          i++;
          while (
            i < lines.length &&
            lines[i].trim() &&
            !/^(#{1,3} |> |[-*•] |\d+[.)] |\||!\[|-{3,}$)/.test(lines[i].trim()) &&
            !/^\s+[-*•]\s|^\s+\d+[.)]\s/.test(lines[i])
          ) {
            para.push(lines[i].trim());
            i++;
          }
          nodes.push(
            <p key={`p${si}-${i}`} className="my-1.5">
              {inline(para.join(" "))}
            </p>
          );
        }
        return <React.Fragment key={si}>{nodes}</React.Fragment>;
      })}
    </div>
  );
}

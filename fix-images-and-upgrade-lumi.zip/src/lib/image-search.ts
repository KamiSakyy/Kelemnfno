// ─────────────────────────────────────────────────────────────────────────────
// LUMI ART ENGINE 2.0
// Рабочий поиск картинок/артов. Источники (все бесплатные, без ключей):
//  • Danbooru / Safebooru  — аниме-арты и персонажи (фан-арты)
//  • Konachan / Yande.re   — обои и арты
//  • Wikimedia Commons     — реальные фото
//  • Openverse             — реальные фото (fallback)
//  • DuckDuckGo Images     — последний запасной вариант
//  • waifu.pics            — гарантированный fallback для аниме-артов
//
// ГЛАВНОЕ: каждая картинка проверяется реальным запросом к серверу картинки —
// битые ссылки (403/404/не image/*) выбрасываются ДО показа пользователю.
// ─────────────────────────────────────────────────────────────────────────────

const UA = "LumiChat/2.0 (lumi; anime-art-search) Mozilla/5.0";

export interface ImageResult {
  image: string;
  thumbnail: string;
  title: string;
  source: string;
}

const IMAGE_EXT_BAD = /\.(zip|webm|mp4|swf|gif)$/i;

// ── Валидация ссылок на картинки (убивает «битые изображения») ───────────────
async function isImageAlive(url: string): Promise<boolean> {
  try {
    const res = await fetch(url, {
      headers: { "User-Agent": UA, Range: "bytes=0-255", Referer: "https://duckduckgo.com/" },
      redirect: "follow",
      signal: AbortSignal.timeout(6500),
    });
    const type = (res.headers.get("content-type") || "").toLowerCase();
    try {
      await res.body?.cancel();
    } catch {
      /* ignore */
    }
    return (res.ok || res.status === 206) && (type.startsWith("image/") || type === "");
  } catch {
    return false;
  }
}

async function validatePick(cands: ImageResult[], limit: number): Promise<ImageResult[]> {
  // Параллельная проверка: берём максимум limit*2 кандидатов, оставляем живые.
    const slice = cands.slice(0, Math.max(limit * 2, limit + 4));
  const checks = await Promise.all(
    slice.map(async (c) => ((await isImageAlive(c.image)) ? c : null))
  );
  const alive = checks.filter(Boolean) as ImageResult[];
  return alive.slice(0, limit);
}

// ── Источник: Danbooru ───────────────────────────────────────────────────────
async function fromDanbooru(tag: string, limit: number, page = 0): Promise<ImageResult[]> {
  try {
    const q = `${tag} rating:s`;
    const res = await fetch(
      `https://danbooru.donmai.us/posts.json?tags=${encodeURIComponent(q)}&limit=${Math.min(limit + 6, 30)}${page > 0 ? `&page=${page}` : ""}`,
      { headers: { "User-Agent": UA }, signal: AbortSignal.timeout(9000) }
    );
    if (!res.ok) return [];
    const data = (await res.json()) as Array<Record<string, unknown>>;
    if (!Array.isArray(data)) return [];
    return data
      .filter((p) => typeof p.file_url === "string" && !IMAGE_EXT_BAD.test(String(p.file_url)))
      .map((p) => {
        const chars = String(p.tag_string_character || "")
          .replace(/_/g, " ")
          .replace(/\s*\([^)]*\)/g, "")
          .trim();
        const artist = String(p.tag_string_artist || "unknown").replace(/_/g, " ");
        return {
          image: String(p.file_url),
          thumbnail: String(p.large_file_url || p.preview_file_url || p.file_url),
          title: chars ? `${chars} — арт от ${artist}` : `Арт от ${artist}`,
          source: `https://danbooru.donmai.us/posts/${p.id}`,
        };
      });
  } catch {
    return [];
  }
}

// ── Источник: Safebooru ──────────────────────────────────────────────────────
async function fromSafebooru(tag: string, limit: number, page = 0): Promise<ImageResult[]> {
  try {
    const res = await fetch(
      `https://safebooru.org/index.php?page=dapi&s=post&q=index&json=1&limit=${Math.min(limit + 6, 40)}&pid=${page}&tags=${encodeURIComponent(tag)}`,
      { headers: { "User-Agent": UA }, signal: AbortSignal.timeout(9000) }
    );
    if (!res.ok) return [];
    const data = (await res.json()) as Array<Record<string, unknown>>;
    if (!Array.isArray(data)) return [];
    return data
      .filter((p) => p.directory && p.image && !IMAGE_EXT_BAD.test(String(p.image)))
      .map((p) => ({
        image: `https://safebooru.org/images/${p.directory}/${encodeURIComponent(String(p.image))}`,
        thumbnail: `https://safebooru.org/images/${p.directory}/${encodeURIComponent(String(p.image))}`,
        title: "Арт (Safebooru)",
        source: `https://safebooru.org/index.php?page=post&s=view&id=${p.id}`,
      }));
  } catch {
    return [];
  }
}

// ── Источники: Konachan / Yande.re ───────────────────────────────────────────
async function fromBooruStyle(base: string, postPath: string, tag: string, limit: number, page = 0): Promise<ImageResult[]> {
  try {
    const res = await fetch(
      `${base}/post.json?tags=${encodeURIComponent(`${tag} rating:safe`)}&limit=${Math.min(limit + 6, 40)}&page=${page + 1}`,
      { headers: { "User-Agent": UA }, signal: AbortSignal.timeout(9000) }
    );
    if (!res.ok) return [];
    const data = (await res.json()) as Array<Record<string, unknown>>;
    if (!Array.isArray(data)) return [];
    return data
      .filter((p) => typeof p.file_url === "string" && !IMAGE_EXT_BAD.test(String(p.file_url)))
      .map((p) => ({
        image: String(p.sample_url && !IMAGE_EXT_BAD.test(String(p.sample_url)) ? p.sample_url : p.file_url),
        thumbnail: String(p.preview_url || p.sample_url || p.file_url),
        title: `Арт (${base.replace("https://", "").split(".")[0]})`,
        source: `${base}/post/${postPath}/${p.id}`,
      }));
  } catch {
    return [];
  }
}

// ── Источник: Wikimedia Commons (реальные фото) ──────────────────────────────
async function fromWikimedia(query: string, limit: number): Promise<ImageResult[]> {
  try {
    const url =
      `https://commons.wikimedia.org/w/api.php?action=query&format=json&origin=*&prop=imageinfo` +
      `&iiprop=url|mime&iiurlwidth=700&generator=search&gsrnamespace=6` +
      `&gsrsearch=${encodeURIComponent(`filetype:bitmap ${query}`)}&gsrlimit=${Math.min(limit + 6, 30)}`;
    const res = await fetch(url, { headers: { "User-Agent": UA }, signal: AbortSignal.timeout(9000) });
    if (!res.ok) return [];
    const data = await res.json();
    const pages = Object.values((data.query?.pages || {}) as Record<string, Record<string, unknown>>);
    return pages
      .map((p) => {
        const info = (p.imageinfo as Array<Record<string, unknown>> | undefined)?.[0];
        if (!info) return null;
        const mime = String(info.mime || "");
        if (!/^image\/(jpeg|png|webp|svg)/.test(mime)) return null;
        return {
          image: String(info.url),
          thumbnail: String(info.thumburl || info.url),
          title: String(p.title || "").replace(/^File:/, "").replace(/\.\w{2,4}$/, ""),
          source: String(info.descriptionurl || info.url),
        } as ImageResult;
      })
      .filter(Boolean) as ImageResult[];
  } catch {
    return [];
  }
}

// ── Источник: Openverse (реальные фото, CC) ──────────────────────────────────
async function fromOpenverse(query: string, limit: number): Promise<ImageResult[]> {
  try {
    const res = await fetch(
      `https://api.openverse.org/v1/images/?q=${encodeURIComponent(query)}&page_size=${Math.min(limit + 6, 20)}&license_type=all-cc`,
      { headers: { "User-Agent": UA }, signal: AbortSignal.timeout(9000) }
    );
    if (!res.ok) return [];
    const data = await res.json();
    const list = (data.results || []) as Array<Record<string, unknown>>;
    return list
      .filter((r) => r.url && String(r.url).startsWith("http"))
      .map((r) => ({
        image: String(r.url),
        thumbnail: String(r.thumbnail || r.url),
        title: String(r.title || "Фото").slice(0, 90),
        source: String(r.foreign_landing_url || r.url),
      }));
  } catch {
    return [];
  }
}

// ── Источник: DuckDuckGo Images (последний запасной) ────────────────────────
async function fromDDG(query: string, limit: number, safe: boolean): Promise<ImageResult[]> {
  try {
    const tokenRes = await fetch(`https://duckduckgo.com/?q=${encodeURIComponent(query)}&iax=images&ia=images`, {
      headers: { "User-Agent": UA },
      signal: AbortSignal.timeout(9000),
    });
    const html = await tokenRes.text();
    const vqd = html.match(/vqd=["']?([\d-]+)["']?/)?.[1] || html.match(/vqd=([\d-]+)&/)?.[1];
    if (!vqd) return [];
    const res = await fetch(
      `https://duckduckgo.com/i.js?l=us-en&o=json&q=${encodeURIComponent(query)}&vqd=${vqd}&f=,,,&p=${safe ? "1" : "-2"}`,
      { headers: { "User-Agent": UA, Referer: "https://duckduckgo.com/" }, signal: AbortSignal.timeout(9000) }
    );
    if (!res.ok) return [];
    const data = await res.json();
    const results = (data.results || []) as Array<Record<string, unknown>>;
    return results
      .filter((r) => r.image && String(r.image).startsWith("http") && !IMAGE_EXT_BAD.test(String(r.image)))
      .slice(0, limit + 6)
      .map((r) => ({
        image: String(r.image),
        thumbnail: String(r.thumbnail || r.image),
        title: String(r.title || "").slice(0, 90),
        source: String(r.url || r.source || ""),
      }));
  } catch {
    return [];
  }
}

// ── Гарантированный fallback: популярные аниме-арты Safebooru ────────────────
async function fromGenericAnimeArts(limit: number): Promise<ImageResult[]> {
  const page = Math.floor(Math.random() * 40);
  return fromSafebooru("1girl solo score:>=30", limit + 4, page);
}

// ── NSFW-источники (только по ЯВНОМУ запросу 18+): Danbooru rating:e/q, Konachan.com ──
async function fromDanbooruNsfw(tag: string, limit: number, page = 0): Promise<ImageResult[]> {
  const out: ImageResult[] = [];
  for (const rating of ["rating:e", "rating:q"]) {
    try {
      const res = await fetch(
        `https://danbooru.donmai.us/posts.json?tags=${encodeURIComponent(`${tag} ${rating}`)}&limit=${Math.min(limit + 6, 30)}${page > 0 ? `&page=${page}` : ""}`,
        { headers: { "User-Agent": UA }, signal: AbortSignal.timeout(9000) }
      );
      if (!res.ok) continue;
      const data = (await res.json()) as Array<Record<string, unknown>>;
      for (const p of Array.isArray(data) ? data : []) {
        if (typeof p.file_url !== "string" || IMAGE_EXT_BAD.test(String(p.file_url))) continue;
        const chars = String(p.tag_string_character || "").replace(/_/g, " ").replace(/\s*\([^)]*\)/g, "").trim();
        const artist = String(p.tag_string_artist || "unknown").replace(/_/g, " ");
        out.push({
          image: String(p.file_url),
          thumbnail: String(p.large_file_url || p.preview_file_url || p.file_url),
          title: chars ? `${chars} — арт 18+ от ${artist}` : `Арт 18+ от ${artist}`,
          source: `https://danbooru.donmai.us/posts/${p.id}`,
        });
      }
      if (out.length >= Math.min(4, limit)) break;
    } catch {
      /* next rating */
    }
  }
  return out;
}

async function fromKonachanNsfw(tag: string, limit: number, page = 0): Promise<ImageResult[]> {
  const out: ImageResult[] = [];
  for (const rating of ["rating:explicit", "rating:questionable"]) {
    try {
      const res = await fetch(
        `https://konachan.com/post.json?tags=${encodeURIComponent(`${tag} ${rating}`)}&limit=${Math.min(limit + 6, 40)}&page=${page + 1}`,
        { headers: { "User-Agent": UA }, signal: AbortSignal.timeout(9000) }
      );
      if (!res.ok) continue;
      const data = (await res.json()) as Array<Record<string, unknown>>;
      for (const p of Array.isArray(data) ? data : []) {
        if (typeof p.file_url !== "string" || IMAGE_EXT_BAD.test(String(p.file_url))) continue;
        out.push({
          image: String(p.sample_url && !IMAGE_EXT_BAD.test(String(p.sample_url)) ? p.sample_url : p.file_url),
          thumbnail: String(p.preview_url || p.sample_url || p.file_url),
          title: "Арт 18+ (Konachan)",
          source: `https://konachan.com/post/show/${p.id}`,
        });
      }
      if (out.length >= Math.min(4, limit)) break;
    } catch {
      /* next rating */
    }
  }
  return out;
}

// ── Романизация имени персонажа через Jikan (MyAnimeList) ────────────────────
const NAME_ALIASES: Record<string, string> = {
  "мику": "hatsune_miku", "хатсуне мику": "hatsune_miku", "miku": "hatsune_miku",
  "наруто": "uzumaki_naruto", "саске": "uchiha_sasuke", "микаса": "mikasa_ackerman",
  "эрен": "eren_yeager", "сайтама": "saitama", "гоку": "son_goku",
  "эмилия": "emilia_(re:zero)", "эмилия ре зеро": "emilia_(re:zero)", "эмилия ре:зеро": "emilia_(re:zero)",
  "emilia": "emilia_(re:zero)", "emilia re zero": "emilia_(re:zero)",
  "асуна": "yuuki_asuna", "асуна сао": "yuuki_asuna", "asuna": "yuuki_asuna",
  "2b": "yorha_no.2_type_b", "ту би": "yorha_no.2_type_b", "2b nier": "yorha_no.2_type_b",
  "нана осаки": "osaki_nana", "нана": "nana",
  "годжо": "gojou_satoru", "сатору годжо": "gojou_satoru", "леви": "levi_rivaille",
  "zero two": "zero_two_(darling_in_the_franxx)", "зеро два": "zero_two_(darling_in_the_franxx)",
};

export function stripNsfwTokens(q: string): string {
  return q
    .replace(/\b18\+\b|nsfw|хентай|hentai|ecchi|эччи|эротич\w*|эротик\w*|lewd|nude|ню\b|голая|голые|голого|топлес|без цензур\w*|для взрослых|для совершеннолетних/gi, " ")
    .replace(/\s{2,}/g, " ")
    .trim();
}

export async function romanizeCharacter(query: string): Promise<string[]> {
  const l = query.toLowerCase().trim();
  if (NAME_ALIASES[l]) return NAME_ALIASES[l] ? [NAME_ALIASES[l]] : [];
  // Латиница без кириллицы — используем как есть
  if (!/[а-яё]/i.test(l)) {
    const tag = l.replace(/\s+/g, "_");
    const words = l.split(/\s+/);
    const tags = [tag];
    if (words.length >= 2) tags.push(`${words[words.length - 1]}_${words[0]}`);
    return tags;
  }
  // Кириллица → Shikimori знает русские имена и отдаёт романизацию.
  // Пробуем варианты запроса: «асуна из интернета» → часть до «из», отброшенные хвосты.
    const variants: string[] = [];
  const headMatch = /^(.*?)\s+из\s+/i.exec(l);
  if (headMatch && headMatch[1].length >= 2) variants.push(headMatch[1].trim());
  const words = [...l.split(/\s+/)];
  while (words.length > 0) {
    const v = words.join(" ").trim();
    if (v.length >= 2 && !variants.includes(v)) variants.push(v);
    words.pop();
  }

  for (const variant of variants) {
    const tags = await shikimoriTags(variant);
    if (tags.length) return tags;
  }
  return [];
}

async function shikimoriTags(q: string): Promise<string[]> {
  try {
    const res = await fetch(`https://shikimori.io/api/characters/search?search=${encodeURIComponent(q)}`, {
      headers: { "User-Agent": UA },
      signal: AbortSignal.timeout(8000),
    });
    if (!res.ok) return [];
    const data = (await res.json()) as Array<Record<string, unknown>>;
    const first = data?.[0];
    if (!first?.name) return [];
    const words = String(first.name).toLowerCase().replace(/[“”"'()·.,]/g, "").split(/\s+/).filter(Boolean);
    const tags: string[] = [];
    if (words.length >= 2) {
      tags.push(`${words[words.length - 1]}_${words[0]}`); // family_first (danbooru-стиль)
      tags.push(`${words[0]}_${words[words.length - 1]}`); // given_first
    } else if (words.length === 1) {
      tags.push(words[0]);
    }
    return tags;
  } catch {
    return [];
  }
}

// ── ГЛАВНАЯ: поиск картинок (мульти-источник + валидация) ───────────────────
export interface ArtSearchOptions {
  limit?: number;
  safe?: boolean;
  page?: number;
  extraTags?: string[];
  exclude?: Set<string>; // уже показанные картинки — не повторяем их в «ещё»
}

// Короткий кэш: повторные одинаковые запросы мгновенные, источники не обижаем
const artCache = new Map<string, { at: number; data: ImageResult[] }>();
const CACHE_TTL = 10 * 60 * 1000;

function normKey(url: string) {
  return url.split("?")[0];
}

export async function searchImages(query: string, limit = 8, safe = true): Promise<ImageResult[]> {
  return searchArts(query, { limit, safe });
}

export async function searchArts(query: string, opts: ArtSearchOptions = {}): Promise<ImageResult[]> {
  const limit = opts.limit ?? 8;
  const page = opts.page ?? 0;
  const cacheKey = `${query}|${limit}|${opts.safe ?? true}|${page}|${(opts.extraTags || []).join(";")}`;

  const notExcluded = (list: ImageResult[]) =>
    opts.exclude?.size ? list.filter((r) => !opts.exclude!.has(normKey(r.image)) && !opts.exclude!.has(normKey(r.thumbnail))) : list;

  const cached = artCache.get(cacheKey);
  if (cached && Date.now() - cached.at < CACHE_TTL) {
    const fresh = notExcluded(cached.data);
    if (fresh.length) return fresh.slice(0, limit);
  }

  const remember = (list: ImageResult[]) => {
    artCache.set(cacheKey, { at: Date.now(), data: list });
    if (artCache.size > 60) {
      const first = artCache.keys().next().value;
      if (first) artCache.delete(first);
    }
    return notExcluded(list);
  };

  const isNsfw = opts.safe === false;
  const tagQuery = isNsfw ? stripNsfwTokens(query) : query;
  const tagCandidates = opts.extraTags?.length
    ? opts.extraTags
    : (NAME_ALIASES[tagQuery.toLowerCase().trim()]
        ? [NAME_ALIASES[tagQuery.toLowerCase().trim()]]
        : await romanizeCharacter(tagQuery));

  // 1) NSFW-ветка (только при ЯВНОМ запросе 18+): Danbooru rating:e/q + Konachan.com
  if (isNsfw && tagCandidates.length) {
    let results = await fromDanbooruNsfw(tagCandidates[0], limit, page);
    if (results.length < limit) {
      results = dedupe([...results, ...(await fromKonachanNsfw(tagCandidates[0], limit, page))]);
    }
    results = notExcluded(results);
    if (results.length) {
      const valid = await validatePick(results, limit);
      if (valid.length) return remember(valid).slice(0, limit);
    }
    // если с тегом пусто — пробуем второй порядок слов
    if (tagCandidates.length > 1) {
      let alt = await fromDanbooruNsfw(tagCandidates[1], limit, page);
      if (alt.length < limit) alt = dedupe([...alt, ...(await fromKonachanNsfw(tagCandidates[1], limit, page))]);
      alt = notExcluded(alt);
      if (alt.length) {
        const valid = await validatePick(alt, limit);
        if (valid.length) return remember(valid).slice(0, limit);
      }
    }
  }

  // 1) Аниме-источники (арт/персонаж) — если знаем бooru-тег
  if (!isNsfw && tagCandidates.length) {
    for (const tag of tagCandidates.slice(0, 2)) {
      let results = await fromDanbooru(tag, limit, page);
      if (results.length < limit) {
        const [konachan, yandere] = await Promise.all([
          fromBooruStyle("https://konachan.net", "show", tag, limit, page),
          fromBooruStyle("https://yande.re", "show", tag, limit, page),
        ]);
        if (results.length === 0) results = await fromSafebooru(tag, limit, page);
        results = dedupe([...results, ...konachan, ...yandere]);
      } else {
        results = dedupe(results);
      }
      results = notExcluded(results); // выкидываем уже показанные ДО валидации
      if (results.length >= Math.min(4, limit)) {
        const valid = await validatePick(results, limit);
        if (valid.length) return remember(valid).slice(0, limit);
      }
    }
  }

  // 2) Фото-источники (работают и с кириллицей)
    const [wiki, openverse, ddg] = await Promise.all([
    fromWikimedia(query, limit),
    fromOpenverse(query, limit),
    fromDDG(query, limit, opts.safe ?? true),
  ]);
  // «ещё»: перемешиваем кандидатов, чтобы валидация брала не тех же первых 8
  let merged = dedupe([...ddg, ...wiki, ...openverse]);
  merged = notExcluded(merged);
  if (page > 0) merged = merged.sort(() => Math.random() - 0.5);
  if (merged.length) {
    const valid = await validatePick(merged, limit);
    if (valid.length) return remember(valid).slice(0, limit);
  }

  // 3) Если пользователь просил аниме-арт, а источники молчат — топ-арты Safebooru
  if (/аним|арт|waifu|манга|тян/i.test(query)) {
    const generic = notExcluded(await fromGenericAnimeArts(limit));
    const valid = await validatePick(generic, limit);
    if (valid.length) return remember(valid).slice(0, limit);
  }

  // 4) Последний шанс — непроверенные (почти не бывает)
  return remember(merged.slice(0, Math.min(4, limit))).slice(0, limit);
}

function dedupe(list: ImageResult[]): ImageResult[] {
  const seen = new Set<string>();
  return list.filter((r) => {
    const key = r.image.split("?")[0];
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

// ── Детект «покажи/дай картинки» ─────────────────────────────────────────────
const IMG_TRIGGERS = [
  "фотки", "фото", "картинки", "картинку", "арт", "арты", "изображения", "пикчи",
  "покажи фото", "найди фото", "дай фото", "дай арт", "скинь фото", "скинь арт",
  "обои", "wallpaper", "images of", "photos of", "pictures of", "art of", "найди картинки",
  "фанарт", "фан-арт", "fanart",
];

export function detectImageSearch(prompt: string): { wants: boolean; query: string } {
  const l = prompt.toLowerCase();
  const wants = IMG_TRIGGERS.some((t) => l.includes(t)) && /(найд|дай|скинь|покаж|пришли|хочу|нужн|есть|глянь|кинь|show|find|want)/i.test(l);
  if (!wants) return { wants: false, query: "" };
  const stop = ["найди в интернете", "из интернета", "с интернета", "из сети", "в интернете", "в сети", "на ПК", "на телефон",
    "18+", "18 плюс", "nsfw", "хентай", "hentai", "эротические", "эротика", "эротичные", "эротичный", "эччи", "ecchi",
    "для взрослых", "для совершеннолетних", "без цензуры", "голые", "голая",
    "найди", "найти", "дай-ка", "дай", "скинь", "покажи", "пришли", "пожалуйста", "плиз",
    "интернет", "фотки", "фоток", "фотографии", "фотография", "фото", "картинки", "картинок", "картинку", "картина", "арты",
    "фанарт", "фан-арты", "фан-арт", "артов", "арт", "fanart", "изображения", "изображение", "пикчи", "пикч", "обои",
    "на рабочий стол", "на телефон", "нужны",
    "нужно", "хочу", "хочется", "срочно", "мне", "пару", "несколько", "show", "find", "images", "image", "photos", "photo",
    "pictures", "picture", "wallpaper", "глянь", "кинь", "по", "на тему", "с", "персонажа", "из аниме"];
  let q = " " + prompt.toLowerCase().replace(/[?!.,;:]+/g, " ") + " ";
  for (const w of stop) q = q.split(` ${w} `).join(" ");
  const query = q.replace(/\s+/g, " ").trim();
  return { wants: true, query: query || prompt };
}

// ── Детект «ещё / больше» (догрузить по прошлой теме) ────────────────────────
export function detectMoreImages(prompt: string): boolean {
  const l = prompt.toLowerCase().trim();
  return /^(ещ[её]|еще артов|больше|добавь|давай ещ[её]|а ещ[её]|покажи ещ[её]|скинь ещ[её]|more|another)[ !.,?]*$/.test(l)
    || /^(ещ[её]|больше)\s+(артов|картинок|фот(ок|о)|вариантов|пикч)/.test(l);
}

// ── Детект «нарисуй / сгенерируй арт» → Pollinations Flux ───────────────────
export function detectArtGeneration(prompt: string): { wants: boolean; prompt: string } {
  const l = prompt.toLowerCase();
  const m =
    /(нарису(?:й|й-ка|йте|ем)?|сгенерир(?:уй|уйте|уем)?|создай|сделай|придумай|замути)\s+(мне\s+)?((?:генеративн\w+\s+)?(?:аниме[-\s]?)?арт\w*|картинк\w+|изображени\w+|иллюстраци\w+|аватарк\w+)[,:\s-]+(.+)/i.exec(l)
    || /(нарису(?:й|й-ка|йте|ем)?)[,:\s-]+(.+)/i.exec(l);
  if (!m) return { wants: false, prompt: "" };
  const raw = (m[4] || m[2] || "").trim();
  if (raw.length < 2) return { wants: false, prompt: "" };
  return { wants: true, prompt: raw };
}

export function generatedArts(prompt: string, count = 4): ImageResult[] {
  const wantsRealistic = /(реалистичн|фотореал|photo|realistic)/i.test(prompt);
  const styled = wantsRealistic
    ? `${prompt}, ultra detailed, cinematic lighting, masterpiece`
    : `${prompt}, breathtaking anime artwork, vibrant colors, soft cinematic lighting, detailed, masterpiece, best quality`;

  // Студия обоев: «обои на телефон/рабочий стол» → настоящие форматы экрана
  const wantDesktop = /рабочий стол|desktop|на пк|компьютер|ноутбук/i.test(prompt);
  const wantPhone = /телефон|phone|mobile/i.test(prompt);
  const isWallpaper = wantDesktop || wantPhone || /обои|wallpaper/i.test(prompt);
  const sizeOf = (i: number): [number, number, string] => {
    if (!isWallpaper) return [1024, 1024, `вариант ${i + 1}`];
    if (wantDesktop && !wantPhone) return [1920, 1080, `обои на ПК · ${i + 1}`];
    if (wantPhone && !wantDesktop) return [1080, 1920, `обои на телефон · ${i + 1}`];
    return i % 2 === 0 ? [1920, 1080, `обои на ПК · ${i / 2 + 1}`] : [1080, 1920, `обои на телефон · ${Math.floor(i / 2) + 1}`];
  };

  const out: ImageResult[] = [];
  for (let i = 0; i < count; i++) {
    const seed = Math.floor(Math.random() * 900000) + 1000 + i * 7777;
    const [w, h, label] = sizeOf(i);
    const styled2 = isWallpaper ? `${styled}, wallpaper composition, full-bleed, no text` : styled;
    const url =
      `https://image.pollinations.ai/prompt/${encodeURIComponent(styled2)}` +
      `?width=${w}&height=${h}&seed=${seed}&model=flux&nologo=true&enhance=true`;
    out.push({
      image: url,
      thumbnail: url,
      title: `${prompt.charAt(0).toUpperCase() + prompt.slice(1)} · ${label}`,
      source: url,
    });
  }
  return out;
}

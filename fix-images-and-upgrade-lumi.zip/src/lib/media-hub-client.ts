"use client";

// Мульти-источник аниме (запросы из БРАУЗЕРА пользователя):
//   • Kodik (публичный токен из скрипта плеера) — до 720p, СОТНИ озвучек
//   • AnimeVost — авторская озвучка, mp4 до 720p
// Всё перехватывается нашим плеером (hls.js / nativный mp4 через наш прокси).

export interface DubSource {
  id: string;
  source: string;
  title: string;
  type: string;
  link: string;
  quality: string;
  year: number | null;
  poster: string | null;
}

export interface DubLinks {
  q: string;
  src: string;
  kind: "hls" | "mp4";
}

let _token: string | null = null;
async function kodikToken(): Promise<string | null> {
  if (_token) return _token;
  try {
    const cached = localStorage.getItem("lumi:kodik-token");
    if (cached) {
      _token = cached;
      return cached;
    }
    const { getPublicToken } = await import("kodikwrapper");
    const t = await getPublicToken();
    if (t) {
      _token = t;
      localStorage.setItem("lumi:kodik-token", t);
    }
    return t;
  } catch {
    return null;
  }
}

async function kwClient() {
  const token = await kodikToken();
  if (!token) return null;
  const { Client } = await import("kodikwrapper");
  return Client.fromToken(token);
}

// — Kodik: все озвучки/команды по названию тайтла —────────────────────────────
export async function searchKodikDubs(title: string, altTitle?: string): Promise<DubSource[]> {
  try {
    const client = await kwClient();
    if (!client) return [];
    const queries = ([title, altTitle].filter(Boolean) as string[]).slice(0, 2);
    const seen = new Set<string>();
    const out: DubSource[] = [];
    for (const q of queries) {
      const res = await client.search({ title: q, limit: 12 });
      const results = ((res.results || []) as unknown) as Array<Record<string, unknown>>;
      for (const m of results) {
        const t = m.translation as { title?: string; type?: string } | undefined;
        const dubTitle = String(t?.title || "Стандартная");
        const dubType = t?.type === "subtitles" ? "subtitles" : "voice";
        const key = `${dubTitle}|${dubType}`;
        if (seen.has(key) || out.length >= 8) continue;
        seen.add(key);
        out.push({
          id: `${key}|${String(m.id)}`,
          source: dubType === "subtitles" ? "Kodik · субтитры" : "Kodik",
          title: dubTitle,
          type: dubType,
          link: String(m.link || ""),
          quality: String(m.quality || ""),
          year: m.year ? Number(m.year) : null,
          poster: Array.isArray(m.screenshots) && m.screenshots[0] ? String(m.screenshots[0]) : null,
        });
      }
      if (out.length >= 8) break;
    }
    return out;
  } catch {
    return [];
  }
}

// — Kodik: прямые потоки по ссылке материала —───────────────────────────────
export async function getKodikLinks(link: string): Promise<DubLinks[]> {
  try {
    const { VideoLinks } = await import("kodikwrapper");
    const groups = (await VideoLinks.getLinks({ link })) as Record<string, Array<{ src: string; type?: string }>>;
    const out: DubLinks[] = [];
    const order = ["2160", "1440", "1080", "720", "576", "480", "360"];
    const qs = Object.keys(groups || {}).sort((a, b) => order.indexOf(a) - order.indexOf(b));
    for (const q of qs) {
      for (const item of groups[q] || []) {
        if (!item?.src) continue;
        const src = item.src.startsWith("//") ? `https:${item.src}` : item.src;
        const kind: DubLinks["kind"] = item.type?.includes("mpegURL") || /\.m3u8?(\?|$)/i.test(src) ? "hls" : (item.type?.includes("mp4") || /\.mp4(\?|$)/i.test(src) ? "mp4" : "hls");
        out.push({ q: `${q}p`, src, kind });
      }
    }
    return out;
  } catch {
    return [];
  }
}

// — AnimeVost (api.animevost.org/v1, без ключа) —─────────────────────────────
export interface VostEpisode {
  num: string;
  std: string | null; // 480p mp4
  hd: string | null;  // 720p mp4
}
export interface VostRelease {
  id: number;
  title: string;
  episodes: VostEpisode[];
}

function bump(u: string | null | undefined): string | null {
  if (!u) return null;
  if (u.startsWith("//")) return `https:${u}`;
  return u;
}

export async function searchAnimeVost(title: string, altTitle?: string): Promise<VostRelease[]> {
  const api = "https://api.animevost.org/v1";
  const queries = ([title, altTitle].filter(Boolean) as string[]).slice(0, 2);
  for (const q of queries) {
    try {
      const res = await fetch(`${api}/search`, {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: `name=${encodeURIComponent(q)}&page=1`,
        signal: AbortSignal.timeout(11000),
      });
      if (!res.ok) continue;
      const data = await res.json();
      const rawList = (data?.data || data?.state?.data || []) as Array<Record<string, unknown>>;
      const out: VostRelease[] = [];
      for (const rel of rawList.slice(0, 3)) {
        const id = Number(rel.id ?? rel.release_id ?? 0);
        if (!id) continue;
        const titleRU = String(rel.title || rel.rusDescription || "").split(" / ")[0] || title;
        let episodes: VostEpisode[] = [];
        try {
          const pl = await fetch(`${api}/getPlayer/${id}?episode=1`, { signal: AbortSignal.timeout(9000) });
          if (pl.ok) {
            const d = await pl.json();
            const eps = (d?.data || []) as Array<Record<string, unknown>>;
            episodes = eps.map((e) => ({
              num: String(e.episode ?? e["№"] ?? e.num ?? out.length + 1),
              std: bump((e.player as Record<string, unknown> | undefined)?.bq as string | undefined || (e.bq as string) || (e.std as string) || null),
              hd: bump((e.player as Record<string, unknown> | undefined)?.hd as string | undefined || (e.hd as string) || null),
            }));
          }
        } catch {
          /* no episodes */
        }
        if (!episodes.length) {
          // запасной: playlist/{id}
          try {
            const pl = await fetch(`${api}/playlist/${id}`, { signal: AbortSignal.timeout(9000) });
            if (pl.ok) {
              const d = await pl.json();
              const eps = (d?.data || []) as Array<Record<string, unknown>>;
              episodes = eps.map((e) => ({
                num: String(e.episode ?? e["№"] ?? e.num ?? episodes.length + 1),
                std: bump((e.player as Record<string, unknown> | undefined)?.bq as string | undefined || (e.bq as string) || null),
                hd: bump((e.player as Record<string, unknown> | undefined)?.hd as string | undefined || (e.hd as string) || null),
              }));
            }
          } catch {
            /* ignore */
          }
        }
        out.push({ id, title: titleRU, episodes });
      }
      if (out.length) return out;
    } catch {
      /* next query */
    }
  }
  return [];
}


// ─────────────────────────────────────────────────────────────────────────────
// YummyAnime (api.yani.tv, CORS-открытый swagger API 2026, 60 000+ аниме).
// Запросы делаем ИЗ БРАУЗЕРА: iframe-токены привязываются к IP ПОЛЬЗОВАТЕЛЯ,
// поэтому их плеер Alloha грузится у него идеально (как на yummyaini.me).
// ─────────────────────────────────────────────────────────────────────────────
export interface YumiClientItem {
  id: number;
  slug: string;
  title: string;
  original: string;
  year: number | null;
  season: number | null;
  poster: string;
  rating: number | null;
  episodesCount: number | null;
  type: string;
  description: string;
}
export interface YumiClientVideo {
  number: number;
  dubbing: string;
  player: string;
  duration: number | null;
  views: number | null;
  iframe: string;
}

const YUM = "https://api.yani.tv";

function yummyPic(p: unknown): string {
  if (!p || typeof p !== "object") return "";
  const o = p as Record<string, unknown>;
  const src = String(o.fullsize || o.big || o.preview || "");
  return src ? (src.startsWith("//") ? `https:${src}` : src) : "";
}

export async function yummySearchClient(title: string, altTitle?: string): Promise<YumiClientItem[]> {
  const qs = ([title, altTitle].filter(Boolean) as string[]).slice(0, 2);
  for (const q of qs) {
    try {
      const res = await fetch(`${YUM}/search?q=${encodeURIComponent(q)}`, { signal: AbortSignal.timeout(10000) });
      if (!res.ok) continue;
      const d = await res.json();
      const items = (d.response || []) as Array<Record<string, unknown>>;
      const out = items.slice(0, 8).map((a) => ({
        id: Number(a.anime_id),
        slug: String(a.anime_url || ""),
        title: String(a.title || ""),
        original: String(a.other_title || a.original || ""),
        year: a.year ? Number(a.year) : null,
        season: a.season != null ? Number(a.season) : null,
        poster: yummyPic(a.poster),
        rating: a.rating ? (Number((a.rating as Record<string, unknown>)?.average ?? 0) || null) : null,
        episodesCount: (a.episodes as Record<string, unknown> | undefined)?.count ? Number((a.episodes as Record<string, unknown>)?.count) : null,
        type: String((a.type as Record<string, unknown> | undefined)?.name || a.type || ""),
        description: String(a.description || "").replace(/<[^>]+>/g, "").slice(0, 600),
      }));
      if (out.length) return out;
    } catch {
      /* next */
    }
  }
  return [];
}

export async function yummyVideosClient(animeId: number): Promise<YumiClientVideo[]> {
  try {
    const res = await fetch(`${YUM}/anime/${animeId}/videos`, { signal: AbortSignal.timeout(11000) });
    if (!res.ok) return [];
    const d = await res.json();
    const items = (d.response || []) as Array<Record<string, unknown>>;
    return items
      .map((v) => ({
        number: Number(v.number ?? v.index ?? 0),
        dubbing: String((v.data as Record<string, unknown> | undefined)?.dubbing || "Озвучка"),
        player: String((v.data as Record<string, unknown> | undefined)?.player || "Плеер"),
        duration: v.duration ? Number(v.duration) : null,
        views: v.views ? Number(v.views) : null,
        iframe: String(v.iframe_url || ""),
      }))
      .filter((v) => v.number > 0 && v.iframe);
  } catch {
    return [];
  }
}

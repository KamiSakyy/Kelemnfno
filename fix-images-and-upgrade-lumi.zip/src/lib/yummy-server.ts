// YummyAnime (api.yani.tv, открытый API v1, swagger) — 60 000+ аниме.
// Серверный адаптер: поиск, профиль, серии по озвучкам.

const YUM = "https://api.yani.tv";
const UA = "LumiChat/2.0 (yumi-bridge)";

export interface YumiItem {
  id: number;
  slug: string;
  title: string;
  original: string;
  year: number | null;
  season: number | null;
  type: string;
  poster: string;
  rating: number | null;
  description: string;
  status: string;
  episodesCount: number | null;
  genres: string[];
  translateList: string[];
}

function pic(p: unknown): string {
  if (!p || typeof p !== "object") return "";
  const obj = p as Record<string, unknown>;
  const src = String(obj.fullsize || obj.big || obj.preview || "");
  return src ? (src.startsWith("//") ? `https:${src}` : src) : "";
}

export async function yummySearch(title: string, altTitle?: string): Promise<YumiItem[]> {
  const candidates = ([title, altTitle].filter(Boolean) as string[]).slice(0, 2);
  for (const q of candidates) {
    try {
      const res = await fetch(`${YUM}/search?q=${encodeURIComponent(q)}`, { headers: { "User-Agent": UA }, signal: AbortSignal.timeout(9000) });
      if (!res.ok) continue;
      const d = (await res.json()) as Record<string, unknown>;
      const items = (d.response || []) as Array<Record<string, unknown>>;
      const out = items.slice(0, 8).map((a) => ({
        id: Number(a.anime_id),
        slug: String(a.anime_url || ""),
        title: String(a.title || ""),
        original: String(a.other_title || a.original || ""),
        year: a.year ? Number(a.year) : null,
        season: a.season != null ? Number(a.season) : null,
        type: String((a.type as Record<string, unknown> | undefined)?.name || a.type || ""),
        poster: pic(a.poster),
        rating: a.rating ? Number((a.rating as Record<string, unknown>)?.average ?? (a.rating as Record<string, unknown>)?.kp_rating ?? 0) || null : null,
        description: String(a.description || "").replace(/<[^>]+>/g, "").slice(0, 600),
        status: String((a.anime_status as Record<string, unknown> | undefined)?.title || ""),
        episodesCount: (a.episodes as Record<string, unknown> | undefined)?.count ? Number((a.episodes as Record<string, unknown>)?.count) : null,
        genres: (Array.isArray(a.genres) ? a.genres : []).map((g: Record<string, unknown>) => String(g.russian || g.name || g.title || "")).filter(Boolean).slice(0, 5),
        translateList: (Array.isArray(a.translates) ? a.translates : []).map((t: Record<string, unknown>) => String(t.title || t.name || "")).filter(Boolean).slice(0, 10),
      }));
      if (out.length) return out;
    } catch {
      /* next alt */
    }
  }
  return [];
}

export interface YumiVideo {
  number: number;
  dubbing: string;
  player: string;
  duration: number | null;
  views: number | null;
  iframe: string;
}

export async function yummyVideos(animeId: number): Promise<YumiVideo[]> {
  try {
    const res = await fetch(`${YUM}/anime/${animeId}/videos`, { headers: { "User-Agent": UA }, signal: AbortSignal.timeout(10000) });
    if (!res.ok) return [];
    const d = (await res.json()) as Record<string, unknown>;
    const items = (d.response || []) as Array<Record<string, unknown>>;
    return items.map((v) => ({
      number: Number(v.number ?? v.index ?? 0),
      dubbing: String((v.data as Record<string, unknown> | undefined)?.dubbing || "Озвучка"),
      player: String((v.data as Record<string, unknown> | undefined)?.player || "Плеер"),
      duration: v.duration ? Number(v.duration) : null,
      views: v.views ? Number(v.views) : null,
      iframe: String(v.iframe_url || ""),
    })).filter((v) => v.number > 0 && v.iframe);
  } catch {
    return [];
  }
}

// ── Выбор правильного сезона — исправление «выбрал слизь 4, играет другое» ──
interface ScorableItem { russian?: string; name?: string; title?: string; year?: number | null; season?: number | null }

export function matchSeason<T extends ScorableItem>(cards: T[], card: { russian: string; name?: string; year?: number | null }): T | null {
  if (!cards.length) return null;
  const norm = (s: string) => s.toLowerCase().replace(/[«»"']/g, " ").replace(/\s+/g, " ").trim();
  const cn = norm(card.russian || card.name || "");
  const seasonMatch = cn.match(/\s(\d)(?:\s*(?:сезон|season|серия|сезона))?$/);
  const wantSeason = seasonMatch ? Number(seasonMatch[1]) : null;
  const wantYear = card.year ?? null;

  let best: T | null = null;
  let bestScore = -1;
  for (const c of cards) {
    const rn = norm((c as { russian?: string; name?: string; title?: string }).russian || (c as { name?: string }).name || (c as { title?: string }).title || "");
    let score = 0;
    if (rn === cn) score += 50;
    else if (cn && (rn.includes(cn) || cn.includes(rn))) score += 20;
    // общие слова
    const toks = cn.split(" ").filter((w) => w.length > 2);
    const overlap = toks.filter((w) => rn.includes(w)).length;
    score += overlap * 4;
    const cSeason = (c as { season?: number | null }).season ?? (rn.match(/\s(\d)(?:\s|$)/) ? Number(rn.match(/\s(\d)(?:\s|$)/)![1]) : null);
    if (wantSeason && cSeason === wantSeason) score += 60;
    else if (wantSeason && cSeason && cSeason !== wantSeason) score -= 40;
    if (wantYear && (c as { year?: number | null }).year && Math.abs(Number((c as { year?: number | null }).year) - wantYear) <= 1) score += 12;
    if (score > bestScore) {
      bestScore = score;
      best = c;
    }
  }
  return best;
}

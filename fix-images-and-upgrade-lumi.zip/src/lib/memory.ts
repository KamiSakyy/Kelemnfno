// Детекторы долгосрочной памяти и умных follow-ups Люми.

export type MemoryIntent =
  | { type: "remember"; fact: string }
  | { type: "forget"; target: string | "all" }
  | { type: "list" }
  | null;

export function detectMemoryIntent(prompt: string): MemoryIntent {
  const p = prompt.trim();
  let m = /^(?:люми,\s*)?запомни(?:т)?(?:-ка)?(?:,?\s*что)?[:\s]+(.{3,400})/i.exec(p);
  if (m) return { type: "remember", fact: m[1].trim().replace(/[.!?]+$/, "") };
  m = /^(?:люми,\s*)?забудь(?:те)?[:\s]+(всё|все|память|обо мне всё|обо мне)/i.exec(p);
  if (m) return { type: "forget", target: "all" };
  m = /^(?:люми,\s*)?забудь(?:те)?[:\s]+(.{3,150})/i.exec(p);
  if (m) return { type: "forget", target: m[1].trim().replace(/[.!?]+$/, "") };
  if (/^(?:люми,\s*)?(что ты (обо мне )?(помнишь|запомнила)|что скажешь о моей памяти|покажи память|моя память)\??$/i.test(p)) {
    return { type: "list" };
  }
  return null;
}

export function buildMemoryBlock(facts: string[]): string | null {
  if (!facts.length) return null;
  return [
    "ДОЛГОСРОЧНАЯ ПАМЯТЬ ЛЮМИ О ПОЛЬЗОВАТЕЛЕ (она реально помнит это между чатами!):",
    ...facts.slice(-25).map((f) => `• ${f}`),
    "Используй эти факты естественно, когда уместно (любимые тайтлы, стиль, имя, предпочтения). Не цитируй список дословно без запроса.",
  ].join("\n");
}

// ── Умные follow-ups: «где смотреть?», «похожие аниме» — тема из контекста ──
export function detectWatchFollowup(prompt: string): boolean {
  const l = prompt.trim().toLowerCase().replace(/[!?.\s]+$/, "");
  return (
    /^(где (?:можно )?(?:его|её|это|этот тайтл|аниме)? ?смотреть|как смотреть|посмотреть|дай смотреть|включай|го смотреть)$/.test(l) ||
    /^а (?:где )?(?:его|её|это) смотреть$/.test(l) ||
    /^(смотреть|го глянем)$/.test(l)
  );
}

export function detectSimilarFollowup(prompt: string): boolean {
  const l = prompt.trim().toLowerCase().replace(/[!?.\s]+$/, "");
  return /^похожее?( аниме| тайтл| тайтлы)?$/.test(l) || /^(дай|посоветуй|предложи|у) похожие?( аниме| тайтлы)?$/.test(l) || /^есть похожие?$/.test(l);
}

// Извлекаем последнюю «тему» из истории: первый тайтл персонажа, карточка аниме, тема артов
export interface TopicHint {
  animeTitle?: string | null;   // след «аниме-карточки»
  charFirstTitle?: string | null; // «первый тайтл» из карточки персонажа
  artTopic?: string | null;
}

export function topicFromHistory(messages: { role: string; content: string; animeData?: unknown }[]): TopicHint {
  const hint: TopicHint = {};
  for (let i = messages.length - 1; i >= 0; i--) {
    const m = messages[i];
    if (m.role !== "assistant") continue;
    const ad = m.animeData as { type?: string; items?: Array<{ russian?: string; name?: string }> } | null | undefined;
    if (!hint.animeTitle && ad?.type === "cards" && ad.items?.length) {
      hint.animeTitle = ad.items[0].russian || ad.items[0].name || null;
    }
    if (!hint.charFirstTitle) {
      const t = /Первый тайтл: "([^"]+)"/.exec(m.content || "");
      if (t) hint.charFirstTitle = t[1];
    }
    if (!hint.artTopic) {
      const t = /по теме "([^"]+)"/.exec(m.content || "");
      if (t) hint.artTopic = t[1];
    }
    if (hint.animeTitle && hint.charFirstTitle && hint.artTopic) break;
  }
  return hint;
}

"use client";

// MangaDex (api.mangadex.org — официальный открытый API, CORS: *, без ключей):
// полный каталог манги/манхвы/ранобэ/додзинси + читалка через их At-Home CDN.
const MDX = "https://api.mangadex.org";
const IMG_HOST = "https://uploads.mangadex.org";

const UA: Record<string, string> = { Accept: "application/json" };
const fetchMDX = async (path: string): Promise<Record<string, unknown>> => {
  const res = await fetch(`${MDX}${path}`, { headers: UA, signal: AbortSignal.timeout(12000) });
  if (!res.ok) throw new Error(`mangadex ${res.status}`);
  return res.json();
};

// — Типы —────────────────────────────────────────────────────────────────────
export interface MangaTile {
  id: string;
  title: string;
  altTitles: string[];
  romance: string;
  year: number | null;
  status: string; // ongoing/completed/hiatus/cancelled
  rating: string; // текстовое age rating (safe/suggestive/erotica)
  poster: string; // URL обложки (uploads.mangadex.org)
  description: string;
  tags: string[]; // имена тегов-вансы RU-маркировкой
  score: number | null;
  follows: number | null;
  latestChapterNo: string | null; // номер последней сканов-главы (нашей выкладки)
}

export interface MangaDetails extends MangaTile {
  altNamesEn: string[];
  altNamesJp: string[];
  author: string;
  artist: string;
  chTotal: number | null;
  chLastDate: string | null;
  source: { russian: string; url: string }[];
}

export interface Chapter {
  id: string;
  number: string | null;
  title: string;
  pages: number;
  language: string;
  scanlator: string | null;
  date: string | null;
  externalUrl: string | null;
}

// Вспомогательные
const tstr = (t: unknown): string => {
  if (!t) return "";
  if (typeof t === "string") return t;
  if (Array.isArray(t)) return t[0] ? String(t[0]) : "";
  return (t as Record<string, unknown>).ru ? String((t as Record<string, unknown>).ru) : (t as Record<string, unknown>).en ? String((t as Record<string, unknown>).en) : String(Object.values(t)[0] ?? "");
};

const titleOf = (a: Record<string, unknown>, altList: Record<string, unknown>[]): string => {
  const ru = (altList || []).find((t) => t.ru);
  if (ru?.ru) return String(ru.ru);
  return tstr(a.title) || tstr(altList[0] as Record<string, unknown>);
};

const coverOf = (rel: Record<string, unknown>[], mId: string): string => {
  const c = rel.find((r) => r.type === "cover_art");
  const fn = (c?.attributes as Record<string, unknown> | undefined)?.fileName;
  return fn ? `${IMG_HOST}/covers/${mId}/${fn}.256.jpg` : `${IMG_HOST}/covers/${mId}/${fn}.512.jpg`.replace(".512.jpg.512.jpg", ".512.jpg");
};

const ORD_MAP = {
  latest: "latestUploadedChapter-desc",
  popular: "followedCount-desc",
  created: "createdAt-desc",
  rating: "rating-desc",
};

function mapManga(m: Record<string, unknown>, rels: Record<string, unknown>[]): MangaTile {
  const a = (m.attributes || {}) as Record<string, unknown>;
  const alt = (a.altTitles as Record<string, unknown>[]) || [];
  return {
    id: String(m.id),
    title: titleOf(a, alt),
    altTitles: alt.slice(0, 5).map((t) => tstr(t)).filter(String),
    romance: tstr(a.title) || "",
    year: a.year ? Number(a.year) : null,
    status: String(a.status || "—"),
    rating: String(a.contentRating || "safe"),
    poster: coverOf(rels, String(m.id)),
    description: tstr(a.description).slice(0, 500),
    tags: (((a.tags as Record<string, unknown>[]) || []).slice(0, 8)).map((t) => tstr((t.attributes as Record<string, unknown>)?.name)),
    score: null,
    follows: null,
    latestChapterNo: null,
  };
}

async function statOf(ids: string[]): Promise<Record<string, { rating: number; follows: number }>> {
  if (!ids.length) return {};
  try {
    const d = await fetchMDX(`/statistics/manga?${ids.map((i) => `manga[]=${i}`).join("&")}`);
    const s = (d.statistics || {}) as Record<string, Record<string, unknown>>;
    const out: Record<string, { rating: number; follows: number }> = {};
    for (const k of Object.keys(s)) {
      const r = (s[k].rating as Record<string, unknown> | undefined)?.average ?? (s[k].rating as Record<string, unknown> | undefined)?.average;
      const f = (s[k].follows as number) || 0;
      out[k] = { rating: r ? Math.round(Number(r) * 10) / 10 : 0, follows: Number(f) };
    }
    return out;
  } catch {
    return {};
  }
}

// — Каталог: поиск/броуз ────────────────────────────────────────────────────────
export async function browseMangaDex(params: {
  q?: string;
  genreIds?: string[];
  status?: string[]; // ongoing/completed...
  rating?: string[]; // safe/suggestive/erotica/pornographic
  yearFrom?: number | null;
  yearTo?: number | null;
  order?: keyof typeof ORD_MAP;
  page?: number;
  limit?: number;
}): Promise<{ items: MangaTile[]; total: number }> {
  const p: string[] = [];
  const lim = params.limit ?? 24;
  const page = params.page ?? 1;
  p.push(`limit=${lim}`);
  p.push(`offset=${(page - 1) * lim}`);
  p.push("includes[]=cover_art");
  if (params.q) p.push(`title=${encodeURIComponent(params.q)}`);
  for (const g of params.genreIds || []) p.push(`includedTags[]=${g}`);
  for (const s of params.status || []) p.push(`status[]=${s}`);
  for (const r of params.rating || []) p.push(`contentRating[]=${r}`);
  if (params.yearFrom) p.push(`year[]=${params.yearFrom}`);
  const orderKey = params.order || "latest";
  p.push(`order[$${""}${ORD_MAP[orderKey]?.split("-")[0] || ORD_MAP.latest.split("-")[0]}]=${ORD_MAP[orderKey]?.split("-")[1] || "desc"}`);
  const d = await fetchMDX(`/manga?${p.join("&")}`);
  const items = ((d.data || []) as Record<string, unknown>[]).map((m) => mapManga(m, (m.relationships || []) as Record<string, unknown>[]));
  const stats = await statOf(items.map((i) => i.id));
  for (const it of items) {
    const st = stats[it.id];
    if (st) {
      it.score = st.rating || null;
      it.follows = st.follows || null;
    }
  }
  return { items, total: Number(d.total || items.length) };
}

// — Полная карточка ────────────────────────────────────────────────────────────
export async function getMangaInfo(id: string): Promise<MangaDetails | null> {
  try {
    const d = await fetchMDX(`/manga/${id}?includes[]=cover_art&includes[]=author&includes[]=artist`);
    const m = d.data as Record<string, unknown>;
    const a = (m.attributes || {}) as Record<string, unknown>;
    const rels = ((m.relationships || []) as Record<string, unknown>[]);
    const base = mapManga(m, rels);
    const alt = (a.altTitles as Record<string, unknown>[]) || [];
    const author = rels.find((r) => r.type === "author");
    const artist = rels.find((r) => r.type === "artist");
    const stat = await statOf([id]);
    // последняя входящая глава числом
    let chTotal: number | null = null;
    let chLastDate: string | null = null;
    try {
      const agg = await fetchMDX(`/manga/${id}/aggregate?translatedLanguage[]=en&translatedLanguage[]=ru`);
      const vols = (agg.volumes || {}) as Record<string, Record<string, unknown>>;
      const chaps = (agg.chapters || {}) as Record<string, Record<string, unknown>> | Record<string, unknown>;
      const count = vols ? Object.keys(agg.chapters || {}).length : Object.keys(chaps as Record<string, unknown>).length;
      const dates = Object.values(((agg.chapters || {}) as Record<string, Record<string, unknown>>) || {}).map((c) => String(c.createdAt || "")).filter(Boolean).sort();
      if (count) chTotal = count;
      if (dates.length) chLastDate = dates[dates.length - 1].slice(0, 10);
    } catch {
      /* aggregate unavailable */
    }
    return {
      ...base,
      altNamesEn: alt.map((t) => tstr(t)).filter(String).slice(0, 4),
      altNamesJp: alt.map((t) => (t.ja ? String(t.ja) : "")).filter(String).slice(0, 3),
      author: tstr((author?.attributes as Record<string, unknown>)?.name as Record<string, unknown> | undefined) || String((author?.attributes as Record<string, unknown>)?.name || ""),
      artist: String((artist?.attributes as Record<string, unknown>)?.name || ""),
      chTotal,
      chLastDate,
      score: stat[id]?.rating || null,
      follows: stat[id]?.follows || null,
      source: [{
        russian: "Shikimori по названию",
        url: `https://shikimori.io/mangas?search=${encodeURIComponent(base.title.split(" ")[0])}`,
      }],
    };
  } catch {
    return null;
  }
}

// — Список глав ────────────────────────────────────────────────────────────────
export async function getMangaChapters(id: string): Promise<Chapter[]> {
  const out: Chapter[] = [];
  try {
    // берём английские+русские если есть; приоритет русским если есть дубликины номера
    const langs: string[][] = [["ru"], ["en"]];
    for (const langSet of langs) {
      const d = await fetchMDX(`/chapter?manga=${id}&${langSet.map((l) => `translatedLanguage[]=${l}`).join("&")}&order[chapter]=asc&limit=400&includes[]=scanlation_group`);
      const list = ((d.data || []) as Record<string, unknown>[]);
      for (const c of list) {
        const a = (c.attributes || {}) as Record<string, unknown>;
        const ref = ((c.relationships || []) as Record<string, unknown>[]).find((r) => r.type === "scanlation_group");
        out.push({
          id: String(c.id),
          number: a.chapter ? String(a.chapter) : null,
          title: String(a.title || ""),
          pages: Number(a.pages || 0),
          language: langSet[0],
          scanlator: String((ref?.attributes as Record<string, unknown>)?.name || "") || null,
          date: a.createdAt ? String(a.createdAt).slice(0, 10) : null,
          externalUrl: (a.externalUrl as string) || null,
        });
      }
      if (out.length) break; // есть — хватаем первый язык
    }
  } catch {
    /* ignore */
  }
  // дедуп по (number, language) — английский и русский имеют свои дубли номеров
  const seen = new Set<string>();
  return out.filter((c) => {
    const k = `${c.number}|${c.language}`;
    if (seen.has(k) || c.pages === 0) return false;
    seen.add(k);
    return true;
  }).sort((a, b) => (parseFloat(a.number || "0") || 0) - (parseFloat(b.number || "0") || 0));
}

// — Читалка ────────────────────────────────────────────────────────────────────
export interface ReaderInfo {
  baseUrl: string;
  hash: string;
  pages: string[];
  dataSaver: string[];
}

export async function getReaderData(chapterId: string): Promise<ReaderInfo | null> {
  try {
    const d = await fetchMDX(`/at-home/server/${chapterId}`);
    const base = String(d.baseUrl || "");
    const ch = (d.chapter || {}) as Record<string, unknown>;
    const hash = String(ch.hash || "");
    const data = (ch.data as string[]) || [];
    const dataSaver = (ch.dataSaver as string[]) || [];
    if (!base || !hash || !data.length) return null;
    return { baseUrl: base, hash, pages: data, dataSaver };
  } catch {
    return null;
  }
}

export function readerPageUrl(info: ReaderInfo, page: number, quality: "data" | "dataSaver" = "data"): string {
  const list = quality === "dataSaver" && info.dataSaver.length ? info.dataSaver : info.pages;
  const file = list[page - 1] || list[0];
  return info.baseUrl + `/${quality === "dataSaver" && info.dataSaver.length ? "data-saver" : "data"}/${info.hash}/${file}`;
}

// — Теги (жанры) MangaDex ─────────────────────────────────────────────────────
export interface MangaTag { id: string; name: string }
let _tags: MangaTag[] | null = null;
export async function getMangaTags(): Promise<MangaTag[]> {
  if (_tags) return _tags;
  try {
    const d = await fetchMDX(`/manga/tag`);
    const list = ((d.data || []) as Record<string, unknown>[]);
    _tags = list.map((t) => ({
      id: String(t.id),
      name: tstr((t.attributes as Record<string, unknown>)?.name as Record<string, unknown> | undefined),
    })).filter((t) => t.name).sort((a, b) => a.name.localeCompare(b.name));
    return _tags;
  } catch {
    return [];
  }
}

export const MANGA_STATS = ["ongoing", "completed", "hiatus", "cancelled"] as const;
export const MANGA_RATINGS = ["safe", "suggestive", "erotica", "pornographic"] as const;

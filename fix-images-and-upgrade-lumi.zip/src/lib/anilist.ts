"use client";

// AniList GraphQL (CORS-открыт, без ключей) — аниме-поиск, топ-подборки.
const ANILIST = "https://graphql.anilist.co";

export interface AL_Anime {
  id: number;
  romaji: string;
  english: string | null;
  native: string | null;
  year: number | null;
  episodes: number | null;
  cover: string;
  score: number | null;
  genres: string[];
}

async function gql(query: string, vars: Record<string, unknown> = {}) {
  const res = await fetch(ANILIST, {
    method: "POST",
    headers: { "Content-Type": "application/json", Accept: "application/json" },
    body: JSON.stringify({ query, variables: vars }),
    signal: AbortSignal.timeout(11000),
  });
  if (!res.ok) throw new Error("anilist err");
  return (await res.json()) as Record<string, unknown>;
}

const MAP = (m: Record<string, unknown>): AL_Anime => ({
  id: Number(m.id),
  romaji: String((m.title as Record<string, unknown>)?.romaji || ""),
  english: ((m.title as Record<string, unknown>)?.english as string) || null,
  native: ((m.title as Record<string, unknown>)?.native as string) || null,
  year: (m.startDate as Record<string, unknown>)?.year ? Number((m.startDate as Record<string, unknown>)?.year) : null,
  episodes: m.episodes ? Number(m.episodes) : null,
  cover: String((m.coverImage as Record<string, unknown>)?.extraLarge || (m.coverImage as Record<string, unknown>)?.large || ""),
  score: (m.averageScore as number) ? Number(m.averageScore) / 10 : null,
  genres: (Array.isArray(m.genres) ? m.genres : []).map(String).slice(0, 3),
});

const FIELDS = `id title { romaji english native } episodes startDate { year } coverImage { extraLarge large } averageScore genres`;

export async function searchAnimeList(q: string, limit = 8): Promise<AL_Anime[]> {
  const query = `query ($q: String, $l: Int) { Page(page: 1, perPage: $l) { media(type: ANIME, search: $q, sort: POPULARITY_DESC) { ${FIELDS} } } }`;
  try {
    const d = await gql(query, { q, l: limit });
    const list = (((d.data as Record<string, unknown>)?.Page as Record<string, unknown>)?.media || []) as Record<string, unknown>[];
    return list.map(MAP).filter((a) => a.romaji);
  } catch {
    return [];
  }
}

export interface AL_TopSection { title: string; items: AL_Anime[] }

export async function topSections(): Promise<AL_TopSection[]> {
  const q1 = `query { Page(page: 1, perPage: 10) { media(type: ANIME, sort: POPULARITY_DESC) { ${FIELDS} } } }`;
  const q2 = `query { Page(page: 1, perPage: 10) { media(type: ANIME, sort: SCORE_DESC) { ${FIELDS} } } }`;
  const q3 = `query { Page(page: 1, perPage: 10) { media(type: ANIME, sort: START_DATE_DESC, status_in: [RELEASING, FINISHED]) { ${FIELDS} } } }`;
  const out: AL_TopSection[] = [];
  try {
    const d1 = await gql(q1);
    out.push({ title: "Популярные", items: ((((d1.data as Record<string, unknown>)?.Page as Record<string, unknown>)?.media || []) as Record<string, unknown>[]).map(MAP).filter((a) => a.romaji) });
  } catch { /* skip */ }
  try {
    const d2 = await gql(q2);
    out.push({ title: "Лучшие рейтинги", items: ((((d2.data as Record<string, unknown>)?.Page as Record<string, unknown>)?.media || []) as Record<string, unknown>[]).map(MAP).filter((a) => a.romaji) });
  } catch { /* skip */ }
  try {
    const d3 = await gql(q3);
    out.push({ title: "Свежие (2024–2026)", items: ((((d3.data as Record<string, unknown>)?.Page as Record<string, unknown>)?.media || []) as Record<string, unknown>[]).map(MAP).filter((a) => a.romaji).slice(0, 10) });
  } catch { /* skip */ }
  return out;
}

// iTunes API (без ключей, CORS) — превью-аудио 30с с обложками.
export interface SongItem {
  id: string;
  title: string;
  artist: string;
  anime: string;
  cover: string;
  bigCover: string;
  preview: string;
  appleUrl: string;
  type: "OP" | "ED" | "OST" | "SONG";
  duration: number | null;
}

const bigArt = (url: string): string => {
  if (!url) return url;
  // iTunes-хитрость: меняем размер превью-обложки 100x100 → 600x600
  return url.replace(/100x100bb\.jpg$/, "600x600bb.jpg");
};

const CLASSIFY = (title: string, album: string): SongItem["type"] => {
  const s = `${title} ${album}`.toLowerCase();
  if (/(opening|опенинг|op\\b|op\\b|オープニング)/.test(s)) return "OP";
  if (/(ending|эндинг|ed\\b|ed\\b|エンディング)/.test(s)) return "ED";
  if (/(soundtrack|ost\\b|ost\\b|サウンドトラック|ost)/.test(s)) return "OST";
  return "SONG";
};

export async function searchSongsByAnime(anime: AL_Anime, extraTerms: string[] = []): Promise<SongItem[]> {
  const terms = [anime.english, anime.romaji, anime.native, ...extraTerms].filter(Boolean) as string[];
  const extra = terms.length > 1 ? ` ${anime.english ?? ""}` : "";
  const queryBase = anime.english || anime.romaji;
  let results: Record<string, unknown>[] = [];
  const trySearch = async (term: string, limit: number) => {
    try {
      const res = await fetch(`https://itunes.apple.com/search?term=${encodeURIComponent(term)}&media=music&limit=${limit}&country=JP`, { signal: AbortSignal.timeout(9000) });
      if (!res.ok) return [];
      const d = await res.json();
      return (d.results || []) as Record<string, unknown>[];
    } catch {
      return [];
    }
  };
  for (const q of [queryBase, (anime.english || anime.romaji) + " opening", anime.romaji + " soundtrack", anime.native || ""].filter(Boolean).slice(0, 3)) {
    results = results.concat(await trySearch(q, 20));
    if (results.length >= 20) break;
  }

  const seen = new Set<string>();
  const seenNormalized = new Set<string>();
  const out: SongItem[] = [];
  for (const r of results) {
    const trackId = String(r.trackId ?? "");
    const name = String(r.trackName || "");
    const nKey = `${String(r.artistName || "").toLowerCase()}|${name.toLowerCase()}|${String(r.collectionName || "").toLowerCase()}`;
    if (!trackId || seen.has(trackId) || seenNormalized.has(nKey)) continue;
    seen.add(trackId);
    seenNormalized.add(nKey);
    // Фильтруем не-аниме-музыку: японский вокал/topicедия музыка/саундтрек из JPN
    const album = String(r.collectionName || "");
    const type = CLASSIFY(name, album);
    const coverRaw = String(r.artworkUrl100 || "");
    out.push({
      id: `itunes-${trackId}`,
      title: name,
      artist: String(r.artistName || ""),
      anime: album.split("(")[0].split("「")[0].split("-")[0].trim() || queryBase,
      cover: coverRaw,
      bigCover: bigArt(coverRaw),
      preview: String(r.previewUrl || ""),
      appleUrl: String(r.trackViewUrl || r.collectionViewUrl || ""),
      type,
      duration: r.trackTimeMillis ? Math.round(Number(r.trackTimeMillis) / 1000) : r.previewUrl ? 30 : null,
    });
    if (out.length >= 40) break;
  }
  return out;
}

// ── Топ-подборки песен: топ-аниме → их OP/ED/OST ══════════════════════════════
export interface SongSection {
  anime: AL_Anime;
  songs: SongItem[];
}

export async function animeSongsOf(items: AL_Anime[], take = 3, songsEach = 6): Promise<SongSection[]> {
  const sections: SongSection[] = [];
  for (const anime of items.slice(0, take)) {
    const songs = await searchSongsByAnime(anime).then((arr) => arr.slice(0, songsEach));
    if (songs.length) sections.push({ anime, songs });
  }
  return sections;
}

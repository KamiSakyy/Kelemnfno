"use client";

// AniLibria calls run in the USER'S browser (their IP isn't blocked by
// AniLibria's Cloudflare, unlike our server). This gives real video streams.
    const ANILIB = "https://anilibria.top/api/v1";

export interface AniLibRelease {
  id: number;
  name: string;
  englishName: string;
  year: number;
  episodesTotal: number;
  poster: string;
}
export interface AniLibEpisode {
  ordinal: number;
  name: string | null;
  hls480: string | null;
  hls720: string | null;
  hls1080: string | null;
  raw480: string | null;
  raw720: string | null;
  raw1080: string | null;
  /** Любые дополнительные КАчестве, которые отдаёт AniLibria (360p, 2K/2160p и т.д.) */
  extras: { label: string; raw: string }[];
}

function poster(rel: Record<string, unknown>): string {
  const p = rel.poster as { src?: string; optimized?: { src?: string } } | undefined;
  const src = p?.optimized?.src || p?.src || "";
  return src ? (src.startsWith("http") ? src : `https://anilibria.top${src}`) : "";
}

export async function searchAniLibriaClient(query: string, limit = 6): Promise<AniLibRelease[]> {
  try {
    const res = await fetch(`${ANILIB}/app/search/releases?query=${encodeURIComponent(query)}&limit=${limit}`, {
      headers: { Accept: "application/json" },
      signal: AbortSignal.timeout(12000),
    });
    if (!res.ok) return [];
    const data = await res.json();
    const list = Array.isArray(data) ? data : data.data || [];
    return list.map((r: Record<string, unknown>) => {
      const name = r.name as Record<string, string> | undefined;
      return {
        id: Number(r.id),
        name: String(name?.main || ""),
        englishName: String(name?.english || ""),
        year: Number(r.year || 0),
        episodesTotal: Number(r.episodes_total || 0),
        poster: poster(r),
      };
    });
  } catch {
    return [];
  }
}

export async function getEpisodesClient(releaseId: number): Promise<{ release: AniLibRelease | null; episodes: AniLibEpisode[] }> {
  try {
    const res = await fetch(`${ANILIB}/anime/releases/${releaseId}`, {
      headers: { Accept: "application/json" },
      signal: AbortSignal.timeout(12000),
    });
    if (!res.ok) return { release: null, episodes: [] };
    const rel = await res.json();
    const name = rel.name as Record<string, string> | undefined;
    const release: AniLibRelease = {
      id: Number(rel.id),
      name: String(name?.main || ""),
      englishName: String(name?.english || ""),
      year: Number(rel.year || 0),
      episodesTotal: Number(rel.episodes_total || 0),
      poster: poster(rel),
    };
    // Route every HLS stream through our proxy → guaranteed CORS + no ad params.
    const prox = (u: unknown): string | null => {
      if (!u || typeof u !== "string") return null;
      return `/api/stream?u=${encodeURIComponent(u)}`;
    };
    const labelFor = (key: string) => {
      if (/2160|2k|4k|uhd/i.test(key)) return "2K";
      if (/1440/i.test(key)) return "1440p";
      if (/1080/i.test(key)) return "1080p";
      if (/720/i.test(key)) return "720p";
      if (/480/i.test(key)) return "480p";
      if (/360/i.test(key)) return "360p";
      if (/240/i.test(key)) return "240p";
      return key;
    };
    const episodes: AniLibEpisode[] = (rel.episodes || []).map((e: Record<string, unknown>) => {
      const extras: { label: string; raw: string }[] = [];
      const core = new Set(["hls_480", "hls_720", "hls_1080"]);
      for (const k of Object.keys(e)) {
        if (k.startsWith("hls_") && !core.has(k) && typeof e[k] === "string" && e[k]) {
          extras.push({ label: labelFor(k), raw: String(e[k]) });
        }
      }
      return {
        ordinal: Number(e.ordinal || 0),
        name: (e.name as string) || null,
        hls480: prox(e.hls_480),
        hls720: prox(e.hls_720),
        hls1080: prox(e.hls_1080),
        raw480: (e.hls_480 as string) || null,
        raw720: (e.hls_720 as string) || null,
        raw1080: (e.hls_1080 as string) || null,
        extras,
      };
    });
    return { release, episodes };
  } catch {
    return { release: null, episodes: [] };
  }
}

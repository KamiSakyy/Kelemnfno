"use client";

// Каталог AniLibria (запросы из браузера): жанры, выдача с фильтрами, торренты.
// Серверные запросы AniLibria блокирует — поэтому всё идёт клиентом.
    const ANILIB = "https://anilibria.top/api/v1";

export interface AniLibGenre {
  id: number;
  name: string;
}
export interface AniLibCatalogItem {
  id: number;
  russian: string;
  englishName: string;
  year: number;
  type: string; // TV / MOVIE и т.п.
  poster: string;
  episodesTotal: number | null;
  genres: AniLibGenre[];
  ageRating: string; // "16+" / "18+" и т.п.
  isAdult: boolean;
  isOngoing: boolean;
}

function posterUrl(rel: Record<string, unknown>): string {
  const p = rel.poster as { src?: string; optimized?: { src?: string; preview?: string } } | undefined;
  const src = p?.optimized?.src || p?.optimized?.preview || p?.src || "";
  return src ? (src.startsWith("http") ? src : `https://anilibria.top${src}`) : "";
}

function mapCatalog(r: Record<string, unknown>): AniLibCatalogItem {
  const name = r.name as Record<string, unknown> | undefined;
  const type = r.type as Record<string, unknown> | undefined;
  const age = r.age_rating as Record<string, unknown> | undefined;
  const genresRaw = (Array.isArray(r.genres) ? r.genres : []) as Array<Record<string, unknown>>;
  const tp = String(type?.value || "");
  return {
    id: Number(r.id),
    russian: String(name?.main || ""),
    englishName: String(name?.english || ""),
    year: Number(r.year || 0),
    type: tp === "TV" ? "Сериал" : tp === "MOVIE" ? "Фильм" : tp || "Сериал",
    poster: posterUrl(r),
    episodesTotal: r.episodes_total == null ? null : Number(r.episodes_total),
    genres: genresRaw.map((g) => ({ id: Number(g.id), name: String(g.name || "") })),
    ageRating: String(age?.label || ""),
    isAdult: Boolean(age?.is_adult) || String(age?.value || "").includes("18"),
    isOngoing: Boolean(r.is_ongoing) || String(r.status || "").toLowerCase() === "ongoing" || Boolean((r.status as Record<string, unknown> | undefined)?.value === "ongoing" || (r.status as Record<string, unknown> | undefined)?.code === "ONGOING"),
  };
}

export async function getGenresClient(): Promise<AniLibGenre[]> {
  try {
    const res = await fetch(`${ANILIB}/anime/genres`, { headers: { Accept: "application/json" }, signal: AbortSignal.timeout(10000) });
    if (!res.ok) return [];
    const data = await res.json();
    return (Array.isArray(data) ? data : [])
      .map((g: Record<string, unknown>) => ({ id: Number(g.id), name: String(g.name || "") }))
      .filter((g) => g.name);
  } catch {
    return [];
  }
}

export interface CatalogFetch {
  items: AniLibCatalogItem[];
  page: number;
  totalPages: number;
}

export async function getCatalogClient(page: number, limit = 21, query?: string): Promise<CatalogFetch> {
  try {
    // Поисковый запрос → РЕАЛЬНЫЙ эндпоинт поиска AniLibria (каталог query не понимает!)
    if (query) {
      const viaTitles = async (url: string) => {
        const res = await fetch(url, { headers: { Accept: "application/json" }, signal: AbortSignal.timeout(11000) });
        if (!res.ok) throw new Error(String(res.status));
        const data = await res.json();
        const list = (Array.isArray(data) ? data : data.data || []) as Array<Record<string, unknown>>;
        return list.map(mapCatalog).filter((i) => i.russian);
      };
      // 1) основной поиск приложения AniLibria
      try {
        const found = await viaTitles(`${ANILIB}/app/search/releases?query=${encodeURIComponent(query)}&limit=50`);
        if (found.length) return { items: found, page: 1, totalPages: 1 };
      } catch {
        // 2) запасной вариант через фильтр каталога (для браузеров, где /app/search заблокирован)
        try {
          const found = await viaTitles(`${ANILIB}/anime/catalog/releases?limit=40&f%5Bsearch%5D=${encodeURIComponent(query)}`);
          if (found.length) return { items: found, page: 1, totalPages: 1 };
        } catch {
          /* fallthrough to empty */
        }
      }
      return { items: [], page: 1, totalPages: 1 };
    }

    // Обычный каталог
    const params = new URLSearchParams({ limit: String(limit), page: String(page) });
    const res = await fetch(`${ANILIB}/anime/catalog/releases?${params.toString()}`, { headers: { Accept: "application/json" }, signal: AbortSignal.timeout(11000) });
    if (!res.ok) return { items: [], page, totalPages: page };
    const data = await res.json();
    const list = (Array.isArray(data) ? data : data.data || []) as Array<Record<string, unknown>>;
    const pag = data?.meta?.pagination as Record<string, unknown> | undefined;
    return {
      items: list.map(mapCatalog).filter((i) => i.russian),
      page,
      totalPages: Number(pag?.total_pages || page),
    };
  } catch {
    return { items: [], page, totalPages: page };
  }
}

export interface AniLibTorrent {
  label: string;
  magnet: string;
  quality: string;
  codec: string;
  sizeGb: number | null;
}

export async function getTorrentsClient(releaseId: number): Promise<AniLibTorrent[]> {
  try {
    const res = await fetch(`${ANILIB}/anime/torrents?release_id=${releaseId}&limit=20`, { headers: { Accept: "application/json" }, signal: AbortSignal.timeout(10000) });
    if (!res.ok) return [];
    const data = await res.json();
    const list = (data?.data || []) as Array<Record<string, unknown>>;
    return (Array.isArray(list) ? list : []).map((t) => ({
      label: String(t.label || t.title || "Все серии"),
      magnet: String(t.magnet || t.magnet_uri || ""),
      quality: String(t.quality || t.resolution || ""),
      codec: String(t.codec || t.video_codec || ""),
      sizeGb: t.total_size ? Math.round((Number(t.total_size) / 1_073_741_824) * 10) / 10 : t.size ? Number(t.size) : null,
    }));
  } catch {
    return [];
  }
}

// Безопасный показ сообщений Люми: прячем внутренние «мысли»-память,
// которые хранятся в БД для контекста ИИ, но не предназначены пользователю.
//
// Формат памяти в конце content: "[Я отправила пользователю ... ]" /
// "[Я сама нарисовала ...]" / "[Я нашла карточку ... ]" и т.п.
// Режем ТОЛЬКО хвостовой блок (обычный текст ссылок не трогаем).
export function stripAssistantMemory(content: string): string {
  if (!content) return content;
  return content
    .replace(/\n{1,4}\[(?:Я|Я,|Люми|Вот|Это служеб|Служебная)[\s\S]*\]\s*$/u, "")
    .trim();
}

export function sanitizeForDisplay<T extends { role: string; content: string }>(messages: T[]): T[] {
  return messages.map((m) =>
    m.role === "assistant" ? { ...m, content: stripAssistantMemory(m.content) } : m
  );
}

// Anime data (Shikimori) + streaming video (AniLibria) integration for Aya.
    const SHIKI = "https://shikimori.io/api";
export const ANILIB = "https://anilibria.top/api/v1";
const UA = "AETHER-Aya";

// ---------------------------------------------------------------------------
// Shikimori — anime info, ratings, dates, calendar
// ---------------------------------------------------------------------------

export interface AnimeCard {
  id: number;
  name: string;
  russian: string;
  image: string;
  score: number;
  episodes: number;
  episodesAired: number;
  status: string;
  kind: string;
  airedOn: string | null;
  releasedOn: string | null;
  url: string;
}

function shikiImage(anime: Record<string, unknown>): string {
  const img = anime.image as Record<string, string> | undefined;
  const path = img?.original || img?.preview || "";
  return path ? (path.startsWith("http") ? path : `https://shikimori.io${path}`) : "";
}

function mapAnime(a: Record<string, unknown>): AnimeCard {
  return {
    id: Number(a.id),
    name: String(a.name || ""),
    russian: String(a.russian || a.name || ""),
    image: shikiImage(a),
    score: Number(a.score || 0),
    episodes: Number(a.episodes || 0),
    episodesAired: Number(a.episodes_aired || 0),
    status: String(a.status || ""),
    kind: String(a.kind || ""),
    airedOn: (a.aired_on as string) || null,
    releasedOn: (a.released_on as string) || null,
    url: `https://shikimori.io${a.url || "/animes/" + a.id}`,
  };
}

export async function searchAnime(query: string, limit = 6): Promise<AnimeCard[]> {
  try {
    const res = await fetch(`${SHIKI}/animes?search=${encodeURIComponent(query)}&limit=${limit}&order=popularity`, {
      headers: { "User-Agent": UA },
      signal: AbortSignal.timeout(12000),
    });
    if (!res.ok) return [];
    const data = await res.json();
    return Array.isArray(data) ? data.map(mapAnime) : [];
  } catch {
    return [];
  }
}

export interface CatalogParams {
  order?: "popularity" | "ranked" | "aired_on";
  status?: "ongoing" | "released" | "anons";
  kind?: string;
  genre?: number;
  season?: string;
  page?: number;
  limit?: number;
  nsfw?: boolean; // показать без цензуры (хентай-жанры)
}

export async function browseAnime(params: CatalogParams = {}): Promise<AnimeCard[]> {
  const q = new URLSearchParams();
  q.set("limit", String(params.limit || 20));
  q.set("page", String(params.page || 1));
  q.set("order", params.order || "popularity");
  if (params.status) q.set("status", params.status);
  if (params.kind) q.set("kind", params.kind);
  if (params.genre) q.set("genre", String(params.genre));
  if (params.season) q.set("season", params.season);
  if (params.nsfw) q.set("is_censored", "false");
  try {
    const res = await fetch(`${SHIKI}/animes?${q.toString()}`, { headers: { "User-Agent": UA }, signal: AbortSignal.timeout(12000) });
    if (!res.ok) return [];
    const data = await res.json();
    return Array.isArray(data) ? data.map(mapAnime) : [];
  } catch {
    return [];
  }
}

export interface Genre {
  id: number;
  name: string;
  russian: string;
}

// Актуальные id жанров АНИМЕ (собраны из карточек Shikimori — /api/genres отдаёт
// смешанный список, поэтому свою карту держим статично). Хентай = 12, Этти = 9.
const ANIME_GENRES: { id: number; russian: string }[] = [
  { id: 1, russian: "Экшен" }, { id: 2, russian: "Приключения" }, { id: 4, russian: "Комедия" },
  { id: 5, russian: "Безумие" }, { id: 8, russian: "Драма" }, { id: 9, russian: "Этти" },
  { id: 10, russian: "Фэнтези" }, { id: 12, russian: "Хентай" }, { id: 13, russian: "Исторический" },
  { id: 14, russian: "Ужасы" }, { id: 15, russian: "Детское" }, { id: 18, russian: "Меха" },
  { id: 19, russian: "Музыка" }, { id: 22, russian: "Романтика" }, { id: 23, russian: "Школа" },
  { id: 24, russian: "Фантастика" }, { id: 25, russian: "Сёдзё" }, { id: 27, russian: "Сёнен" },
  { id: 30, russian: "Спорт" }, { id: 35, russian: "Гарем" }, { id: 37, russian: "Сверхъестественное" },
  { id: 38, russian: "Военное" }, { id: 39, russian: "Полиция" }, { id: 40, russian: "Психологическое" },
  { id: 41, russian: "Триллер" }, { id: 42, russian: "Сэйнэн" },
];

export async function getGenres(): Promise<Genre[]> {
  return ANIME_GENRES.map((g) => ({ id: g.id, name: g.russian, russian: g.russian }));
}

export interface AnimeDetails extends AnimeCard {
  description: string;
  genres: string[];
  studios: string[];
  rating: string;
  duration: number;
  nextEpisodeAt: string | null;
}

export async function getAnimeDetails(id: number): Promise<AnimeDetails | null> {
  try {
    const res = await fetch(`${SHIKI}/animes/${id}`, { headers: { "User-Agent": UA }, signal: AbortSignal.timeout(12000) });
    if (!res.ok) return null;
    const a = await res.json();
    return {
      ...mapAnime(a),
      description: String(a.description || "").replace(/\[[^\]]*\]/g, "").trim(),
      genres: (a.genres || []).map((g: Record<string, unknown>) => String(g.russian || g.name)),
      studios: (a.studios || []).map((s: Record<string, unknown>) => String(s.name)),
      rating: String(a.rating || ""),
      duration: Number(a.duration || 0),
      nextEpisodeAt: (a.next_episode_at as string) || null,
    };
  } catch {
    return null;
  }
}

// Calendar of upcoming/ongoing episodes
export interface CalendarEntry {
  animeId: number;
  name: string;
  russian: string;
  image: string;
  nextEpisode: number;
  nextEpisodeAt: string;
}

export async function getAnimeCalendar(limit = 12): Promise<CalendarEntry[]> {
  try {
    const res = await fetch(`${SHIKI}/calendar`, { headers: { "User-Agent": UA }, signal: AbortSignal.timeout(12000) });
    if (!res.ok) return [];
    const data = await res.json();
    return (Array.isArray(data) ? data : [])
      .slice(0, limit)
      .map((c: Record<string, unknown>) => {
        const a = (c.anime as Record<string, unknown>) || {};
        return {
          animeId: Number(a.id),
          name: String(a.name || ""),
          russian: String(a.russian || a.name || ""),
          image: shikiImage(a),
          nextEpisode: Number(c.next_episode || 0),
          nextEpisodeAt: String(c.next_episode_at || ""),
        };
      });
  } catch {
    return [];
  }
}

// ---------------------------------------------------------------------------
// AniLibria — streamable video (HLS)
// ---------------------------------------------------------------------------

export interface AniLibRelease {
  id: number;
  name: string;
  englishName: string;
  year: number;
  episodesTotal: number;
  poster: string;
}

export interface AniLibEpisode {
  ordinal: number;
  name: string | null;
  duration: number;
  hls480: string | null;
  hls720: string | null;
  hls1080: string | null;
}

function anilibPoster(rel: Record<string, unknown>): string {
  const p = rel.poster as { src?: string; optimized?: { src?: string } } | undefined;
  const src = p?.optimized?.src || p?.src || "";
  return src ? (src.startsWith("http") ? src : `https://anilibria.top${src}`) : "";
}

export async function searchAniLibria(query: string, limit = 5): Promise<AniLibRelease[]> {
  try {
    const res = await fetch(`${ANILIB}/app/search/releases?query=${encodeURIComponent(query)}&limit=${limit}`, {
      signal: AbortSignal.timeout(12000),
    });
    if (!res.ok) return [];
    const data = await res.json();
    const list = Array.isArray(data) ? data : data.data || [];
    return list.map((r: Record<string, unknown>) => {
      const name = r.name as Record<string, string> | undefined;
      return {
        id: Number(r.id),
        name: String(name?.main || ""),
        englishName: String(name?.english || ""),
        year: Number(r.year || 0),
        episodesTotal: Number(r.episodes_total || 0),
        poster: anilibPoster(r),
      };
    });
  } catch {
    return [];
  }
}

export async function getAniLibriaEpisodes(releaseId: number): Promise<{ release: AniLibRelease | null; episodes: AniLibEpisode[] }> {
  try {
    const res = await fetch(`${ANILIB}/anime/releases/${releaseId}`, { signal: AbortSignal.timeout(12000) });
    if (!res.ok) return { release: null, episodes: [] };
    const rel = await res.json();
    const name = rel.name as Record<string, string> | undefined;
    const release: AniLibRelease = {
      id: Number(rel.id),
      name: String(name?.main || ""),
      englishName: String(name?.english || ""),
      year: Number(rel.year || 0),
      episodesTotal: Number(rel.episodes_total || 0),
      poster: anilibPoster(rel),
    };
    const episodes: AniLibEpisode[] = (rel.episodes || []).map((e: Record<string, unknown>) => ({
      ordinal: Number(e.ordinal || 0),
      name: (e.name as string) || null,
      duration: Number(e.duration || 0),
      hls480: (e.hls_480 as string) || null,
      hls720: (e.hls_720 as string) || null,
      hls1080: (e.hls_1080 as string) || null,
    }));
    return { release, episodes };
  } catch {
    return { release: null, episodes: [] };
  }
}

// ---------------------------------------------------------------------------
// Intent detection — is the user asking about anime / to watch anime?
// ---------------------------------------------------------------------------

const WATCH_TRIGGERS = ["посмотреть", "смотреть", "видео", "серию", "серия", "эпизод", "включи", "покажи аниме", "хочу посмотреть", "дай посмотреть", "watch"];
const INFO_TRIGGERS = ["аниме", "anime", "манга", "рейтинг аниме", "когда выйдет", "сколько серий", "календарь аниме", "что за аниме"];

export function detectAnimeIntent(prompt: string): { wantsWatch: boolean; wantsInfo: boolean; wantsCalendar: boolean } {
  const l = prompt.toLowerCase();
  const wantsCalendar = /календар|расписани.*аниме|аниме.*расписани|что выходит|ongoing|онгоинг/.test(l);
  const wantsWatch = WATCH_TRIGGERS.some((t) => l.includes(t)) && /аниме|серию|серия|эпизод|видео/.test(l);
  const wantsInfo = INFO_TRIGGERS.some((t) => l.includes(t));
  return { wantsWatch, wantsInfo: wantsInfo || wantsWatch, wantsCalendar };
}

// Extract a clean anime title from a request like "покажи 2 серию наруто в 720"
export function extractAnimeQuery(prompt: string): { title: string; episode: number | null; quality: 480 | 720 | 1080 | null } {
  let t = prompt;
  const epMatch = t.match(/(\d{1,4})\s*(?:-?[ыяй]?\s*)?(?:сери|эпизод|episode|ep)/i);
  const episode = epMatch ? Number(epMatch[1]) : null;
  const qMatch = t.match(/(480|720|1080)/);
  const quality = qMatch ? (Number(qMatch[1]) as 480 | 720 | 1080) : null;
  t = t
    .replace(/\d{1,4}\s*(?:-?[ыяй]?\s*)?(?:сери\w*|эпизод\w*|episode|ep)/gi, "")
    .replace(/(480|720|1080)\s*(p|пикс\w*)?/gi, "")
    .replace(/\b(посмотреть|смотреть|видео|включи|покажи|хочу|дай|аниме|anime|в качестве|качество|озвучк\w*|серию|серия|эпизод|watch|найди|про)\b/gi, "")
    .replace(/\s+/g, " ")
    .trim();
  return { title: t, episode, quality };
}
